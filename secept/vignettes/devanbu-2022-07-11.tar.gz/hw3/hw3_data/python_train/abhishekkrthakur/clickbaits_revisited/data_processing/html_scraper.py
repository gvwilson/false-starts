

import	sys	
reload	(	sys	)	
sys	.	setdefaultencoding	(	"str"	)	

import	pandas	as	pd	
import	requests	
from	joblib	import	Parallel	,	delayed	
import	cPickle	
from	tqdm	import	tqdm	


def	html_extractor	(	url	)	:	
try	:	
cookies	=	dict	(	cookies_are	=	"str"	)	
r	=	requests	.	get	(	url	,	cookies	=	cookies	)	
return	r	.	text	
except	:	
return	"str"	


clickbaits	=	pd	.	read_csv	(	"str"	)	
non_clickbaits	=	pd	.	read_csv	(	"str"	)	

clickbait_urls	=	clickbaits	.	status_link	.	values	
non_clickbait_urls	=	non_clickbaits	.	status_link	.	values	


clickbait_html	=	Parallel	(	n_jobs	=	20	)	(	delayed	(	html_extractor	)	(	u	)	for	u	in	tqdm	(	clickbait_urls	)	)	
cPickle	.	dump	(	clickbait_html	,	open	(	"str"	,	"str"	)	,	-	1	)	

non_clickbait_html	=	Parallel	(	n_jobs	=	20	)	(	delayed	(	html_extractor	)	(	u	)	for	u	in	tqdm	(	non_clickbait_urls	)	)	
cPickle	.	dump	(	non_clickbait_html	,	open	(	"str"	,	"str"	)	,	-	1	)	
	