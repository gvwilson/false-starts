


import	pandas	as	pd	
from	sklearn	.	cross_validation	import	train_test_split	

internet_stop_words	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	]	


def	remove_internet_stop_words	(	x	)	:	
return	"str"	.	join	(	[	word	for	word	in	str	(	x	)	.	lower	(	)	.	split	(	)	if	word	not	in	internet_stop_words	]	)	


df	=	pd	.	read_csv	(	"str"	)	
df	=	df	.	drop_duplicates	(	)	

df	.	textdata	=	df	.	textdata	.	apply	(	lambda	x	:	str	(	x	)	.	replace	(	"str"	,	"str"	)	.	strip	(	)	)	

df	.	textdata	=	df	.	textdata	.	apply	(	remove_internet_stop_words	)	
df	.	link_name	=	df	.	link_name	.	apply	(	remove_internet_stop_words	)	

df	=	df	.	drop	(	[	"str"	,	"str"	]	,	axis	=	1	)	

train_df	,	test_df	=	train_test_split	(	df	,	stratify	=	df	.	label	.	values	,	random_state	=	42	,	test_size	=	0.1	)	

train_df	.	to_csv	(	"str"	,	index	=	False	,	encoding	=	"str"	)	
test_df	.	to_csv	(	"str"	,	index	=	False	,	encoding	=	"str"	)	
	