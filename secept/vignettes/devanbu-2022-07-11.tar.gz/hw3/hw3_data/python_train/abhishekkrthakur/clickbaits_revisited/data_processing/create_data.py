


import	pandas	as	pd	

buzzfeed	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

clickhole	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

cnn	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

nytimes	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

stopclickbait	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

upworthy	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

wikinews	=	pd	.	read_csv	(	"str"	,	
usecols	=	[	"str"	,	"str"	,	"str"	]	)	

wikinews	.	link_name	=	wikinews	.	link_name	.	apply	(	lambda	x	:	str	(	x	)	.	replace	(	"str"	,	"str"	)	)	
buzzfeed	=	buzzfeed	[	buzzfeed	.	status_type	==	"str"	]	
clickhole	=	clickhole	[	clickhole	.	status_type	==	"str"	]	
cnn	=	cnn	[	cnn	.	status_type	==	"str"	]	
nytimes	=	nytimes	[	nytimes	.	status_type	==	"str"	]	
stopclickbait	=	stopclickbait	[	stopclickbait	.	status_type	==	"str"	]	
upworthy	=	upworthy	[	upworthy	.	status_type	==	"str"	]	
wikinews	=	wikinews	[	wikinews	.	status_type	==	"str"	]	

cnn	=	cnn	.	sample	(	frac	=	1	)	.	head	(	10000	)	
nytimes	=	nytimes	.	sample	(	frac	=	1	)	.	head	(	13000	)	

clickbaits	=	pd	.	concat	(	[	buzzfeed	,	clickhole	,	stopclickbait	,	upworthy	]	)	
non_clickbaits	=	pd	.	concat	(	[	cnn	,	nytimes	,	wikinews	]	)	

clickbaits	.	to_csv	(	"str"	,	index	=	False	)	
non_clickbaits	.	to_csv	(	"str"	,	index	=	False	)	
	