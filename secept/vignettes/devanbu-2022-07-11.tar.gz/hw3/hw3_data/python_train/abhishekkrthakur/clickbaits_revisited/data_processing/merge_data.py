

import	pandas	as	pd	

clickbait_titles	=	pd	.	read_csv	(	"str"	)	
non_clickbait_titles	=	pd	.	read_csv	(	"str"	)	

clickbait_features	=	pd	.	read_csv	(	"str"	)	
non_clickbait_features	=	pd	.	read_csv	(	"str"	)	

clickbait_full	=	pd	.	concat	(	[	clickbait_titles	,	clickbait_features	]	,	axis	=	1	)	
non_clickbait_full	=	pd	.	concat	(	[	non_clickbait_titles	,	non_clickbait_features	]	,	axis	=	1	)	

clickbait_full	[	"str"	]	=	1	
non_clickbait_full	[	"str"	]	=	0	

fulldata	=	pd	.	concat	(	[	clickbait_full	,	non_clickbait_full	]	)	
fulldata	=	fulldata	.	sample	(	frac	=	1	)	.	reset_index	(	drop	=	True	)	
fulldata	=	fulldata	[	fulldata	.	html_len	!=	-	1	]	

fulldata	.	to_csv	(	"str"	,	index	=	False	)	
	