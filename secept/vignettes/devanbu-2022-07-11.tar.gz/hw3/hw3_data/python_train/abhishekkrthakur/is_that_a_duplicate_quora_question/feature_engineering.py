

import	cPickle	
import	pandas	as	pd	
import	numpy	as	np	
import	gensim	
from	fuzzywuzzy	import	fuzz	
from	nltk	.	corpus	import	stopwords	
from	tqdm	import	tqdm	
from	scipy	.	stats	import	skew	,	kurtosis	
from	scipy	.	spatial	.	distance	import	cosine	,	cityblock	,	jaccard	,	canberra	,	euclidean	,	minkowski	,	braycurtis	
from	nltk	import	word_tokenize	
stop_words	=	stopwords	.	words	(	"str"	)	


def	wmd	(	s1	,	s2	)	:	
s1	=	str	(	s1	)	.	lower	(	)	.	split	(	)	
s2	=	str	(	s2	)	.	lower	(	)	.	split	(	)	
stop_words	=	stopwords	.	words	(	"str"	)	
s1	=	[	w	for	w	in	s1	if	w	not	in	stop_words	]	
s2	=	[	w	for	w	in	s2	if	w	not	in	stop_words	]	
return	model	.	wmdistance	(	s1	,	s2	)	


def	norm_wmd	(	s1	,	s2	)	:	
s1	=	str	(	s1	)	.	lower	(	)	.	split	(	)	
s2	=	str	(	s2	)	.	lower	(	)	.	split	(	)	
stop_words	=	stopwords	.	words	(	"str"	)	
s1	=	[	w	for	w	in	s1	if	w	not	in	stop_words	]	
s2	=	[	w	for	w	in	s2	if	w	not	in	stop_words	]	
return	norm_model	.	wmdistance	(	s1	,	s2	)	


def	sent2vec	(	s	)	:	
words	=	str	(	s	)	.	lower	(	)	.	decode	(	"str"	)	
words	=	word_tokenize	(	words	)	
words	=	[	w	for	w	in	words	if	not	w	in	stop_words	]	
words	=	[	w	for	w	in	words	if	w	.	isalpha	(	)	]	
M	=	[	]	
for	w	in	words	:	
try	:	
M	.	append	(	model	[	w	]	)	
except	:	
continue	
M	=	np	.	array	(	M	)	
v	=	M	.	sum	(	axis	=	0	)	
return	v	/	np	.	sqrt	(	(	v	*	*	2	)	.	sum	(	)	)	


data	=	pd	.	read_csv	(	"str"	,	sep	=	"str"	)	
data	=	data	.	drop	(	[	"str"	,	"str"	,	"str"	]	,	axis	=	1	)	


data	[	"str"	]	=	data	.	question1	.	apply	(	lambda	x	:	len	(	str	(	x	)	)	)	
data	[	"str"	]	=	data	.	question2	.	apply	(	lambda	x	:	len	(	str	(	x	)	)	)	
data	[	"str"	]	=	data	.	len_q1	-	data	.	len_q2	
data	[	"str"	]	=	data	.	question1	.	apply	(	lambda	x	:	len	(	"str"	.	join	(	set	(	str	(	x	)	.	replace	(	"str"	,	"str"	)	)	)	)	)	
data	[	"str"	]	=	data	.	question2	.	apply	(	lambda	x	:	len	(	"str"	.	join	(	set	(	str	(	x	)	.	replace	(	"str"	,	"str"	)	)	)	)	)	
data	[	"str"	]	=	data	.	question1	.	apply	(	lambda	x	:	len	(	str	(	x	)	.	split	(	)	)	)	
data	[	"str"	]	=	data	.	question2	.	apply	(	lambda	x	:	len	(	str	(	x	)	.	split	(	)	)	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	len	(	set	(	str	(	x	[	"str"	]	)	.	lower	(	)	.	split	(	)	)	.	intersection	(	set	(	str	(	x	[	"str"	]	)	.	lower	(	)	.	split	(	)	)	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	QRatio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	WRatio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	partial_ratio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	partial_token_set_ratio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	partial_token_sort_ratio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	token_set_ratio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	fuzz	.	token_sort_ratio	(	str	(	x	[	"str"	]	)	,	str	(	x	[	"str"	]	)	)	,	axis	=	1	)	


model	=	gensim	.	models	.	KeyedVectors	.	load_word2vec_format	(	"str"	,	binary	=	True	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	wmd	(	x	[	"str"	]	,	x	[	"str"	]	)	,	axis	=	1	)	


norm_model	=	gensim	.	models	.	KeyedVectors	.	load_word2vec_format	(	"str"	,	binary	=	True	)	
norm_model	.	init_sims	(	replace	=	True	)	
data	[	"str"	]	=	data	.	apply	(	lambda	x	:	norm_wmd	(	x	[	"str"	]	,	x	[	"str"	]	)	,	axis	=	1	)	

question1_vectors	=	np	.	zeros	(	(	data	.	shape	[	0	]	,	300	)	)	
error_count	=	0	

for	i	,	q	in	tqdm	(	enumerate	(	data	.	question1	.	values	)	)	:	
question1_vectors	[	i	,	:	]	=	sent2vec	(	q	)	

question2_vectors	=	np	.	zeros	(	(	data	.	shape	[	0	]	,	300	)	)	
for	i	,	q	in	tqdm	(	enumerate	(	data	.	question2	.	values	)	)	:	
question2_vectors	[	i	,	:	]	=	sent2vec	(	q	)	

data	[	"str"	]	=	[	cosine	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	cityblock	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	jaccard	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	canberra	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	euclidean	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	minkowski	(	x	,	y	,	3	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	braycurtis	(	x	,	y	)	for	(	x	,	y	)	in	zip	(	np	.	nan_to_num	(	question1_vectors	)	,	
np	.	nan_to_num	(	question2_vectors	)	)	]	

data	[	"str"	]	=	[	skew	(	x	)	for	x	in	np	.	nan_to_num	(	question1_vectors	)	]	
data	[	"str"	]	=	[	skew	(	x	)	for	x	in	np	.	nan_to_num	(	question2_vectors	)	]	
data	[	"str"	]	=	[	kurtosis	(	x	)	for	x	in	np	.	nan_to_num	(	question1_vectors	)	]	
data	[	"str"	]	=	[	kurtosis	(	x	)	for	x	in	np	.	nan_to_num	(	question2_vectors	)	]	

cPickle	.	dump	(	question1_vectors	,	open	(	"str"	,	"str"	)	,	-	1	)	
cPickle	.	dump	(	question2_vectors	,	open	(	"str"	,	"str"	)	,	-	1	)	

data	.	to_csv	(	"str"	,	index	=	False	)	
	