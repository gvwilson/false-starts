






def	two_group_difference	(	control	,	test	,	is_paired	=	False	,	
effect_size	=	"str"	)	:	

import	numpy	as	np	

if	effect_size	==	"str"	:	
return	func_difference	(	control	,	test	,	np	.	mean	,	is_paired	)	

elif	effect_size	==	"str"	:	
return	func_difference	(	control	,	test	,	np	.	median	,	is_paired	)	

elif	effect_size	==	"str"	:	
return	cohens_d	(	control	,	test	,	is_paired	)	

elif	effect_size	==	"str"	:	
return	hedges_g	(	control	,	test	,	is_paired	)	

elif	effect_size	==	"str"	:	
if	is_paired	is	True	:	
err1	=	"str"	
raise	ValueError	(	err1	)	
else	:	
return	cliffs_delta	(	control	,	test	)	



def	func_difference	(	control	,	test	,	func	,	is_paired	)	:	

import	numpy	as	np	



if	control	.	__class__	!=	np	.	ndarray	:	
control	=	np	.	array	(	control	)	
if	test	.	__class__	!=	np	.	ndarray	:	
test	=	np	.	array	(	test	)	

if	is_paired	:	
if	len	(	control	)	!=	len	(	test	)	:	
err	=	"str"	
raise	ValueError	(	err	)	

control_nan	=	np	.	where	(	np	.	isnan	(	control	)	)	[	0	]	
test_nan	=	np	.	where	(	np	.	isnan	(	test	)	)	[	0	]	

indexes_to_drop	=	np	.	unique	(	np	.	concatenate	(	[	control_nan	,	
test_nan	]	)	)	

good_indexes	=	[	i	for	i	in	range	(	0	,	len	(	control	)	)	
if	i	not	in	indexes_to_drop	]	

control	=	control	[	good_indexes	]	
test	=	test	[	good_indexes	]	

return	func	(	test	-	control	)	

else	:	
control	=	control	[	~	np	.	isnan	(	control	)	]	
test	=	test	[	~	np	.	isnan	(	test	)	]	
return	func	(	test	)	-	func	(	control	)	



def	cohens_d	(	control	,	test	,	is_paired	=	False	)	:	

import	numpy	as	np	



if	control	.	__class__	!=	np	.	ndarray	:	
control	=	np	.	array	(	control	)	
if	test	.	__class__	!=	np	.	ndarray	:	
test	=	np	.	array	(	test	)	
control	=	control	[	~	np	.	isnan	(	control	)	]	
test	=	test	[	~	np	.	isnan	(	test	)	]	

pooled_sd	,	average_sd	=	_compute_standardizers	(	control	,	test	)	







if	is_paired	:	

if	len	(	control	)	!=	len	(	test	)	:	
raise	ValueError	(	"str"	)	

delta	=	test	-	control	
M	=	np	.	mean	(	delta	)	
divisor	=	average_sd	

else	:	
M	=	np	.	mean	(	test	)	-	np	.	mean	(	control	)	
divisor	=	pooled_sd	

return	M	/	divisor	



def	hedges_g	(	control	,	test	,	is_paired	=	False	)	:	

import	numpy	as	np	



if	control	.	__class__	!=	np	.	ndarray	:	
control	=	np	.	array	(	control	)	
if	test	.	__class__	!=	np	.	ndarray	:	
test	=	np	.	array	(	test	)	
control	=	control	[	~	np	.	isnan	(	control	)	]	
test	=	test	[	~	np	.	isnan	(	test	)	]	

d	=	cohens_d	(	control	,	test	,	is_paired	)	
len_c	=	len	(	control	)	
len_t	=	len	(	test	)	
correction_factor	=	_compute_hedges_correction_factor	(	len_c	,	len_t	)	
return	correction_factor	*	d	



def	cliffs_delta	(	control	,	test	)	:	

import	numpy	as	np	
from	scipy	.	stats	import	mannwhitneyu	



if	control	.	__class__	!=	np	.	ndarray	:	
control	=	np	.	array	(	control	)	
if	test	.	__class__	!=	np	.	ndarray	:	
test	=	np	.	array	(	test	)	

c	=	control	[	~	np	.	isnan	(	control	)	]	
t	=	test	[	~	np	.	isnan	(	test	)	]	

control_n	=	len	(	c	)	
test_n	=	len	(	t	)	


U	,	_	=	mannwhitneyu	(	t	,	c	,	alternative	=	"str"	)	
cliffs_delta	=	(	(	2	*	U	)	/	(	control_n	*	test_n	)	)	-	1	













return	cliffs_delta	



def	_compute_standardizers	(	control	,	test	)	:	
from	numpy	import	mean	,	var	,	sqrt	,	nan	



control_n	=	len	(	control	)	
test_n	=	len	(	test	)	

control_mean	=	mean	(	control	)	
test_mean	=	mean	(	test	)	

control_var	=	var	(	control	,	ddof	=	1	)	
test_var	=	var	(	test	,	ddof	=	1	)	

control_std	=	sqrt	(	control_var	)	
test_std	=	sqrt	(	test_var	)	


pooled	=	sqrt	(	(	(	control_n	-	1	)	*	control_var	+	(	test_n	-	1	)	*	test_var	)	/	
(	control_n	+	test_n	-	2	)	
)	


average	=	sqrt	(	(	control_var	+	test_var	)	/	2	)	








return	pooled	,	average	



def	_compute_hedges_correction_factor	(	n1	,	n2	)	:	


from	scipy	.	special	import	gamma	
from	numpy	import	sqrt	,	isinf	
import	warnings	

df	=	n1	+	n2	-	2	
numer	=	gamma	(	df	/	2	)	
denom0	=	gamma	(	(	df	-	1	)	/	2	)	
denom	=	sqrt	(	df	/	2	)	*	denom0	

if	isinf	(	numer	)	or	isinf	(	denom	)	:	


df_sum	=	n1	+	n2	
denom	=	(	4	*	df_sum	)	-	9	
out	=	1	-	(	3	/	denom	)	

else	:	
out	=	numer	/	denom	

return	out	
	