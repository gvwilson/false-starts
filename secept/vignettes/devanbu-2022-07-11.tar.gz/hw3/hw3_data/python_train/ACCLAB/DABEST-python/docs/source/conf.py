









































autoclass_content	=	"str"	




extensions	=	[	"str"	,	"str"	,	
"str"	,	"str"	]	


intersphinx_mapping	=	{	
"str"	:	(	"str"	,	None	)	,	
}	


templates_path	=	[	"str"	]	





source_suffix	=	"str"	


master_doc	=	"str"	


project	=	"str"	
copyright	=	"str"	
author	=	"str"	






version	=	"str"	

release	=	"str"	






language	=	None	




exclude_patterns	=	[	]	


pygments_style	=	"str"	


todo_include_todos	=	False	







html_theme	=	"str"	






html_sidebars	=	{	
"str"	:	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	
}	





html_theme_options	=	{	


"str"	:	"str"	,	

"str"	:	"str"	,	

"str"	:	True	,	
"str"	:	True	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	

}	




html_static_path	=	[	"str"	]	







htmlhelp_basename	=	"str"	




latex_elements	=	{	















}	




latex_documents	=	[	
(	master_doc	,	"str"	,	"str"	,	
"str"	,	"str"	)	,	
]	






man_pages	=	[	
(	master_doc	,	"str"	,	"str"	,	
[	author	]	,	1	)	
]	







texinfo_documents	=	[	
(	master_doc	,	"str"	,	"str"	,	
author	,	"str"	,	
"str"	,	
"str"	)	,	
]	






epub_title	=	project	
epub_author	=	author	
epub_publisher	=	author	
epub_copyright	=	copyright	











epub_exclude_files	=	[	"str"	]	

def	setup	(	app	)	:	
app	.	add_stylesheet	(	"str"	)	
	