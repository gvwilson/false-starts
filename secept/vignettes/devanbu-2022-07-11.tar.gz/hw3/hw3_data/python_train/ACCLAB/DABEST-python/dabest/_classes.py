




class	Dabest	(	object	)	:	



def	__init__	(	self	,	data	,	idx	,	x	,	y	,	paired	,	id_col	,	ci	,	resamples	,	
random_seed	)	:	




import	numpy	as	np	
import	pandas	as	pd	
import	seaborn	as	sns	

self	.	__ci	=	ci	
self	.	__data	=	data	
self	.	__idx	=	idx	
self	.	__id_col	=	id_col	
self	.	__is_paired	=	paired	
self	.	__resamples	=	resamples	
self	.	__random_seed	=	random_seed	


data_in	=	data	.	copy	(	)	






if	all	(	[	isinstance	(	i	,	str	)	for	i	in	idx	]	)	:	

all_plot_groups	=	pd	.	unique	(	[	t	for	t	in	idx	]	)	.	tolist	(	)	
if	len	(	idx	)	>	len	(	all_plot_groups	)	:	
err0	=	"str"	
raise	ValueError	(	err0	)	



self	.	__idx	=	(	idx	,	)	

elif	all	(	[	isinstance	(	i	,	(	tuple	,	list	)	)	for	i	in	idx	]	)	:	
all_plot_groups	=	pd	.	unique	(	[	tt	for	t	in	idx	for	tt	in	t	]	)	.	tolist	(	)	

actual_groups_given	=	sum	(	[	len	(	i	)	for	i	in	idx	]	)	

if	actual_groups_given	>	len	(	all_plot_groups	)	:	
err0	=	"str"	
err1	=	"str"	
err2	=	"str"	
raise	ValueError	(	err0	+	err1	+	err2	)	

else	:	
err	=	"str"	
"str"	.	format	(	idx	)	
raise	ValueError	(	err	)	



if	paired	is	True	:	
all_idx_lengths	=	[	len	(	t	)	for	t	in	self	.	__idx	]	
if	(	np	.	array	(	all_idx_lengths	)	!=	2	)	.	any	(	)	:	
err1	=	"str"	
err2	=	"str"	.	format	(	idx	)	
raise	ValueError	(	err1	+	err2	)	



if	x	is	None	and	y	is	not	None	:	
err	=	"str"	
raise	ValueError	(	err	)	

elif	y	is	None	and	x	is	not	None	:	
err	=	"str"	
raise	ValueError	(	err	)	


elif	x	is	not	None	and	y	is	not	None	:	


if	x	not	in	data_in	.	columns	:	
err	=	"str"	.	format	(	x	)	
raise	IndexError	(	err	)	
if	y	not	in	data_in	.	columns	:	
err	=	"str"	.	format	(	y	)	
raise	IndexError	(	err	)	


if	not	np	.	issubdtype	(	data_in	[	y	]	.	dtype	,	np	.	number	)	:	
err	=	"str"	.	format	(	y	)	
raise	ValueError	(	err	)	


for	g	in	all_plot_groups	:	
if	g	not	in	data_in	[	x	]	.	unique	(	)	:	
err0	=	"str"	.	format	(	g	,	x	)	
err1	=	"str"	
raise	IndexError	(	err0	+	err1	)	



plot_data	=	data_in	[	data_in	.	loc	[	:	,	x	]	.	isin	(	all_plot_groups	)	]	.	copy	(	)	




self	.	__x	=	x	
self	.	__y	=	y	
self	.	__xvar	=	x	
self	.	__yvar	=	y	

elif	x	is	None	and	y	is	None	:	


self	.	__x	=	None	
self	.	__y	=	None	
self	.	__xvar	=	"str"	
self	.	__yvar	=	"str"	


for	g	in	all_plot_groups	:	
if	g	not	in	data_in	.	columns	:	
err0	=	"str"	.	format	(	g	)	
err1	=	"str"	
raise	IndexError	(	err0	+	err1	)	

set_all_columns	=	set	(	data_in	.	columns	.	tolist	(	)	)	
set_all_plot_groups	=	set	(	all_plot_groups	)	
id_vars	=	set_all_columns	.	difference	(	set_all_plot_groups	)	

plot_data	=	pd	.	melt	(	data_in	,	
id_vars	=	id_vars	,	
value_vars	=	all_plot_groups	,	
value_name	=	self	.	__yvar	,	
var_name	=	self	.	__xvar	)	



plot_data	.	dropna	(	axis	=	0	,	how	=	"str"	,	subset	=	[	self	.	__yvar	]	,	inplace	=	True	)	





if	isinstance	(	plot_data	[	self	.	__xvar	]	.	dtype	,	
pd	.	CategoricalDtype	)	is	True	:	
plot_data	[	self	.	__xvar	]	.	cat	.	remove_unused_categories	(	inplace	=	True	)	
plot_data	[	self	.	__xvar	]	.	cat	.	reorder_categories	(	all_plot_groups	,	
ordered	=	True	,	
inplace	=	True	)	
else	:	
plot_data	.	loc	[	:	,	self	.	__xvar	]	=	pd	.	Categorical	(	plot_data	[	self	.	__xvar	]	,	
categories	=	all_plot_groups	,	
ordered	=	True	)	




self	.	__plot_data	=	plot_data	

self	.	__all_plot_groups	=	all_plot_groups	



if	paired	is	True	:	
if	id_col	is	None	:	
err	=	"str"	
raise	IndexError	(	err	)	
elif	id_col	not	in	plot_data	.	columns	:	
err	=	"str"	.	format	(	id_col	)	
raise	IndexError	(	err	)	

EffectSizeDataFrame_kwargs	=	dict	(	ci	=	ci	,	is_paired	=	paired	,	
random_seed	=	random_seed	,	
resamples	=	resamples	)	

self	.	mean_diff	=	EffectSizeDataFrame	(	self	,	"str"	,	
*	*	EffectSizeDataFrame_kwargs	)	

self	.	median_diff	=	EffectSizeDataFrame	(	self	,	"str"	,	
*	*	EffectSizeDataFrame_kwargs	)	

self	.	cohens_d	=	EffectSizeDataFrame	(	self	,	"str"	,	
*	*	EffectSizeDataFrame_kwargs	)	

self	.	hedges_g	=	EffectSizeDataFrame	(	self	,	"str"	,	
*	*	EffectSizeDataFrame_kwargs	)	

if	paired	is	False	:	
self	.	cliffs_delta	=	EffectSizeDataFrame	(	self	,	"str"	,	
*	*	EffectSizeDataFrame_kwargs	)	
else	:	
self	.	cliffs_delta	=	"str"	


def	__repr__	(	self	)	:	
from		.	__init__	import	__version__	
import	datetime	as	dt	
import	numpy	as	np	

from		.	misc_tools	import	print_greeting	

if	self	.	__is_paired	:	
es	=	"str"	
else	:	
es	=	"str"	

greeting_header	=	print_greeting	(	)	

s1	=	"str"	.	format	(	es	)	
s2	=	"str"	.	format	(	self	.	__ci	)	
desc_line	=	s1	+	s2	

out	=	[	greeting_header	+	"str"	+	desc_line	]	

comparisons	=	[	]	

for	j	,	current_tuple	in	enumerate	(	self	.	__idx	)	:	
control_name	=	current_tuple	[	0	]	

for	ix	,	test_name	in	enumerate	(	current_tuple	[	1	:	]	)	:	
comparisons	.	append	(	"str"	.	format	(	test_name	,	control_name	)	)	

for	j	,	g	in	enumerate	(	comparisons	)	:	
out	.	append	(	"str"	.	format	(	j	+	1	,	g	)	)	

resamples_line1	=	"str"	.	format	(	self	.	__resamples	)	
resamples_line2	=	"str"	
out	.	append	(	resamples_line1	+	resamples_line2	)	

return	"str"	.	join	(	out	)	










@property	
def	data	(	self	)	:	

return	self	.	__data	

@property	
def	idx	(	self	)	:	

return	self	.	__idx	

@property	
def	is_paired	(	self	)	:	

return	self	.	__is_paired	

@property	
def	id_col	(	self	)	:	

return	self	.	__id_col	

@property	
def	ci	(	self	)	:	

return	self	.	__ci	

@property	
def	resamples	(	self	)	:	

return	self	.	__resamples	

@property	
def	random_seed	(	self	)	:	

return	self	.	__random_seed	


@property	
def	x	(	self	)	:	

return	self	.	__x	

@property	
def	y	(	self	)	:	

return	self	.	__y	

@property	
def	_xvar	(	self	)	:	

return	self	.	__xvar	

@property	
def	_yvar	(	self	)	:	

return	self	.	__yvar	

@property	
def	_plot_data	(	self	)	:	

return	self	.	__plot_data	

@property	
def	_all_plot_groups	(	self	)	:	

return	self	.	__all_plot_groups	






class	TwoGroupsEffectSize	(	object	)	:	



def	__init__	(	self	,	control	,	test	,	effect_size	,	
is_paired	=	False	,	ci	=	95	,	
resamples	=	5000	,	random_seed	=	12345	)	:	



from	numpy	import	array	,	isnan	,	isinf	
from	numpy	import	sort	as	npsort	
from	numpy	.	random	import	choice	,	seed	

import	scipy	.	stats	as	spstats	



from	string	import	Template	
import	warnings	

from		.	_stats_tools	import	confint_2group_diff	as	ci2g	
from		.	_stats_tools	import	effsize	as	es	



self	.	__EFFECT_SIZE_DICT	=	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	


kosher_es	=	[	a	for	a	in	self	.	__EFFECT_SIZE_DICT	.	keys	(	)	]	
if	effect_size	not	in	kosher_es	:	
err1	=	"str"	.	format	(	effect_size	)	
err2	=	"str"	.	format	(	kosher_es	)	
raise	ValueError	(	"str"	.	join	(	[	err1	,	err2	]	)	)	

if	effect_size	==	"str"	and	is_paired	is	True	:	
err1	=	"str"	
raise	ValueError	(	err1	)	



control	=	array	(	control	)	
test	=	array	(	test	)	
control	=	control	[	~	isnan	(	control	)	]	
test	=	test	[	~	isnan	(	test	)	]	

self	.	__effect_size	=	effect_size	
self	.	__control	=	control	
self	.	__test	=	test	
self	.	__is_paired	=	is_paired	
self	.	__resamples	=	resamples	
self	.	__random_seed	=	random_seed	
self	.	__ci	=	ci	
self	.	__alpha	=	ci2g	.	_compute_alpha_from_ci	(	ci	)	


self	.	__difference	=	es	.	two_group_difference	(	
control	,	test	,	is_paired	,	effect_size	)	

self	.	__jackknives	=	ci2g	.	compute_meandiff_jackknife	(	
control	,	test	,	is_paired	,	effect_size	)	

self	.	__acceleration_value	=	ci2g	.	_calc_accel	(	self	.	__jackknives	)	

bootstraps	=	ci2g	.	compute_bootstrapped_diff	(	
control	,	test	,	is_paired	,	effect_size	,	
resamples	,	random_seed	)	
self	.	__bootstraps	=	npsort	(	bootstraps	)	



num_infinities	=	len	(	self	.	__bootstraps	[	isinf	(	self	.	__bootstraps	)	]	)	

if	num_infinities	>	0	:	
warn_msg	=	"str"	"str"	"str"	"str"	"str"	"str"	
warnings	.	warn	(	warn_msg	.	format	(	num_infinities	)	,	
category	=	UserWarning	)	

self	.	__bias_correction	=	ci2g	.	compute_meandiff_bias_correction	(	
self	.	__bootstraps	,	self	.	__difference	)	


bca_idx_low	,	bca_idx_high	=	ci2g	.	compute_interval_limits	(	
self	.	__bias_correction	,	self	.	__acceleration_value	,	
self	.	__resamples	,	ci	)	

self	.	__bca_interval_idx	=	(	bca_idx_low	,	bca_idx_high	)	

if	~	isnan	(	bca_idx_low	)	and	~	isnan	(	bca_idx_high	)	:	
self	.	__bca_low	=	self	.	__bootstraps	[	bca_idx_low	]	
self	.	__bca_high	=	self	.	__bootstraps	[	bca_idx_high	]	

err1	=	"str"	
err2	=	"str"	
err3	=	"str"	
err_temp	=	Template	(	"str"	.	join	(	[	err1	,	err2	,	err3	]	)	)	

if	bca_idx_low	<	=	10	:	
warnings	.	warn	(	err_temp	.	substitute	(	lim_type	=	"str"	,	
loc	=	"str"	)	,	
stacklevel	=	1	)	

if	bca_idx_high	>	=	resamples	-	9	:	
warnings	.	warn	(	err_temp	.	substitute	(	lim_type	=	"str"	,	
loc	=	"str"	)	,	
stacklevel	=	1	)	

else	:	
err1	=	"str"	
err2	=	"str"	
err3	=	"str"	
err_temp	=	Template	(	"str"	.	join	(	[	err1	,	err2	,	err3	]	)	)	

if	isnan	(	bca_idx_low	)	:	
self	.	__bca_low	=	self	.	__difference	
warnings	.	warn	(	err_temp	.	substitute	(	lim_type	=	"str"	)	,	
stacklevel	=	0	)	

if	isnan	(	bca_idx_high	)	:	
self	.	__bca_high	=	self	.	__difference	
warnings	.	warn	(	err_temp	.	substitute	(	lim_type	=	"str"	)	,	
stacklevel	=	0	)	


pct_idx_low	=	int	(	(	self	.	__alpha	/	2	)	*	resamples	)	
pct_idx_high	=	int	(	(	1	-	(	self	.	__alpha	/	2	)	)	*	resamples	)	

self	.	__pct_interval_idx	=	(	pct_idx_low	,	pct_idx_high	)	
self	.	__pct_low	=	self	.	__bootstraps	[	pct_idx_low	]	
self	.	__pct_high	=	self	.	__bootstraps	[	pct_idx_high	]	


if	is_paired	is	True	:	

wilcoxon	=	spstats	.	wilcoxon	(	control	,	test	)	
self	.	__pvalue_wilcoxon	=	wilcoxon	.	pvalue	
self	.	__statistic_wilcoxon	=	wilcoxon	.	statistic	

if	effect_size	!=	"str"	:	

paired_t	=	spstats	.	ttest_rel	(	control	,	test	,	nan_policy	=	"str"	)	
self	.	__pvalue_paired_students_t	=	paired_t	.	pvalue	
self	.	__statistic_paired_students_t	=	paired_t	.	statistic	

standardized_es	=	es	.	cohens_d	(	control	,	test	,	is_paired	=	True	)	





elif	effect_size	==	"str"	:	

brunner_munzel	=	spstats	.	brunnermunzel	(	control	,	test	,	
nan_policy	=	"str"	)	
self	.	__pvalue_brunner_munzel	=	brunner_munzel	.	pvalue	
self	.	__statistic_brunner_munzel	=	brunner_munzel	.	statistic	


elif	effect_size	==	"str"	:	



kruskal	=	spstats	.	kruskal	(	control	,	test	,	nan_policy	=	"str"	)	
self	.	__pvalue_kruskal	=	kruskal	.	pvalue	
self	.	__statistic_kruskal	=	kruskal	.	statistic	


else	:	


welch	=	spstats	.	ttest_ind	(	control	,	test	,	equal_var	=	False	,	
nan_policy	=	"str"	)	
self	.	__pvalue_welch	=	welch	.	pvalue	
self	.	__statistic_welch	=	welch	.	statistic	



students_t	=	spstats	.	ttest_ind	(	control	,	test	,	equal_var	=	True	,	
nan_policy	=	"str"	)	
self	.	__pvalue_students_t	=	students_t	.	pvalue	
self	.	__statistic_students_t	=	students_t	.	statistic	



try	:	
mann_whitney	=	spstats	.	mannwhitneyu	(	control	,	test	,	
alternative	=	"str"	)	
self	.	__pvalue_mann_whitney	=	mann_whitney	.	pvalue	
self	.	__statistic_mann_whitney	=	mann_whitney	.	statistic	
except	ValueError	:	


pass	

standardized_es	=	es	.	cohens_d	(	control	,	test	,	is_paired	=	False	)	











def	__repr__	(	self	,	show_resample_count	=	True	,	define_pval	=	True	,	sigfig	=	3	)	:	
UNPAIRED_ES_TO_TEST	=	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	

TEST_TO_PVAL_ATTR	=	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	

PAIRED_STATUS	=	{	True	:	"str"	,	False	:	"str"	}	

first_line	=	{	"str"	:	PAIRED_STATUS	[	self	.	__is_paired	]	,	
"str"	:	self	.	__EFFECT_SIZE_DICT	[	self	.	__effect_size	]	}	

out1	=	"str"	.	format	(	*	*	first_line	)	

base_string_fmt	=	"str"	+	str	(	sigfig	)	+	"str"	
if	"str"	in	str	(	self	.	__ci	)	:	
ci_width	=	base_string_fmt	.	format	(	self	.	__ci	)	
else	:	
ci_width	=	str	(	self	.	__ci	)	

ci_out	=	{	"str"	:	base_string_fmt	.	format	(	self	.	__difference	)	,	
"str"	:	ci_width	,	
"str"	:	base_string_fmt	.	format	(	self	.	__bca_low	)	,	
"str"	:	base_string_fmt	.	format	(	self	.	__bca_high	)	}	

out2	=	"str"	.	format	(	*	*	ci_out	)	
out	=	out1	+	out2	

if	self	.	__is_paired	:	
stats_test	=	"str"	
else	:	
stats_test	=	UNPAIRED_ES_TO_TEST	[	self	.	__effect_size	]	
pval_rounded	=	base_string_fmt	.	format	(	getattr	(	self	,	
TEST_TO_PVAL_ATTR	[	stats_test	]	)	
)	
pvalue	=	"str"	.	format	(	stats_test	,	
pval_rounded	)	

bs1	=	"str"	.	format	(	self	.	__resamples	)	
bs2	=	"str"	
bs	=	bs1	+	bs2	

defined	=	"str"	+	"str"	

if	show_resample_count	and	define_pval	:	
return	"str"	.	format	(	out	,	pvalue	,	bs	,	defined	)	
elif	show_resample_count	is	False	and	define_pval	is	True	:	
return	"str"	.	format	(	out	,	pvalue	,	defined	)	
elif	show_resample_count	is	True	and	define_pval	is	False	:	
return	"str"	.	format	(	out	,	pvalue	,	bs	)	
else	:	
return	"str"	.	format	(	out	,	pvalue	)	



def	to_dict	(	self	)	:	


attrs	=	[	a	for	a	in	dir	(	self	)	
if	not	a	.	startswith	(	(	"str"	,	"str"	)	)	]	
out	=	{	}	
for	a	in	attrs	:	
out	[	a	]	=	getattr	(	self	,	a	)	
return	out	




@property	
def	difference	(	self	)	:	

return	self	.	__difference	

@property	
def	effect_size	(	self	)	:	

return	self	.	__EFFECT_SIZE_DICT	[	self	.	__effect_size	]	

@property	
def	is_paired	(	self	)	:	
return	self	.	__is_paired	

@property	
def	ci	(	self	)	:	

return	self	.	__ci	

@property	
def	alpha	(	self	)	:	

return	self	.	__alpha	

@property	
def	resamples	(	self	)	:	

return	self	.	__resamples	

@property	
def	bootstraps	(	self	)	:	

return	self	.	__bootstraps	

@property	
def	random_seed	(	self	)	:	

return	self	.	__random_seed	

@property	
def	bca_interval_idx	(	self	)	:	
return	self	.	__bca_interval_idx	

@property	
def	bca_low	(	self	)	:	

return	self	.	__bca_low	

@property	
def	bca_high	(	self	)	:	

return	self	.	__bca_high	

@property	
def	pct_interval_idx	(	self	)	:	
return	self	.	__pct_interval_idx	

@property	
def	pct_low	(	self	)	:	

return	self	.	__pct_low	

@property	
def	pct_high	(	self	)	:	

return	self	.	__pct_high	



@property	
def	pvalue_brunner_munzel	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_brunner_munzel	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_brunner_munzel	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_brunner_munzel	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_wilcoxon	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_wilcoxon	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_wilcoxon	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_wilcoxon	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_paired_students_t	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_paired_students_t	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_paired_students_t	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_paired_students_t	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_kruskal	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_kruskal	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_kruskal	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_kruskal	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_welch	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_welch	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_welch	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_welch	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_students_t	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_students_t	
except	AttributeError	:	
return	npnan	

@property	
def	statistic_students_t	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_students_t	
except	AttributeError	:	
return	npnan	



@property	
def	pvalue_mann_whitney	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__pvalue_mann_whitney	
except	AttributeError	:	
return	npnan	



@property	
def	statistic_mann_whitney	(	self	)	:	
from	numpy	import	nan	as	npnan	
try	:	
return	self	.	__statistic_mann_whitney	
except	AttributeError	:	
return	npnan	















class	EffectSizeDataFrame	(	object	)	:	


def	__init__	(	self	,	dabest	,	effect_size	,	
is_paired	,	ci	=	95	,	
resamples	=	5000	,	random_seed	=	12345	)	:	


self	.	__dabest_obj	=	dabest	
self	.	__effect_size	=	effect_size	
self	.	__is_paired	=	is_paired	
self	.	__ci	=	ci	
self	.	__resamples	=	resamples	
self	.	__random_seed	=	random_seed	


def	__pre_calc	(	self	)	:	
import	pandas	as	pd	
from		.	misc_tools	import	print_greeting	,	get_varname	

idx	=	self	.	__dabest_obj	.	idx	
dat	=	self	.	__dabest_obj	.	_plot_data	
xvar	=	self	.	__dabest_obj	.	_xvar	
yvar	=	self	.	__dabest_obj	.	_yvar	

out	=	[	]	
reprs	=	[	]	

for	j	,	current_tuple	in	enumerate	(	idx	)	:	

cname	=	current_tuple	[	0	]	
control	=	dat	[	dat	[	xvar	]	==	cname	]	[	yvar	]	.	copy	(	)	

for	ix	,	tname	in	enumerate	(	current_tuple	[	1	:	]	)	:	
test	=	dat	[	dat	[	xvar	]	==	tname	]	[	yvar	]	.	copy	(	)	

result	=	TwoGroupsEffectSize	(	control	,	test	,	
self	.	__effect_size	,	
self	.	__is_paired	,	
self	.	__ci	,	
self	.	__resamples	,	
self	.	__random_seed	)	
r_dict	=	result	.	to_dict	(	)	

r_dict	[	"str"	]	=	cname	
r_dict	[	"str"	]	=	tname	
r_dict	[	"str"	]	=	int	(	len	(	control	)	)	
r_dict	[	"str"	]	=	int	(	len	(	test	)	)	

out	.	append	(	r_dict	)	

if	j	==	len	(	idx	)	-	1	and	ix	==	len	(	current_tuple	)	-	2	:	
resamp_count	=	True	
def_pval	=	True	
else	:	
resamp_count	=	False	
def_pval	=	False	

text_repr	=	result	.	__repr__	(	show_resample_count	=	resamp_count	,	
define_pval	=	def_pval	)	

to_replace	=	"str"	.	format	(	cname	,	tname	)	
text_repr	=	text_repr	.	replace	(	"str"	,	to_replace	,	1	)	

reprs	.	append	(	text_repr	)	

varname	=	get_varname	(	self	.	__dabest_obj	)	
lastline	=	"str"	+	"str"	.	format	(	varname	,	self	.	__effect_size	)	
reprs	.	append	(	lastline	)	

reprs	.	insert	(	0	,	print_greeting	(	)	)	

self	.	__for_print	=	"str"	.	join	(	reprs	)	

out_	=	pd	.	DataFrame	(	out	)	

columns_in_order	=	[	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	"str"	,	

"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	

"str"	,	"str"	,	"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	]	

self	.	__results	=	out_	.	reindex	(	columns	=	columns_in_order	)	
self	.	__results	.	dropna	(	axis	=	"str"	,	how	=	"str"	,	inplace	=	True	)	



def	__repr__	(	self	)	:	
try	:	
return	self	.	__for_print	
except	AttributeError	:	
self	.	__pre_calc	(	)	
return	self	.	__for_print	



def	plot	(	self	,	color_col	=	None	,	

raw_marker_size	=	6	,	es_marker_size	=	9	,	

swarm_label	=	None	,	contrast_label	=	None	,	
swarm_ylim	=	None	,	contrast_ylim	=	None	,	

custom_palette	=	None	,	swarm_desat	=	0.5	,	halfviolin_desat	=	1	,	
halfviolin_alpha	=	0.8	,	

float_contrast	=	True	,	
show_pairs	=	True	,	
group_summaries	=	None	,	
group_summaries_offset	=	0.1	,	

fig_size	=	None	,	
dpi	=	100	,	
ax	=	None	,	

swarmplot_kwargs	=	None	,	
violinplot_kwargs	=	None	,	
slopegraph_kwargs	=	None	,	
reflines_kwargs	=	None	,	
group_summary_kwargs	=	None	,	
legend_kwargs	=	None	)	:	


from		.	plotter	import	EffectSizeDataFramePlotter	

if	hasattr	(	self	,	"str"	)	is	False	:	
self	.	__pre_calc	(	)	

all_kwargs	=	locals	(	)	
del	all_kwargs	[	"str"	]	

out	=	EffectSizeDataFramePlotter	(	self	,	*	*	all_kwargs	)	

return	out	


@property	
def	results	(	self	)	:	

try	:	
return	self	.	__results	
except	AttributeError	:	
self	.	__pre_calc	(	)	
return	self	.	__results	



@property	
def	statistical_tests	(	self	)	:	
results_df	=	self	.	results	


stats_columns	=	[	c	for	c	in	results_df	.	columns	
if	c	.	startswith	(	"str"	)	or	c	.	startswith	(	"str"	)	]	

default_cols	=	[	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	]	

cols_of_interest	=	default_cols	+	stats_columns	

return	results_df	[	cols_of_interest	]	


@property	
def	_for_print	(	self	)	:	
return	self	.	__for_print	

@property	
def	_plot_data	(	self	)	:	
return	self	.	__dabest_obj	.	_plot_data	

@property	
def	idx	(	self	)	:	
return	self	.	__dabest_obj	.	idx	

@property	
def	xvar	(	self	)	:	
return	self	.	__dabest_obj	.	_xvar	

@property	
def	yvar	(	self	)	:	
return	self	.	__dabest_obj	.	_yvar	

@property	
def	is_paired	(	self	)	:	
return	self	.	__is_paired	

@property	
def	ci	(	self	)	:	

return	self	.	__ci	

@property	
def	resamples	(	self	)	:	

return	self	.	__resamples	

@property	
def	random_seed	(	self	)	:	

return	self	.	__random_seed	

@property	
def	effect_size	(	self	)	:	

return	self	.	__effect_size	

@property	
def	dabest_obj	(	self	)	:	

return	self	.	__dabest_obj	
	