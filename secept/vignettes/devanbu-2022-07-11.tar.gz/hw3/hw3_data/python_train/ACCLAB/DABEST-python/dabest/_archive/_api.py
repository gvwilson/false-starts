



from	__future__	import	division	


def	plot	(	data	,	idx	,	x	=	None	,	y	=	None	,	ci	=	95	,	n_boot	=	5000	,	random_seed	=	12345	,	

color_col	=	None	,	
paired	=	False	,	
effect_size	=	"str"	,	
raw_marker_size	=	6	,	
es_marker_size	=	9	,	

swarm_label	=	None	,	
contrast_label	=	None	,	
swarm_ylim	=	None	,	
contrast_ylim	=	None	,	

plot_context	=	"str"	,	
font_scale	=	1.	,	

custom_palette	=	None	,	
float_contrast	=	True	,	
show_pairs	=	True	,	
show_group_count	=	True	,	
group_summaries	=	"str"	,	

fig_size	=	None	,	
dpi	=	100	,	
tick_length	=	10	,	
tick_pad	=	7	,	

swarmplot_kwargs	=	None	,	
violinplot_kwargs	=	None	,	
reflines_kwargs	=	None	,	
group_summary_kwargs	=	None	,	
legend_kwargs	=	None	,	
aesthetic_kwargs	=	None	,	
)	:	


import	warnings	


warnings	.	filterwarnings	(	"str"	,	message	=	"str"	)	



warnings	.	simplefilter	(	action	=	"str"	,	category	=	FutureWarning	)	

import	matplotlib	as	mpl	
import	matplotlib	.	pyplot	as	plt	
import	matplotlib	.	ticker	as	tk	
import	matplotlib	.	lines	as	mlines	

plt	.	rcParams	[	"str"	]	=	"str"	

import	numpy	as	np	
from	scipy	.	stats	import	ttest_ind	,	ttest_rel	,	wilcoxon	,	mannwhitneyu	

import	seaborn	as	sns	
import	pandas	as	pd	

from		.	stats_tools	.	confint_2group_diff	import	difference_ci	

from		.	plot_tools	import	halfviolin	,	align_yaxis	,	rotate_ticks	
from		.	plot_tools	import	gapped_lines	,	get_swarm_spans	

from		.	misc_tools	import	merge_two_dicts	,	unpack_and_add	



data_in	=	data	.	copy	(	)	
data_in	.	reset_index	(	inplace	=	True	)	



if	all	(	[	isinstance	(	i	,	str	)	for	i	in	idx	]	)	:	
plottype	=	"str"	

ncols	=	1	
ngroups	=	len	(	idx	)	
widthratio	=	[	1	]	

if	ngroups	>	2	:	
paired	=	False	
float_contrast	=	False	

all_plot_groups	=	np	.	unique	(	[	t	for	t	in	idx	]	)	.	tolist	(	)	

idx	=	(	idx	,	)	


elif	all	(	[	isinstance	(	i	,	(	tuple	,	list	)	)	for	i	in	idx	]	)	:	
plottype	=	"str"	
all_plot_groups	=	np	.	unique	(	[	tt	for	t	in	idx	for	tt	in	t	]	)	.	tolist	(	)	
widthratio	=	[	len	(	ii	)	for	ii	in	idx	]	
if	[	True	for	i	in	widthratio	if	i	>	2	]	:	
paired	=	False	
float_contrast	=	False	

ncols	=	len	(	idx	)	
ngroups	=	len	(	all_plot_groups	)	


else	:	
err	=	"str"	
"str"	.	format	(	idx	)	
raise	ValueError	(	err	)	



if	(	color_col	is	not	None	)	and	(	color_col	not	in	data_in	.	columns	)	:	
err	=	"str"	.	join	(	[	"str"	,	
"str"	.	format	(	color_col	)	]	)	
raise	IndexError	(	err	)	

if	x	is	None	and	y	is	not	None	:	
err	=	"str"	
raise	ValueError	(	err	)	

elif	y	is	None	and	x	is	not	None	:	
err	=	"str"	
raise	ValueError	(	err	)	

elif	x	is	not	None	and	y	is	not	None	:	


if	x	not	in	data_in	.	columns	:	
err	=	"str"	.	format	(	x	)	
raise	IndexError	(	err	)	
if	y	not	in	data_in	.	columns	:	
err	=	"str"	.	format	(	y	)	
raise	IndexError	(	err	)	

if	not	np	.	issubdtype	(	data_in	[	y	]	.	dtype	,	np	.	number	)	:	
err	=	"str"	.	format	(	y	)	
raise	ValueError	(	err	)	

for	g	in	all_plot_groups	:	
if	g	not	in	data_in	[	x	]	.	unique	(	)	:	
raise	IndexError	(	"str"	.	format	(	g	,	x	)	)	

elif	x	is	None	and	y	is	None	:	


for	g	in	all_plot_groups	:	
if	g	not	in	data_in	.	columns	:	
raise	IndexError	(	"str"	.	format	(	g	)	)	



x	=	"str"	
if	swarm_label	is	None	:	
y	=	"str"	
else	:	
y	=	str	(	swarm_label	)	


if	color_col	is	None	:	
idv	=	[	"str"	]	
turn_to_cat	=	[	x	]	
data_in	=	data_in	[	all_plot_groups	]	.	copy	(	)	
else	:	
idv	=	[	"str"	,	color_col	]	
turn_to_cat	=	[	x	,	color_col	]	
plot_groups_with_color	=	unpack_and_add	(	all_plot_groups	,	color_col	)	
data_in	=	data_in	[	plot_groups_with_color	]	.	copy	(	)	

data_in	=	pd	.	melt	(	data_in	.	reset_index	(	)	,	
id_vars	=	idv	,	
value_vars	=	all_plot_groups	,	
value_name	=	y	,	
var_name	=	x	)	

for	c	in	turn_to_cat	:	
data_in	.	loc	[	:	,	c	]	=	pd	.	Categorical	(	data_in	[	c	]	,	
categories	=	data_in	[	c	]	.	unique	(	)	,	
ordered	=	True	)	



default_swarmplot_kwargs	=	{	"str"	:	raw_marker_size	}	
if	swarmplot_kwargs	is	None	:	
swarmplot_kwargs	=	default_swarmplot_kwargs	
else	:	
swarmplot_kwargs	=	merge_two_dicts	(	default_swarmplot_kwargs	,	
swarmplot_kwargs	)	



default_violinplot_kwargs	=	{	"str"	:	0.5	,	"str"	:	True	,	
"str"	:	False	,	"str"	:	False	}	
if	violinplot_kwargs	is	None	:	
violinplot_kwargs	=	default_violinplot_kwargs	
else	:	
violinplot_kwargs	=	merge_two_dicts	(	default_violinplot_kwargs	,	
violinplot_kwargs	)	



default_reflines_kwargs	=	{	"str"	:	"str"	,	"str"	:	0.75	,	
"str"	:	"str"	}	
if	reflines_kwargs	is	None	:	
reflines_kwargs	=	default_reflines_kwargs	
else	:	
reflines_kwargs	=	merge_two_dicts	(	default_reflines_kwargs	,	
reflines_kwargs	)	



default_legend_kwargs	=	{	"str"	:	"str"	,	"str"	:	False	,	
"str"	:	(	0.95	,	1.	)	,	"str"	:	2	}	
if	legend_kwargs	is	None	:	
legend_kwargs	=	default_legend_kwargs	
else	:	
legend_kwargs	=	merge_two_dicts	(	default_legend_kwargs	,	legend_kwargs	)	



default_aesthetic_kwargs	=	{	"str"	:	plot_context	,	"str"	:	"str"	,	
"str"	:	font_scale	,	
"str"	:	{	"str"	:	1	}	}	
if	aesthetic_kwargs	is	None	:	
aesthetic_kwargs	=	default_aesthetic_kwargs	
else	:	
aesthetic_kwargs	=	merge_two_dicts	(	default_aesthetic_kwargs	,	
aesthetic_kwargs	)	



if	paired	is	False	:	
show_pairs	=	False	

gs_default	=	{	"str"	,	"str"	,	"str"	}	
if	group_summaries	not	in	{	"str"	,	"str"	,	"str"	}	:	
raise	ValueError	(	"str"	
"str"	.	format	(	gs_default	)	)	

default_group_summary_kwargs	=	{	"str"	:	5	,	"str"	:	2	,	
"str"	:	"str"	,	"str"	:	1	}	
if	group_summary_kwargs	is	None	:	
group_summary_kwargs	=	default_group_summary_kwargs	
else	:	
group_summary_kwargs	=	merge_two_dicts	(	default_group_summary_kwargs	,	
group_summary_kwargs	)	


_es	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
labels	=	[	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	]	
if	effect_size	not	in	_es	:	
err1	=	"str"	.	format	(	effect_size	)	
err2	=	"str"	.	format	(	_es	)	
raise	ValueError	(	err1	+	err2	)	
if	effect_size	in	[	"str"	,	"str"	,	"str"	]	:	
float_contrast	=	False	
dict_effect_size_label	=	dict	(	zip	(	_es	,	labels	)	)	
effect_size_label	=	dict_effect_size_label	[	effect_size	]	



if	float_contrast	is	True	and	group_summaries	!=	"str"	:	
group_summaries	=	"str"	


if	ci	<	0	or	ci	>	100	:	
raise	ValueError	(	"str"	)	
alpha_level	=	(	100.	-	int	(	ci	)	)	/	100.	


if	swarm_ylim	is	None	:	

pad	=	data_in	[	y	]	.	diff	(	)	.	abs	(	)	.	min	(	)	*	2	
if	pad	<	3	:	
pad	=	3	
swarm_ylim	=	(	np	.	floor	(	data_in	[	y	]	.	min	(	)	-	pad	)	,	
np	.	ceil	(	data_in	[	y	]	.	max	(	)	+	pad	)	)	



if	float_contrast	is	False	:	
hs	=	cumming_vertical_spacing	
else	:	
hs	=	0	


if	color_col	is	None	:	
legend_xspan	=	0	
else	:	
legend_xspan	=	1.5	

if	float_contrast	is	True	:	
height_inches	=	4	
width_inches	=	3.5	*	ncols	+	legend_xspan	
else	:	
height_inches	=	6	
width_inches	=	1.5	*	ngroups	+	legend_xspan	



fsize	=	(	width_inches	,	height_inches	)	
if	fig_size	is	None	:	
fig_size	=	fsize	



if	color_col	is	None	:	
color_groups	=	data_in	[	x	]	.	unique	(	)	
else	:	
color_groups	=	data_in	[	color_col	]	.	unique	(	)	

if	custom_palette	is	None	:	
plotPal	=	dict	(	zip	(	color_groups	,	
sns	.	color_palette	(	n_colors	=	len	(	color_groups	)	)	
)	
)	
else	:	
if	isinstance	(	custom_palette	,	dict	)	:	


col_grps	=	{	k	for	k	in	color_groups	}	
pal_grps	=	{	k	for	k	in	custom_palette	.	keys	(	)	}	
not_in_pal	=	pal_grps	.	difference	(	col_grps	)	
if	len	(	not_in_pal	)	>	0	:	
err1	=	"str"	.	format	(	not_in_pal	)	
err2	=	"str"	.	format	(	color_col	)	
errstring	=	(	err1	+	err2	)	
raise	IndexError	(	errstring	)	
plotPal	=	custom_palette	

elif	isinstance	(	custom_palette	,	list	)	:	
n_groups	=	len	(	color_groups	)	
plotPal	=	dict	(	zip	(	color_groups	,	custom_palette	[	0	:	n_groups	]	)	)	

elif	isinstance	(	custom_palette	,	str	)	:	

if	custom_palette	in	mpl	.	pyplot	.	colormaps	(	)	:	
plotPal	=	custom_palette	
else	:	
err1	=	"str"	.	format	(	custom_palette	)	
err2	=	"str"	
raise	ValueError	(	err1	+	err2	)	



legend_handles	=	[	]	
legend_labels	=	[	]	



bootlist	=	list	(	)	




sns	.	set	(	*	*	aesthetic_kwargs	)	

if	float_contrast	is	True	:	
fig	,	axx	=	plt	.	subplots	(	ncols	=	ncols	,	figsize	=	fig_size	,	dpi	=	dpi	,	
gridspec_kw	=	{	"str"	:	widthratio	,	
"str"	:	1.	}	)	

else	:	
fig	,	axx	=	plt	.	subplots	(	ncols	=	ncols	,	nrows	=	2	,	figsize	=	fig_size	,	dpi	=	dpi	,	
gridspec_kw	=	{	"str"	:	widthratio	,	
"str"	:	0	}	)	



contrast_ax_ylim_low	=	list	(	)	
contrast_ax_ylim_high	=	list	(	)	
contrast_ax_ylim_tickintervals	=	list	(	)	



for	j	,	current_tuple	in	enumerate	(	idx	)	:	
plotdat	=	data_in	[	data_in	[	x	]	.	isin	(	current_tuple	)	]	.	copy	(	)	
plotdat	.	loc	[	:	,	x	]	=	pd	.	Categorical	(	plotdat	[	x	]	,	
categories	=	current_tuple	,	
ordered	=	True	)	
plotdat	.	sort_values	(	by	=	[	x	]	)	

counts	=	plotdat	.	groupby	(	x	)	[	y	]	.	count	(	)	

if	float_contrast	is	True	:	
if	ncols	==	1	:	
ax_raw	=	axx	
else	:	
ax_raw	=	axx	[	j	]	
ax_contrast	=	ax_raw	.	twinx	(	)	
else	:	
if	ncols	==	1	:	
ax_raw	=	axx	[	0	]	
ax_contrast	=	axx	[	1	]	
else	:	
ax_raw	=	axx	[	0	,	j	]	
ax_contrast	=	axx	[	1	,	j	]	











if	(	paired	is	True	and	show_pairs	is	True	)	:	

if	len	(	current_tuple	)	!=	2	:	
err1	=	"str"	
err2	=	"str"	.	format	(	current_tuple	)	
raise	ValueError	(	err1	+	err2	)	


before	=	plotdat	[	plotdat	[	x	]	==	current_tuple	[	0	]	]	[	y	]	.	dropna	(	)	.	tolist	(	)	
after	=	plotdat	[	plotdat	[	x	]	==	current_tuple	[	1	]	]	[	y	]	.	dropna	(	)	.	tolist	(	)	
if	len	(	before	)	!=	len	(	after	)	:	
err1	=	"str"	.	format	(	current_tuple	[	0	]	)	
err2	=	"str"	.	format	(	current_tuple	[	1	]	)	
raise	ValueError	(	err1	+	err2	)	

if	color_col	is	not	None	:	
colors	=	plotdat	[	plotdat	[	x	]	==	current_tuple	[	0	]	]	[	color_col	]	
else	:	
plotPal	[	"str"	]	=	(	0.	,	0.	,	0.	)	
colors	=	np	.	repeat	(	"str"	,	len	(	before	)	)	
linedf	=	pd	.	DataFrame	(	{	str	(	current_tuple	[	0	]	)	:	before	,	
str	(	current_tuple	[	1	]	)	:	after	,	
"str"	:	colors	}	)	


for	ii	in	linedf	.	index	:	
ax_raw	.	plot	(	[	0	,	1	]	,	
[	linedf	.	loc	[	ii	,	current_tuple	[	0	]	]	,	
linedf	.	loc	[	ii	,	current_tuple	[	1	]	]	]	,	
linestyle	=	"str"	,	linewidth	=	1	,	
color	=	plotPal	[	linedf	.	loc	[	ii	,	"str"	]	]	,	
label	=	linedf	.	loc	[	ii	,	"str"	]	)	
ax_raw	.	set_xticks	(	[	0	,	1	]	)	
ax_raw	.	set_xlim	(	-	0.25	,	1.5	)	
ax_raw	.	set_xticklabels	(	[	current_tuple	[	0	]	,	current_tuple	[	1	]	]	)	
swarm_ylim	=	ax_raw	.	get_ylim	(	)	

elif	(	paired	is	True	and	show_pairs	is	False	)	or	(	paired	is	False	)	:	

if	swarm_ylim	is	not	None	:	
ax_raw	.	set_ylim	(	swarm_ylim	)	
sns	.	swarmplot	(	data	=	plotdat	,	x	=	x	,	y	=	y	,	ax	=	ax_raw	,	
order	=	current_tuple	,	hue	=	color_col	,	
palette	=	plotPal	,	zorder	=	3	,	*	*	swarmplot_kwargs	)	
if	swarm_ylim	is	None	:	
swarm_ylim	=	ax_raw	.	get_ylim	(	)	

if	group_summaries	!=	"str"	:	

xspans	=	[	]	
for	jj	,	c	in	enumerate	(	ax_raw	.	collections	)	:	
try	:	
_	,	x_max	,	_	,	_	=	get_swarm_spans	(	c	)	
x_max_span	=	x_max	-	jj	
xspans	.	append	(	x_max_span	)	
except	TypeError	:	

pass	
gapped_lines	(	plotdat	,	x	=	x	,	y	=	y	,	

offset	=	np	.	max	(	xspans	)	+	0.1	,	
type	=	group_summaries	,	
ax	=	ax_raw	,	*	*	group_summary_kwargs	)	

ax_raw	.	set_xlabel	(	"str"	)	





xticklabels	=	list	(	)	

for	xticklab	in	ax_raw	.	xaxis	.	get_ticklabels	(	)	:	
t	=	xticklab	.	get_text	(	)	
N	=	str	(	counts	.	ix	[	t	]	)	
if	show_group_count	:	
xticklabels	.	append	(	t	+	"str"	+	N	)	
else	:	
xticklabels	.	append	(	t	)	
if	float_contrast	is	True	:	
ax_raw	.	set_xticklabels	(	xticklabels	,	rotation	=	45	,	
horizontalalignment	=	"str"	)	



if	float_contrast	:	
sns	.	despine	(	ax	=	ax_raw	,	trim	=	True	)	
else	:	
ax_raw	.	xaxis	.	set_visible	(	False	)	
not_first_ax	=	(	j	!=	0	)	
sns	.	despine	(	ax	=	ax_raw	,	bottom	=	True	,	left	=	not_first_ax	,	trim	=	True	)	
if	not_first_ax	:	
ax_raw	.	yaxis	.	set_visible	(	False	)	



handles	,	labels	=	ax_raw	.	get_legend_handles_labels	(	)	
for	l	in	labels	:	
legend_labels	.	append	(	l	)	
for	h	in	handles	:	
legend_handles	.	append	(	h	)	
if	color_col	is	not	None	:	
ax_raw	.	legend	(	)	.	set_visible	(	False	)	

if	j	+	1	==	ncols	:	
last_swarm	=	ax_raw	



ref	=	np	.	array	(	plotdat	[	plotdat	[	x	]	==	current_tuple	[	0	]	]	[	y	]	.	dropna	(	)	)	
for	ix	,	grp	in	enumerate	(	current_tuple	[	1	:	]	)	:	

if	float_contrast	is	True	:	
if	paired	is	True	and	show_pairs	is	True	:	
spacer	=	0.5	
else	:	
spacer	=	0.75	
else	:	
spacer	=	0	
pos	=	ix	+	spacer	


exp	=	np	.	array	(	plotdat	[	plotdat	[	x	]	==	grp	]	[	y	]	.	dropna	(	)	)	
results	=	difference_ci	(	ref	,	exp	,	is_paired	=	paired	,	
alpha	=	alpha_level	,	resamples	=	n_boot	,	
random_seed	=	random_seed	)	
res	=	{	}	
res	[	"str"	]	=	current_tuple	[	0	]	
res	[	"str"	]	=	grp	


for	_es_	in	results	.	index	:	
res	[	_es_	]	=	results	.	loc	[	_es_	,	"str"	]	

es_ci_low	=	"str"	.	format	(	_es_	)	
res	[	es_ci_low	]	=	results	.	loc	[	_es_	,	"str"	]	

es_ci_high	=	"str"	.	format	(	_es_	)	
res	[	es_ci_high	]	=	results	.	loc	[	_es_	,	"str"	]	

es_bootstraps	=	"str"	.	format	(	_es_	)	
res	[	es_bootstraps	]	=	results	.	loc	[	_es_	,	"str"	]	

if	paired	:	
res	[	"str"	]	=	True	
res	[	"str"	]	=	ttest_rel	(	ref	,	exp	)	.	pvalue	
res	[	"str"	]	=	mannwhitneyu	(	ref	,	exp	)	.	pvalue	
else	:	
res	[	"str"	]	=	False	
res	[	"str"	]	=	ttest_ind	(	ref	,	exp	)	.	pvalue	
res	[	"str"	]	=	wilcoxon	(	ref	,	exp	)	.	pvalue	

bootlist	.	append	(	res	)	


bootstraps	=	res	[	"str"	.	format	(	effect_size	)	]	
es	=	res	[	effect_size	]	
ci_low	=	res	[	"str"	.	format	(	effect_size	)	]	
ci_high	=	res	[	"str"	.	format	(	effect_size	)	]	


v	=	ax_contrast	.	violinplot	(	bootstraps	,	positions	=	[	pos	+	1	]	,	
*	*	violinplot_kwargs	)	
halfviolin	(	v	)	

ax_contrast	.	plot	(	[	pos	+	1	]	,	es	,	marker	=	"str"	,	color	=	"str"	,	
markersize	=	es_marker_size	)	

ax_contrast	.	plot	(	[	pos	+	1	,	pos	+	1	]	,	[	ci_low	,	ci_high	]	,	
"str"	,	linewidth	=	group_summary_kwargs	[	"str"	]	)	

if	float_contrast	is	False	:	
l	,	h	=	ax_contrast	.	get_ylim	(	)	
contrast_ax_ylim_low	.	append	(	l	)	
contrast_ax_ylim_high	.	append	(	h	)	
ticklocs	=	ax_contrast	.	yaxis	.	get_majorticklocs	(	)	
new_interval	=	ticklocs	[	1	]	-	ticklocs	[	0	]	
contrast_ax_ylim_tickintervals	.	append	(	new_interval	)	

if	float_contrast	is	False	:	
ax_contrast	.	set_xlim	(	ax_raw	.	get_xlim	(	)	)	
ax_contrast	.	set_xticks	(	ax_raw	.	get_xticks	(	)	)	
ax_contrast	.	set_xticklabels	(	xticklabels	,	rotation	=	45	,	
horizontalalignment	=	"str"	)	

else	:	
if	effect_size	==	"str"	:	
_e	=	np	.	mean	(	exp	)	
elif	effect_size	==	"str"	:	
_e	=	np	.	median	(	exp	)	



min_check	=	swarm_ylim	[	0	]	-	_e	
max_check	=	swarm_ylim	[	1	]	-	_e	
if	(	min_check	<	=	es	<	=	max_check	)	==	False	:	
err1	=	"str"	.	format	(	_e	)	
err2	=	"str"	.	format	(	swarm_ylim	)	
err3	=	"str"	
err4	=	"str"	
err	=	err1	+	err2	+	err3	+	err4	
raise	ValueError	(	err	)	


ylimlow	,	ylimhigh	=	ax_contrast	.	get_xlim	(	)	
ax_contrast	.	set_xlim	(	ylimlow	,	ylimhigh	+	spacer	)	


if	es	>	0	:	
rightmin	,	rightmax	=	np	.	array	(	ax_raw	.	get_ylim	(	)	)	-	es	

elif	es	<	0	:	
rightmin	,	rightmax	=	np	.	array	(	ax_raw	.	get_ylim	(	)	)	+	es	

ax_contrast	.	set_ylim	(	rightmin	,	rightmax	)	


align_yaxis	(	ax_raw	,	_e	,	ax_contrast	,	es	)	


xlimlow	,	xlimhigh	=	ax_contrast	.	get_xlim	(	)	
ax_contrast	.	hlines	(	0	,	
0	,	xlimhigh	,	
*	*	reflines_kwargs	)	


ax_contrast	.	hlines	(	es	,	
1	,	xlimhigh	,	
*	*	reflines_kwargs	)	



lower	=	bootstraps	.	min	(	)	
upper	=	bootstraps	.	max	(	)	


if	lower	>	0	:	
lower	=	0.	
if	upper	<	0	:	
upper	=	0.	


leftticks	=	ax_contrast	.	get_yticks	(	)	
tickstep	=	leftticks	[	1	]	-	leftticks	[	0	]	


new_locator	=	tk	.	MultipleLocator	(	base	=	tickstep	)	
ax_contrast	.	yaxis	.	set_major_locator	(	new_locator	)	
newticks1	=	ax_contrast	.	get_yticks	(	)	


newticks2	=	list	(	)	
for	a	,	b	in	enumerate	(	newticks1	)	:	
if	(	b	>	=	lower	and	b	<	=	upper	)	:	

newticks2	.	append	(	b	)	



if	np	.	max	(	newticks2	)	<	es	:	

ind	=	np	.	where	(	newticks1	==	np	.	max	(	newticks2	)	)	[	0	]	[	0	]	
newticks2	.	append	(	newticks1	[	ind	+	1	]	)	
elif	es	<	np	.	min	(	newticks2	)	:	

ind	=	np	.	where	(	newticks1	==	np	.	min	(	newticks2	)	)	[	0	]	[	0	]	
newticks2	.	append	(	newticks1	[	ind	-	1	]	)	
newticks2	=	np	.	array	(	newticks2	)	
newticks2	.	sort	(	)	


locc	=	tk	.	FixedLocator	(	locs	=	newticks2	)	
ax_contrast	.	yaxis	.	set_major_locator	(	locc	)	


sns	.	despine	(	ax	=	ax_contrast	,	trim	=	True	,	

left	=	True	,	bottom	=	True	,	

right	=	False	)	



if	j	>	0	:	
ax_raw	.	set_ylabel	(	"str"	,	labelpad	=	tick_length	)	
else	:	
ax_raw	.	set_ylabel	(	y	,	labelpad	=	tick_length	)	

if	float_contrast	is	False	:	
if	j	>	0	:	
ax_contrast	.	set_ylabel	(	"str"	,	labelpad	=	tick_length	)	
else	:	
if	contrast_label	is	None	:	
if	paired	:	
ax_contrast	.	set_ylabel	(	"str"	+	effect_size_label	,	
labelpad	=	tick_length	)	
else	:	
ax_contrast	.	set_ylabel	(	effect_size_label	,	
labelpad	=	tick_length	)	
else	:	
ax_contrast	.	set_ylabel	(	str	(	contrast_label	)	,	
labelpad	=	tick_length	)	


rotate_ticks	(	ax_contrast	,	angle	=	45	,	alignment	=	"str"	)	



if	float_contrast	is	False	:	

contrast_ax_ylim_low	=	np	.	sort	(	contrast_ax_ylim_low	)	
contrast_ax_ylim_high	=	np	.	sort	(	contrast_ax_ylim_high	)	
contrast_ax_ylim_tickintervals	=	np	.	sort	(	contrast_ax_ylim_tickintervals	)	


if	contrast_ylim	is	None	:	
normYlim	=	(	contrast_ax_ylim_low	[	0	]	,	contrast_ax_ylim_high	[	-	1	]	)	
else	:	
normYlim	=	contrast_ylim	


for	i	in	range	(	ncols	,	ncols	*	2	,	1	)	:	

axx	=	fig	.	get_axes	(	)	[	i	]	


axx	.	set_ylim	(	normYlim	[	0	]	,	normYlim	[	1	]	)	


if	normYlim	[	0	]	<	0.	and	0.	<	normYlim	[	1	]	:	
axx	.	axhline	(	y	=	0	,	lw	=	0.5	,	color	=	"str"	)	


if	i	>	ncols	:	
axx	.	get_yaxis	(	)	.	set_visible	(	False	)	
sns	.	despine	(	ax	=	axx	,	left	=	True	,	trim	=	True	)	
else	:	

sns	.	despine	(	ax	=	axx	,	trim	=	True	)	



if	color_col	is	not	None	:	
legend_labels_unique	=	np	.	unique	(	legend_labels	)	
unique_idx	=	np	.	unique	(	legend_labels	,	return_index	=	True	)	[	1	]	
legend_handles_unique	=	(	pd	.	Series	(	legend_handles	)	.	loc	[	unique_idx	]	)	.	tolist	(	)	
leg	=	last_swarm	.	legend	(	legend_handles_unique	,	legend_labels_unique	,	
*	*	legend_kwargs	)	

if	paired	is	True	and	show_pairs	is	True	:	
for	line	in	leg	.	get_lines	(	)	:	
line	.	set_linewidth	(	3.0	)	



bootlist_df	=	pd	.	DataFrame	(	bootlist	)	



cols	=	bootlist_df	.	columns	.	tolist	(	)	

move_to_front	=	[	"str"	,	"str"	,	"str"	]	
mean_diff_cols	=	[	"str"	,	"str"	,	
"str"	,	"str"	]	
for	c	in	move_to_front	+	mean_diff_cols	:	
cols	.	remove	(	c	)	
new_order_cols	=	move_to_front	+	mean_diff_cols	+	cols	
bootlist_df	=	bootlist_df	[	new_order_cols	]	


bootlist_df	=	bootlist_df	.	replace	(	to_replace	=	"str"	,	
value	=	np	.	nan	)	.	dropna	(	axis	=	1	)	



sns	.	set	(	)	



if	swarm_label	is	not	None	:	
fig	.	axes	[	0	]	.	set_ylabel	(	swarm_label	)	



for	ax	in	fig	.	axes	:	
ax	.	tick_params	(	length	=	tick_length	,	pad	=	tick_pad	,	width	=	1	)	



for	ax	in	fig	.	axes	:	
ax	.	patch	.	set_visible	(	False	)	



return	fig	,	bootlist_df	
	