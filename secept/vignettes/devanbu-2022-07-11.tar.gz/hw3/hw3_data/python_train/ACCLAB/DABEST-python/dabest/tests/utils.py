def	create_demo_dataset	(	seed	=	9999	,	N	=	20	)	:	

import	numpy	as	np	
import	pandas	as	pd	
from	scipy	.	stats	import	norm	

np	.	random	.	seed	(	9999	)	



c1	=	norm	.	rvs	(	loc	=	3	,	scale	=	0.4	,	size	=	N	)	
c2	=	norm	.	rvs	(	loc	=	3.5	,	scale	=	0.75	,	size	=	N	)	
c3	=	norm	.	rvs	(	loc	=	3.25	,	scale	=	0.4	,	size	=	N	)	

t1	=	norm	.	rvs	(	loc	=	3.5	,	scale	=	0.5	,	size	=	N	)	
t2	=	norm	.	rvs	(	loc	=	2.5	,	scale	=	0.6	,	size	=	N	)	
t3	=	norm	.	rvs	(	loc	=	3	,	scale	=	0.75	,	size	=	N	)	
t4	=	norm	.	rvs	(	loc	=	3.5	,	scale	=	0.75	,	size	=	N	)	
t5	=	norm	.	rvs	(	loc	=	3.25	,	scale	=	0.4	,	size	=	N	)	
t6	=	norm	.	rvs	(	loc	=	3.25	,	scale	=	0.4	,	size	=	N	)	



females	=	np	.	repeat	(	"str"	,	N	/	2	)	.	tolist	(	)	
males	=	np	.	repeat	(	"str"	,	N	/	2	)	.	tolist	(	)	
gender	=	females	+	males	


id_col	=	pd	.	Series	(	range	(	1	,	N	+	1	)	)	


df	=	pd	.	DataFrame	(	{	"str"	:	c1	,	"str"	:	t1	,	
"str"	:	c2	,	"str"	:	t2	,	
"str"	:	c3	,	"str"	:	t3	,	
"str"	:	t4	,	"str"	:	t5	,	"str"	:	t6	,	
"str"	:	gender	,	"str"	:	id_col	
}	)	

return	df	



def	get_swarm_yspans	(	coll	,	round_result	=	False	,	decimals	=	12	)	:	

import	numpy	as	np	
_	,	y	=	np	.	array	(	coll	.	get_offsets	(	)	)	.	T	
try	:	
if	round_result	:	
return	np	.	around	(	y	.	min	(	)	,	decimals	)	,	np	.	around	(	y	.	max	(	)	,	decimals	)	
else	:	
return	y	.	min	(	)	,	y	.	max	(	)	
except	ValueError	:	
return	None	













































	