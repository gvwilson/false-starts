





from	__future__	import	division	


class	bootstrap	:	

def	__init__	(	self	,	x1	,	x2	=	None	,	
paired	=	False	,	
statfunction	=	None	,	
smoothboot	=	False	,	
alpha_level	=	0.05	,	
reps	=	5000	)	:	

import	numpy	as	np	
import	pandas	as	pd	
import	seaborn	as	sns	

from	scipy	.	stats	import	norm	
from	numpy	.	random	import	randint	
from	scipy	.	stats	import	ttest_1samp	,	ttest_ind	,	ttest_rel	
from	scipy	.	stats	import	mannwhitneyu	,	wilcoxon	,	norm	
import	warnings	


x1	=	pd	.	Series	(	x1	)	.	dropna	(	)	
diff	=	False	


if	statfunction	==	None	:	
statfunction	=	np	.	mean	


if	alpha_level	>	1.	or	alpha_level	<	0.	:	
raise	ValueError	(	"str"	)	
alphas	=	np	.	array	(	[	alpha_level	/	2.	,	1	-	alpha_level	/	2.	]	)	

sns_bootstrap_kwargs	=	{	"str"	:	statfunction	,	
"str"	:	reps	,	
"str"	:	smoothboot	}	

if	paired	:	

if	x2	is	None	:	
raise	ValueError	(	"str"	)	
else	:	
x2	=	pd	.	Series	(	x2	)	.	dropna	(	)	
if	len	(	x1	)	!=	len	(	x2	)	:	
raise	ValueError	(	"str"	)	

if	(	x2	is	None	)	or	(	paired	is	True	)	:	

if	x2	is	None	:	
tx	=	x1	
paired	=	False	
ttest_single	=	ttest_1samp	(	x1	,	0	)	[	1	]	
ttest_2_ind	=	"str"	
ttest_2_paired	=	"str"	
wilcoxonresult	=	"str"	

elif	paired	is	True	:	
diff	=	True	
tx	=	x2	-	x1	
ttest_single	=	"str"	
ttest_2_ind	=	"str"	
ttest_2_paired	=	ttest_rel	(	x1	,	x2	)	[	1	]	
wilcoxonresult	=	wilcoxon	(	x1	,	x2	)	[	1	]	
mannwhitneyresult	=	"str"	


tdata	=	(	tx	,	)	



summ_stat	=	statfunction	(	*	tdata	)	
statarray	=	sns	.	algorithms	.	bootstrap	(	tx	,	*	*	sns_bootstrap_kwargs	)	
statarray	.	sort	(	)	


pct_low_high	=	np	.	round	(	(	reps	-	1	)	*	alphas	)	
pct_low_high	=	np	.	nan_to_num	(	pct_low_high	)	.	astype	(	"str"	)	


elif	x2	is	not	None	and	paired	is	False	:	
diff	=	True	
x2	=	pd	.	Series	(	x2	)	.	dropna	(	)	

ref_statarray	=	sns	.	algorithms	.	bootstrap	(	x1	,	*	*	sns_bootstrap_kwargs	)	
exp_statarray	=	sns	.	algorithms	.	bootstrap	(	x2	,	*	*	sns_bootstrap_kwargs	)	

tdata	=	exp_statarray	-	ref_statarray	
statarray	=	tdata	.	copy	(	)	
statarray	.	sort	(	)	
tdata	=	(	tdata	,	)	


summ_stat	=	statfunction	(	x2	)	-	statfunction	(	x1	)	


pct_low_high	=	np	.	round	(	(	reps	-	1	)	*	alphas	)	
pct_low_high	=	np	.	nan_to_num	(	pct_low_high	)	.	astype	(	"str"	)	


ttest_single	=	"str"	
ttest_2_ind	=	ttest_ind	(	x1	,	x2	)	[	1	]	
ttest_2_paired	=	"str"	
mannwhitneyresult	=	mannwhitneyu	(	x1	,	x2	,	alternative	=	"str"	)	[	1	]	
wilcoxonresult	=	"str"	


bca_low_high	=	bca	(	tdata	,	alphas	,	statarray	,	
statfunction	,	summ_stat	,	reps	)	


for	ind	in	[	pct_low_high	,	bca_low_high	]	:	
if	np	.	any	(	ind	==	0	)	or	np	.	any	(	ind	==	reps	-	1	)	:	
warnings	.	warn	(	"str"	
"str"	)	
elif	np	.	any	(	ind	<	10	)	or	np	.	any	(	ind	>	=	reps	-	10	)	:	
warnings	.	warn	(	"str"	
"str"	)	

self	.	summary	=	summ_stat	
self	.	is_paired	=	paired	
self	.	is_difference	=	diff	
self	.	statistic	=	str	(	statfunction	)	
self	.	n_reps	=	reps	

self	.	ci	=	(	1	-	alpha_level	)	*	100	
self	.	stat_array	=	np	.	array	(	statarray	)	

self	.	pct_ci_low	=	statarray	[	pct_low_high	[	0	]	]	
self	.	pct_ci_high	=	statarray	[	pct_low_high	[	1	]	]	
self	.	pct_low_high_indices	=	pct_low_high	

self	.	bca_ci_low	=	statarray	[	bca_low_high	[	0	]	]	
self	.	bca_ci_high	=	statarray	[	bca_low_high	[	1	]	]	
self	.	bca_low_high_indices	=	bca_low_high	

self	.	pvalue_1samp_ttest	=	ttest_single	
self	.	pvalue_2samp_ind_ttest	=	ttest_2_ind	
self	.	pvalue_2samp_paired_ttest	=	ttest_2_paired	
self	.	pvalue_wilcoxon	=	wilcoxonresult	
self	.	pvalue_mann_whitney	=	mannwhitneyresult	

self	.	results	=	{	"str"	:	self	.	summary	,	
"str"	:	diff	,	
"str"	:	paired	,	
"str"	:	self	.	bca_ci_low	,	
"str"	:	self	.	bca_ci_high	,	
"str"	:	self	.	ci	
}	

def	__repr__	(	self	)	:	
import	numpy	as	np	

if	"str"	in	self	.	statistic	:	
stat	=	"str"	
elif	"str"	in	self	.	statistic	:	
stat	=	"str"	
else	:	
stat	=	self	.	statistic	

diff_types	=	{	True	:	"str"	,	False	:	"str"	}	
if	self	.	is_difference	:	
a	=	"str"	.	format	(	diff_types	[	self	.	is_paired	]	,	
stat	,	self	.	summary	)	
else	:	
a	=	"str"	.	format	(	stat	,	self	.	summary	)	

b	=	"str"	.	format	(	self	.	ci	,	self	.	bca_ci_low	,	self	.	bca_ci_high	)	
return	"str"	.	join	(	[	a	,	b	]	)	

def	jackknife_indexes	(	data	)	:	


import	numpy	as	np	

base	=	np	.	arange	(	0	,	len	(	data	)	)	
return	(	np	.	delete	(	base	,	i	)	for	i	in	base	)	

def	bca	(	data	,	alphas	,	statarray	,	statfunction	,	ostat	,	reps	)	:	

import	warnings	

import	numpy	as	np	
import	pandas	as	pd	
import	seaborn	as	sns	

from	scipy	.	stats	import	norm	
from	numpy	.	random	import	randint	


z0	=	norm	.	ppf	(	(	1.0	*	np	.	sum	(	statarray	<	ostat	,	axis	=	0	)	)	/	reps	)	


jackindexes	=	jackknife_indexes	(	data	[	0	]	)	
jstat	=	[	statfunction	(	*	(	x	[	indexes	]	for	x	in	data	)	)	
for	indexes	in	jackindexes	]	
jmean	=	np	.	mean	(	jstat	,	axis	=	0	)	


a	=	np	.	divide	(	np	.	sum	(	(	jmean	-	jstat	)	*	*	3	,	axis	=	0	)	,	
(	6.0	*	np	.	sum	(	(	jmean	-	jstat	)	*	*	2	,	axis	=	0	)	*	*	1.5	)	
)	
if	np	.	any	(	np	.	isnan	(	a	)	)	:	
nanind	=	np	.	nonzero	(	np	.	isnan	(	a	)	)	
warnings	.	warn	(	"str"	
"str"	
"str"	
"str"	
"str"	.	format	(	nanind	)	)	
zs	=	z0	+	norm	.	ppf	(	alphas	)	.	reshape	(	alphas	.	shape	+	(	1	,	)	*	z0	.	ndim	)	
avals	=	norm	.	cdf	(	z0	+	zs	/	(	1	-	a	*	zs	)	)	
nvals	=	np	.	round	(	(	reps	-	1	)	*	avals	)	
nvals	=	np	.	nan_to_num	(	nvals	)	.	astype	(	"str"	)	

return	nvals	
	