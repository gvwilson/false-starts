





def	load	(	data	,	idx	,	x	=	None	,	y	=	None	,	paired	=	False	,	id_col	=	None	,	
ci	=	95	,	resamples	=	5000	,	random_seed	=	12345	)	:	

from		.	_classes	import	Dabest	

return	Dabest	(	data	,	idx	,	x	,	y	,	paired	,	id_col	,	ci	,	resamples	,	random_seed	)	
	