







def	merge_two_dicts	(	x	,	y	)	:	

z	=	x	.	copy	(	)	
z	.	update	(	y	)	
return	z	



def	unpack_and_add	(	l	,	c	)	:	

t	=	[	a	for	a	in	l	]	
t	.	append	(	c	)	
return	(	t	)	



def	print_greeting	(	)	:	
from		.	__init__	import	__version__	
import	datetime	as	dt	
import	numpy	as	np	

line1	=	"str"	.	format	(	__version__	)	
header	=	"str"	.	join	(	np	.	repeat	(	"str"	,	len	(	line1	)	)	)	
spacer	=	"str"	.	join	(	np	.	repeat	(	"str"	,	len	(	line1	)	)	)	

now	=	dt	.	datetime	.	now	(	)	
if	0	<	now	.	hour	<	12	:	
greeting	=	"str"	
elif	12	<	now	.	hour	<	18	:	
greeting	=	"str"	
else	:	
greeting	=	"str"	

current_time	=	"str"	.	format	(	now	.	ctime	(	)	)	

return	"str"	.	join	(	[	line1	,	header	,	spacer	,	greeting	,	current_time	]	)	


def	get_varname	(	obj	)	:	
matching_vars	=	[	k	for	k	,	v	in	globals	(	)	.	items	(	)	if	v	is	obj	]	
if	len	(	matching_vars	)	>	0	:	
return	matching_vars	[	0	]	
else	:	
return	"str"	
	