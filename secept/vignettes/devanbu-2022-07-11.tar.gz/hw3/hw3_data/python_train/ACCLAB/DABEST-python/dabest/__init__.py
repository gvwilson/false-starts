







from		.	_api	import	load	
from		.	_stats_tools	import	effsize	as	effsize	
from		.	_classes	import	TwoGroupsEffectSize	

__version__	=	"str"	
	