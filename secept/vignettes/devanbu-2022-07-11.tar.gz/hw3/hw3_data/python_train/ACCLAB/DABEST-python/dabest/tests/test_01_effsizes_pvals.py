





import	sys	
import	numpy	as	np	
import	scipy	as	sp	
import	pytest	
import	pandas	as	pd	
from		.		.	_stats_tools	import	effsize	
from		.		.	_classes	import	TwoGroupsEffectSize	







wb	=	{	"str"	:	[	34	,	54	,	33	,	44	,	45	,	53	,	37	,	26	,	38	,	58	]	,	
"str"	:	[	66	,	38	,	35	,	55	,	48	,	39	,	65	,	32	,	57	,	41	]	}	
wellbeing	=	pd	.	DataFrame	(	wb	)	




paired_wb	=	{	"str"	:	[	43	,	28	,	54	,	36	,	31	,	48	,	50	,	69	,	29	,	40	]	,	
"str"	:	[	51	,	33	,	58	,	42	,	39	,	45	,	54	,	68	,	35	,	44	]	}	
paired_wellbeing	=	pd	.	DataFrame	(	paired_wb	)	









likert_control	=	[	1	,	1	,	2	,	2	,	2	,	3	,	3	,	3	,	4	,	5	]	
likert_treatment	=	[	1	,	2	,	3	,	4	,	4	,	5	]	







a_scores	=	[	6	,	7	,	9	,	10	]	
b_scores	=	[	1	,	3	,	4	,	7	,	8	]	






def	test_mean_diff_unpaired	(	)	:	
import	numpy	as	np	
mean_diff	=	effsize	.	func_difference	(	wellbeing	.	control	,	wellbeing	.	expt	,	
np	.	mean	,	is_paired	=	False	)	
assert	mean_diff	==	pytest	.	approx	(	5.4	)	



def	test_median_diff_unpaired	(	)	:	
from	numpy	import	median	as	npmedian	
median_diff	=	effsize	.	func_difference	(	wellbeing	.	control	,	wellbeing	.	expt	,	
npmedian	,	is_paired	=	False	)	
assert	median_diff	==	pytest	.	approx	(	3.5	)	



def	test_mean_diff_paired	(	)	:	
from	numpy	import	mean	as	npmean	
mean_diff	=	effsize	.	func_difference	(	paired_wellbeing	.	pre	,	
paired_wellbeing	.	post	,	
npmean	,	is_paired	=	True	)	
assert	mean_diff	==	pytest	.	approx	(	4.10	)	



def	test_median_diff_paired	(	)	:	
from	numpy	import	median	as	npmedian	
median_diff	=	effsize	.	func_difference	(	paired_wellbeing	.	pre	,	
paired_wellbeing	.	post	,	
npmedian	,	is_paired	=	True	)	
assert	median_diff	==	pytest	.	approx	(	4.5	)	



def	test_cohens_d_unpaired	(	)	:	
import	numpy	as	np	
cohens_d	=	effsize	.	cohens_d	(	wellbeing	.	control	,	wellbeing	.	expt	,	
is_paired	=	False	)	
assert	np	.	round	(	cohens_d	,	2	)	==	pytest	.	approx	(	0.47	)	



def	test_hedges_g_unpaired	(	)	:	
import	numpy	as	np	
hedges_g	=	effsize	.	hedges_g	(	wellbeing	.	control	,	wellbeing	.	expt	,	
is_paired	=	False	)	
assert	np	.	round	(	hedges_g	,	2	)	==	pytest	.	approx	(	0.45	)	



def	test_cohens_d_paired	(	)	:	
import	numpy	as	np	
cohens_d	=	effsize	.	cohens_d	(	paired_wellbeing	.	pre	,	paired_wellbeing	.	post	,	
is_paired	=	True	)	
assert	np	.	round	(	cohens_d	,	2	)	==	pytest	.	approx	(	0.34	)	



def	test_hedges_g_paired	(	)	:	
import	numpy	as	np	
hedges_g	=	effsize	.	hedges_g	(	paired_wellbeing	.	pre	,	paired_wellbeing	.	post	,	
is_paired	=	True	)	
assert	np	.	round	(	hedges_g	,	2	)	==	pytest	.	approx	(	0.33	)	



def	test_cliffs_delta	(	)	:	
likert_delta	=	effsize	.	cliffs_delta	(	likert_treatment	,	likert_control	)	
assert	likert_delta	==	pytest	.	approx	(	-	0.25	)	

scores_delta	=	effsize	.	cliffs_delta	(	b_scores	,	a_scores	)	
assert	scores_delta	==	pytest	.	approx	(	0.65	)	



def	test_unpaired_stats	(	)	:	
c	=	wellbeing	.	control	
t	=	wellbeing	.	expt	

unpaired_es	=	TwoGroupsEffectSize	(	c	,	t	,	"str"	,	is_paired	=	False	)	

p1	=	sp	.	stats	.	mannwhitneyu	(	c	,	t	,	alternative	=	"str"	)	.	pvalue	
assert	unpaired_es	.	pvalue_mann_whitney	==	pytest	.	approx	(	p1	)	

p2	=	sp	.	stats	.	ttest_ind	(	c	,	t	,	nan_policy	=	"str"	)	.	pvalue	
assert	unpaired_es	.	pvalue_students_t	==	pytest	.	approx	(	p2	)	

p3	=	sp	.	stats	.	ttest_ind	(	c	,	t	,	equal_var	=	False	,	nan_policy	=	"str"	)	.	pvalue	
assert	unpaired_es	.	pvalue_welch	==	pytest	.	approx	(	p3	)	



def	test_paired_stats	(	)	:	
before	=	paired_wellbeing	.	pre	
after	=	paired_wellbeing	.	post	

paired_es	=	TwoGroupsEffectSize	(	before	,	after	,	"str"	,	is_paired	=	True	)	

p1	=	sp	.	stats	.	ttest_rel	(	before	,	after	,	nan_policy	=	"str"	)	.	pvalue	
assert	paired_es	.	pvalue_paired_students_t	==	pytest	.	approx	(	p1	)	

p2	=	sp	.	stats	.	wilcoxon	(	before	,	after	)	.	pvalue	
assert	paired_es	.	pvalue_wilcoxon	==	pytest	.	approx	(	p2	)	



def	test_median_diff_stats	(	)	:	
c	=	wellbeing	.	control	
t	=	wellbeing	.	expt	

es	=	TwoGroupsEffectSize	(	c	,	t	,	"str"	,	is_paired	=	False	)	

p1	=	sp	.	stats	.	kruskal	(	c	,	t	,	nan_policy	=	"str"	)	.	pvalue	
assert	es	.	pvalue_kruskal	==	pytest	.	approx	(	p1	)	



def	test_ordinal_dominance	(	)	:	
es	=	TwoGroupsEffectSize	(	likert_control	,	likert_treatment	,	
"str"	,	is_paired	=	False	)	

p1	=	sp	.	stats	.	brunnermunzel	(	likert_control	,	likert_treatment	)	.	pvalue	
assert	es	.	pvalue_brunner_munzel	==	pytest	.	approx	(	p1	)	
	