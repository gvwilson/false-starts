





def	create_bootstrap_indexes	(	array	,	resamples	=	5000	,	random_seed	=	12345	)	:	

import	numpy	as	np	


np	.	random	.	seed	(	random_seed	)	

indexes	=	range	(	0	,	len	(	array	)	)	

out	=	(	np	.	random	.	choice	(	indexes	,	len	(	indexes	)	,	replace	=	True	)	
for	i	in	range	(	0	,	resamples	)	)	


np	.	random	.	seed	(	)	

return	out	

def	compute_1group_jackknife	(	x	,	func	,	*	args	,	*	*	kwargs	)	:	

from		.		import	confint_2group_diff	as	ci_2g	
jackknives	=	[	i	for	i	in	ci_2g	.	create_jackknife_indexes	(	x	)	]	
out	=	[	func	(	x	[	j	]	,	*	args	,	*	*	kwargs	)	for	j	in	jackknives	]	
del	jackknives	
return	out	



def	compute_1group_acceleration	(	jack_dist	)	:	
from		.		import	confint_2group_diff	as	ci_2g	
return	ci_2g	.	_calc_accel	(	jack_dist	)	



def	compute_1group_bootstraps	(	x	,	func	,	resamples	=	5000	,	random_seed	=	12345	,	
*	args	,	*	*	kwargs	)	:	


import	numpy	as	np	


np	.	random	.	seed	(	random_seed	)	


boot_indexes	=	create_bootstrap_indexes	(	x	,	resamples	=	resamples	,	
random_seed	=	random_seed	)	

out	=	[	func	(	x	[	b	]	,	*	args	,	*	*	kwargs	)	for	b	in	boot_indexes	]	

del	boot_indexes	

np	.	random	.	seed	(	)	

return	out	



def	compute_1group_bias_correction	(	x	,	bootstraps	,	func	,	*	args	,	*	*	kwargs	)	:	
from	scipy	.	stats	import	norm	
metric	=	func	(	x	,	*	args	,	*	*	kwargs	)	
prop_boots_less_than_metric	=	sum	(	bootstraps	<	metric	)	/	len	(	bootstraps	)	

return	norm	.	ppf	(	prop_boots_less_than_metric	)	



def	summary_ci_1group	(	x	,	func	,	resamples	=	5000	,	alpha	=	0.05	,	random_seed	=	12345	,	
sort_bootstraps	=	True	,	*	args	,	*	*	kwargs	)	:	

from		.		import	confint_2group_diff	as	ci2g	
from	numpy	import	sort	as	npsort	

boots	=	compute_1group_bootstraps	(	x	,	func	,	resamples	=	resamples	,	
random_seed	=	random_seed	,	
*	args	,	*	*	kwargs	)	
bias	=	compute_1group_bias_correction	(	x	,	boots	,	func	)	

jk	=	compute_1group_jackknife	(	x	,	func	,	*	args	,	*	*	kwargs	)	
accel	=	compute_1group_acceleration	(	jk	)	
del	jk	

ci_idx	=	ci2g	.	compute_interval_limits	(	bias	,	accel	,	resamples	,	alpha	)	

boots_sorted	=	npsort	(	boots	)	

low	=	boots_sorted	[	ci_idx	[	0	]	]	
high	=	boots_sorted	[	ci_idx	[	1	]	]	

if	sort_bootstraps	:	
B	=	boots_sorted	
else	:	
B	=	boots	
del	boots	
del	boots_sorted	

out	=	{	"str"	:	func	(	x	)	,	"str"	:	func	,	
"str"	:	low	,	"str"	:	high	,	
"str"	:	B	}	

del	B	
return	out	
	