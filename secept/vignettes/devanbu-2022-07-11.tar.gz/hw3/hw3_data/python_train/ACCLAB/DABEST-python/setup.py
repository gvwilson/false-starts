from	setuptools	import	setup	,	find_packages	
import	os	




os	.	environ	[	"str"	]	=	"str"	

DESCRIPTION	=	"str"	
LONG_DESCRIPTION	=	"str"	


if	__name__	==	"str"	:	
setup	(	
name	=	"str"	,	
author	=	"str"	,	
author_email	=	"str"	,	
maintainer	=	"str"	,	
maintainer_email	=	"str"	,	
version	=	"str"	,	
description	=	DESCRIPTION	,	
long_description	=	LONG_DESCRIPTION	,	
packages	=	find_packages	(	)	,	
install_requires	=	[	
"str"	,	
"str"	,	
"str"	,	

"str"	,	
"str"	
]	,	
extras_require	=	{	"str"	:	[	"str"	,	"str"	]	}	,	
python_requires	=	"str"	,	
url	=	"str"	,	
download_url	=	"str"	,	
license	=	"str"	
)	
	