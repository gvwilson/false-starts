






from		.	misc_tools	import	merge_two_dicts	



def	halfviolin	(	v	,	half	=	"str"	,	fill_color	=	"str"	,	alpha	=	1	,	
line_color	=	"str"	,	line_width	=	0	)	:	
import	numpy	as	np	

for	b	in	v	[	"str"	]	:	
V	=	b	.	get_paths	(	)	[	0	]	.	vertices	

mean_vertical	=	np	.	mean	(	V	[	:	,	0	]	)	
mean_horizontal	=	np	.	mean	(	V	[	:	,	1	]	)	

if	half	is	"str"	:	
V	[	:	,	0	]	=	np	.	clip	(	V	[	:	,	0	]	,	-	np	.	inf	,	mean_vertical	)	
if	half	is	"str"	:	
V	[	:	,	0	]	=	np	.	clip	(	V	[	:	,	0	]	,	mean_vertical	,	np	.	inf	)	
if	half	is	"str"	:	
V	[	:	,	1	]	=	np	.	clip	(	V	[	:	,	1	]	,	-	np	.	inf	,	mean_horizontal	)	
if	half	is	"str"	:	
V	[	:	,	1	]	=	np	.	clip	(	V	[	:	,	1	]	,	mean_horizontal	,	np	.	inf	)	

b	.	set_color	(	fill_color	)	
b	.	set_alpha	(	alpha	)	
b	.	set_edgecolor	(	line_color	)	
b	.	set_linewidth	(	line_width	)	
























def	get_swarm_spans	(	coll	)	:	

import	numpy	as	np	
x	,	y	=	np	.	array	(	coll	.	get_offsets	(	)	)	.	T	
try	:	
return	x	.	min	(	)	,	x	.	max	(	)	,	y	.	min	(	)	,	y	.	max	(	)	
except	ValueError	:	
return	None	



def	gapped_lines	(	data	,	x	,	y	,	type	=	"str"	,	offset	=	0.2	,	ax	=	None	,	
line_color	=	"str"	,	gap_width_percent	=	1	,	
*	*	kwargs	)	:	

import	numpy	as	np	
import	pandas	as	pd	
import	matplotlib	.	pyplot	as	plt	
import	matplotlib	.	lines	as	mlines	

if	gap_width_percent	<	0	or	gap_width_percent	>	100	:	
raise	ValueError	(	"str"	)	

if	ax	is	None	:	
ax	=	plt	.	gca	(	)	
ax_ylims	=	ax	.	get_ylim	(	)	
ax_yspan	=	np	.	abs	(	ax_ylims	[	1	]	-	ax_ylims	[	0	]	)	
gap_width	=	ax_yspan	*	gap_width_percent	/	100	

keys	=	kwargs	.	keys	(	)	
if	"str"	not	in	keys	:	
kwargs	[	"str"	]	=	False	

if	"str"	not	in	keys	:	
kwargs	[	"str"	]	=	5	

if	"str"	not	in	keys	:	
kwargs	[	"str"	]	=	2.	






if	isinstance	(	data	[	x	]	.	dtype	,	pd	.	CategoricalDtype	)	:	
group_order	=	pd	.	unique	(	data	[	x	]	)	.	categories	
else	:	
group_order	=	pd	.	unique	(	data	[	x	]	)	

means	=	data	.	groupby	(	x	)	[	y	]	.	mean	(	)	.	reindex	(	index	=	group_order	)	
sd	=	data	.	groupby	(	x	)	[	y	]	.	std	(	)	.	reindex	(	index	=	group_order	)	
lower_sd	=	means	-	sd	
upper_sd	=	means	+	sd	


if	(	lower_sd	<	ax_ylims	[	0	]	)	.	any	(	)	or	(	upper_sd	>	ax_ylims	[	1	]	)	.	any	(	)	:	
kwargs	[	"str"	]	=	True	

medians	=	data	.	groupby	(	x	)	[	y	]	.	median	(	)	.	reindex	(	index	=	group_order	)	
quantiles	=	data	.	groupby	(	x	)	[	y	]	.	quantile	(	[	0.25	,	0.75	]	)	.	unstack	(	)	.	reindex	(	index	=	group_order	)	
lower_quartiles	=	quantiles	[	0.25	]	
upper_quartiles	=	quantiles	[	0.75	]	


if	type	==	"str"	:	
central_measures	=	means	
lows	=	lower_sd	
highs	=	upper_sd	
elif	type	==	"str"	:	
central_measures	=	medians	
lows	=	lower_quartiles	
highs	=	upper_quartiles	


n_groups	=	len	(	central_measures	)	

if	isinstance	(	line_color	,	str	)	:	
custom_palette	=	np	.	repeat	(	line_color	,	n_groups	)	
else	:	
if	len	(	line_color	)	!=	n_groups	:	
err1	=	"str"	.	format	(	n_groups	)	
err2	=	"str"	.	format	(	len	(	line_color	)	)	
raise	ValueError	(	err1	+	err2	)	
custom_palette	=	line_color	

try	:	
len_offset	=	len	(	offset	)	
except	TypeError	:	
offset	=	np	.	repeat	(	offset	,	n_groups	)	
len_offset	=	len	(	offset	)	

if	len_offset	!=	n_groups	:	
err1	=	"str"	.	format	(	n_groups	)	
err2	=	"str"	.	format	(	len_offset	)	
raise	ValueError	(	err1	+	err2	)	

kwargs	[	"str"	]	=	kwargs	[	"str"	]	

for	xpos	,	central_measure	in	enumerate	(	central_measures	)	:	


kwargs	[	"str"	]	=	custom_palette	[	xpos	]	

_xpos	=	xpos	+	offset	[	xpos	]	

low	=	lows	[	xpos	]	
low_to_mean	=	mlines	.	Line2D	(	[	_xpos	,	_xpos	]	,	
[	low	,	central_measure	-	gap_width	]	,	
*	*	kwargs	)	
ax	.	add_line	(	low_to_mean	)	


high	=	highs	[	xpos	]	
mean_to_high	=	mlines	.	Line2D	(	[	_xpos	,	_xpos	]	,	
[	central_measure	+	gap_width	,	high	]	,	
*	*	kwargs	)	
ax	.	add_line	(	mean_to_high	)	









	