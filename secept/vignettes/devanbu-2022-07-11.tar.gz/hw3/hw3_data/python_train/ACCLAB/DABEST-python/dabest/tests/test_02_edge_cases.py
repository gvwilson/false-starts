





import	sys	
import	numpy	as	np	
import	scipy	as	sp	
import	pytest	
import	pandas	as	pd	
from		.		.	_api	import	load	



def	test_unrelated_columns	(	N	=	60	,	random_seed	=	12345	)	:	


np	.	random	.	seed	(	random_seed	)	

df	=	pd	.	DataFrame	(	
{	"str"	:	np	.	random	.	choice	(	[	"str"	,	"str"	,	"str"	]	,	size	=	(	N	,	)	)	,	
"str"	:	np	.	random	.	choice	(	[	"str"	,	"str"	,	"str"	]	,	size	=	(	N	,	)	)	,	
"str"	:	np	.	random	.	random	(	size	=	(	N	,	)	)	}	)	

np	.	random	.	seed	(	)	

df	[	"str"	]	=	np	.	nan	

test	=	load	(	data	=	df	,	x	=	"str"	,	y	=	"str"	,	
idx	=	[	"str"	,	"str"	]	)	

md	=	test	.	mean_diff	.	results	

assert	md	.	difference	[	0	]	==	pytest	.	approx	(	0.1115	,	abs	=	1e-6	)	
assert	md	.	bca_low	[	0	]	==	pytest	.	approx	(	-	0.042835	,	abs	=	1e-6	)	
assert	md	.	bca_high	[	0	]	==	pytest	.	approx	(	0.264542	,	abs	=	1e-6	)	
	