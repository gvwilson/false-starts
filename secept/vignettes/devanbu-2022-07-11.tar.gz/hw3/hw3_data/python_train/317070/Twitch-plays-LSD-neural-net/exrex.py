



















try	:	
from	future_builtins	import	map	,	range	
except	:	
pass	
from	re	import	sre_parse	,	U	
from	itertools	import	tee	
from	random	import	choice	,	randint	
from	types	import	GeneratorType	

from	sys	import	version_info	
IS_PY3	=	version_info	[	0	]	==	3	

if	IS_PY3	:	
unichr	=	chr	

__all__	=	(	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	)	

CATEGORIES	=	{	"str"	:	sorted	(	sre_parse	.	WHITESPACE	)	
,	"str"	:	sorted	(	sre_parse	.	DIGITS	)	
,	"str"	:	[	unichr	(	x	)	for	x	in	range	(	32	,	123	)	]	
}	

REVERSE_CATEGORIES	=	{	vv	[	1	]	:	k	for	k	,	v	
in	sre_parse	.	CATEGORIES	.	items	(	)	for	vv	
in	v	[	1	]	
if	v	[	0	]	==	"str"	and	vv	[	0	]	==	"str"	}	


def	comb	(	g	,	i	)	:	
for	c	in	g	:	
g2	,	i	=	tee	(	i	)	
for	c2	in	g2	:	
yield	c	+	c2	


def	mappend	(	g	,	c	)	:	
for	cc	in	g	:	
yield	cc	+	c	


def	dappend	(	g	,	d	,	k	)	:	
for	cc	in	g	:	
yield	cc	+	d	[	k	]	


def	_in	(	d	)	:	
ret	=	[	]	
neg	=	False	
for	i	in	d	:	
if	i	[	0	]	==	"str"	:	
subs	=	map	(	unichr	,	range	(	i	[	1	]	[	0	]	,	i	[	1	]	[	1	]	+	1	)	)	
if	neg	:	
for	char	in	subs	:	
try	:	
ret	.	remove	(	char	)	
except	:	
pass	
else	:	
ret	.	extend	(	subs	)	
elif	i	[	0	]	==	"str"	:	
if	neg	:	
try	:	
ret	.	remove	(	unichr	(	i	[	1	]	)	)	
except	:	
pass	
else	:	
ret	.	append	(	unichr	(	i	[	1	]	)	)	
elif	i	[	0	]	==	"str"	:	
subs	=	CATEGORIES	.	get	(	i	[	1	]	,	[	"str"	]	)	
if	neg	:	
for	char	in	subs	:	
try	:	
ret	.	remove	(	char	)	
except	:	
pass	
else	:	
ret	.	extend	(	subs	)	
elif	i	[	0	]	==	"str"	:	
ret	=	list	(	CATEGORIES	[	"str"	]	)	
neg	=	True	
return	ret	


def	prods	(	orig	,	ran	,	items	,	limit	,	grouprefs	)	:	
for	o	in	orig	:	
for	r	in	ran	:	
if	r	==	0	:	
yield	o	
else	:	
ret	=	[	o	]	
for	_	in	range	(	r	)	:	
ret	=	ggen	(	ret	,	_gen	,	items	,	limit	=	limit	,	count	=	False	,	grouprefs	=	grouprefs	)	
for	i	in	ret	:	
yield	i	


def	ggen	(	g1	,	f	,	*	args	,	*	*	kwargs	)	:	
groupref	=	None	
grouprefs	=	kwargs	.	get	(	"str"	,	{	}	)	
if	"str"	in	kwargs	.	keys	(	)	:	
groupref	=	kwargs	.	pop	(	"str"	)	
for	a	in	g1	:	
g2	=	f	(	*	args	,	*	*	kwargs	)	
if	isinstance	(	g2	,	GeneratorType	)	:	
for	b	in	g2	:	
grouprefs	[	groupref	]	=	b	
yield	a	+	b	
else	:	
yield	g2	


def	concit	(	g1	,	seqs	,	limit	,	grouprefs	)	:	
for	a	in	g1	:	
for	s	in	seqs	:	
for	b	in	_gen	(	s	,	limit	,	grouprefs	=	grouprefs	)	:	
yield	a	+	b	


def	_gen	(	d	,	limit	=	20	,	count	=	False	,	grouprefs	=	None	)	:	

if	grouprefs	==	None	:	
grouprefs	=	{	}	
ret	=	[	"str"	]	
strings	=	0	
literal	=	False	
for	i	in	d	:	
if	i	[	0	]	==	"str"	:	
subs	=	_in	(	i	[	1	]	)	
if	count	:	
strings	=	(	strings	or	1	)	*	len	(	subs	)	
ret	=	comb	(	ret	,	subs	)	
elif	i	[	0	]	==	"str"	:	
literal	=	True	
ret	=	mappend	(	ret	,	unichr	(	i	[	1	]	)	)	
elif	i	[	0	]	==	"str"	:	
subs	=	CATEGORIES	.	get	(	i	[	1	]	,	[	"str"	]	)	
if	count	:	
strings	=	(	strings	or	1	)	*	len	(	subs	)	
ret	=	comb	(	ret	,	subs	)	
elif	i	[	0	]	==	"str"	:	
subs	=	CATEGORIES	[	"str"	]	
if	count	:	
strings	=	(	strings	or	1	)	*	len	(	subs	)	
ret	=	comb	(	ret	,	subs	)	
elif	i	[	0	]	==	"str"	:	
items	=	list	(	i	[	1	]	[	2	]	)	
if	i	[	1	]	[	1	]	+	1	-	i	[	1	]	[	0	]	>	=	limit	:	
ran	=	range	(	i	[	1	]	[	0	]	,	i	[	1	]	[	0	]	+	limit	)	
r1	=	i	[	1	]	[	0	]	
r2	=	i	[	1	]	[	0	]	+	limit	
else	:	
r1	=	i	[	1	]	[	0	]	
r2	=	i	[	1	]	[	1	]	+	1	
ran	=	range	(	r1	,	r2	)	
if	count	:	
for	p	in	ran	:	
strings	+	=	pow	(	_gen	(	items	,	limit	,	True	,	grouprefs	)	,	p	)	or	1	
ret	=	prods	(	ret	,	ran	,	items	,	limit	,	grouprefs	)	
elif	i	[	0	]	==	"str"	:	
if	count	:	
for	x	in	i	[	1	]	[	1	]	:	
strings	+	=	_gen	(	x	,	limit	,	True	,	grouprefs	)	
ret	=	concit	(	ret	,	i	[	1	]	[	1	]	,	limit	,	grouprefs	)	
elif	i	[	0	]	==	"str"	:	
if	count	:	
strings	=	(	strings	or	1	)	*	(	sum	(	ggen	(	[	0	]	,	_gen	,	i	[	1	]	[	1	]	,	limit	=	limit	,	count	=	True	,	grouprefs	=	grouprefs	)	)	or	1	)	
ret	=	ggen	(	ret	,	_gen	,	i	[	1	]	[	1	]	,	limit	=	limit	,	count	=	False	,	grouprefs	=	grouprefs	,	groupref	=	i	[	1	]	[	0	]	)	

elif	i	[	0	]	==	"str"	:	
continue	
elif	i	[	0	]	==	"str"	:	
subs	=	list	(	CATEGORIES	[	"str"	]	)	
subs	.	remove	(	unichr	(	i	[	1	]	)	)	
if	count	:	
strings	=	(	strings	or	1	)	*	len	(	subs	)	
ret	=	comb	(	ret	,	subs	)	
elif	i	[	0	]	==	"str"	:	
ret	=	dappend	(	ret	,	grouprefs	,	i	[	1	]	)	
elif	i	[	0	]	==	"str"	:	


pass	
elif	i	[	0	]	==	"str"	:	
pass	
else	:	
print	(	"str"	+	repr	(	i	)	)	

if	count	:	
if	strings	==	0	and	literal	:	
inc	=	True	
for	i	in	d	:	
if	i	[	0	]	not	in	(	"str"	"str"	)	:	
inc	=	False	
if	inc	:	
strings	=	1	
return	strings	

return	ret	


def	_randone	(	d	,	limit	=	20	,	grouprefs	=	None	)	:	
if	grouprefs	==	None	:	
grouprefs	=	{	}	

ret	=	"str"	
for	i	in	d	:	
if	i	[	0	]	==	"str"	:	
ret	+	=	choice	(	_in	(	i	[	1	]	)	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	unichr	(	i	[	1	]	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	choice	(	CATEGORIES	.	get	(	i	[	1	]	,	[	"str"	]	)	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	choice	(	CATEGORIES	[	"str"	]	)	
elif	i	[	0	]	==	"str"	:	
if	i	[	1	]	[	1	]	+	1	-	i	[	1	]	[	0	]	>	=	limit	:	
min	,	max	=	i	[	1	]	[	0	]	,	i	[	1	]	[	0	]	+	limit	
else	:	
min	,	max	=	i	[	1	]	[	0	]	,	i	[	1	]	[	1	]	
for	_	in	range	(	randint	(	min	,	max	)	)	:	
ret	+	=	_randone	(	list	(	i	[	1	]	[	2	]	)	,	limit	,	grouprefs	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	_randone	(	choice	(	i	[	1	]	[	1	]	)	,	limit	,	grouprefs	)	
elif	i	[	0	]	==	"str"	:	
subp	=	_randone	(	i	[	1	]	[	1	]	,	limit	,	grouprefs	)	
if	i	[	1	]	[	0	]	:	
grouprefs	[	i	[	1	]	[	0	]	]	=	subp	
ret	+	=	subp	
elif	i	[	0	]	==	"str"	:	
continue	
elif	i	[	0	]	==	"str"	:	
c	=	list	(	CATEGORIES	[	"str"	]	)	
c	.	remove	(	unichr	(	i	[	1	]	)	)	
ret	+	=	choice	(	c	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	grouprefs	[	i	[	1	]	]	
elif	i	[	0	]	==	"str"	:	
pass	
elif	i	[	0	]	==	"str"	:	
pass	
else	:	
print	(	"str"	%	str	(	i	)	)	

return	ret	


def	sre_to_string	(	sre_obj	,	paren	=	True	)	:	

ret	=	"str"	
for	i	in	sre_obj	:	
if	i	[	0	]	==	"str"	:	
prefix	=	"str"	
if	len	(	i	[	1	]	)	and	i	[	1	]	[	0	]	[	0	]	==	"str"	:	
prefix	=	"str"	
ret	+	=	"str"	.	format	(	prefix	,	sre_to_string	(	i	[	1	]	,	paren	=	paren	)	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	unichr	(	i	[	1	]	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	REVERSE_CATEGORIES	[	i	[	1	]	]	
elif	i	[	0	]	==	"str"	:	
ret	+	=	"str"	
elif	i	[	0	]	in	"str"	:	

parts	=	[	sre_to_string	(	x	,	paren	=	paren	)	for	x	in	i	[	1	]	[	1	]	]	
if	not	any	(	parts	)	:	
continue	
if	i	[	1	]	[	0	]	:	
if	len	(	parts	)	==	1	:	
paren	=	False	
prefix	=	"str"	
else	:	
prefix	=	"str"	
branch	=	"str"	.	join	(	parts	)	
if	paren	:	
ret	+	=	"str"	.	format	(	prefix	,	branch	)	
else	:	
ret	+	=	"str"	.	format	(	branch	)	
elif	i	[	0	]	==	"str"	:	
if	i	[	1	]	[	0	]	:	
ret	+	=	"str"	.	format	(	sre_to_string	(	i	[	1	]	[	1	]	,	paren	=	False	)	)	
else	:	
ret	+	=	"str"	.	format	(	sre_to_string	(	i	[	1	]	[	1	]	,	paren	=	paren	)	)	
elif	i	[	0	]	==	"str"	:	
ret	+	=	"str"	.	format	(	unichr	(	i	[	1	]	)	)	
elif	i	[	0	]	==	"str"	:	
if	i	[	1	]	[	0	]	==	i	[	1	]	[	1	]	:	
range_str	=	"str"	.	format	(	i	[	1	]	[	0	]	)	
else	:	
if	i	[	1	]	[	0	]	==	0	and	i	[	1	]	[	1	]	-	i	[	1	]	[	0	]	==	sre_parse	.	MAXREPEAT	:	
range_str	=	"str"	
elif	i	[	1	]	[	0	]	==	1	and	i	[	1	]	[	1	]	-	i	[	1	]	[	0	]	==	sre_parse	.	MAXREPEAT	-	1	:	
range_str	=	"str"	
else	:	
range_str	=	"str"	.	format	(	i	[	1	]	[	0	]	,	i	[	1	]	[	1	]	)	
ret	+	=	sre_to_string	(	i	[	1	]	[	2	]	,	paren	=	paren	)	+	range_str	
elif	i	[	0	]	==	"str"	:	
ret	+	=	"str"	.	format	(	i	[	1	]	)	
elif	i	[	0	]	==	"str"	:	
if	i	[	1	]	==	"str"	:	
ret	+	=	"str"	
elif	i	[	1	]	==	"str"	:	
ret	+	=	"str"	
elif	i	[	0	]	==	"str"	:	
pass	

else	:	
print	(	"str"	%	str	(	i	)	)	
return	ret	


def	simplify	(	regex_string	)	:	

r	=	parse	(	regex_string	)	
return	sre_to_string	(	r	)	


def	parse	(	s	)	:	

if	IS_PY3	:	
r	=	sre_parse	.	parse	(	s	,	flags	=	U	)	
else	:	
r	=	sre_parse	.	parse	(	s	.	decode	(	"str"	)	,	flags	=	U	)	
return	list	(	r	)	


def	generate	(	s	,	limit	=	20	)	:	

return	_gen	(	parse	(	s	)	,	limit	)	


def	count	(	s	,	limit	=	20	)	:	

return	_gen	(	parse	(	s	)	,	limit	,	count	=	True	)	


def	getone	(	regex_string	,	limit	=	20	)	:	

return	_randone	(	parse	(	regex_string	)	,	limit	)	


def	argparser	(	)	:	
import	argparse	
from	sys	import	stdout	
argp	=	argparse	.	ArgumentParser	(	description	=	"str"	)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	metavar	=	"str"	
,	default	=	stdout	
,	type	=	argparse	.	FileType	(	"str"	)	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	20	
,	action	=	"str"	
,	type	=	int	
,	metavar	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	False	
,	action	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	-	1	
,	action	=	"str"	
,	type	=	int	
,	metavar	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	False	
,	action	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	False	
,	action	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	help	=	"str"	
,	default	=	"str"	
)	
argp	.	add_argument	(	"str"	,	"str"	
,	action	=	"str"	
,	help	=	"str"	
,	default	=	False	
)	
argp	.	add_argument	(	"str"	
,	metavar	=	"str"	
,	help	=	"str"	
)	
return	vars	(	argp	.	parse_args	(	)	)	


def	__main__	(	)	:	
from	sys	import	exit	,	stderr	
args	=	argparser	(	)	
if	args	[	"str"	]	:	
args	[	"str"	]	.	write	(	"str"	%	(	parse	(	args	[	"str"	]	)	,	args	[	"str"	]	)	)	
if	args	[	"str"	]	:	
args	[	"str"	]	.	write	(	"str"	%	(	count	(	args	[	"str"	]	,	limit	=	args	[	"str"	]	)	,	args	[	"str"	]	)	)	
exit	(	0	)	
if	args	[	"str"	]	:	
args	[	"str"	]	.	write	(	"str"	%	(	getone	(	args	[	"str"	]	,	limit	=	args	[	"str"	]	)	,	args	[	"str"	]	)	)	
exit	(	0	)	
if	args	[	"str"	]	:	
args	[	"str"	]	.	write	(	"str"	%	(	simplify	(	args	[	"str"	]	)	,	args	[	"str"	]	)	)	
exit	(	0	)	
try	:	
g	=	generate	(	args	[	"str"	]	,	args	[	"str"	]	)	
except	Exception	as	e	:	
stderr	.	write	(	"str"	%	e	)	
exit	(	1	)	
args	[	"str"	]	.	write	(	next	(	g	)	)	
args	[	"str"	]	-	=	1	
for	s	in	g	:	
if	args	[	"str"	]	==	0	:	
break	
args	[	"str"	]	-	=	1	
args	[	"str"	]	.	write	(	args	[	"str"	]	)	
args	[	"str"	]	.	write	(	s	)	
if	args	[	"str"	]	==	"str"	:	
args	[	"str"	]	.	write	(	"str"	)	


if	__name__	==	"str"	:	
__main__	(	)	
	