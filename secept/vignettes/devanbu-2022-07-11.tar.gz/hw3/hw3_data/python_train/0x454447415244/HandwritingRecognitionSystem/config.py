







import	tensorflow	as	tf	
import	os	

flags	=	tf	.	app	.	flags	



flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	



flags	.	DEFINE_integer	(	"str"	,	20	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	



flags	.	DEFINE_integer	(	"str"	,	20	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	



flags	.	DEFINE_integer	(	"str"	,	20	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	True	,	"str"	)	



flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	



flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	



flags	.	DEFINE_boolean	(	"str"	,	True	,	"str"	)	



flags	.	DEFINE_integer	(	"str"	,	256	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	3	,	"str"	)	



flags	.	DEFINE_integer	(	"str"	,	0	,	"str"	)	
flags	.	DEFINE_float	(	"str"	,	0.0005	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	10	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	True	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	5	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	1	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	1000000	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	20	,	"str"	)	

cfg	=	flags	.	FLAGS	

if	(	os	.	path	.	exists	(	cfg	.	SaveDir	)	==	False	)	:	os	.	makedirs	(	cfg	.	SaveDir	)	
if	(	os	.	path	.	exists	(	cfg	.	LogDir	)	==	False	)	:	os	.	makedirs	(	cfg	.	LogDir	)	
	