













from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	import	flags	
from	absl	.	flags	import	_helpers	
from	absl	.	testing	import	absltest	

FLAGS	=	flags	.	FLAGS	


class	FlagsUnitTest	(	absltest	.	TestCase	)	:	


def	test_get_help_width	(	self	)	:	

default_help_width	=	_helpers	.	_DEFAULT_HELP_WIDTH	
self	.	assertEqual	(	80	,	_helpers	.	_DEFAULT_HELP_WIDTH	)	
self	.	assertEqual	(	_helpers	.	_DEFAULT_HELP_WIDTH	,	flags	.	get_help_width	(	)	)	
_helpers	.	_DEFAULT_HELP_WIDTH	=	10	
self	.	assertEqual	(	_helpers	.	_DEFAULT_HELP_WIDTH	,	flags	.	get_help_width	(	)	)	
_helpers	.	_DEFAULT_HELP_WIDTH	=	default_help_width	

def	test_text_wrap	(	self	)	:	

default_help_width	=	_helpers	.	_DEFAULT_HELP_WIDTH	
_helpers	.	_DEFAULT_HELP_WIDTH	=	10	


text	=	"str"	
expect	=	[	]	
for	n	in	range	(	4	)	:	
line	=	str	(	n	)	
line	+	=	"str"	
text	+	=	line	
expect	.	append	(	line	)	


wrapped	=	flags	.	text_wrap	(	text	)	.	split	(	"str"	)	
self	.	assertEqual	(	4	,	len	(	wrapped	)	)	
self	.	assertEqual	(	expect	,	wrapped	)	

wrapped	=	flags	.	text_wrap	(	text	,	80	)	.	split	(	"str"	)	
self	.	assertEqual	(	1	,	len	(	wrapped	)	)	
self	.	assertEqual	(	[	text	]	,	wrapped	)	


input_value	=	"str"	
expect	=	{	1	:	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
2	:	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
3	:	[	"str"	,	"str"	,	"str"	,	"str"	]	,	
4	:	[	"str"	,	"str"	,	"str"	,	"str"	]	,	
5	:	[	"str"	,	"str"	,	"str"	]	,	
6	:	[	"str"	,	"str"	,	"str"	]	,	
7	:	[	"str"	,	"str"	]	,	
8	:	[	"str"	,	"str"	]	,	
9	:	[	"str"	,	"str"	]	,	
10	:	[	"str"	,	"str"	]	,	
11	:	[	"str"	,	"str"	]	,	
12	:	[	"str"	,	"str"	]	,	
13	:	[	"str"	,	"str"	]	,	
14	:	[	"str"	,	"str"	]	,	
15	:	[	"str"	]	}	
for	width	,	exp	in	expect	.	items	(	)	:	
self	.	assertEqual	(	exp	,	flags	.	text_wrap	(	input_value	,	width	)	.	split	(	"str"	)	)	



self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	


self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	)	)	


self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	,	80	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	


self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	3	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	4	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	5	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	6	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	7	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	8	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	9	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	10	,	"str"	,	"str"	)	)	


self	.	assertEqual	(	"str"	,	
flags	.	text_wrap	(	"str"	,	80	,	"str"	,	"str"	)	)	

_helpers	.	_DEFAULT_HELP_WIDTH	=	default_help_width	

def	test_doc_to_help	(	self	)	:	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	

self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	flags	.	doc_to_help	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	
flags	.	doc_to_help	(	"str"	)	)	

def	test_doc_to_help_flag_values	(	self	)	:	





doc	=	flags	.	doc_to_help	(	self	.	test_doc_to_help_flag_values	.	__doc__	)	

lines	=	doc	.	splitlines	(	)	
self	.	assertEqual	(	17	,	len	(	lines	)	)	
empty_lines	=	[	index	for	index	in	range	(	len	(	lines	)	)	if	not	lines	[	index	]	]	
self	.	assertEqual	(	[	1	,	3	,	5	,	8	,	12	,	15	]	,	empty_lines	)	

flags_lines	=	[	index	for	index	in	range	(	len	(	lines	)	)	
if	lines	[	index	]	.	startswith	(	"str"	)	]	
self	.	assertEqual	(	[	7	,	10	,	11	]	,	flags_lines	)	

space_lines	=	[	index	for	index	in	range	(	len	(	lines	)	)	
if	lines	[	index	]	and	lines	[	index	]	[	0	]	.	isspace	(	)	]	
self	.	assertEqual	(	[	7	,	10	,	11	,	14	]	,	space_lines	)	

rspace_lines	=	[	index	for	index	in	range	(	len	(	lines	)	)	
if	lines	[	index	]	!=	lines	[	index	]	.	rstrip	(	)	]	
self	.	assertEqual	(	[	]	,	rspace_lines	)	

self	.	assertEqual	(	True	,	lines	[	2	]	.	endswith	(	"str"	)	)	

def	test_text_wrap_raises_on_excessive_indent	(	self	)	:	

self	.	assertRaises	(	ValueError	,	
flags	.	text_wrap	,	"str"	,	length	=	10	,	indent	=	"str"	*	10	)	

def	test_text_wrap_raises_on_excessive_first_line	(	self	)	:	

self	.	assertRaises	(	
ValueError	,	
flags	.	text_wrap	,	"str"	,	length	=	80	,	firstline_indent	=	"str"	*	80	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	