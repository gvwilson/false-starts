















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	getopt	
import	os	
import	re	
import	sys	
import	types	
import	warnings	

from	absl	.	flags	import	_argument_parser	
from	absl	.	flags	import	_defines	
from	absl	.	flags	import	_exceptions	
from	absl	.	flags	import	_flag	
from	absl	.	flags	import	_flagvalues	
from	absl	.	flags	import	_helpers	
from	absl	.	flags	import	_validators	
import	six	



_helpers	.	FLAGS_MODULE	=	sys	.	modules	[	__name__	]	


_helpers	.	disclaim_module_ids	.	add	(	id	(	sys	.	modules	[	__name__	]	)	)	



DEFINE	=	_defines	.	DEFINE	
DEFINE_flag	=	_defines	.	DEFINE_flag	
DEFINE_string	=	_defines	.	DEFINE_string	
DEFINE_boolean	=	_defines	.	DEFINE_boolean	
DEFINE_bool	=	DEFINE_boolean	
DEFINE_float	=	_defines	.	DEFINE_float	
DEFINE_integer	=	_defines	.	DEFINE_integer	
DEFINE_enum	=	_defines	.	DEFINE_enum	
DEFINE_enum_class	=	_defines	.	DEFINE_enum_class	
DEFINE_list	=	_defines	.	DEFINE_list	
DEFINE_spaceseplist	=	_defines	.	DEFINE_spaceseplist	
DEFINE_multi	=	_defines	.	DEFINE_multi	
DEFINE_multi_string	=	_defines	.	DEFINE_multi_string	
DEFINE_multi_integer	=	_defines	.	DEFINE_multi_integer	
DEFINE_multi_float	=	_defines	.	DEFINE_multi_float	
DEFINE_multi_enum	=	_defines	.	DEFINE_multi_enum	
DEFINE_multi_enum_class	=	_defines	.	DEFINE_multi_enum_class	
DEFINE_alias	=	_defines	.	DEFINE_alias	




register_validator	=	_validators	.	register_validator	
validator	=	_validators	.	validator	
register_multi_flags_validator	=	_validators	.	register_multi_flags_validator	
multi_flags_validator	=	_validators	.	multi_flags_validator	
mark_flag_as_required	=	_validators	.	mark_flag_as_required	
mark_flags_as_required	=	_validators	.	mark_flags_as_required	
mark_flags_as_mutual_exclusive	=	_validators	.	mark_flags_as_mutual_exclusive	
mark_bool_flags_as_mutual_exclusive	=	_validators	.	mark_bool_flags_as_mutual_exclusive	



declare_key_flag	=	_defines	.	declare_key_flag	
adopt_module_key_flags	=	_defines	.	adopt_module_key_flags	
disclaim_key_flags	=	_defines	.	disclaim_key_flags	




Error	=	_exceptions	.	Error	
CantOpenFlagFileError	=	_exceptions	.	CantOpenFlagFileError	
DuplicateFlagError	=	_exceptions	.	DuplicateFlagError	
IllegalFlagValueError	=	_exceptions	.	IllegalFlagValueError	
UnrecognizedFlagError	=	_exceptions	.	UnrecognizedFlagError	
UnparsedFlagAccessError	=	_exceptions	.	UnparsedFlagAccessError	
ValidationError	=	_exceptions	.	ValidationError	
FlagNameConflictsWithMethodError	=	_exceptions	.	FlagNameConflictsWithMethodError	



Flag	=	_flag	.	Flag	
BooleanFlag	=	_flag	.	BooleanFlag	
EnumFlag	=	_flag	.	EnumFlag	
EnumClassFlag	=	_flag	.	EnumClassFlag	
MultiFlag	=	_flag	.	MultiFlag	
MultiEnumClassFlag	=	_flag	.	MultiEnumClassFlag	
FlagValues	=	_flagvalues	.	FlagValues	
ArgumentParser	=	_argument_parser	.	ArgumentParser	
BooleanParser	=	_argument_parser	.	BooleanParser	
EnumParser	=	_argument_parser	.	EnumParser	
EnumClassParser	=	_argument_parser	.	EnumClassParser	
ArgumentSerializer	=	_argument_parser	.	ArgumentSerializer	
FloatParser	=	_argument_parser	.	FloatParser	
IntegerParser	=	_argument_parser	.	IntegerParser	
BaseListParser	=	_argument_parser	.	BaseListParser	
ListParser	=	_argument_parser	.	ListParser	
ListSerializer	=	_argument_parser	.	ListSerializer	
CsvListSerializer	=	_argument_parser	.	CsvListSerializer	
WhitespaceSeparatedListParser	=	_argument_parser	.	WhitespaceSeparatedListParser	




get_help_width	=	_helpers	.	get_help_width	
text_wrap	=	_helpers	.	text_wrap	
flag_dict_to_args	=	_helpers	.	flag_dict_to_args	
doc_to_help	=	_helpers	.	doc_to_help	



_helpers	.	SPECIAL_FLAGS	=	FlagValues	(	)	

DEFINE_string	(	
"str"	,	"str"	,	
"str"	,	
_helpers	.	SPECIAL_FLAGS	)	

DEFINE_string	(	
"str"	,	"str"	,	
"str"	
"str"	
"str"	
"str"	,	_helpers	.	SPECIAL_FLAGS	)	


FLAGS	=	_flagvalues	.	FLAGS	
	