















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	contextlib	
import	io	
import	os	
import	re	
import	sys	
import	tempfile	

from	absl	import	logging	
from	absl	.	testing	import	absltest	
import	mock	

logging	.	get_verbosity	(	)	

logging	.	get_absl_handler	(	)	.	use_absl_log_file	(	)	


class	Error	(	Exception	)	:	
pass	


@contextlib.contextmanager	
def	captured_stderr_filename	(	)	:	

stderr_capture_file_fd	,	stderr_capture_file_name	=	tempfile	.	mkstemp	(	)	
original_stderr_fd	=	os	.	dup	(	sys	.	stderr	.	fileno	(	)	)	
os	.	dup2	(	stderr_capture_file_fd	,	sys	.	stderr	.	fileno	(	)	)	
try	:	
yield	stderr_capture_file_name	
finally	:	
os	.	close	(	stderr_capture_file_fd	)	
os	.	dup2	(	original_stderr_fd	,	sys	.	stderr	.	fileno	(	)	)	



with	captured_stderr_filename	(	)	as	before_set_verbosity_filename	:	

logging	.	debug	(	"str"	)	
logging	.	info	(	"str"	)	
logging	.	error	(	"str"	)	
logging	.	warning	(	"str"	)	
try	:	
raise	Error	(	"str"	)	
except	Error	:	
logging	.	exception	(	"str"	)	


logging	.	set_verbosity	(	logging	.	ERROR	)	
with	captured_stderr_filename	(	)	as	after_set_verbosity_filename	:	

logging	.	debug	(	"str"	)	
logging	.	info	(	"str"	)	
logging	.	warning	(	"str"	)	
logging	.	error	(	"str"	)	


class	LoggingInitWarningTest	(	absltest	.	TestCase	)	:	

def	test_captured_pre_init_warnings	(	self	)	:	
with	open	(	before_set_verbosity_filename	)	as	stderr_capture_file	:	
captured_stderr	=	stderr_capture_file	.	read	(	)	
self	.	assertNotIn	(	"str"	,	captured_stderr	)	
self	.	assertNotIn	(	"str"	,	captured_stderr	)	

traceback_re	=	re	.	compile	(	
"str"	,	
re	.	MULTILINE	|	re	.	DOTALL	)	
if	not	traceback_re	.	search	(	captured_stderr	)	:	
self	.	fail	(	
"str"	
"str"	.	format	(	captured_stderr	)	)	

captured_stderr	=	traceback_re	.	sub	(	"str"	,	captured_stderr	)	
captured_stderr_lines	=	captured_stderr	.	splitlines	(	)	
self	.	assertLen	(	captured_stderr_lines	,	3	)	
self	.	assertIn	(	"str"	,	captured_stderr_lines	[	0	]	)	
self	.	assertIn	(	"str"	,	captured_stderr_lines	[	1	]	)	
self	.	assertIn	(	"str"	,	captured_stderr_lines	[	2	]	)	

def	test_set_verbosity_pre_init	(	self	)	:	
with	open	(	after_set_verbosity_filename	)	as	stderr_capture_file	:	
captured_stderr	=	stderr_capture_file	.	read	(	)	
captured_stderr_lines	=	captured_stderr	.	splitlines	(	)	

self	.	assertNotIn	(	"str"	,	captured_stderr	)	
self	.	assertNotIn	(	"str"	,	captured_stderr	)	
self	.	assertNotIn	(	"str"	,	captured_stderr	)	
self	.	assertLen	(	captured_stderr_lines	,	1	)	
self	.	assertIn	(	"str"	,	captured_stderr_lines	[	0	]	)	

def	test_no_more_warnings	(	self	)	:	
fake_stderr_type	=	io	.	BytesIO	if	bytes	is	str	else	io	.	StringIO	
with	mock	.	patch	(	"str"	,	new	=	fake_stderr_type	(	)	)	as	mock_stderr	:	
self	.	assertMultiLineEqual	(	"str"	,	mock_stderr	.	getvalue	(	)	)	
logging	.	warning	(	"str"	)	
self	.	assertNotIn	(	"str"	,	
mock_stderr	.	getvalue	(	)	)	
logging	.	info	(	"str"	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	