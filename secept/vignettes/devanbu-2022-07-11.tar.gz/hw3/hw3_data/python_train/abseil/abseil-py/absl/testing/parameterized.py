















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	collections	
import	functools	
import	re	
import	types	
import	unittest	

from	absl	.	_collections_abc	import	abc	
from	absl	.	testing	import	absltest	
import	six	

_ADDR_RE	=	re	.	compile	(	"str"	)	
_NAMED	=	object	(	)	
_ARGUMENT_REPR	=	object	(	)	
_NAMED_DICT_KEY	=	"str"	


class	NoTestsError	(	Exception	)	:	



class	DuplicateTestNameError	(	Exception	)	:	


def	__init__	(	self	,	test_class_name	,	new_test_name	,	original_test_name	)	:	
super	(	DuplicateTestNameError	,	self	)	.	__init__	(	
"str"	
"str"	
"str"	
"str"	.	format	(	
test_class_name	,	new_test_name	,	original_test_name	)	)	


def	_clean_repr	(	obj	)	:	
return	_ADDR_RE	.	sub	(	"str"	,	repr	(	obj	)	)	


def	_non_string_or_bytes_iterable	(	obj	)	:	
return	(	isinstance	(	obj	,	abc	.	Iterable	)	and	
not	isinstance	(	obj	,	six	.	text_type	)	and	
not	isinstance	(	obj	,	six	.	binary_type	)	)	


def	_format_parameter_list	(	testcase_params	)	:	
if	isinstance	(	testcase_params	,	abc	.	Mapping	)	:	
return	"str"	.	join	(	"str"	%	(	argname	,	_clean_repr	(	value	)	)	
for	argname	,	value	in	six	.	iteritems	(	testcase_params	)	)	
elif	_non_string_or_bytes_iterable	(	testcase_params	)	:	
return	"str"	.	join	(	map	(	_clean_repr	,	testcase_params	)	)	
else	:	
return	_format_parameter_list	(	(	testcase_params	,	)	)	


class	_ParameterizedTestIter	(	object	)	:	


def	__init__	(	self	,	test_method	,	testcases	,	naming_type	,	original_name	=	None	)	:	

self	.	_test_method	=	test_method	
self	.	testcases	=	testcases	
self	.	_naming_type	=	naming_type	
if	original_name	is	None	:	
original_name	=	test_method	.	__name__	
self	.	_original_name	=	original_name	
self	.	__name__	=	_ParameterizedTestIter	.	__name__	

def	__call__	(	self	,	*	args	,	*	*	kwargs	)	:	
raise	RuntimeError	(	"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	

def	__iter__	(	self	)	:	
test_method	=	self	.	_test_method	
naming_type	=	self	.	_naming_type	
extra_ids	=	collections	.	defaultdict	(	int	)	

def	make_bound_param_test	(	testcase_params	)	:	
@functools.wraps	(	test_method	)	
def	bound_param_test	(	self	)	:	
if	isinstance	(	testcase_params	,	abc	.	Mapping	)	:	
test_method	(	self	,	*	*	testcase_params	)	
elif	_non_string_or_bytes_iterable	(	testcase_params	)	:	
test_method	(	self	,	*	testcase_params	)	
else	:	
test_method	(	self	,	testcase_params	)	

if	naming_type	is	_NAMED	:	


bound_param_test	.	__x_use_name__	=	True	

testcase_name	=	None	
if	isinstance	(	testcase_params	,	abc	.	Mapping	)	:	
if	_NAMED_DICT_KEY	not	in	testcase_params	:	
raise	RuntimeError	(	
"str"	%	_NAMED_DICT_KEY	)	

testcase_name	=	testcase_params	[	_NAMED_DICT_KEY	]	
testcase_params	=	{	k	:	v	for	k	,	v	in	six	.	iteritems	(	testcase_params	)	
if	k	!=	_NAMED_DICT_KEY	}	
elif	_non_string_or_bytes_iterable	(	testcase_params	)	:	
testcase_name	=	testcase_params	[	0	]	
testcase_params	=	testcase_params	[	1	:	]	
else	:	
raise	RuntimeError	(	
"str"	)	

test_method_name	=	self	.	_original_name	

if	(	test_method_name	.	startswith	(	"str"	)	
and	testcase_name	
and	not	testcase_name	.	startswith	(	"str"	)	)	:	
test_method_name	+	=	"str"	

bound_param_test	.	__name__	=	test_method_name	+	str	(	testcase_name	)	
elif	naming_type	is	_ARGUMENT_REPR	:	


if	isinstance	(	testcase_params	,	types	.	GeneratorType	)	:	
testcase_params	=	tuple	(	testcase_params	)	





extra_id	=	"str"	%	(	_format_parameter_list	(	testcase_params	)	,	)	
extra_ids	[	extra_id	]	+	=	1	
while	extra_ids	[	extra_id	]	>	1	:	
extra_id	=	"str"	%	(	extra_id	,	extra_ids	[	extra_id	]	)	
extra_ids	[	extra_id	]	+	=	1	
bound_param_test	.	__x_extra_id__	=	extra_id	
else	:	
raise	RuntimeError	(	"str"	%	(	naming_type	,	)	)	

bound_param_test	.	__doc__	=	"str"	%	(	
bound_param_test	.	__name__	,	_format_parameter_list	(	testcase_params	)	)	
if	test_method	.	__doc__	:	
bound_param_test	.	__doc__	+	=	"str"	%	(	test_method	.	__doc__	,	)	
return	bound_param_test	

return	(	make_bound_param_test	(	c	)	for	c	in	self	.	testcases	)	


def	_modify_class	(	class_object	,	testcases	,	naming_type	)	:	
assert	not	getattr	(	class_object	,	"str"	,	None	)	,	(	
"str"	
"str"	%	(	
class_object	,	)	)	
class_object	.	_test_method_ids	=	test_method_ids	=	{	}	
for	name	,	obj	in	six	.	iteritems	(	class_object	.	__dict__	.	copy	(	)	)	:	
if	(	name	.	startswith	(	unittest	.	TestLoader	.	testMethodPrefix	)	
and	isinstance	(	obj	,	types	.	FunctionType	)	)	:	
delattr	(	class_object	,	name	)	
methods	=	{	}	
_update_class_dict_for_param_test_case	(	
class_object	.	__name__	,	methods	,	test_method_ids	,	name	,	
_ParameterizedTestIter	(	obj	,	testcases	,	naming_type	,	name	)	)	
for	name	,	meth	in	six	.	iteritems	(	methods	)	:	
setattr	(	class_object	,	name	,	meth	)	


def	_parameter_decorator	(	naming_type	,	testcases	)	:	

def	_apply	(	obj	)	:	
if	isinstance	(	obj	,	type	)	:	
_modify_class	(	obj	,	testcases	,	naming_type	)	
return	obj	
else	:	
return	_ParameterizedTestIter	(	obj	,	testcases	,	naming_type	)	

if	(	len	(	testcases	)	==	1	and	
not	isinstance	(	testcases	[	0	]	,	tuple	)	and	
not	(	naming_type	==	_NAMED	and	
isinstance	(	testcases	[	0	]	,	abc	.	Mapping	)	)	)	:	



assert	_non_string_or_bytes_iterable	(	testcases	[	0	]	)	,	(	
"str"	)	
testcases	=	testcases	[	0	]	

if	not	isinstance	(	testcases	,	abc	.	Sequence	)	:	
testcases	=	list	(	testcases	)	
if	not	testcases	:	
raise	NoTestsError	(	
"str"	
"str"	
"str"	)	

return	_apply	


def	parameters	(	*	testcases	)	:	

return	_parameter_decorator	(	_ARGUMENT_REPR	,	testcases	)	


def	named_parameters	(	*	testcases	)	:	

return	_parameter_decorator	(	_NAMED	,	testcases	)	


class	TestGeneratorMetaclass	(	type	)	:	


def	__new__	(	mcs	,	class_name	,	bases	,	dct	)	:	
test_method_ids	=	dct	.	setdefault	(	"str"	,	{	}	)	
for	name	,	obj	in	six	.	iteritems	(	dct	.	copy	(	)	)	:	
if	(	name	.	startswith	(	unittest	.	TestLoader	.	testMethodPrefix	)	and	
_non_string_or_bytes_iterable	(	obj	)	)	:	
if	isinstance	(	obj	,	_ParameterizedTestIter	)	:	





obj	.	_original_name	=	name	
iterator	=	iter	(	obj	)	
dct	.	pop	(	name	)	
_update_class_dict_for_param_test_case	(	
class_name	,	dct	,	test_method_ids	,	name	,	iterator	)	


for	base	in	bases	:	





if	getattr	(	base	,	"str"	,	None	)	and	issubclass	(	base	,	TestCase	)	:	
for	test_method	,	test_method_id	in	six	.	iteritems	(	base	.	_test_method_ids	)	:	



test_method_ids	.	setdefault	(	test_method	,	test_method_id	)	

return	type	.	__new__	(	mcs	,	class_name	,	bases	,	dct	)	


def	_update_class_dict_for_param_test_case	(	
test_class_name	,	dct	,	test_method_ids	,	name	,	iterator	)	:	

for	idx	,	func	in	enumerate	(	iterator	)	:	
assert	callable	(	func	)	,	"str"	%	(	
func	,	)	
if	getattr	(	func	,	"str"	,	False	)	:	
original_name	=	func	.	__name__	
new_name	=	original_name	
else	:	
original_name	=	name	
new_name	=	"str"	%	(	original_name	,	idx	)	

if	new_name	in	dct	:	
raise	DuplicateTestNameError	(	test_class_name	,	new_name	,	original_name	)	

dct	[	new_name	]	=	func	
test_method_id	=	original_name	+	getattr	(	func	,	"str"	,	"str"	)	
assert	test_method_id	not	in	test_method_ids	.	values	(	)	,	(	
"str"	%	(	test_method_id	,	)	)	
test_method_ids	[	new_name	]	=	test_method_id	


class	TestCase	(	six	.	with_metaclass	(	TestGeneratorMetaclass	,	absltest	.	TestCase	)	)	:	


def	__str__	(	self	)	:	
return	"str"	%	(	
self	.	_test_method_ids	.	get	(	self	.	_testMethodName	,	self	.	_testMethodName	)	,	
unittest	.	util	.	strclass	(	self	.	__class__	)	)	

def	id	(	self	)	:	

return	"str"	%	(	
unittest	.	util	.	strclass	(	self	.	__class__	)	,	


self	.	_test_method_ids	.	get	(	self	.	_testMethodName	,	self	.	_testMethodName	)	)	



def	CoopTestCase	(	other_base_class	)	:	

metaclass	=	type	(	
"str"	,	
(	other_base_class	.	__metaclass__	,	
TestGeneratorMetaclass	)	,	{	}	)	
return	metaclass	(	
"str"	,	
(	other_base_class	,	TestCase	)	,	{	}	)	
	