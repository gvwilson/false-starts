















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	collections	
import	io	
import	os	
import	re	
import	string	
import	subprocess	
import	sys	
import	tempfile	

from	absl	import	flags	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	
import	six	

PY_VERSION_2	=	sys	.	version_info	[	0	]	==	2	

FLAGS	=	flags	.	FLAGS	


class	HelperMixin	(	object	)	:	

def	_get_helper_exec_path	(	self	)	:	
helper	=	"str"	
return	_bazelize_command	.	get_executable_path	(	helper	)	

def	run_helper	(	self	,	test_id	,	args	,	env_overrides	,	expect_success	)	:	
env	=	os	.	environ	.	copy	(	)	
for	key	,	value	in	six	.	iteritems	(	env_overrides	)	:	
if	value	is	None	:	
if	key	in	env	:	
del	env	[	key	]	
else	:	
env	[	key	]	=	value	

command	=	[	self	.	_get_helper_exec_path	(	)	,	
"str"	.	format	(	test_id	)	]	+	args	
process	=	subprocess	.	Popen	(	
command	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	env	=	env	,	
universal_newlines	=	True	)	
stdout	,	stderr	=	process	.	communicate	(	)	
if	expect_success	:	
self	.	assertEqual	(	
0	,	process	.	returncode	,	
"str"	
"str"	.	format	(	stdout	,	stderr	)	)	
else	:	
self	.	assertEqual	(	
1	,	process	.	returncode	,	
"str"	
"str"	.	format	(	stdout	,	stderr	)	)	
return	stdout	,	stderr	


class	TestCaseTest	(	absltest	.	TestCase	,	HelperMixin	)	:	
longMessage	=	True	

def	run_helper	(	self	,	test_id	,	args	,	env_overrides	,	expect_success	)	:	
return	super	(	TestCaseTest	,	self	)	.	run_helper	(	test_id	,	args	+	[	"str"	]	,	
env_overrides	,	expect_success	)	

def	test_flags_no_env_var_no_flags	(	self	)	:	
self	.	run_helper	(	
1	,	
[	]	,	
{	"str"	:	None	,	
"str"	:	None	,	
"str"	:	None	,	
}	,	
expect_success	=	True	)	

def	test_flags_env_var_no_flags	(	self	)	:	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
srcdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
2	,	
[	]	,	
{	"str"	:	"str"	,	
"str"	:	srcdir	,	
"str"	:	tmpdir	,	
"str"	:	srcdir	,	
"str"	:	tmpdir	,	
}	,	
expect_success	=	True	)	

def	test_flags_no_env_var_flags	(	self	)	:	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
srcdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
3	,	
[	"str"	,	"str"	.	format	(	srcdir	)	,	
"str"	.	format	(	tmpdir	)	]	,	
{	"str"	:	None	,	
"str"	:	None	,	
"str"	:	None	,	
"str"	:	srcdir	,	
"str"	:	tmpdir	,	
}	,	
expect_success	=	True	)	

def	test_flags_env_var_flags	(	self	)	:	
tmpdir_from_flag	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
srcdir_from_flag	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
tmpdir_from_env_var	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
srcdir_from_env_var	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
4	,	
[	"str"	,	"str"	.	format	(	srcdir_from_flag	)	,	
"str"	.	format	(	tmpdir_from_flag	)	]	,	
{	"str"	:	"str"	,	
"str"	:	srcdir_from_env_var	,	
"str"	:	tmpdir_from_env_var	,	
"str"	:	srcdir_from_flag	,	
"str"	:	tmpdir_from_flag	,	
}	,	
expect_success	=	True	)	

def	test_xml_output_file_from_xml_output_file_env	(	self	)	:	
xml_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
xml_output_file_env	=	os	.	path	.	join	(	xml_dir	,	"str"	)	
random_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
6	,	
[	]	,	
{	"str"	:	xml_output_file_env	,	
"str"	:	"str"	,	
"str"	:	random_dir	,	
"str"	:	xml_output_file_env	,	
}	,	
expect_success	=	True	)	

def	test_xml_output_file_from_daemon	(	self	)	:	
tmpdir	=	os	.	path	.	join	(	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	,	"str"	)	
random_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
6	,	
[	"str"	,	tmpdir	]	,	
{	"str"	:	None	,	
"str"	:	"str"	,	
"str"	:	random_dir	,	
"str"	:	os	.	path	.	join	(	
os	.	path	.	dirname	(	tmpdir	)	,	"str"	)	,	
}	,	
expect_success	=	True	)	

def	test_xml_output_file_from_test_xmloutputdir_env	(	self	)	:	
xml_output_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
expected_xml_file	=	"str"	
self	.	run_helper	(	
6	,	
[	]	,	
{	"str"	:	None	,	
"str"	:	None	,	
"str"	:	xml_output_dir	,	
"str"	:	os	.	path	.	join	(	
xml_output_dir	,	expected_xml_file	)	,	
}	,	
expect_success	=	True	)	

def	test_xml_output_file_from_flag	(	self	)	:	
random_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
flag_file	=	os	.	path	.	join	(	
tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	,	"str"	)	
self	.	run_helper	(	
6	,	
[	"str"	,	flag_file	]	,	
{	"str"	:	os	.	path	.	join	(	random_dir	,	"str"	)	,	
"str"	:	"str"	,	
"str"	:	random_dir	,	
"str"	:	flag_file	,	
}	,	
expect_success	=	True	)	

def	test_assert_in	(	self	)	:	
animals	=	{	"str"	:	"str"	,	"str"	:	"str"	,	"str"	:	"str"	}	

self	.	assertIn	(	"str"	,	"str"	)	
self	.	assertIn	(	2	,	[	1	,	2	,	3	]	)	
self	.	assertIn	(	"str"	,	animals	)	

self	.	assertNotIn	(	"str"	,	"str"	)	
self	.	assertNotIn	(	0	,	[	1	,	2	,	3	]	)	
self	.	assertNotIn	(	"str"	,	animals	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertIn	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIn	,	4	,	[	1	,	2	,	3	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIn	,	"str"	,	animals	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertNotIn	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotIn	,	1	,	[	1	,	2	,	3	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotIn	,	"str"	,	animals	)	

@absltest.expectedFailure	
def	test_expected_failure	(	self	)	:	
self	.	assertEqual	(	1	,	2	)	

@absltest.expectedFailureIf	(	True	,	"str"	)	
def	test_expected_failure_if	(	self	)	:	
self	.	assertEqual	(	1	,	2	)	

def	test_expected_failure_success	(	self	)	:	
_	,	stderr	=	self	.	run_helper	(	5	,	[	"str"	,	"str"	]	,	{	}	,	expect_success	=	False	)	
self	.	assertRegex	(	stderr	,	"str"	)	

def	test_assert_equal	(	self	)	:	
self	.	assertListEqual	(	[	]	,	[	]	)	
self	.	assertTupleEqual	(	(	)	,	(	)	)	
self	.	assertSequenceEqual	(	[	]	,	(	)	)	

a	=	[	0	,	"str"	,	[	]	]	
b	=	[	]	
self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertListEqual	,	a	,	b	)	
self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertListEqual	,	tuple	(	a	)	,	tuple	(	b	)	)	
self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertSequenceEqual	,	a	,	tuple	(	b	)	)	

b	.	extend	(	a	)	
self	.	assertListEqual	(	a	,	b	)	
self	.	assertTupleEqual	(	tuple	(	a	)	,	tuple	(	b	)	)	
self	.	assertSequenceEqual	(	a	,	tuple	(	b	)	)	
self	.	assertSequenceEqual	(	tuple	(	a	)	,	b	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertListEqual	,	a	,	tuple	(	b	)	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTupleEqual	,	tuple	(	a	)	,	b	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertListEqual	,	None	,	b	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTupleEqual	,	None	,	tuple	(	b	)	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSequenceEqual	,	None	,	tuple	(	b	)	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertListEqual	,	1	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTupleEqual	,	1	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSequenceEqual	,	1	,	1	)	

self	.	assertSameElements	(	[	1	,	2	,	3	]	,	[	3	,	2	,	1	]	)	
self	.	assertSameElements	(	[	1	,	2	]	+	[	3	]	*	100	,	[	1	]	*	100	+	[	2	,	3	]	)	
self	.	assertSameElements	(	[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSameElements	,	[	10	]	,	[	10	,	11	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSameElements	,	[	10	,	11	]	,	[	10	]	)	


self	.	assertSameElements	(	[	[	1	,	2	]	,	[	3	,	4	]	]	,	[	[	3	,	4	]	,	[	1	,	2	]	]	)	
if	PY_VERSION_2	:	



self	.	assertSameElements	(	[	{	"str"	:	1	}	,	{	"str"	:	2	}	]	,	[	{	"str"	:	2	}	,	{	"str"	:	1	}	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSameElements	,	[	[	1	]	]	,	[	[	2	]	]	)	

def	test_assert_items_equal_hotfix	(	self	)	:	

for	assert_items_method	in	(	self	.	assertItemsEqual	,	self	.	assertCountEqual	)	:	
with	self	.	assertRaises	(	self	.	failureException	)	as	error_context	:	
assert_items_method	(	[	4	]	,	[	2	]	)	
error_message	=	str	(	error_context	.	exception	)	



self	.	assertIn	(	"str"	,	error_message	)	
self	.	assertIn	(	"str"	,	error_message	)	

def	test_assert_dict_equal	(	self	)	:	
self	.	assertDictEqual	(	{	}	,	{	}	)	

c	=	{	"str"	:	1	}	
d	=	{	}	
self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictEqual	,	c	,	d	)	

d	.	update	(	c	)	
self	.	assertDictEqual	(	c	,	d	)	

d	[	"str"	]	=	0	
self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictEqual	,	c	,	d	,	"str"	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertDictEqual	,	None	,	d	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertDictEqual	,	[	]	,	d	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertDictEqual	,	1	,	1	)	

try	:	


self	.	assertDictEqual	(	{	1	:	1.0	,	2	:	2	}	,	{	1	:	1	,	2	:	3	}	)	
except	AssertionError	as	e	:	
self	.	assertMultiLineEqual	(	"str"	
"str"	,	
str	(	e	)	)	

try	:	
self	.	assertDictEqual	(	{	}	,	{	"str"	:	1	}	)	
except	AssertionError	as	e	:	
self	.	assertMultiLineEqual	(	"str"	
"str"	,	
str	(	e	)	)	
else	:	
self	.	fail	(	"str"	)	

try	:	
self	.	assertDictEqual	(	{	}	,	{	"str"	:	1	}	,	"str"	)	
except	AssertionError	as	e	:	
self	.	assertIn	(	"str"	,	str	(	e	)	)	
else	:	
self	.	fail	(	"str"	)	

expected	=	{	"str"	:	1	,	"str"	:	2	,	"str"	:	3	}	
seen	=	{	"str"	:	2	,	"str"	:	3	,	"str"	:	4	}	
try	:	
self	.	assertDictEqual	(	expected	,	seen	)	
except	AssertionError	as	e	:	
self	.	assertMultiLineEqual	(	"str"	,	str	(	e	)	)	
else	:	
self	.	fail	(	"str"	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertDictEqual	,	(	1	,	2	)	,	{	}	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertDictEqual	,	{	}	,	(	1	,	2	)	)	




class	Obj	(	object	)	:	

def	__init__	(	self	,	name	)	:	
self	.	name	=	name	

def	__repr__	(	self	)	:	
return	self	.	name	

try	:	
self	.	assertDictEqual	(	
{	"str"	:	Obj	(	"str"	)	,	Obj	(	"str"	)	:	Obj	(	"str"	)	,	Obj	(	"str"	)	:	Obj	(	"str"	)	}	,	
{	"str"	:	Obj	(	"str"	)	,	Obj	(	"str"	)	:	Obj	(	"str"	)	,	Obj	(	"str"	)	:	Obj	(	"str"	)	}	)	
except	AssertionError	as	e	:	


err_str	=	str	(	e	)	
self	.	assertStartsWith	(	err_str	,	
"str"	)	
self	.	assertRegex	(	
err_str	,	"str"	
"str"	)	
self	.	assertRegex	(	
err_str	,	"str"	
"str"	,	err_str	)	
self	.	assertRegex	(	
err_str	,	"str"	
"str"	)	
else	:	
self	.	fail	(	"str"	)	


class	RaisesOnRepr	(	object	)	:	

def	__repr__	(	self	)	:	
return	1	/	0	

try	:	
self	.	assertDictEqual	(	
{	RaisesOnRepr	(	)	:	RaisesOnRepr	(	)	}	,	
{	RaisesOnRepr	(	)	:	RaisesOnRepr	(	)	}	
)	
self	.	fail	(	"str"	)	
except	AssertionError	as	e	:	


error_msg	=	re	.	sub	(	
"str"	,	"str"	,	str	(	e	)	)	
self	.	assertRegex	(	error_msg	,	"str"	)	


class	RaisesOnLt	(	object	)	:	

def	__lt__	(	self	,	unused_other	)	:	
raise	TypeError	(	"str"	)	

def	__repr__	(	self	)	:	
return	"str"	

try	:	
self	.	assertDictEqual	(	
{	RaisesOnLt	(	)	:	RaisesOnLt	(	)	}	,	
{	RaisesOnLt	(	)	:	RaisesOnLt	(	)	}	)	
except	AssertionError	as	e	:	
self	.	assertIn	(	"str"	,	str	(	e	)	)	
self	.	assertIn	(	"str"	,	str	(	e	)	)	

def	test_assert_set_equal	(	self	)	:	
set1	=	set	(	)	
set2	=	set	(	)	
self	.	assertSetEqual	(	set1	,	set2	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	None	,	set2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	[	]	,	set2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	None	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	[	]	)	

set1	=	set	(	[	"str"	]	)	
set2	=	set	(	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	set2	)	

set1	=	set	(	[	"str"	]	)	
set2	=	set	(	[	"str"	]	)	
self	.	assertSetEqual	(	set1	,	set2	)	

set1	=	set	(	[	"str"	]	)	
set2	=	set	(	[	"str"	,	"str"	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	set2	)	

set1	=	set	(	[	"str"	]	)	
set2	=	frozenset	(	[	"str"	,	"str"	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	set2	)	

set1	=	set	(	[	"str"	,	"str"	]	)	
set2	=	frozenset	(	[	"str"	,	"str"	]	)	
self	.	assertSetEqual	(	set1	,	set2	)	

set1	=	set	(	)	
set2	=	"str"	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	set2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set2	,	set1	)	


set1	=	set	(	[	(	0	,	1	)	,	(	2	,	3	)	]	)	
set2	=	set	(	[	(	4	,	5	)	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertSetEqual	,	set1	,	set2	)	

def	test_assert_dict_contains_subset	(	self	)	:	
self	.	assertDictContainsSubset	(	{	}	,	{	}	)	

self	.	assertDictContainsSubset	(	{	}	,	{	"str"	:	1	}	)	

self	.	assertDictContainsSubset	(	{	"str"	:	1	}	,	{	"str"	:	1	}	)	

self	.	assertDictContainsSubset	(	{	"str"	:	1	}	,	{	"str"	:	1	,	"str"	:	2	}	)	

self	.	assertDictContainsSubset	(	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	2	}	)	

self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictContainsSubset	,	{	"str"	:	2	}	,	{	"str"	:	1	}	,	
"str"	)	

self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictContainsSubset	,	{	"str"	:	1	}	,	{	"str"	:	1	}	,	
"str"	)	

self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictContainsSubset	,	{	"str"	:	1	,	"str"	:	1	}	,	{	"str"	:	1	}	,	
"str"	)	

self	.	assertRaises	(	absltest	.	TestCase	.	failureException	,	
self	.	assertDictContainsSubset	,	{	"str"	:	1	,	"str"	:	1	}	,	{	"str"	:	1	}	,	
"str"	)	

def	test_assert_sequence_almost_equal	(	self	)	:	
actual	=	(	1.1	,	1.2	,	1.4	)	


self	.	assertSequenceAlmostEqual	(	(	1.1	,	1.2	,	1.4	)	,	actual	)	
self	.	assertSequenceAlmostEqual	(	[	1.1	,	1.2	,	1.4	]	,	actual	)	


with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertSequenceAlmostEqual	(	[	1.1	,	1.2	]	,	actual	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertSequenceAlmostEqual	(	[	1.1	,	1.2	,	1.4	,	1.5	]	,	actual	)	


with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertSequenceAlmostEqual	(	(	1.15	,	1.15	,	1.4	)	,	actual	)	
self	.	assertSequenceAlmostEqual	(	(	1.15	,	1.15	,	1.4	)	,	actual	,	delta	=	0.1	)	


with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertSequenceAlmostEqual	(	(	1.1001	,	1.2001	,	1.3999	)	,	actual	)	
self	.	assertSequenceAlmostEqual	(	(	1.1001	,	1.2001	,	1.3999	)	,	actual	,	places	=	3	)	

def	test_assert_contains_subset	(	self	)	:	


actual	=	(	"str"	,	"str"	,	"str"	)	
self	.	assertContainsSubset	(	{	"str"	,	"str"	}	,	actual	)	
self	.	assertContainsSubset	(	(	"str"	,	"str"	)	,	actual	)	
self	.	assertContainsSubset	(	{	"str"	:	1	,	"str"	:	2	}	,	list	(	actual	)	)	
self	.	assertContainsSubset	(	[	"str"	,	"str"	]	,	set	(	actual	)	)	
self	.	assertContainsSubset	(	[	]	,	set	(	)	)	
self	.	assertContainsSubset	(	[	]	,	{	"str"	:	1	}	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertContainsSubset	,	(	"str"	,	)	,	actual	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertContainsSubset	,	[	"str"	]	,	
set	(	actual	)	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertContainsSubset	,	{	"str"	:	1	}	,	[	]	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
self	.	assertContainsSubset	(	{	1	,	2	,	3	}	,	{	1	,	2	}	)	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
re	.	compile	(	"str"	,	re	.	DOTALL	)	)	:	
self	.	assertContainsSubset	(	{	1	,	2	}	,	{	1	}	,	"str"	)	

def	test_assert_no_common_elements	(	self	)	:	
actual	=	(	"str"	,	"str"	,	"str"	)	
self	.	assertNoCommonElements	(	(	)	,	actual	)	
self	.	assertNoCommonElements	(	(	"str"	,	"str"	)	,	actual	)	
self	.	assertNoCommonElements	(	{	"str"	,	"str"	}	,	actual	)	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
re	.	compile	(	"str"	,	re	.	DOTALL	)	)	:	
self	.	assertNoCommonElements	(	{	1	,	2	}	,	{	1	}	,	"str"	)	

with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertNoCommonElements	(	[	"str"	]	,	actual	)	

with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertNoCommonElements	(	{	"str"	,	"str"	,	"str"	}	,	actual	)	

with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertNoCommonElements	(	{	"str"	,	"str"	}	,	set	(	actual	)	)	

def	test_assert_almost_equal	(	self	)	:	
self	.	assertAlmostEqual	(	1.00000001	,	1.0	)	
self	.	assertNotAlmostEqual	(	1.0000001	,	1.0	)	

def	test_assert_almost_equals_with_delta	(	self	)	:	
self	.	assertAlmostEquals	(	3.14	,	3	,	delta	=	0.2	)	
self	.	assertAlmostEquals	(	2.81	,	3.14	,	delta	=	1	)	
self	.	assertAlmostEquals	(	-	1	,	1	,	delta	=	3	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertAlmostEquals	,	
3.14	,	2.81	,	delta	=	0.1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertAlmostEquals	,	
1	,	2	,	delta	=	0.5	)	
self	.	assertNotAlmostEquals	(	3.14	,	2.81	,	delta	=	0.1	)	

def	test_assert_starts_with	(	self	)	:	
self	.	assertStartsWith	(	"str"	,	"str"	)	
self	.	assertStartsWith	(	"str"	,	"str"	)	
msg	=	"str"	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertStartsWith	,	
"str"	,	"str"	,	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertStartsWith	,	"str"	,	"str"	)	

def	test_assert_not_starts_with	(	self	)	:	
self	.	assertNotStartsWith	(	"str"	,	"str"	)	
self	.	assertNotStartsWith	(	"str"	,	"str"	)	
msg	=	"str"	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertNotStartsWith	,	
"str"	,	"str"	,	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotStartsWith	,	"str"	,	
"str"	)	

def	test_assert_ends_with	(	self	)	:	
self	.	assertEndsWith	(	"str"	,	"str"	)	
self	.	assertEndsWith	(	"str"	,	"str"	)	
msg	=	"str"	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertEndsWith	,	
"str"	,	"str"	,	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertEndsWith	,	"str"	,	"str"	)	

def	test_assert_not_ends_with	(	self	)	:	
self	.	assertNotEndsWith	(	"str"	,	"str"	)	
self	.	assertNotEndsWith	(	"str"	,	"str"	)	
msg	=	"str"	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertNotEndsWith	,	
"str"	,	"str"	,	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEndsWith	,	"str"	,	
"str"	)	

def	test_assert_regex_backports	(	self	)	:	
self	.	assertRegex	(	"str"	,	"str"	)	
self	.	assertNotRegex	(	"str"	,	"str"	)	
with	self	.	assertRaisesRegex	(	ValueError	,	"str"	)	:	
raise	ValueError	(	"str"	)	

def	test_assert_regex_match_matches	(	self	)	:	
self	.	assertRegexMatch	(	"str"	,	[	"str"	]	)	

def	test_assert_regex_match_matches_substring	(	self	)	:	
self	.	assertRegexMatch	(	"str"	,	[	"str"	]	)	

def	test_assert_regex_match_multiple_regex_matches	(	self	)	:	
self	.	assertRegexMatch	(	"str"	,	[	"str"	,	"str"	]	)	

def	test_assert_regex_match_empty_list_fails	(	self	)	:	
expected_re	=	re	.	compile	(	"str"	,	re	.	MULTILINE	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	expected_re	)	:	
self	.	assertRegexMatch	(	"str"	,	regexes	=	[	]	)	

def	test_assert_regex_match_bad_arguments	(	self	)	:	
with	self	.	assertRaisesRegex	(	AssertionError	,	
"str"	)	:	
self	.	assertRegexMatch	(	"str"	,	"str"	)	

def	test_assert_regex_match_unicode_vs_bytes	(	self	)	:	

self	.	assertRegexMatch	(	"str"	,	[	b	"str"	]	)	
self	.	assertRegexMatch	(	b	"str"	,	[	"str"	]	)	

def	test_assert_regex_match_unicode	(	self	)	:	
self	.	assertRegexMatch	(	"str"	,	[	"str"	]	)	

def	test_assert_regex_match_bytes	(	self	)	:	
self	.	assertRegexMatch	(	b	"str"	,	[	b	"str"	]	)	

def	test_assert_regex_match_all_the_same_type	(	self	)	:	
with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
self	.	assertRegexMatch	(	"str"	,	[	b	"str"	,	"str"	]	)	

def	test_assert_command_fails_stderr	(	self	)	:	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	assertCommandFails	(	
[	"str"	,	os	.	path	.	join	(	tmpdir	,	"str"	)	]	,	
[	"str"	]	)	

def	test_assert_command_fails_with_list_of_string	(	self	)	:	
self	.	assertCommandFails	(	[	"str"	]	,	[	"str"	]	)	

def	test_assert_command_fails_with_list_of_unicode_string	(	self	)	:	
self	.	assertCommandFails	(	[	"str"	]	,	[	"str"	]	)	

def	test_assert_command_fails_with_unicode_string	(	self	)	:	
self	.	assertCommandFails	(	"str"	,	[	"str"	]	)	

def	test_assert_command_fails_with_unicode_string_bytes_regex	(	self	)	:	
self	.	assertCommandFails	(	"str"	,	[	b	"str"	]	)	

def	test_assert_command_fails_with_message	(	self	)	:	
msg	=	"str"	
expected_re	=	re	.	compile	(	"str"	
"str"	,	re	.	DOTALL	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	expected_re	)	:	
self	.	assertCommandFails	(	[	"str"	]	,	[	"str"	]	,	msg	=	msg	)	

def	test_assert_command_succeeds_stderr	(	self	)	:	
expected_re	=	re	.	compile	(	"str"	)	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	expected_re	)	:	
self	.	assertCommandSucceeds	(	[	"str"	,	os	.	path	.	join	(	tmpdir	,	"str"	)	]	)	

def	test_assert_command_succeeds_with_matching_unicode_regexes	(	self	)	:	
self	.	assertCommandSucceeds	(	[	"str"	,	"str"	]	,	regexes	=	[	"str"	]	)	

def	test_assert_command_succeeds_with_matching_bytes_regexes	(	self	)	:	
self	.	assertCommandSucceeds	(	[	"str"	,	"str"	]	,	regexes	=	[	b	"str"	]	)	

def	test_assert_command_succeeds_with_non_matching_regexes	(	self	)	:	
expected_re	=	re	.	compile	(	"str"	,	
re	.	DOTALL	)	
msg	=	"str"	

with	self	.	assertRaisesRegex	(	AssertionError	,	expected_re	)	:	
self	.	assertCommandSucceeds	(	[	"str"	,	"str"	]	,	regexes	=	[	"str"	]	,	msg	=	msg	)	

def	test_assert_command_succeeds_with_list_of_string	(	self	)	:	
self	.	assertCommandSucceeds	(	[	"str"	]	)	

def	test_assert_command_succeeds_with_list_of_unicode_string	(	self	)	:	
self	.	assertCommandSucceeds	(	[	"str"	]	)	

def	test_assert_command_succeeds_with_unicode_string	(	self	)	:	


self	.	assertCommandSucceeds	(	"str"	,	env	=	dict	(	os	.	environ	)	)	

def	test_inequality	(	self	)	:	

self	.	assertGreater	(	2	,	1	)	
self	.	assertGreaterEqual	(	2	,	1	)	
self	.	assertGreaterEqual	(	1	,	1	)	
self	.	assertLess	(	1	,	2	)	
self	.	assertLessEqual	(	1	,	2	)	
self	.	assertLessEqual	(	1	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	1	,	2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	1	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	1	,	2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	2	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	1	,	1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	2	,	1	)	


self	.	assertGreater	(	1.1	,	1.0	)	
self	.	assertGreaterEqual	(	1.1	,	1.0	)	
self	.	assertGreaterEqual	(	1.0	,	1.0	)	
self	.	assertLess	(	1.0	,	1.1	)	
self	.	assertLessEqual	(	1.0	,	1.1	)	
self	.	assertLessEqual	(	1.0	,	1.0	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	1.0	,	1.1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	1.0	,	1.0	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	1.0	,	1.1	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	1.1	,	1.0	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	1.0	,	1.0	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	1.1	,	1.0	)	


self	.	assertGreater	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertLess	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	"str"	,	"str"	)	


self	.	assertGreater	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertLess	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	"str"	,	"str"	)	


self	.	assertGreater	(	"str"	,	"str"	)	
self	.	assertGreater	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertGreaterEqual	(	"str"	,	"str"	)	
self	.	assertLess	(	"str"	,	"str"	)	
self	.	assertLess	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertLessEqual	(	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreater	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertGreaterEqual	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLess	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertLessEqual	,	"str"	,	"str"	)	

def	test_assert_multi_line_equal	(	self	)	:	
sample_text	=	"str"	
revised_sample_text	=	"str"	
sample_text_error	=	"str"	
types	=	(	str	,	unicode	)	if	PY_VERSION_2	else	(	str	,	)	

for	type1	in	types	:	
for	type2	in	types	:	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	sample_text_error	,	
self	.	assertMultiLineEqual	,	
type1	(	sample_text	)	,	
type2	(	revised_sample_text	)	)	

self	.	assertRaises	(	AssertionError	,	self	.	assertMultiLineEqual	,	(	1	,	2	)	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertMultiLineEqual	,	"str"	,	(	1	,	2	)	)	

def	test_assert_multi_line_equal_adds_newlines_if_needed	(	self	)	:	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	,	
self	.	assertMultiLineEqual	,	
"str"	
"str"	,	
"str"	
"str"	)	

def	test_assert_multi_line_equal_shows_missing_newlines	(	self	)	:	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	
"str"	
"str"	
"str"	
"str"	,	
self	.	assertMultiLineEqual	,	
"str"	
"str"	,	
"str"	
"str"	)	

def	test_assert_multi_line_equal_shows_extra_newlines	(	self	)	:	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	
"str"	
"str"	
"str"	
"str"	,	
self	.	assertMultiLineEqual	,	
"str"	
"str"	,	
"str"	
"str"	)	

def	test_assert_multi_line_equal_line_limit_limits	(	self	)	:	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	
"str"	
"str"	,	
self	.	assertMultiLineEqual	,	
"str"	
"str"	,	
"str"	
"str"	,	
line_limit	=	1	)	

def	test_assert_multi_line_equal_line_limit_limits_with_message	(	self	)	:	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	
"str"	
"str"	,	
self	.	assertMultiLineEqual	,	
"str"	
"str"	,	
"str"	
"str"	,	
"str"	,	
line_limit	=	1	)	

def	test_assert_is_none	(	self	)	:	
self	.	assertIsNone	(	None	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIsNone	,	False	)	
self	.	assertIsNotNone	(	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIsNotNone	,	None	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIsNone	,	(	1	,	2	)	)	

def	test_assert_is	(	self	)	:	
self	.	assertIs	(	object	,	object	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIsNot	,	object	,	object	)	
self	.	assertIsNot	(	True	,	False	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertIs	,	True	,	False	)	

def	test_assert_between	(	self	)	:	
self	.	assertBetween	(	3.14	,	3.1	,	3.141	)	
self	.	assertBetween	(	4	,	4	,	1e10000	)	
self	.	assertBetween	(	9.5	,	9.4	,	9.5	)	
self	.	assertBetween	(	-	1e10	,	-	1e10000	,	0	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertBetween	,	9.4	,	9.3	,	9.3999	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertBetween	,	-	1e10000	,	-	1e10	,	0	)	

def	test_assert_raises_with_predicate_match_no_raise	(	self	)	:	
with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
self	.	assertRaisesWithPredicateMatch	(	Exception	,	
lambda	e	:	True	,	
lambda	:	1	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
with	self	.	assertRaisesWithPredicateMatch	(	Exception	,	lambda	e	:	True	)	:	
pass	

def	test_assert_raises_with_predicate_match_raises_wrong_exception	(	self	)	:	
def	_raise_value_error	(	)	:	
raise	ValueError	

with	self	.	assertRaises	(	ValueError	)	:	
self	.	assertRaisesWithPredicateMatch	(	IOError	,	
lambda	e	:	True	,	
_raise_value_error	)	

with	self	.	assertRaises	(	ValueError	)	:	
with	self	.	assertRaisesWithPredicateMatch	(	IOError	,	lambda	e	:	True	)	:	
raise	ValueError	

def	test_assert_raises_with_predicate_match_predicate_fails	(	self	)	:	
def	_raise_value_error	(	)	:	
raise	ValueError	
with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
self	.	assertRaisesWithPredicateMatch	(	ValueError	,	
lambda	e	:	False	,	
_raise_value_error	)	

with	self	.	assertRaisesRegex	(	AssertionError	,	"str"	)	:	
with	self	.	assertRaisesWithPredicateMatch	(	ValueError	,	lambda	e	:	False	)	:	
raise	ValueError	

def	test_assert_raises_with_predicate_match_predicate_passes	(	self	)	:	
def	_raise_value_error	(	)	:	
raise	ValueError	

self	.	assertRaisesWithPredicateMatch	(	ValueError	,	
lambda	e	:	True	,	
_raise_value_error	)	

with	self	.	assertRaisesWithPredicateMatch	(	ValueError	,	lambda	e	:	True	)	:	
raise	ValueError	

def	test_assert_contains_in_order	(	self	)	:	

self	.	assertContainsInOrder	(	
[	"str"	,	"str"	]	,	"str"	)	
self	.	assertContainsInOrder	(	
[	"str"	,	"str"	,	"str"	]	,	
"str"	)	
self	.	assertContainsInOrder	(	
[	"str"	,	"str"	,	"str"	]	,	"str"	)	
self	.	assertContainsInOrder	(	
[	"str"	]	,	"str"	)	
self	.	assertContainsInOrder	(	
"str"	,	"str"	)	
self	.	assertContainsInOrder	(	
[	"str"	,	"str"	]	,	"str"	)	
self	.	assertContainsInOrder	(	
[	]	,	"str"	)	
self	.	assertContainsInOrder	(	
[	]	,	"str"	)	


msg	=	"str"	
whole_msg	=	(	"str"	
"str"	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	whole_msg	,	self	.	assertContainsInOrder	,	
[	"str"	,	"str"	]	,	"str"	,	msg	=	msg	)	
self	.	assertRaises	(	
AssertionError	,	self	.	assertContainsInOrder	,	
[	"str"	,	"str"	,	"str"	]	,	"str"	)	
self	.	assertRaises	(	
AssertionError	,	self	.	assertContainsInOrder	,	[	"str"	]	,	"str"	)	

def	test_assert_contains_subsequence_for_numbers	(	self	)	:	
self	.	assertContainsSubsequence	(	[	1	,	2	,	3	]	,	[	1	]	)	
self	.	assertContainsSubsequence	(	[	1	,	2	,	3	]	,	[	1	,	2	]	)	
self	.	assertContainsSubsequence	(	[	1	,	2	,	3	]	,	[	1	,	3	]	)	

with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsSubsequence	(	[	1	,	2	,	3	]	,	[	4	]	)	
msg	=	"str"	
whole_msg	=	(	"str"	
"str"	)	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertContainsSubsequence	,	
[	1	,	2	,	3	]	,	[	3	,	1	]	,	msg	=	msg	)	

def	test_assert_contains_subsequence_for_strings	(	self	)	:	
self	.	assertContainsSubsequence	(	[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	]	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsSubsequence	(	
[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	]	)	

def	test_assert_contains_subsequence_with_empty_subsequence	(	self	)	:	
self	.	assertContainsSubsequence	(	[	1	,	2	,	3	]	,	[	]	)	
self	.	assertContainsSubsequence	(	[	"str"	,	"str"	,	"str"	]	,	[	]	)	
self	.	assertContainsSubsequence	(	[	]	,	[	]	)	

def	test_assert_contains_subsequence_with_empty_container	(	self	)	:	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsSubsequence	(	[	]	,	[	1	]	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsSubsequence	(	[	]	,	[	"str"	]	)	

def	test_assert_contains_exact_subsequence_for_numbers	(	self	)	:	
self	.	assertContainsExactSubsequence	(	[	1	,	2	,	3	]	,	[	1	]	)	
self	.	assertContainsExactSubsequence	(	[	1	,	2	,	3	]	,	[	1	,	2	]	)	
self	.	assertContainsExactSubsequence	(	[	1	,	2	,	3	]	,	[	2	,	3	]	)	

with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsExactSubsequence	(	[	1	,	2	,	3	]	,	[	4	]	)	
msg	=	"str"	
whole_msg	=	(	"str"	
"str"	)	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertContainsExactSubsequence	,	
[	1	,	2	,	3	,	4	]	,	[	1	,	2	,	4	]	,	msg	=	msg	)	

def	test_assert_contains_exact_subsequence_for_strings	(	self	)	:	
self	.	assertContainsExactSubsequence	(	
[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	]	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsExactSubsequence	(	
[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	]	)	

def	test_assert_contains_exact_subsequence_with_empty_subsequence	(	self	)	:	
self	.	assertContainsExactSubsequence	(	[	1	,	2	,	3	]	,	[	]	)	
self	.	assertContainsExactSubsequence	(	[	"str"	,	"str"	,	"str"	]	,	[	]	)	
self	.	assertContainsExactSubsequence	(	[	]	,	[	]	)	

def	test_assert_contains_exact_subsequence_with_empty_container	(	self	)	:	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsExactSubsequence	(	[	]	,	[	3	]	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertContainsExactSubsequence	(	[	]	,	[	"str"	,	"str"	]	)	
self	.	assertContainsExactSubsequence	(	[	]	,	[	]	)	

def	test_assert_totally_ordered	(	self	)	:	

self	.	assertTotallyOrdered	(	)	
self	.	assertTotallyOrdered	(	[	1	]	)	
self	.	assertTotallyOrdered	(	[	1	]	,	[	2	]	)	
self	.	assertTotallyOrdered	(	[	1	,	1	,	1	]	)	
self	.	assertTotallyOrdered	(	[	(	1	,	1	)	]	,	[	(	1	,	2	)	]	,	[	(	2	,	1	)	]	)	
if	PY_VERSION_2	:	

self	.	assertTotallyOrdered	(	[	None	]	,	[	1	]	,	[	2	]	)	
self	.	assertTotallyOrdered	(	[	1	,	1	,	1	]	,	[	"str"	]	)	


class	A	(	object	)	:	

def	__init__	(	self	,	x	,	y	)	:	
self	.	x	=	x	
self	.	y	=	y	

def	__hash__	(	self	)	:	
return	hash	(	self	.	x	)	

def	__repr__	(	self	)	:	
return	"str"	%	(	self	.	x	,	self	.	y	)	

def	__eq__	(	self	,	other	)	:	
try	:	
return	self	.	x	==	other	.	x	
except	AttributeError	:	
return	NotImplemented	

def	__ne__	(	self	,	other	)	:	
try	:	
return	self	.	x	!=	other	.	x	
except	AttributeError	:	
return	NotImplemented	

def	__lt__	(	self	,	other	)	:	
try	:	
return	self	.	x	<	other	.	x	
except	AttributeError	:	
return	NotImplemented	

def	__le__	(	self	,	other	)	:	
try	:	
return	self	.	x	<	=	other	.	x	
except	AttributeError	:	
return	NotImplemented	

def	__gt__	(	self	,	other	)	:	
try	:	
return	self	.	x	>	other	.	x	
except	AttributeError	:	
return	NotImplemented	

def	__ge__	(	self	,	other	)	:	
try	:	
return	self	.	x	>	=	other	.	x	
except	AttributeError	:	
return	NotImplemented	

class	B	(	A	)	:	

__hash__	=	None	

if	PY_VERSION_2	:	
self	.	assertTotallyOrdered	(	
[	None	]	,	
[	1	]	,	
[	A	(	1	,	"str"	)	]	,	
[	A	(	2	,	"str"	)	]	,	
[	
A	(	3	,	"str"	)	,	
B	(	3	,	"str"	)	,	
B	(	3	,	"str"	)	
]	,	
[	A	(	4	,	"str"	)	]	,	
[	"str"	]	)	
else	:	

self	.	assertTotallyOrdered	(	
[	A	(	1	,	"str"	)	]	,	
[	A	(	2	,	"str"	)	]	,	
[	
A	(	3	,	"str"	)	,	
B	(	3	,	"str"	)	,	
B	(	3	,	"str"	)	
]	,	
[	A	(	4	,	"str"	)	]	)	


msg	=	"str"	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertTotallyOrdered	,	[	2	]	,	[	1	]	,	
msg	=	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTotallyOrdered	,	[	2	]	,	[	1	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTotallyOrdered	,	[	2	]	,	[	1	]	,	[	3	]	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertTotallyOrdered	,	[	1	,	2	]	)	

def	test_short_description_without_docstring	(	self	)	:	
self	.	assertEquals	(	
self	.	shortDescription	(	)	,	
(	"str"	
"str"	%	__name__	)	)	

def	test_short_description_with_one_line_docstring	(	self	)	:	

self	.	assertEquals	(	
self	.	shortDescription	(	)	,	
(	"str"	
"str"	
"str"	%	__name__	)	)	

def	test_short_description_with_multi_line_docstring	(	self	)	:	

self	.	assertEquals	(	
self	.	shortDescription	(	)	,	
(	"str"	
"str"	
"str"	
%	__name__	)	)	

def	test_assert_url_equal_same	(	self	)	:	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	
"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	
self	.	assertUrlEqual	(	"str"	,	
"str"	)	
self	.	assertUrlEqual	(	"str"	,	"str"	)	

def	test_assert_url_equal_different	(	self	)	:	
msg	=	"str"	
if	PY_VERSION_2	:	
whole_msg	=	"str"	
else	:	
whole_msg	=	"str"	
self	.	assertRaisesWithLiteralMatch	(	AssertionError	,	whole_msg	,	
self	.	assertUrlEqual	,	
"str"	,	"str"	,	msg	=	msg	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertUrlEqual	,	
"str"	,	"str"	)	

def	test_same_structure_same	(	self	)	:	
self	.	assertSameStructure	(	0	,	0	)	
self	.	assertSameStructure	(	1	,	1	)	
self	.	assertSameStructure	(	"str"	,	"str"	)	
self	.	assertSameStructure	(	"str"	,	"str"	,	msg	=	"str"	)	
self	.	assertSameStructure	(	set	(	)	,	set	(	)	)	
self	.	assertSameStructure	(	set	(	[	1	,	2	]	)	,	set	(	[	1	,	2	]	)	)	
self	.	assertSameStructure	(	set	(	)	,	frozenset	(	)	)	
self	.	assertSameStructure	(	set	(	[	1	,	2	]	)	,	frozenset	(	[	1	,	2	]	)	)	
self	.	assertSameStructure	(	[	]	,	[	]	)	
self	.	assertSameStructure	(	[	"str"	]	,	[	"str"	]	)	
self	.	assertSameStructure	(	[	]	,	(	)	)	
self	.	assertSameStructure	(	[	"str"	]	,	(	"str"	,	)	)	
self	.	assertSameStructure	(	{	}	,	{	}	)	
self	.	assertSameStructure	(	{	"str"	:	1	}	,	{	"str"	:	1	}	)	
self	.	assertSameStructure	(	collections	.	defaultdict	(	None	,	{	"str"	:	1	}	)	,	
{	"str"	:	1	}	)	
self	.	assertSameStructure	(	collections	.	OrderedDict	(	{	"str"	:	1	}	)	,	
collections	.	defaultdict	(	None	,	{	"str"	:	1	}	)	)	

if	PY_VERSION_2	:	
self	.	assertSameStructure	(	{	long	(	3	)	:	3	}	,	{	3	:	long	(	3	)	}	)	

def	test_same_structure_different	(	self	)	:	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	0	,	"str"	)	
with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	0	,	[	]	)	
with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	2	,	2.0	)	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	[	]	,	{	}	)	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	[	]	,	set	(	)	)	

with	self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	)	:	
self	.	assertSameStructure	(	{	}	,	set	(	)	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	0	,	1	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	"str"	,	"str"	,	msg	=	"str"	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	
set	(	[	1	,	2	]	)	,	
set	(	[	1	]	)	,	
aname	=	"str"	,	
bname	=	"str"	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	
set	(	[	1	]	)	,	
set	(	[	1	,	2	]	)	,	
aname	=	"str"	,	
bname	=	"str"	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	]	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	[	"str"	,	"str"	]	,	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	[	"str"	,	"str"	,	"str"	]	,	[	"str"	,	"str"	,	"str"	]	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	}	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	{	"str"	:	1	}	,	{	"str"	:	1	,	"str"	:	2	}	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	"str"	,	
self	.	assertSameStructure	,	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	3	}	)	



self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	[	]	,	"str"	)	
self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	"str"	,	(	)	)	
self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	[	"str"	,	"str"	,	"str"	]	,	"str"	)	
self	.	assertRaisesRegex	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	"str"	,	(	"str"	,	"str"	,	"str"	)	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	
[	[	{	"str"	:	{	"str"	:	{	"str"	:	[	1	]	}	}	}	]	]	,	[	[	{	"str"	:	{	"str"	:	{	"str"	:	[	2	]	}	}	}	]	]	)	


self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	[	1	,	2	]	,	[	3	,	4	]	)	
with	self	.	assertRaisesRegex	(	
AssertionError	,	
re	.	compile	(	"str"	
"str"	)	)	:	
self	.	assertSameStructure	(	
list	(	string	.	ascii_lowercase	)	,	list	(	string	.	ascii_uppercase	)	)	


self	.	maxDiff	=	None	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	[	1	,	2	]	,	[	3	,	4	]	)	

def	test_same_structure_mapping_unchanged	(	self	)	:	
default_a	=	collections	.	defaultdict	(	lambda	:	"str"	,	{	}	)	
dict_b	=	{	"str"	:	"str"	}	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	default_a	,	dict_b	)	
self	.	assertEmpty	(	default_a	)	

dict_a	=	{	"str"	:	"str"	}	
default_b	=	collections	.	defaultdict	(	lambda	:	"str"	,	{	}	)	
self	.	assertRaisesWithLiteralMatch	(	
AssertionError	,	
"str"	,	
self	.	assertSameStructure	,	dict_a	,	default_b	)	
self	.	assertEmpty	(	default_b	)	

def	test_assert_json_equal_same	(	self	)	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertJsonEqual	(	"str"	,	"str"	,	msg	=	"str"	)	
self	.	assertJsonEqual	(	"str"	,	
"str"	)	
self	.	assertJsonEqual	(	"str"	,	
"str"	)	

def	test_assert_json_equal_different	(	self	)	:	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
with	self	.	assertRaises	(	AssertionError	)	as	error_context	:	
self	.	assertJsonEqual	(	"str"	,	"str"	,	msg	=	"str"	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	
"str"	)	
with	self	.	assertRaises	(	AssertionError	)	:	
self	.	assertJsonEqual	(	"str"	,	
"str"	)	

def	test_assert_json_equal_bad_json	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	as	error_context	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	

with	self	.	assertRaises	(	ValueError	)	as	error_context	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	
self	.	assertIn	(	"str"	,	error_context	.	exception	.	args	[	0	]	)	

with	self	.	assertRaises	(	ValueError	)	as	error_context	:	
self	.	assertJsonEqual	(	"str"	,	"str"	)	


class	GetCommandStderrTestCase	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	original_environ	=	os	.	environ	.	copy	(	)	

def	tearDown	(	self	)	:	
os	.	environ	=	self	.	original_environ	

def	test_return_status	(	self	)	:	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
returncode	=	(	
absltest	.	get_command_stderr	(	
[	"str"	,	os	.	path	.	join	(	tmpdir	,	"str"	)	]	)	[	0	]	)	
self	.	assertEqual	(	1	,	returncode	)	

def	test_stderr	(	self	)	:	
tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
stderr	=	(	
absltest	.	get_command_stderr	(	
[	"str"	,	os	.	path	.	join	(	tmpdir	,	"str"	)	]	)	[	1	]	)	
if	not	PY_VERSION_2	:	
stderr	=	stderr	.	decode	(	"str"	)	
self	.	assertRegex	(	stderr	,	"str"	)	


class	EqualityAssertionTest	(	absltest	.	TestCase	)	:	


class	NeverEqual	(	object	)	:	


def	__eq__	(	self	,	unused_other	)	:	
return	False	

def	__ne__	(	self	,	unused_other	)	:	
return	False	

class	AllSame	(	object	)	:	


def	__eq__	(	self	,	unused_other	)	:	
return	True	

def	__ne__	(	self	,	unused_other	)	:	
return	False	

class	EqualityTestsWithEq	(	object	)	:	


def	__init__	(	self	,	value	)	:	
self	.	_value	=	value	

def	__eq__	(	self	,	other	)	:	
return	self	.	_value	==	other	.	_value	

def	__ne__	(	self	,	other	)	:	
return	not	self	.	__eq__	(	other	)	

class	EqualityTestsWithNe	(	object	)	:	


def	__init__	(	self	,	value	)	:	
self	.	_value	=	value	

def	__eq__	(	self	,	other	)	:	
return	not	self	.	__ne__	(	other	)	

def	__ne__	(	self	,	other	)	:	
return	self	.	_value	!=	other	.	_value	

class	EqualityTestsWithCmp	(	object	)	:	

def	__init__	(	self	,	value	)	:	
self	.	_value	=	value	

def	__cmp__	(	self	,	other	)	:	
return	cmp	(	self	.	_value	,	other	.	_value	)	

class	EqualityTestsWithLtEq	(	object	)	:	

def	__init__	(	self	,	value	)	:	
self	.	_value	=	value	

def	__eq__	(	self	,	other	)	:	
return	self	.	_value	==	other	.	_value	

def	__lt__	(	self	,	other	)	:	
return	self	.	_value	<	other	.	_value	

def	test_all_comparisons_fail	(	self	)	:	
i1	=	self	.	NeverEqual	(	)	
i2	=	self	.	NeverEqual	(	)	
self	.	assertFalse	(	i1	==	i2	)	
self	.	assertFalse	(	i1	!=	i2	)	


self	.	assertFalse	(	i1	is	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertEquals	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	failUnlessEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEquals	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	failIfEqual	,	i1	,	i2	)	

i2	=	i1	
self	.	assertTrue	(	i1	is	i2	)	
self	.	assertFalse	(	i1	==	i2	)	
self	.	assertFalse	(	i1	!=	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertEquals	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	failUnlessEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEqual	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEquals	,	i1	,	i2	)	
self	.	assertRaises	(	AssertionError	,	self	.	failIfEqual	,	i1	,	i2	)	

def	test_all_comparisons_succeed	(	self	)	:	
a	=	self	.	AllSame	(	)	
b	=	self	.	AllSame	(	)	
self	.	assertFalse	(	a	is	b	)	
self	.	assertTrue	(	a	==	b	)	
self	.	assertFalse	(	a	!=	b	)	
self	.	assertEqual	(	a	,	b	)	
self	.	assertEquals	(	a	,	b	)	
self	.	failUnlessEqual	(	a	,	b	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEqual	,	a	,	b	)	
self	.	assertRaises	(	AssertionError	,	self	.	assertNotEquals	,	a	,	b	)	
self	.	assertRaises	(	AssertionError	,	self	.	failIfEqual	,	a	,	b	)	

def	_perform_apple_apple_orange_checks	(	self	,	same_a	,	same_b	,	different	)	:	

self	.	assertTrue	(	same_a	==	same_b	)	
self	.	assertFalse	(	same_a	!=	same_b	)	
self	.	assertEqual	(	same_a	,	same_b	)	
self	.	assertEquals	(	same_a	,	same_b	)	
self	.	failUnlessEqual	(	same_a	,	same_b	)	
if	PY_VERSION_2	:	

self	.	assertEqual	(	0	,	cmp	(	same_a	,	same_b	)	)	

self	.	assertFalse	(	same_a	==	different	)	
self	.	assertTrue	(	same_a	!=	different	)	
self	.	assertNotEqual	(	same_a	,	different	)	
self	.	assertNotEquals	(	same_a	,	different	)	
self	.	failIfEqual	(	same_a	,	different	)	
if	PY_VERSION_2	:	
self	.	assertNotEqual	(	0	,	cmp	(	same_a	,	different	)	)	

self	.	assertFalse	(	same_b	==	different	)	
self	.	assertTrue	(	same_b	!=	different	)	
self	.	assertNotEqual	(	same_b	,	different	)	
self	.	assertNotEquals	(	same_b	,	different	)	
self	.	failIfEqual	(	same_b	,	different	)	
if	PY_VERSION_2	:	
self	.	assertNotEqual	(	0	,	cmp	(	same_b	,	different	)	)	

def	test_comparison_with_eq	(	self	)	:	
same_a	=	self	.	EqualityTestsWithEq	(	42	)	
same_b	=	self	.	EqualityTestsWithEq	(	42	)	
different	=	self	.	EqualityTestsWithEq	(	1769	)	
self	.	_perform_apple_apple_orange_checks	(	same_a	,	same_b	,	different	)	

def	test_comparison_with_ne	(	self	)	:	
same_a	=	self	.	EqualityTestsWithNe	(	42	)	
same_b	=	self	.	EqualityTestsWithNe	(	42	)	
different	=	self	.	EqualityTestsWithNe	(	1769	)	
self	.	_perform_apple_apple_orange_checks	(	same_a	,	same_b	,	different	)	

def	test_comparison_with_cmp_or_lt_eq	(	self	)	:	
if	PY_VERSION_2	:	

cmp_or_lteq_class	=	self	.	EqualityTestsWithCmp	
else	:	
cmp_or_lteq_class	=	self	.	EqualityTestsWithLtEq	

same_a	=	cmp_or_lteq_class	(	42	)	
same_b	=	cmp_or_lteq_class	(	42	)	
different	=	cmp_or_lteq_class	(	1769	)	
self	.	_perform_apple_apple_orange_checks	(	same_a	,	same_b	,	different	)	


class	AssertSequenceStartsWithTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	a	=	[	5	,	"str"	,	{	"str"	:	"str"	}	,	None	]	

def	test_empty_sequence_starts_with_empty_prefix	(	self	)	:	
self	.	assertSequenceStartsWith	(	[	]	,	(	)	)	

def	test_sequence_prefix_is_an_empty_list	(	self	)	:	
self	.	assertSequenceStartsWith	(	[	[	]	]	,	(	[	]	,	"str"	)	)	

def	test_raise_if_empty_prefix_with_non_empty_whole	(	self	)	:	
with	self	.	assertRaisesRegex	(	
AssertionError	,	"str"	%	(	len	(	
self	.	a	)	,	"str"	)	)	:	
self	.	assertSequenceStartsWith	(	[	]	,	self	.	a	)	

def	test_single_element_prefix	(	self	)	:	
self	.	assertSequenceStartsWith	(	[	5	]	,	self	.	a	)	

def	test_two_element_prefix	(	self	)	:	
self	.	assertSequenceStartsWith	(	(	5	,	"str"	)	,	self	.	a	)	

def	test_prefix_is_full_sequence	(	self	)	:	
self	.	assertSequenceStartsWith	(	[	5	,	"str"	,	{	"str"	:	"str"	}	,	None	]	,	self	.	a	)	

def	test_string_prefix	(	self	)	:	
self	.	assertSequenceStartsWith	(	"str"	,	"str"	)	

def	test_convert_non_sequence_prefix_to_sequence_and_try_again	(	self	)	:	
self	.	assertSequenceStartsWith	(	5	,	self	.	a	)	

def	test_whole_not_asequence	(	self	)	:	
msg	=	(	"str"	
"str"	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	msg	)	:	
self	.	assertSequenceStartsWith	(	self	.	a	,	5	)	

def	test_raise_if_sequence_does_not_start_with_prefix	(	self	)	:	
msg	=	(	"str"	
"str"	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	msg	)	:	
self	.	assertSequenceStartsWith	(	[	"str"	,	{	"str"	:	"str"	}	]	,	self	.	a	)	

def	test_raise_if_types_ar_not_supported	(	self	)	:	
with	self	.	assertRaisesRegex	(	TypeError	,	"str"	)	:	
self	.	assertSequenceStartsWith	(	{	"str"	:	1	,	2	:	"str"	}	,	
{	"str"	:	1	,	2	:	"str"	,	"str"	:	"str"	}	)	


class	TestAssertEmpty	(	absltest	.	TestCase	)	:	
longMessage	=	True	

def	test_raises_if_not_asized_object	(	self	)	:	
msg	=	"str"	
with	self	.	assertRaisesRegex	(	AssertionError	,	msg	)	:	
self	.	assertEmpty	(	1	)	

def	test_calls_len_not_bool	(	self	)	:	

class	BadList	(	list	)	:	

def	__bool__	(	self	)	:	
return	False	

__nonzero__	=	__bool__	

bad_list	=	BadList	(	)	
self	.	assertEmpty	(	bad_list	)	
self	.	assertFalse	(	bad_list	)	

def	test_passes_when_empty	(	self	)	:	
empty_containers	=	[	
list	(	)	,	
tuple	(	)	,	
dict	(	)	,	
set	(	)	,	
frozenset	(	)	,	
b	"str"	,	
"str"	,	
bytearray	(	)	,	
]	
for	container	in	empty_containers	:	
self	.	assertEmpty	(	container	)	

def	test_raises_with_not_empty_containers	(	self	)	:	
not_empty_containers	=	[	
[	1	]	,	
(	1	,	)	,	
{	"str"	:	"str"	}	,	
{	1	}	,	
frozenset	(	[	1	]	)	,	
b	"str"	,	
"str"	,	
bytearray	(	b	"str"	)	,	
]	
regexp	=	"str"	
for	container	in	not_empty_containers	:	
with	self	.	assertRaisesRegex	(	AssertionError	,	regexp	)	:	
self	.	assertEmpty	(	container	)	

def	test_user_message_added_to_default	(	self	)	:	
msg	=	"str"	
whole_msg	=	re	.	escape	(	"str"	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	whole_msg	)	:	
self	.	assertEmpty	(	[	1	]	,	msg	=	msg	)	


class	TestAssertNotEmpty	(	absltest	.	TestCase	)	:	
longMessage	=	True	

def	test_raises_if_not_asized_object	(	self	)	:	
msg	=	"str"	
with	self	.	assertRaisesRegex	(	AssertionError	,	msg	)	:	
self	.	assertNotEmpty	(	1	)	

def	test_calls_len_not_bool	(	self	)	:	

class	BadList	(	list	)	:	

def	__bool__	(	self	)	:	
return	False	

__nonzero__	=	__bool__	

bad_list	=	BadList	(	[	1	]	)	
self	.	assertNotEmpty	(	bad_list	)	
self	.	assertFalse	(	bad_list	)	

def	test_passes_when_not_empty	(	self	)	:	
not_empty_containers	=	[	
[	1	]	,	
(	1	,	)	,	
{	"str"	:	"str"	}	,	
{	1	}	,	
frozenset	(	[	1	]	)	,	
b	"str"	,	
"str"	,	
bytearray	(	b	"str"	)	,	
]	
for	container	in	not_empty_containers	:	
self	.	assertNotEmpty	(	container	)	

def	test_raises_with_empty_containers	(	self	)	:	
empty_containers	=	[	
list	(	)	,	
tuple	(	)	,	
dict	(	)	,	
set	(	)	,	
frozenset	(	)	,	
b	"str"	,	
"str"	,	
bytearray	(	)	,	
]	
regexp	=	"str"	
for	container	in	empty_containers	:	
with	self	.	assertRaisesRegex	(	AssertionError	,	regexp	)	:	
self	.	assertNotEmpty	(	container	)	

def	test_user_message_added_to_default	(	self	)	:	
msg	=	"str"	
whole_msg	=	re	.	escape	(	"str"	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	whole_msg	)	:	
self	.	assertNotEmpty	(	[	]	,	msg	=	msg	)	


class	TestAssertLen	(	absltest	.	TestCase	)	:	
longMessage	=	True	

def	test_raises_if_not_asized_object	(	self	)	:	
msg	=	"str"	
with	self	.	assertRaisesRegex	(	AssertionError	,	msg	)	:	
self	.	assertLen	(	1	,	1	)	

def	test_passes_when_expected_len	(	self	)	:	
containers	=	[	
[	[	1	]	,	1	]	,	
[	(	1	,	2	)	,	2	]	,	
[	{	"str"	:	1	,	"str"	:	2	,	"str"	:	3	}	,	3	]	,	
[	{	1	,	2	,	3	,	4	}	,	4	]	,	
[	frozenset	(	[	1	]	)	,	1	]	,	
[	b	"str"	,	3	]	,	
[	"str"	,	3	]	,	
[	bytearray	(	b	"str"	)	,	4	]	,	
]	
for	container	,	expected_len	in	containers	:	
self	.	assertLen	(	container	,	expected_len	)	

def	test_raises_when_unexpected_len	(	self	)	:	
containers	=	[	
[	1	]	,	
(	1	,	2	)	,	
{	"str"	:	1	,	"str"	:	2	,	"str"	:	3	}	,	
{	1	,	2	,	3	,	4	}	,	
frozenset	(	[	1	]	)	,	
b	"str"	,	
"str"	,	
bytearray	(	b	"str"	)	,	
]	
for	container	in	containers	:	
regexp	=	"str"	%	len	(	container	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	regexp	)	:	
self	.	assertLen	(	container	,	100	)	

def	test_user_message_added_to_default	(	self	)	:	
msg	=	"str"	
whole_msg	=	(	
"str"	)	
with	self	.	assertRaisesRegex	(	AssertionError	,	whole_msg	)	:	
self	.	assertLen	(	[	1	]	,	100	,	msg	)	


class	TestLoaderTest	(	absltest	.	TestCase	)	:	



class	Valid	(	absltest	.	TestCase	)	:	


test_property	=	1	
TestProperty	=	2	

@staticmethod	
def	TestStaticMethod	(	)	:	
pass	

@staticmethod	
def	TestStaticMethodWithArg	(	foo	)	:	
pass	

@classmethod	
def	TestClassMethod	(	cls	)	:	
pass	

def	Test	(	self	)	:	
pass	

def	TestingHelper	(	self	)	:	
pass	

def	testMethod	(	self	)	:	
pass	

def	TestHelperWithParams	(	self	,	a	,	b	)	:	
pass	

def	TestHelperWithVarargs	(	self	,	*	args	,	*	*	kwargs	)	:	
pass	

def	TestHelperWithDefaults	(	self	,	a	=	5	)	:	
pass	

class	Invalid	(	absltest	.	TestCase	)	:	


def	testMethod	(	self	)	:	
pass	

def	TestSuspiciousMethod	(	self	)	:	
pass	


def	setUp	(	self	)	:	
self	.	loader	=	absltest	.	TestLoader	(	)	

def	test_valid	(	self	)	:	
suite	=	self	.	loader	.	loadTestsFromTestCase	(	TestLoaderTest	.	Valid	)	
self	.	assertEquals	(	1	,	suite	.	countTestCases	(	)	)	

def	testInvalid	(	self	)	:	
with	self	.	assertRaisesRegex	(	TypeError	,	"str"	)	:	
self	.	loader	.	loadTestsFromTestCase	(	TestLoaderTest	.	Invalid	)	


class	InitNotNecessaryForAssertsTest	(	absltest	.	TestCase	)	:	


def	test_subclass	(	self	)	:	

class	Subclass	(	absltest	.	TestCase	)	:	

def	__init__	(	self	)	:	
pass	

Subclass	(	)	.	assertEquals	(	{	}	,	{	}	)	

def	test_multiple_inheritance	(	self	)	:	

class	Foo	(	object	)	:	

def	__init__	(	self	,	*	args	,	*	*	kwargs	)	:	
pass	

class	Subclass	(	Foo	,	absltest	.	TestCase	)	:	
pass	

Subclass	(	)	.	assertEquals	(	{	}	,	{	}	)	


class	GetCommandStringTest	(	parameterized	.	TestCase	)	:	

@parameterized.parameters	(	
(	[	]	,	"str"	,	"str"	)	,	
(	[	"str"	]	,	"str"	,	"str"	)	,	
(	[	"str"	,	"str"	]	,	"str"	,	"str"	)	,	
(	[	"str"	,	"str"	]	,	"str"	,	"str"	)	,	
(	[	"str"	]	,	"str"	,	"str"	)	,	
(	[	"str"	]	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	)	
def	test_get_command_string	(	
self	,	command	,	expected_non_windows	,	expected_windows	)	:	
expected	=	expected_windows	if	os	.	name	==	"str"	else	expected_non_windows	
self	.	assertEqual	(	expected	,	absltest	.	get_command_string	(	command	)	)	


class	TempFileTest	(	absltest	.	TestCase	,	HelperMixin	)	:	

def	assert_dir_exists	(	self	,	temp_dir	)	:	
path	=	temp_dir	.	full_path	
self	.	assertTrue	(	os	.	path	.	exists	(	path	)	,	"str"	.	format	(	path	)	)	
self	.	assertTrue	(	os	.	path	.	isdir	(	path	)	,	
"str"	.	format	(	path	)	)	

def	assert_file_exists	(	self	,	temp_file	,	expected_content	=	b	"str"	)	:	
path	=	temp_file	.	full_path	
self	.	assertTrue	(	os	.	path	.	exists	(	path	)	,	"str"	.	format	(	path	)	)	
self	.	assertTrue	(	os	.	path	.	isfile	(	path	)	,	
"str"	.	format	(	path	)	)	

mode	=	"str"	if	isinstance	(	expected_content	,	bytes	)	else	"str"	
with	io	.	open	(	path	,	mode	)	as	fp	:	
actual	=	fp	.	read	(	)	
self	.	assertEqual	(	expected_content	,	actual	)	

def	run_tempfile_helper	(	self	,	cleanup	,	expected_paths	)	:	
tmpdir	=	self	.	create_tempdir	(	"str"	)	
env	=	{	
"str"	:	cleanup	,	
"str"	:	tmpdir	.	full_path	,	
}	
stdout	,	stderr	=	self	.	run_helper	(	0	,	[	"str"	]	,	env	,	
expect_success	=	False	)	
output	=	(	"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	.	format	(	stdout	,	stderr	)	
self	.	assertIn	(	"str"	,	stderr	,	output	)	


expected_paths	=	{	path	.	replace	(	"str"	,	os	.	sep	)	for	path	in	expected_paths	}	

actual	=	{	
os	.	path	.	relpath	(	f	,	tmpdir	.	full_path	)	
for	f	in	_listdir_recursive	(	tmpdir	.	full_path	)	
if	f	!=	tmpdir	.	full_path	
}	
self	.	assertEqual	(	expected_paths	,	actual	,	output	)	

def	test_create_file_pre_existing_readonly	(	self	)	:	
first	=	self	.	create_tempfile	(	"str"	,	content	=	"str"	)	
os	.	chmod	(	first	.	full_path	,	0	o444	)	
second	=	self	.	create_tempfile	(	"str"	,	content	=	"str"	)	
self	.	assertEqual	(	"str"	,	first	.	read_text	(	)	)	
self	.	assertEqual	(	"str"	,	second	.	read_text	(	)	)	

def	test_unnamed	(	self	)	:	
td	=	self	.	create_tempdir	(	)	
self	.	assert_dir_exists	(	td	)	

tdf	=	td	.	create_file	(	)	
self	.	assert_file_exists	(	tdf	)	

tdd	=	td	.	mkdir	(	)	
self	.	assert_dir_exists	(	tdd	)	

tf	=	self	.	create_tempfile	(	)	
self	.	assert_file_exists	(	tf	)	

def	test_named	(	self	)	:	
td	=	self	.	create_tempdir	(	"str"	)	
self	.	assert_dir_exists	(	td	)	

tdf	=	td	.	create_file	(	"str"	)	
self	.	assert_file_exists	(	tdf	)	

tdd	=	td	.	mkdir	(	"str"	)	
self	.	assert_dir_exists	(	tdd	)	

tf	=	self	.	create_tempfile	(	"str"	)	
self	.	assert_file_exists	(	tf	)	

def	test_nested_paths	(	self	)	:	
td	=	self	.	create_tempdir	(	"str"	)	
self	.	assert_dir_exists	(	td	)	

tdf	=	td	.	create_file	(	"str"	)	
self	.	assert_file_exists	(	tdf	)	

tdd	=	td	.	mkdir	(	"str"	)	
self	.	assert_dir_exists	(	tdd	)	

tf	=	self	.	create_tempfile	(	"str"	)	
self	.	assert_file_exists	(	tf	)	

def	test_tempdir_create_file	(	self	)	:	
td	=	self	.	create_tempdir	(	)	
td	.	create_file	(	content	=	"str"	)	

def	test_tempfile_text	(	self	)	:	
tf	=	self	.	create_tempfile	(	content	=	"str"	)	
self	.	assert_file_exists	(	tf	,	"str"	)	
self	.	assertEqual	(	"str"	,	tf	.	read_text	(	)	)	

with	tf	.	open_text	(	)	as	fp	:	
self	.	assertEqual	(	"str"	,	fp	.	read	(	)	)	

with	tf	.	open_text	(	"str"	)	as	fp	:	
fp	.	write	(	"str"	)	
self	.	assertEqual	(	"str"	,	tf	.	read_text	(	)	)	

tf	.	write_text	(	"str"	)	
self	.	assertEqual	(	"str"	,	tf	.	read_text	(	)	)	

def	test_tempfile_bytes	(	self	)	:	
tf	=	self	.	create_tempfile	(	content	=	b	"str"	)	
self	.	assert_file_exists	(	tf	,	b	"str"	)	
self	.	assertEqual	(	b	"str"	,	tf	.	read_bytes	(	)	)	

with	tf	.	open_bytes	(	)	as	fp	:	
self	.	assertEqual	(	b	"str"	,	fp	.	read	(	)	)	

with	tf	.	open_bytes	(	"str"	)	as	fp	:	
fp	.	write	(	b	"str"	)	
self	.	assertEqual	(	b	"str"	,	tf	.	read_bytes	(	)	)	

tf	.	write_bytes	(	b	"str"	)	
self	.	assertEqual	(	b	"str"	,	tf	.	read_bytes	(	)	)	

def	test_tempdir_same_name	(	self	)	:	

td1	=	self	.	create_tempdir	(	"str"	)	
td2	=	self	.	create_tempdir	(	"str"	)	
self	.	assert_dir_exists	(	td1	)	
self	.	assert_dir_exists	(	td2	)	

def	test_tempfile_cleanup_success	(	self	)	:	
expected	=	{	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
}	
self	.	run_tempfile_helper	(	"str"	,	expected	)	

def	test_tempfile_cleanup_always	(	self	)	:	
expected	=	{	
"str"	,	
"str"	,	
"str"	,	
}	
self	.	run_tempfile_helper	(	"str"	,	expected	)	

def	test_tempfile_cleanup_off	(	self	)	:	
expected	=	{	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
}	
self	.	run_tempfile_helper	(	"str"	,	expected	)	


def	_listdir_recursive	(	path	)	:	
for	dirname	,	_	,	filenames	in	os	.	walk	(	path	)	:	
yield	dirname	
for	filename	in	filenames	:	
yield	os	.	path	.	join	(	dirname	,	filename	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	