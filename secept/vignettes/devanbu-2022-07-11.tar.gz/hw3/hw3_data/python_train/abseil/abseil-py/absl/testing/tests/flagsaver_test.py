















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	import	flags	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	flagsaver	

flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_string	(	"str"	,	None	,	"str"	)	
flags	.	register_validator	(	"str"	,	lambda	x	:	not	x	)	

FLAGS	=	flags	.	FLAGS	


@flags.validator	(	"str"	)	
def	check_no_upper_case	(	value	)	:	
return	value	==	value	.	lower	(	)	


class	_TestError	(	Exception	)	:	



class	FlagSaverTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	

global	FLAGS	
self	.	flags	=	FLAGS	

FLAGS	=	flags	.	FlagValues	(	)	
FLAGS	.	append_flag_values	(	self	.	flags	)	
FLAGS	.	mark_as_parsed	(	)	

def	tearDown	(	self	)	:	
global	FLAGS	
FLAGS	=	self	.	flags	

def	test_context_manager_without_parameters	(	self	)	:	
with	flagsaver	.	flagsaver	(	)	:	
FLAGS	.	flagsaver_test_flag0	=	"str"	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_context_manager_with_overrides	(	self	)	:	
with	flagsaver	.	flagsaver	(	flagsaver_test_flag0	=	"str"	)	:	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag1	=	"str"	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag1	)	

def	test_context_manager_with_exception	(	self	)	:	
with	self	.	assertRaises	(	_TestError	)	:	
with	flagsaver	.	flagsaver	(	flagsaver_test_flag0	=	"str"	)	:	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag1	=	"str"	
raise	_TestError	(	"str"	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag1	)	

def	test_context_manager_with_validation_exception	(	self	)	:	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
with	flagsaver	.	flagsaver	(	
flagsaver_test_flag0	=	"str"	,	
flagsaver_test_validated_flag	=	"str"	)	:	
pass	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag1	)	
self	.	assertEqual	(	None	,	FLAGS	.	flagsaver_test_validated_flag	)	

def	test_decorator_without_call	(	self	)	:	

@flagsaver.flagsaver	
def	mutate_flags	(	value	)	:	





FLAGS	.	flagsaver_test_flag0	=	value	
return	FLAGS	.	flagsaver_test_flag0	




self	.	assertEqual	(	"str"	,	
mutate_flags	(	"str"	)	)	

self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_decorator_without_parameters	(	self	)	:	

@flagsaver.flagsaver	(	)	
def	mutate_flags	(	value	)	:	
FLAGS	.	flagsaver_test_flag0	=	value	
return	FLAGS	.	flagsaver_test_flag0	

self	.	assertEqual	(	"str"	,	mutate_flags	(	"str"	)	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_decorator_with_overrides	(	self	)	:	

@flagsaver.flagsaver	(	flagsaver_test_flag0	=	"str"	)	
def	mutate_flags	(	)	:	





return	FLAGS	.	flagsaver_test_flag0	




self	.	assertEqual	(	"str"	,	mutate_flags	(	)	)	

self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_save_flag_value	(	self	)	:	

saved_flag_values	=	flagsaver	.	save_flag_values	(	)	


FLAGS	.	flagsaver_test_flag0	=	"str"	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	


flagsaver	.	restore_flag_values	(	saved_flag_values	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_save_flag_default	(	self	)	:	

saved_flag_values	=	flagsaver	.	save_flag_values	(	)	


FLAGS	.	set_default	(	"str"	,	"str"	)	
self	.	assertEqual	(	"str"	,	FLAGS	[	"str"	]	.	default	)	


flagsaver	.	restore_flag_values	(	saved_flag_values	)	
self	.	assertEqual	(	"str"	,	FLAGS	[	"str"	]	.	default	)	

def	test_restore_after_parse	(	self	)	:	

saved_flag_values	=	flagsaver	.	save_flag_values	(	)	


self	.	assertEqual	(	0	,	FLAGS	[	"str"	]	.	present	)	

FLAGS	[	"str"	]	.	parse	(	"str"	)	
self	.	assertEqual	(	"str"	,	FLAGS	[	"str"	]	.	value	)	
self	.	assertEqual	(	1	,	FLAGS	[	"str"	]	.	present	)	


flagsaver	.	restore_flag_values	(	saved_flag_values	)	
self	.	assertEqual	(	"str"	,	FLAGS	[	"str"	]	.	value	)	
self	.	assertEqual	(	0	,	FLAGS	[	"str"	]	.	present	)	

def	test_decorator_with_exception	(	self	)	:	

@flagsaver.flagsaver	
def	raise_exception	(	)	:	
FLAGS	.	flagsaver_test_flag0	=	"str"	

raise	_TestError	(	"str"	)	

self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
self	.	assertRaises	(	_TestError	,	raise_exception	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	

def	test_validator_list_is_restored	(	self	)	:	

self	.	assertLen	(	FLAGS	[	"str"	]	.	validators	,	1	)	
original_validators	=	list	(	FLAGS	[	"str"	]	.	validators	)	

@flagsaver.flagsaver	
def	modify_validators	(	)	:	

def	no_space	(	value	)	:	
return	"str"	not	in	value	

flags	.	register_validator	(	"str"	,	no_space	)	
self	.	assertLen	(	FLAGS	[	"str"	]	.	validators	,	2	)	

modify_validators	(	)	
self	.	assertEqual	(	
original_validators	,	FLAGS	[	"str"	]	.	validators	)	


class	FlagSaverDecoratorUsageTest	(	absltest	.	TestCase	)	:	

@flagsaver.flagsaver	
def	test_mutate1	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

@flagsaver.flagsaver	
def	test_mutate2	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

@flagsaver.flagsaver	
def	test_mutate3	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

@flagsaver.flagsaver	
def	test_mutate4	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	


class	FlagSaverSetUpTearDownUsageTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	saved_flag_values	=	flagsaver	.	save_flag_values	(	)	

def	tearDown	(	self	)	:	
flagsaver	.	restore_flag_values	(	self	.	saved_flag_values	)	

def	test_mutate1	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

def	test_mutate2	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

def	test_mutate3	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	

def	test_mutate4	(	self	)	:	


self	.	assertEqual	(	"str"	,	FLAGS	.	flagsaver_test_flag0	)	
FLAGS	.	flagsaver_test_flag0	=	"str"	


class	FlagSaverBadUsageTest	(	absltest	.	TestCase	)	:	


def	test_flag_saver_on_class	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	



@flagsaver.flagsaver	
class	FooTest	(	absltest	.	TestCase	)	:	

def	test_tautology	(	self	)	:	
pass	

del	FooTest	

def	test_flag_saver_call_on_class	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	



@flagsaver.flagsaver	(	)	
class	FooTest	(	absltest	.	TestCase	)	:	

def	test_tautology	(	self	)	:	
pass	

del	FooTest	

def	test_flag_saver_with_overrides_on_class	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	



@flagsaver.flagsaver	(	foo	=	"str"	)	
class	FooTest	(	absltest	.	TestCase	)	:	

def	test_tautology	(	self	)	:	
pass	

del	FooTest	

def	test_multiple_positional_parameters	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
func_a	=	lambda	:	None	
func_b	=	lambda	:	None	
flagsaver	.	flagsaver	(	func_a	,	func_b	)	

def	test_both_positional_and_keyword_parameters	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
func_a	=	lambda	:	None	
flagsaver	.	flagsaver	(	func_a	,	flagsaver_test_flag0	=	"str"	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	