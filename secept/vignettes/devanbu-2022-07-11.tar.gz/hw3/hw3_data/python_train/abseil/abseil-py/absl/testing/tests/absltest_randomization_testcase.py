















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	sys	

from	absl	.	testing	import	absltest	


class	ClassA	(	absltest	.	TestCase	)	:	

def	test_a	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	test_b	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	test_c	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	