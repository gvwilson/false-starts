















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	collections	
import	errno	
import	os	
import	pdb	
import	sys	
import	traceback	

from	absl	import	command_name	
from	absl	import	flags	
from	absl	import	logging	

try	:	
import	faulthandler	
except	ImportError	:	
faulthandler	=	None	

FLAGS	=	flags	.	FLAGS	

flags	.	DEFINE_boolean	(	"str"	,	False	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	False	,	
"str"	
"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	False	,	
"str"	
"str"	
"str"	)	
flags	.	DEFINE_string	(	"str"	,	None	,	
"str"	
"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	True	,	
"str"	
"str"	
"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	False	,	
"str"	,	
allow_hide_cpp	=	True	)	




EXCEPTION_HANDLERS	=	[	]	


class	Error	(	Exception	)	:	
pass	


class	UsageError	(	Error	)	:	


def	__init__	(	self	,	message	,	exitcode	=	1	)	:	
super	(	UsageError	,	self	)	.	__init__	(	message	)	
self	.	exitcode	=	exitcode	


class	HelpFlag	(	flags	.	BooleanFlag	)	:	

NAME	=	"str"	
SHORT_NAME	=	"str"	

def	__init__	(	self	)	:	
super	(	HelpFlag	,	self	)	.	__init__	(	
self	.	NAME	,	False	,	"str"	,	
short_name	=	self	.	SHORT_NAME	,	allow_hide_cpp	=	True	)	

def	parse	(	self	,	arg	)	:	
if	self	.	_parse	(	arg	)	:	
usage	(	shorthelp	=	True	,	writeto_stdout	=	True	)	

print	(	)	
print	(	"str"	)	
sys	.	exit	(	1	)	


class	HelpshortFlag	(	HelpFlag	)	:	

NAME	=	"str"	
SHORT_NAME	=	None	


class	HelpfullFlag	(	flags	.	BooleanFlag	)	:	


def	__init__	(	self	)	:	
super	(	HelpfullFlag	,	self	)	.	__init__	(	
"str"	,	False	,	"str"	,	allow_hide_cpp	=	True	)	

def	parse	(	self	,	arg	)	:	
if	self	.	_parse	(	arg	)	:	
usage	(	writeto_stdout	=	True	)	
sys	.	exit	(	1	)	


class	HelpXMLFlag	(	flags	.	BooleanFlag	)	:	


def	__init__	(	self	)	:	
super	(	HelpXMLFlag	,	self	)	.	__init__	(	
"str"	,	False	,	"str"	,	
allow_hide_cpp	=	True	)	

def	parse	(	self	,	arg	)	:	
if	self	.	_parse	(	arg	)	:	
flags	.	FLAGS	.	write_help_in_xml_format	(	sys	.	stdout	)	
sys	.	exit	(	1	)	


def	parse_flags_with_usage	(	args	)	:	

try	:	
return	FLAGS	(	args	)	
except	flags	.	Error	as	error	:	
sys	.	stderr	.	write	(	"str"	%	error	)	
sys	.	stderr	.	write	(	"str"	)	
sys	.	exit	(	1	)	


_define_help_flags_called	=	False	


def	define_help_flags	(	)	:	


global	_define_help_flags_called	

if	not	_define_help_flags_called	:	
flags	.	DEFINE_flag	(	HelpFlag	(	)	)	
flags	.	DEFINE_flag	(	HelpshortFlag	(	)	)	
flags	.	DEFINE_flag	(	HelpfullFlag	(	)	)	
flags	.	DEFINE_flag	(	HelpXMLFlag	(	)	)	
_define_help_flags_called	=	True	


def	_register_and_parse_flags_with_usage	(	
argv	=	None	,	
flags_parser	=	parse_flags_with_usage	,	
)	:	

if	_register_and_parse_flags_with_usage	.	done	:	
raise	SystemError	(	"str"	)	

define_help_flags	(	)	

original_argv	=	sys	.	argv	if	argv	is	None	else	argv	
args_to_main	=	flags_parser	(	original_argv	)	
if	not	FLAGS	.	is_parsed	(	)	:	
raise	Error	(	"str"	)	


if	FLAGS	.	only_check_args	:	
sys	.	exit	(	0	)	


if	FLAGS	[	"str"	]	.	using_default_value	:	
FLAGS	.	verbosity	=	0	
_register_and_parse_flags_with_usage	.	done	=	True	

return	args_to_main	

_register_and_parse_flags_with_usage	.	done	=	False	


def	_run_main	(	main	,	argv	)	:	

if	FLAGS	.	run_with_pdb	:	
sys	.	exit	(	pdb	.	runcall	(	main	,	argv	)	)	
elif	FLAGS	.	run_with_profiling	or	FLAGS	.	profile_file	:	


import	atexit	
if	FLAGS	.	use_cprofile_for_profiling	:	
import	cProfile	as	profile	
else	:	
import	profile	
profiler	=	profile	.	Profile	(	)	
if	FLAGS	.	profile_file	:	
atexit	.	register	(	profiler	.	dump_stats	,	FLAGS	.	profile_file	)	
else	:	
atexit	.	register	(	profiler	.	print_stats	)	
retval	=	profiler	.	runcall	(	main	,	argv	)	
sys	.	exit	(	retval	)	
else	:	
sys	.	exit	(	main	(	argv	)	)	


def	_call_exception_handlers	(	exception	)	:	

for	handler	in	EXCEPTION_HANDLERS	:	
try	:	
if	handler	.	wants	(	exception	)	:	
handler	.	handle	(	exception	)	
except	:	
try	:	


logging	.	error	(	traceback	.	format_exc	(	)	)	
except	:	

pass	


def	run	(	
main	,	
argv	=	None	,	
flags_parser	=	parse_flags_with_usage	,	
)	:	

try	:	
args	=	_run_init	(	
sys	.	argv	if	argv	is	None	else	argv	,	
flags_parser	,	
)	
while	_init_callbacks	:	
callback	=	_init_callbacks	.	popleft	(	)	
callback	(	)	
try	:	
_run_main	(	main	,	args	)	
except	UsageError	as	error	:	
usage	(	shorthelp	=	True	,	detailed_error	=	error	,	exitcode	=	error	.	exitcode	)	
except	:	
exc	=	sys	.	exc_info	(	)	[	1	]	



if	isinstance	(	exc	,	SystemExit	)	and	not	exc	.	code	:	
raise	



if	FLAGS	.	pdb_post_mortem	and	sys	.	stdout	.	isatty	(	)	:	
traceback	.	print_exc	(	)	
print	(	)	
print	(	"str"	)	
print	(	)	
pdb	.	post_mortem	(	)	
raise	
except	Exception	as	e	:	
_call_exception_handlers	(	e	)	
raise	


_init_callbacks	=	collections	.	deque	(	)	


def	call_after_init	(	callback	)	:	

if	_run_init	.	done	:	
callback	(	)	
else	:	
_init_callbacks	.	append	(	callback	)	


def	_run_init	(	
argv	,	
flags_parser	,	
)	:	

if	_run_init	.	done	:	
return	flags_parser	(	argv	)	
command_name	.	make_process_name_useful	(	)	

logging	.	use_absl_handler	(	)	
args	=	_register_and_parse_flags_with_usage	(	
argv	=	argv	,	
flags_parser	=	flags_parser	,	
)	
if	faulthandler	:	
try	:	
faulthandler	.	enable	(	)	
except	Exception	:	


pass	
_run_init	.	done	=	True	
return	args	


_run_init	.	done	=	False	


def	usage	(	shorthelp	=	False	,	writeto_stdout	=	False	,	detailed_error	=	None	,	
exitcode	=	None	)	:	

if	writeto_stdout	:	
stdfile	=	sys	.	stdout	
else	:	
stdfile	=	sys	.	stderr	

doc	=	sys	.	modules	[	"str"	]	.	__doc__	
if	not	doc	:	
doc	=	"str"	%	sys	.	argv	[	0	]	
doc	=	flags	.	text_wrap	(	doc	,	indent	=	"str"	,	firstline_indent	=	"str"	)	
else	:	

num_specifiers	=	doc	.	count	(	"str"	)	-	2	*	doc	.	count	(	"str"	)	
try	:	
doc	%	=	(	sys	.	argv	[	0	]	,	)	*	num_specifiers	
except	(	OverflowError	,	TypeError	,	ValueError	)	:	

pass	
if	shorthelp	:	
flag_str	=	FLAGS	.	main_module_help	(	)	
else	:	
flag_str	=	FLAGS	.	get_help	(	)	
try	:	
stdfile	.	write	(	doc	)	
if	flag_str	:	
stdfile	.	write	(	"str"	)	
stdfile	.	write	(	flag_str	)	
stdfile	.	write	(	"str"	)	
if	detailed_error	is	not	None	:	
stdfile	.	write	(	"str"	%	detailed_error	)	
except	IOError	as	e	:	


if	e	.	errno	!=	errno	.	EPIPE	:	
raise	
if	exitcode	is	not	None	:	
sys	.	exit	(	exitcode	)	


class	ExceptionHandler	(	object	)	:	


def	wants	(	self	,	exc	)	:	

del	exc	
return	True	

def	handle	(	self	,	exc	)	:	

raise	NotImplementedError	(	)	


def	install_exception_handler	(	handler	)	:	

if	not	isinstance	(	handler	,	ExceptionHandler	)	:	
raise	TypeError	(	"str"	
%	type	(	handler	)	)	
EXCEPTION_HANDLERS	.	append	(	handler	)	
	