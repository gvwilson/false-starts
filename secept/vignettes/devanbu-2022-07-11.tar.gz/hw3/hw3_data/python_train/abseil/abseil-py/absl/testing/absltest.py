















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	contextlib	
import	difflib	
import	errno	
import	getpass	
import	inspect	
import	io	
import	itertools	
import	json	
import	os	
import	random	
import	re	
import	shlex	
import	shutil	
import	signal	
import	stat	
import	subprocess	
import	sys	
import	tempfile	
import	textwrap	
import	unittest	

try	:	



import	faulthandler	

except	ImportError	:	

faulthandler	=	None	

from	absl	import	app	
from	absl	import	flags	
from	absl	import	logging	
from	absl	.	_collections_abc	import	abc	
from	absl	.	_enum_module	import	enum	
from	absl	.	testing	import	_pretty_print_reporter	
from	absl	.	testing	import	xml_reporter	
from	absl	.	third_party	import	unittest3_backport	
import	six	
from	six	.	moves	import	urllib	
from	six	.	moves	import	xrange	



try	:	

import	typing	
from	typing	import	AnyStr	,	Callable	,	Text	,	Optional	,	ContextManager	,	TextIO	,	BinaryIO	,	Union	,	Type	,	Tuple	,	Any	,	MutableSequence	,	Sequence	,	Mapping	,	MutableMapping	,	IO	,	List	

except	ImportError	:	
pass	
else	:	


if	typing	.	TYPE_CHECKING	:	

_T	=	typing	.	TypeVar	(	"str"	)	

if	six	.	PY2	:	
_OutcomeType	=	unittest3_backport	.	case	.	_Outcome	
else	:	
import	unittest	.	case	
_OutcomeType	=	unittest	.	case	.	_Outcome	


if	six	.	PY3	:	
from	unittest	import	mock	
else	:	
try	:	
import	mock	
except	ImportError	:	
mock	=	None	





skip	=	unittest	.	skip	
skipIf	=	unittest	.	skipIf	
skipUnless	=	unittest	.	skipUnless	
SkipTest	=	unittest	.	SkipTest	
expectedFailure	=	unittest	.	expectedFailure	




FLAGS	=	flags	.	FLAGS	

_TEXT_OR_BINARY_TYPES	=	(	six	.	text_type	,	six	.	binary_type	)	


def	expectedFailureIf	(	condition	,	reason	)	:	

del	reason	
if	condition	:	
return	unittest	.	expectedFailure	
else	:	
return	lambda	f	:	f	


class	TempFileCleanup	(	enum	.	Enum	)	:	

ALWAYS	=	"str"	



SUCCESS	=	"str"	

OFF	=	"str"	








def	_get_default_test_random_seed	(	)	:	

random_seed	=	301	
value	=	os	.	environ	.	get	(	"str"	,	"str"	)	
try	:	
random_seed	=	int	(	value	)	
except	ValueError	:	
pass	
return	random_seed	


def	get_default_test_srcdir	(	)	:	


return	os	.	environ	.	get	(	"str"	,	"str"	)	


def	get_default_test_tmpdir	(	)	:	


tmpdir	=	os	.	environ	.	get	(	"str"	,	"str"	)	
if	not	tmpdir	:	
tmpdir	=	os	.	path	.	join	(	tempfile	.	gettempdir	(	)	,	"str"	)	

return	tmpdir	


def	_get_default_randomize_ordering_seed	(	)	:	


if	FLAGS	.	test_randomize_ordering_seed	is	not	None	:	
randomize	=	FLAGS	.	test_randomize_ordering_seed	
else	:	
randomize	=	os	.	environ	.	get	(	"str"	)	
if	randomize	is	None	:	
return	0	
if	randomize	==	"str"	:	
return	random	.	Random	(	)	.	randint	(	1	,	4294967295	)	
if	randomize	==	"str"	:	
return	0	
try	:	
seed	=	int	(	randomize	)	
if	seed	>	0	:	
return	seed	
except	ValueError	:	
pass	
raise	ValueError	(	
"str"	.	format	(	randomize	)	)	


flags	.	DEFINE_integer	(	"str"	,	_get_default_test_random_seed	(	)	,	
"str"	
"str"	
"str"	,	
allow_override_cpp	=	True	)	
flags	.	DEFINE_string	(	"str"	,	
get_default_test_srcdir	(	)	,	
"str"	,	
allow_override_cpp	=	True	)	
flags	.	DEFINE_string	(	"str"	,	get_default_test_tmpdir	(	)	,	
"str"	,	
allow_override_cpp	=	True	)	
flags	.	DEFINE_string	(	"str"	,	None	,	
"str"	
"str"	
"str"	
"str"	
"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	
"str"	)	





def	_monkey_patch_test_result_for_unexpected_passes	(	)	:	



def	wasSuccessful	(	self	)	:	


return	(	len	(	self	.	failures	)	==	len	(	self	.	errors	)	==	
len	(	self	.	unexpectedSuccesses	)	==	0	)	

test_result	=	unittest	.	TestResult	(	)	
test_result	.	addUnexpectedSuccess	(	unittest	.	FunctionTestCase	(	lambda	:	None	)	)	
if	test_result	.	wasSuccessful	(	)	:	
unittest	.	TestResult	.	wasSuccessful	=	wasSuccessful	
if	test_result	.	wasSuccessful	(	)	:	
sys	.	stderr	.	write	(	"str"	
"str"	)	


_monkey_patch_test_result_for_unexpected_passes	(	)	


def	_open	(	filepath	,	mode	,	_open_func	=	open	)	:	


if	six	.	PY2	:	
return	_open_func	(	filepath	,	mode	)	
else	:	
return	_open_func	(	filepath	,	mode	,	encoding	=	"str"	)	


class	_TempDir	(	object	)	:	


def	__init__	(	self	,	path	)	:	


self	.	_path	=	path	

@property	
def	full_path	(	self	)	:	


return	self	.	_path	

def	create_file	(	self	,	file_path	=	None	,	content	=	None	,	mode	=	"str"	,	encoding	=	"str"	,	
errors	=	"str"	)	:	


tf	,	_	=	_TempFile	.	_create	(	self	.	_path	,	file_path	,	content	,	mode	,	encoding	,	
errors	)	
return	tf	

def	mkdir	(	self	,	dir_path	=	None	)	:	


if	dir_path	:	
path	=	os	.	path	.	join	(	self	.	_path	,	dir_path	)	
else	:	
path	=	tempfile	.	mkdtemp	(	dir	=	self	.	_path	)	



_makedirs_exist_ok	(	path	)	
return	_TempDir	(	path	)	


class	_TempFile	(	object	)	:	


def	__init__	(	self	,	path	)	:	


self	.	_path	=	path	


@classmethod	
def	_create	(	cls	,	base_path	,	file_path	,	content	,	mode	,	encoding	,	errors	)	:	



if	file_path	:	
cleanup_path	=	os	.	path	.	join	(	base_path	,	_get_first_part	(	file_path	)	)	
path	=	os	.	path	.	join	(	base_path	,	file_path	)	
_makedirs_exist_ok	(	os	.	path	.	dirname	(	path	)	)	


if	os	.	path	.	exists	(	path	)	and	not	os	.	access	(	path	,	os	.	W_OK	)	:	
stat_info	=	os	.	stat	(	path	)	
os	.	chmod	(	path	,	stat_info	.	st_mode	|	stat	.	S_IWUSR	)	
else	:	
_makedirs_exist_ok	(	base_path	)	
fd	,	path	=	tempfile	.	mkstemp	(	dir	=	str	(	base_path	)	)	
os	.	close	(	fd	)	
cleanup_path	=	path	

tf	=	cls	(	path	)	

if	content	:	
if	isinstance	(	content	,	six	.	text_type	)	:	
tf	.	write_text	(	content	,	mode	=	mode	,	encoding	=	encoding	,	errors	=	errors	)	
else	:	
tf	.	write_bytes	(	content	,	mode	)	

else	:	
tf	.	write_bytes	(	b	"str"	)	

return	tf	,	cleanup_path	

@property	
def	full_path	(	self	)	:	


return	self	.	_path	

def	read_text	(	self	,	encoding	=	"str"	,	errors	=	"str"	)	:	


with	self	.	open_text	(	encoding	=	encoding	,	errors	=	errors	)	as	fp	:	
return	fp	.	read	(	)	

def	read_bytes	(	self	)	:	


with	self	.	open_bytes	(	)	as	fp	:	
return	fp	.	read	(	)	

def	write_text	(	self	,	text	,	mode	=	"str"	,	encoding	=	"str"	,	errors	=	"str"	)	:	


if	six	.	PY2	and	isinstance	(	text	,	bytes	)	:	
text	=	text	.	decode	(	encoding	,	errors	)	
with	self	.	open_text	(	mode	,	encoding	=	encoding	,	errors	=	errors	)	as	fp	:	
fp	.	write	(	text	)	

def	write_bytes	(	self	,	data	,	mode	=	"str"	)	:	


with	self	.	open_bytes	(	mode	)	as	fp	:	
fp	.	write	(	data	)	

def	open_text	(	self	,	mode	=	"str"	,	encoding	=	"str"	,	errors	=	"str"	)	:	


if	"str"	in	mode	:	
raise	ValueError	(	"str"	
"str"	.	format	(	mode	)	)	
if	"str"	not	in	mode	:	
mode	+	=	"str"	
return	self	.	_open	(	mode	,	encoding	,	errors	)	

def	open_bytes	(	self	,	mode	=	"str"	)	:	


if	"str"	in	mode	:	
raise	ValueError	(	"str"	
"str"	.	format	(	mode	)	)	
if	"str"	not	in	mode	:	
mode	+	=	"str"	
return	self	.	_open	(	mode	,	encoding	=	None	,	errors	=	None	)	

@contextlib.contextmanager	
def	_open	(	self	,	mode	,	encoding	=	"str"	,	errors	=	"str"	)	:	

with	io	.	open	(	
self	.	full_path	,	mode	=	mode	,	encoding	=	encoding	,	errors	=	errors	)	as	fp	:	
yield	fp	


class	TestCase	(	unittest3_backport	.	TestCase	)	:	








tempfile_cleanup	=	TempFileCleanup	.	ALWAYS	

maxDiff	=	80	*	20	
longMessage	=	True	

def	__init__	(	self	,	*	args	,	*	*	kwargs	)	:	
super	(	TestCase	,	self	)	.	__init__	(	*	args	,	*	*	kwargs	)	

self	.	_outcome	=	getattr	(	self	,	"str"	)	

def	create_tempdir	(	self	,	name	=	None	,	cleanup	=	None	)	:	


test_path	=	self	.	_get_tempdir_path_test	(	)	

if	name	:	
path	=	os	.	path	.	join	(	test_path	,	name	)	
cleanup_path	=	os	.	path	.	join	(	test_path	,	_get_first_part	(	name	)	)	
else	:	
_makedirs_exist_ok	(	test_path	)	
path	=	tempfile	.	mkdtemp	(	dir	=	test_path	)	
cleanup_path	=	path	

_rmtree_ignore_errors	(	cleanup_path	)	
_makedirs_exist_ok	(	path	)	

self	.	_maybe_add_temp_path_cleanup	(	cleanup_path	,	cleanup	)	

return	_TempDir	(	path	)	


def	create_tempfile	(	self	,	file_path	=	None	,	content	=	None	,	mode	=	"str"	,	
encoding	=	"str"	,	errors	=	"str"	,	cleanup	=	None	)	:	



test_path	=	self	.	_get_tempdir_path_test	(	)	
tf	,	cleanup_path	=	_TempFile	.	_create	(	test_path	,	file_path	,	content	=	content	,	
mode	=	mode	,	encoding	=	encoding	,	
errors	=	errors	)	
self	.	_maybe_add_temp_path_cleanup	(	cleanup_path	,	cleanup	)	
return	tf	

@classmethod	
def	_get_tempdir_path_cls	(	cls	)	:	

return	os	.	path	.	join	(	FLAGS	.	test_tmpdir	,	_get_qualname	(	cls	)	)	

def	_get_tempdir_path_test	(	self	)	:	

return	os	.	path	.	join	(	self	.	_get_tempdir_path_cls	(	)	,	self	.	_testMethodName	)	

def	_get_tempfile_cleanup	(	self	,	override	)	:	

if	override	is	not	None	:	
return	override	
return	self	.	tempfile_cleanup	

def	_maybe_add_temp_path_cleanup	(	self	,	path	,	cleanup	)	:	

cleanup	=	self	.	_get_tempfile_cleanup	(	cleanup	)	
if	cleanup	==	TempFileCleanup	.	OFF	:	
return	
elif	cleanup	==	TempFileCleanup	.	ALWAYS	:	
self	.	addCleanup	(	_rmtree_ignore_errors	,	path	)	
elif	cleanup	==	TempFileCleanup	.	SUCCESS	:	
self	.	_internal_cleanup_on_success	(	_rmtree_ignore_errors	,	path	)	
else	:	
raise	AssertionError	(	"str"	.	format	(	cleanup	)	)	

def	_internal_cleanup_on_success	(	self	,	function	,	*	args	,	*	*	kwargs	)	:	

def	_call_cleaner_on_success	(	*	args	,	*	*	kwargs	)	:	
if	not	self	.	_ran_and_passed	(	)	:	
return	
function	(	*	args	,	*	*	kwargs	)	
self	.	addCleanup	(	_call_cleaner_on_success	,	*	args	,	*	*	kwargs	)	

def	_ran_and_passed	(	self	)	:	

outcome	=	self	.	_outcome	
result	=	self	.	defaultTestResult	(	)	
self	.	_feedErrorsToResult	(	result	,	outcome	.	errors	)	
return	result	.	wasSuccessful	(	)	

def	shortDescription	(	self	)	:	


desc	=	str	(	self	)	






doc_first_line	=	super	(	TestCase	,	self	)	.	shortDescription	(	)	
if	doc_first_line	is	not	None	:	
desc	=	"str"	.	join	(	(	desc	,	doc_first_line	)	)	
return	desc	

def	assertStartsWith	(	self	,	actual	,	expected_start	,	msg	=	None	)	:	

if	not	actual	.	startswith	(	expected_start	)	:	
self	.	fail	(	"str"	%	(	actual	,	expected_start	)	,	msg	)	

def	assertNotStartsWith	(	self	,	actual	,	unexpected_start	,	msg	=	None	)	:	

if	actual	.	startswith	(	unexpected_start	)	:	
self	.	fail	(	"str"	%	(	actual	,	unexpected_start	)	,	msg	)	

def	assertEndsWith	(	self	,	actual	,	expected_end	,	msg	=	None	)	:	

if	not	actual	.	endswith	(	expected_end	)	:	
self	.	fail	(	"str"	%	(	actual	,	expected_end	)	,	msg	)	

def	assertNotEndsWith	(	self	,	actual	,	unexpected_end	,	msg	=	None	)	:	

if	actual	.	endswith	(	unexpected_end	)	:	
self	.	fail	(	"str"	%	(	actual	,	unexpected_end	)	,	msg	)	

def	assertSequenceStartsWith	(	self	,	prefix	,	whole	,	msg	=	None	)	:	

try	:	
prefix_len	=	len	(	prefix	)	
except	(	TypeError	,	NotImplementedError	)	:	
prefix	=	[	prefix	]	
prefix_len	=	1	

try	:	
whole_len	=	len	(	whole	)	
except	(	TypeError	,	NotImplementedError	)	:	
self	.	fail	(	"str"	
"str"	%	(	whole	,	type	(	whole	)	)	,	msg	)	

assert	prefix_len	<	=	whole_len	,	self	.	_formatMessage	(	
msg	,	
"str"	%	
(	prefix_len	,	whole_len	)	
)	

if	not	prefix_len	and	whole_len	:	
self	.	fail	(	"str"	%	
(	len	(	whole	)	,	whole	)	,	msg	)	

try	:	
self	.	assertSequenceEqual	(	prefix	,	whole	[	:	prefix_len	]	,	msg	)	
except	AssertionError	:	
self	.	fail	(	"str"	%	
(	prefix	,	whole	)	,	msg	)	

def	assertEmpty	(	self	,	container	,	msg	=	None	)	:	

if	not	isinstance	(	container	,	abc	.	Sized	)	:	
self	.	fail	(	"str"	
"str"	.	format	(	type	(	container	)	.	__name__	)	,	msg	)	



if	len	(	container	)	:	
self	.	fail	(	"str"	.	format	(	container	,	len	(	container	)	)	,	msg	)	

def	assertNotEmpty	(	self	,	container	,	msg	=	None	)	:	

if	not	isinstance	(	container	,	abc	.	Sized	)	:	
self	.	fail	(	"str"	
"str"	.	format	(	type	(	container	)	.	__name__	)	,	msg	)	



if	not	len	(	container	)	:	
self	.	fail	(	"str"	.	format	(	container	)	,	msg	)	

def	assertLen	(	self	,	container	,	expected_len	,	msg	=	None	)	:	

if	not	isinstance	(	container	,	abc	.	Sized	)	:	
self	.	fail	(	"str"	
"str"	.	format	(	type	(	container	)	.	__name__	)	,	msg	)	
if	len	(	container	)	!=	expected_len	:	
container_repr	=	unittest	.	util	.	safe_repr	(	container	)	
self	.	fail	(	"str"	.	format	(	
container_repr	,	len	(	container	)	,	expected_len	)	,	msg	)	

def	assertSequenceAlmostEqual	(	self	,	expected_seq	,	actual_seq	,	places	=	None	,	
msg	=	None	,	delta	=	None	)	:	

if	len	(	expected_seq	)	!=	len	(	actual_seq	)	:	
self	.	fail	(	"str"	.	format	(	
len	(	expected_seq	)	,	len	(	actual_seq	)	)	,	msg	)	

err_list	=	[	]	
for	idx	,	(	exp_elem	,	act_elem	)	in	enumerate	(	zip	(	expected_seq	,	actual_seq	)	)	:	
try	:	




self	.	assertAlmostEqual	(	exp_elem	,	act_elem	,	places	=	places	,	msg	=	msg	,	
delta	=	delta	)	

except	self	.	failureException	as	err	:	
err_list	.	append	(	"str"	.	format	(	idx	,	err	)	)	

if	err_list	:	
if	len	(	err_list	)	>	30	:	
err_list	=	err_list	[	:	30	]	+	[	"str"	]	
msg	=	self	.	_formatMessage	(	msg	,	"str"	.	join	(	err_list	)	)	
self	.	fail	(	msg	)	

def	assertContainsSubset	(	self	,	expected_subset	,	actual_set	,	msg	=	None	)	:	

missing	=	set	(	expected_subset	)	-	set	(	actual_set	)	
if	not	missing	:	
return	

self	.	fail	(	"str"	%	(	
missing	,	expected_subset	,	actual_set	)	,	msg	)	

def	assertNoCommonElements	(	self	,	expected_seq	,	actual_seq	,	msg	=	None	)	:	

common	=	set	(	expected_seq	)	&	set	(	actual_seq	)	
if	not	common	:	
return	

self	.	fail	(	"str"	%	(	
common	,	expected_seq	,	actual_seq	)	,	msg	)	

def	assertItemsEqual	(	self	,	expected_seq	,	actual_seq	,	msg	=	None	)	:	

if	six	.	PY3	:	

super	(	TestCase	,	self	)	.	assertCountEqual	(	expected_seq	,	actual_seq	,	msg	)	
else	:	
super	(	TestCase	,	self	)	.	assertItemsEqual	(	expected_seq	,	actual_seq	,	msg	)	


if	six	.	PY2	:	

def	assertCountEqual	(	self	,	expected_seq	,	actual_seq	,	msg	=	None	)	:	


super	(	TestCase	,	self	)	.	assertItemsEqual	(	expected_seq	,	actual_seq	,	msg	)	

def	assertSameElements	(	self	,	expected_seq	,	actual_seq	,	msg	=	None	)	:	








if	(	isinstance	(	expected_seq	,	_TEXT_OR_BINARY_TYPES	)	or	
isinstance	(	actual_seq	,	_TEXT_OR_BINARY_TYPES	)	)	:	
self	.	fail	(	"str"	
"str"	
"str"	%	(	expected_seq	,	actual_seq	)	)	
try	:	
expected	=	dict	(	[	(	element	,	None	)	for	element	in	expected_seq	]	)	
actual	=	dict	(	[	(	element	,	None	)	for	element	in	actual_seq	]	)	
missing	=	[	element	for	element	in	expected	if	element	not	in	actual	]	
unexpected	=	[	element	for	element	in	actual	if	element	not	in	expected	]	
missing	.	sort	(	)	
unexpected	.	sort	(	)	
except	TypeError	:	


expected	=	list	(	expected_seq	)	
actual	=	list	(	actual_seq	)	
expected	.	sort	(	)	
actual	.	sort	(	)	
missing	,	unexpected	=	_sorted_list_difference	(	expected	,	actual	)	
errors	=	[	]	
if	msg	:	
errors	.	extend	(	(	msg	,	"str"	)	)	
if	missing	:	
errors	.	append	(	"str"	%	missing	)	
if	unexpected	:	
errors	.	append	(	"str"	%	unexpected	)	
if	missing	or	unexpected	:	
self	.	fail	(	"str"	.	join	(	errors	)	)	



def	assertMultiLineEqual	(	self	,	first	,	second	,	msg	=	None	,	*	*	kwargs	)	:	

assert	isinstance	(	first	,	six	.	string_types	)	,	(	
"str"	%	(	first	,	)	)	
assert	isinstance	(	second	,	six	.	string_types	)	,	(	
"str"	%	(	second	,	)	)	
line_limit	=	kwargs	.	pop	(	"str"	,	0	)	
if	kwargs	:	
raise	TypeError	(	"str"	.	format	(	tuple	(	kwargs	)	)	)	

if	first	==	second	:	
return	
if	msg	:	
failure_message	=	[	msg	+	"str"	]	
else	:	
failure_message	=	[	"str"	]	
if	line_limit	:	
line_limit	+	=	len	(	failure_message	)	
for	line	in	difflib	.	ndiff	(	first	.	splitlines	(	True	)	,	second	.	splitlines	(	True	)	)	:	
failure_message	.	append	(	line	)	
if	not	line	.	endswith	(	"str"	)	:	
failure_message	.	append	(	"str"	)	
if	line_limit	and	len	(	failure_message	)	>	line_limit	:	
n_omitted	=	len	(	failure_message	)	-	line_limit	
failure_message	=	failure_message	[	:	line_limit	]	
failure_message	.	append	(	
"str"	.	format	(	
n_omitted	)	)	

raise	self	.	failureException	(	"str"	.	join	(	failure_message	)	)	

def	assertBetween	(	self	,	value	,	minv	,	maxv	,	msg	=	None	)	:	

msg	=	self	.	_formatMessage	(	msg	,	
"str"	%	
(	value	,	minv	,	maxv	)	)	
self	.	assertTrue	(	minv	<	=	value	,	msg	)	
self	.	assertTrue	(	maxv	>	=	value	,	msg	)	


if	six	.	PY2	:	

def	assertRegex	(	self	,	*	args	,	*	*	kwargs	)	:	
return	self	.	assertRegexpMatches	(	*	args	,	*	*	kwargs	)	

def	assertRaisesRegex	(	self	,	*	args	,	*	*	kwargs	)	:	
return	self	.	assertRaisesRegexp	(	*	args	,	*	*	kwargs	)	

def	assertNotRegex	(	self	,	*	args	,	*	*	kwargs	)	:	
return	self	.	assertNotRegexpMatches	(	*	args	,	*	*	kwargs	)	

def	assertRegexMatch	(	self	,	actual_str	,	regexes	,	message	=	None	)	:	

if	isinstance	(	regexes	,	_TEXT_OR_BINARY_TYPES	)	:	
self	.	fail	(	"str"	,	
message	)	
if	not	regexes	:	
self	.	fail	(	"str"	,	message	)	

regex_type	=	type	(	regexes	[	0	]	)	
for	regex	in	regexes	[	1	:	]	:	
if	type	(	regex	)	is	not	regex_type	:	
self	.	fail	(	"str"	,	message	)	

if	regex_type	is	bytes	and	isinstance	(	actual_str	,	six	.	text_type	)	:	
regexes	=	[	regex	.	decode	(	"str"	)	for	regex	in	regexes	]	
regex_type	=	six	.	text_type	
elif	regex_type	is	six	.	text_type	and	isinstance	(	actual_str	,	bytes	)	:	
regexes	=	[	regex	.	encode	(	"str"	)	for	regex	in	regexes	]	
regex_type	=	bytes	

if	regex_type	is	six	.	text_type	:	
regex	=	"str"	%	"str"	.	join	(	regexes	)	
elif	regex_type	is	bytes	:	
regex	=	b	"str"	+	(	b	"str"	.	join	(	regexes	)	)	+	b	"str"	
else	:	
self	.	fail	(	"str"	,	
message	)	

if	not	re	.	search	(	regex	,	actual_str	,	re	.	MULTILINE	)	:	
self	.	fail	(	"str"	%	
(	actual_str	,	regexes	)	,	message	)	

def	assertCommandSucceeds	(	self	,	command	,	regexes	=	(	b	"str"	,	)	,	env	=	None	,	
close_fds	=	True	,	msg	=	None	)	:	

(	ret_code	,	err	)	=	get_command_stderr	(	command	,	env	,	close_fds	)	




if	isinstance	(	regexes	[	0	]	,	six	.	text_type	)	:	
regexes	=	[	regex	.	encode	(	"str"	)	for	regex	in	regexes	]	

command_string	=	get_command_string	(	command	)	
self	.	assertEqual	(	
ret_code	,	0	,	
self	.	_formatMessage	(	msg	,	
"str"	
"str"	
"str"	%	(	_quote_long_string	(	command_string	)	,	
ret_code	,	
_quote_long_string	(	err	)	)	)	
)	
self	.	assertRegexMatch	(	
err	,	
regexes	,	
message	=	self	.	_formatMessage	(	
msg	,	
"str"	
"str"	
"str"	%	(	
_quote_long_string	(	command_string	)	,	
ret_code	,	
_quote_long_string	(	err	)	,	
regexes	)	)	)	

def	assertCommandFails	(	self	,	command	,	regexes	,	env	=	None	,	close_fds	=	True	,	
msg	=	None	)	:	

(	ret_code	,	err	)	=	get_command_stderr	(	command	,	env	,	close_fds	)	




if	isinstance	(	regexes	[	0	]	,	six	.	text_type	)	:	
regexes	=	[	regex	.	encode	(	"str"	)	for	regex	in	regexes	]	

command_string	=	get_command_string	(	command	)	
self	.	assertNotEqual	(	
ret_code	,	0	,	
self	.	_formatMessage	(	msg	,	"str"	
"str"	%	
_quote_long_string	(	command_string	)	)	)	
self	.	assertRegexMatch	(	
err	,	
regexes	,	
message	=	self	.	_formatMessage	(	
msg	,	
"str"	
"str"	
"str"	%	(	
_quote_long_string	(	command_string	)	,	
ret_code	,	
_quote_long_string	(	err	)	,	
regexes	)	)	)	

class	_AssertRaisesContext	(	object	)	:	

def	__init__	(	self	,	expected_exception	,	test_case	,	test_func	,	msg	=	None	)	:	
self	.	expected_exception	=	expected_exception	
self	.	test_case	=	test_case	
self	.	test_func	=	test_func	
self	.	msg	=	msg	

def	__enter__	(	self	)	:	
return	self	

def	__exit__	(	self	,	exc_type	,	exc_value	,	tb	)	:	
if	exc_type	is	None	:	
self	.	test_case	.	fail	(	self	.	expected_exception	.	__name__	+	"str"	,	
self	.	msg	)	
if	not	issubclass	(	exc_type	,	self	.	expected_exception	)	:	
return	False	
self	.	test_func	(	exc_value	)	
return	True	

def	assertRaisesWithPredicateMatch	(	self	,	expected_exception	,	predicate	,	
callable_obj	=	None	,	*	args	,	*	*	kwargs	)	:	

def	Check	(	err	)	:	
self	.	assertTrue	(	predicate	(	err	)	,	
"str"	%	(	err	,	predicate	)	)	

context	=	self	.	_AssertRaisesContext	(	expected_exception	,	self	,	Check	)	
if	callable_obj	is	None	:	
return	context	
with	context	:	
callable_obj	(	*	args	,	*	*	kwargs	)	

def	assertRaisesWithLiteralMatch	(	self	,	expected_exception	,	
expected_exception_message	,	
callable_obj	=	None	,	*	args	,	*	*	kwargs	)	:	

def	Check	(	err	)	:	
actual_exception_message	=	str	(	err	)	
self	.	assertTrue	(	expected_exception_message	==	actual_exception_message	,	
"str"	
"str"	
"str"	%	(	expected_exception_message	,	
actual_exception_message	)	)	

context	=	self	.	_AssertRaisesContext	(	expected_exception	,	self	,	Check	)	
if	callable_obj	is	None	:	
return	context	
with	context	:	
callable_obj	(	*	args	,	*	*	kwargs	)	

def	assertContainsInOrder	(	self	,	strings	,	target	,	msg	=	None	)	:	

if	isinstance	(	strings	,	(	bytes	,	unicode	if	str	is	bytes	else	str	)	)	:	
strings	=	(	strings	,	)	

current_index	=	0	
last_string	=	None	
for	string	in	strings	:	
index	=	target	.	find	(	str	(	string	)	,	current_index	)	
if	index	==	-	1	and	current_index	==	0	:	
self	.	fail	(	"str"	%	
(	string	,	target	)	,	msg	)	
elif	index	==	-	1	:	
self	.	fail	(	"str"	%	
(	string	,	last_string	,	target	)	,	msg	)	
last_string	=	string	
current_index	=	index	

def	assertContainsSubsequence	(	self	,	container	,	subsequence	,	msg	=	None	)	:	

first_nonmatching	=	None	
reversed_container	=	list	(	reversed	(	container	)	)	
subsequence	=	list	(	subsequence	)	

for	e	in	subsequence	:	
if	e	not	in	reversed_container	:	
first_nonmatching	=	e	
break	
while	e	!=	reversed_container	.	pop	(	)	:	
pass	

if	first_nonmatching	is	not	None	:	
self	.	fail	(	"str"	%	
(	subsequence	,	container	,	first_nonmatching	)	,	msg	)	

def	assertContainsExactSubsequence	(	self	,	container	,	subsequence	,	msg	=	None	)	:	

container	=	list	(	container	)	
subsequence	=	list	(	subsequence	)	
longest_match	=	0	

for	start	in	xrange	(	1	+	len	(	container	)	-	len	(	subsequence	)	)	:	
if	longest_match	==	len	(	subsequence	)	:	
break	
index	=	0	
while	(	index	<	len	(	subsequence	)	and	
subsequence	[	index	]	==	container	[	start	+	index	]	)	:	
index	+	=	1	
longest_match	=	max	(	longest_match	,	index	)	

if	longest_match	<	len	(	subsequence	)	:	
self	.	fail	(	"str"	
"str"	%	
(	subsequence	,	container	,	subsequence	[	:	longest_match	]	)	,	msg	)	

def	assertTotallyOrdered	(	self	,	*	groups	,	*	*	kwargs	)	:	


def	CheckOrder	(	small	,	big	)	:	

self	.	assertFalse	(	small	==	big	,	
self	.	_formatMessage	(	msg	,	"str"	%	
(	small	,	big	)	)	)	
self	.	assertTrue	(	small	!=	big	,	
self	.	_formatMessage	(	msg	,	"str"	%	
(	small	,	big	)	)	)	
self	.	assertLess	(	small	,	big	,	msg	)	
self	.	assertFalse	(	big	<	small	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	big	,	small	)	)	)	
self	.	assertLessEqual	(	small	,	big	,	msg	)	
self	.	assertFalse	(	big	<	=	small	,	self	.	_formatMessage	(	
"str"	%	(	big	,	small	)	,	msg	
)	)	
self	.	assertGreater	(	big	,	small	,	msg	)	
self	.	assertFalse	(	small	>	big	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	small	,	big	)	)	)	
self	.	assertGreaterEqual	(	big	,	small	)	
self	.	assertFalse	(	small	>	=	big	,	self	.	_formatMessage	(	
msg	,	
"str"	%	(	small	,	big	)	)	)	

def	CheckEqual	(	a	,	b	)	:	

self	.	assertEqual	(	a	,	b	,	msg	)	
self	.	assertFalse	(	a	!=	b	,	
self	.	_formatMessage	(	msg	,	"str"	%	
(	a	,	b	)	)	)	



if	(	isinstance	(	a	,	abc	.	Hashable	)	and	
isinstance	(	b	,	abc	.	Hashable	)	)	:	
self	.	assertEqual	(	
hash	(	a	)	,	hash	(	b	)	,	
self	.	_formatMessage	(	
msg	,	"str"	%	
(	hash	(	a	)	,	a	,	hash	(	b	)	,	b	)	)	)	

self	.	assertFalse	(	a	<	b	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	a	,	b	)	)	)	
self	.	assertFalse	(	b	<	a	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	b	,	a	)	)	)	
self	.	assertLessEqual	(	a	,	b	,	msg	)	
self	.	assertLessEqual	(	b	,	a	,	msg	)	
self	.	assertFalse	(	a	>	b	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	a	,	b	)	)	)	
self	.	assertFalse	(	b	>	a	,	
self	.	_formatMessage	(	msg	,	
"str"	%	
(	b	,	a	)	)	)	
self	.	assertGreaterEqual	(	a	,	b	,	msg	)	
self	.	assertGreaterEqual	(	b	,	a	,	msg	)	

msg	=	kwargs	.	get	(	"str"	)	



for	elements	in	itertools	.	product	(	*	groups	)	:	
elements	=	list	(	elements	)	
for	index	,	small	in	enumerate	(	elements	[	:	-	1	]	)	:	
for	big	in	elements	[	index	+	1	:	]	:	
CheckOrder	(	small	,	big	)	


for	group	in	groups	:	
for	a	in	group	:	
CheckEqual	(	a	,	a	)	
for	a	,	b	in	itertools	.	product	(	group	,	group	)	:	
CheckEqual	(	a	,	b	)	

def	assertDictEqual	(	self	,	a	,	b	,	msg	=	None	)	:	

self	.	assertIsInstance	(	a	,	dict	,	self	.	_formatMessage	(	
msg	,	
"str"	
)	)	
self	.	assertIsInstance	(	b	,	dict	,	self	.	_formatMessage	(	
msg	,	
"str"	
)	)	

def	Sorted	(	list_of_items	)	:	
try	:	
return	sorted	(	list_of_items	)	
except	TypeError	:	
return	list_of_items	

if	a	==	b	:	
return	
a_items	=	Sorted	(	list	(	six	.	iteritems	(	a	)	)	)	
b_items	=	Sorted	(	list	(	six	.	iteritems	(	b	)	)	)	

unexpected	=	[	]	
missing	=	[	]	
different	=	[	]	

safe_repr	=	unittest	.	util	.	safe_repr	

def	Repr	(	dikt	)	:	



entries	=	sorted	(	(	safe_repr	(	k	)	,	safe_repr	(	v	)	)	
for	k	,	v	in	six	.	iteritems	(	dikt	)	)	
return	"str"	%	(	"str"	.	join	(	"str"	%	pair	for	pair	in	entries	)	)	

message	=	[	"str"	%	(	Repr	(	a	)	,	Repr	(	b	)	,	"str"	%	msg	if	msg	else	"str"	)	]	



for	a_key	,	a_value	in	a_items	:	
if	a_key	not	in	b	:	
missing	.	append	(	(	a_key	,	a_value	)	)	
elif	a_value	!=	b	[	a_key	]	:	
different	.	append	(	(	a_key	,	a_value	,	b	[	a_key	]	)	)	

for	b_key	,	b_value	in	b_items	:	
if	b_key	not	in	a	:	
unexpected	.	append	(	(	b_key	,	b_value	)	)	

if	unexpected	:	
message	.	append	(	
"str"	%	"str"	.	join	(	
"str"	%	(	safe_repr	(	k	)	,	safe_repr	(	v	)	)	for	k	,	v	in	unexpected	)	)	

if	different	:	
message	.	append	(	
"str"	%	"str"	.	join	(	
"str"	%	(	safe_repr	(	k	)	,	safe_repr	(	a_value	)	,	
safe_repr	(	b_value	)	)	
for	k	,	a_value	,	b_value	in	different	)	)	

if	missing	:	
message	.	append	(	
"str"	%	"str"	.	join	(	
(	"str"	%	(	safe_repr	(	k	)	,	safe_repr	(	v	)	)	for	k	,	v	in	missing	)	)	)	

raise	self	.	failureException	(	"str"	.	join	(	message	)	)	

def	assertUrlEqual	(	self	,	a	,	b	,	msg	=	None	)	:	

parsed_a	=	urllib	.	parse	.	urlparse	(	a	)	
parsed_b	=	urllib	.	parse	.	urlparse	(	b	)	
self	.	assertEqual	(	parsed_a	.	scheme	,	parsed_b	.	scheme	,	msg	)	
self	.	assertEqual	(	parsed_a	.	netloc	,	parsed_b	.	netloc	,	msg	)	
self	.	assertEqual	(	parsed_a	.	path	,	parsed_b	.	path	,	msg	)	
self	.	assertEqual	(	parsed_a	.	fragment	,	parsed_b	.	fragment	,	msg	)	
self	.	assertEqual	(	sorted	(	parsed_a	.	params	.	split	(	"str"	)	)	,	
sorted	(	parsed_b	.	params	.	split	(	"str"	)	)	,	msg	)	
self	.	assertDictEqual	(	
urllib	.	parse	.	parse_qs	(	parsed_a	.	query	,	keep_blank_values	=	True	)	,	
urllib	.	parse	.	parse_qs	(	parsed_b	.	query	,	keep_blank_values	=	True	)	,	msg	)	

def	assertSameStructure	(	self	,	a	,	b	,	aname	=	"str"	,	bname	=	"str"	,	msg	=	None	)	:	




problems	=	[	]	

_walk_structure_for_problems	(	a	,	b	,	aname	,	bname	,	problems	)	


if	self	.	maxDiff	is	not	None	:	
max_problems_to_show	=	self	.	maxDiff	/	/	80	
if	len	(	problems	)	>	max_problems_to_show	:	
problems	=	problems	[	0	:	max_problems_to_show	-	1	]	+	[	"str"	]	

if	problems	:	
self	.	fail	(	"str"	.	join	(	problems	)	,	msg	)	

def	assertJsonEqual	(	self	,	first	,	second	,	msg	=	None	)	:	

try	:	
first_structured	=	json	.	loads	(	first	)	
except	ValueError	as	e	:	
raise	ValueError	(	self	.	_formatMessage	(	
msg	,	
"str"	%	(	first	,	e	)	)	)	

try	:	
second_structured	=	json	.	loads	(	second	)	
except	ValueError	as	e	:	
raise	ValueError	(	self	.	_formatMessage	(	
msg	,	
"str"	%	(	second	,	e	)	)	)	

self	.	assertSameStructure	(	first_structured	,	second_structured	,	
aname	=	"str"	,	bname	=	"str"	,	msg	=	msg	)	

def	_getAssertEqualityFunc	(	self	,	first	,	second	)	:	

try	:	
return	super	(	TestCase	,	self	)	.	_getAssertEqualityFunc	(	first	,	second	)	
except	AttributeError	:	




test_method	=	getattr	(	self	,	"str"	,	"str"	)	
super	(	TestCase	,	self	)	.	__init__	(	test_method	)	

return	super	(	TestCase	,	self	)	.	_getAssertEqualityFunc	(	first	,	second	)	

def	fail	(	self	,	msg	=	None	,	prefix	=	None	)	:	

return	super	(	TestCase	,	self	)	.	fail	(	self	.	_formatMessage	(	prefix	,	msg	)	)	


def	_sorted_list_difference	(	expected	,	actual	)	:	


i	=	j	=	0	
missing	=	[	]	
unexpected	=	[	]	
while	True	:	
try	:	
e	=	expected	[	i	]	
a	=	actual	[	j	]	
if	e	<	a	:	
missing	.	append	(	e	)	
i	+	=	1	
while	expected	[	i	]	==	e	:	
i	+	=	1	
elif	e	>	a	:	
unexpected	.	append	(	a	)	
j	+	=	1	
while	actual	[	j	]	==	a	:	
j	+	=	1	
else	:	
i	+	=	1	
try	:	
while	expected	[	i	]	==	e	:	
i	+	=	1	
finally	:	
j	+	=	1	
while	actual	[	j	]	==	a	:	
j	+	=	1	
except	IndexError	:	
missing	.	extend	(	expected	[	i	:	]	)	
unexpected	.	extend	(	actual	[	j	:	]	)	
break	
return	missing	,	unexpected	


def	_are_both_of_integer_type	(	a	,	b	)	:	

return	isinstance	(	a	,	six	.	integer_types	)	and	isinstance	(	b	,	six	.	integer_types	)	


def	_are_both_of_sequence_type	(	a	,	b	)	:	

return	isinstance	(	a	,	abc	.	Sequence	)	and	isinstance	(	
b	,	abc	.	Sequence	)	and	not	isinstance	(	
a	,	_TEXT_OR_BINARY_TYPES	)	and	not	isinstance	(	b	,	_TEXT_OR_BINARY_TYPES	)	


def	_are_both_of_set_type	(	a	,	b	)	:	

return	isinstance	(	a	,	abc	.	Set	)	and	isinstance	(	b	,	abc	.	Set	)	


def	_are_both_of_mapping_type	(	a	,	b	)	:	

return	isinstance	(	a	,	abc	.	Mapping	)	and	isinstance	(	
b	,	abc	.	Mapping	)	


def	_walk_structure_for_problems	(	a	,	b	,	aname	,	bname	,	problem_list	)	:	

if	type	(	a	)	!=	type	(	b	)	and	not	(	
_are_both_of_integer_type	(	a	,	b	)	or	_are_both_of_sequence_type	(	a	,	b	)	or	
_are_both_of_set_type	(	a	,	b	)	or	_are_both_of_mapping_type	(	a	,	b	)	)	:	


problem_list	.	append	(	"str"	%	
(	aname	,	type	(	a	)	,	bname	,	type	(	b	)	)	)	

return	

if	isinstance	(	a	,	abc	.	Set	)	:	
for	k	in	a	:	
if	k	not	in	b	:	
problem_list	.	append	(	
"str"	%	(	aname	,	k	,	bname	)	)	
for	k	in	b	:	
if	k	not	in	a	:	
problem_list	.	append	(	"str"	%	(	aname	,	k	,	bname	)	)	



elif	isinstance	(	a	,	abc	.	Mapping	)	:	
for	k	in	a	:	
if	k	in	b	:	
_walk_structure_for_problems	(	
a	[	k	]	,	b	[	k	]	,	"str"	%	(	aname	,	k	)	,	"str"	%	(	bname	,	k	)	,	
problem_list	)	
else	:	
problem_list	.	append	(	
"str"	%	
(	aname	,	k	,	a	[	k	]	,	bname	)	)	
for	k	in	b	:	
if	k	not	in	a	:	
problem_list	.	append	(	
"str"	%	
(	aname	,	k	,	bname	,	b	[	k	]	)	)	


elif	(	isinstance	(	a	,	abc	.	Sequence	)	and	
not	isinstance	(	a	,	_TEXT_OR_BINARY_TYPES	)	)	:	
minlen	=	min	(	len	(	a	)	,	len	(	b	)	)	
for	i	in	xrange	(	minlen	)	:	
_walk_structure_for_problems	(	
a	[	i	]	,	b	[	i	]	,	"str"	%	(	aname	,	i	)	,	"str"	%	(	bname	,	i	)	,	
problem_list	)	
for	i	in	xrange	(	minlen	,	len	(	a	)	)	:	
problem_list	.	append	(	"str"	%	
(	aname	,	i	,	a	[	i	]	,	bname	)	)	
for	i	in	xrange	(	minlen	,	len	(	b	)	)	:	
problem_list	.	append	(	"str"	%	
(	aname	,	i	,	bname	,	b	[	i	]	)	)	

else	:	
if	a	!=	b	:	
problem_list	.	append	(	"str"	%	(	aname	,	a	,	bname	,	b	)	)	


def	get_command_string	(	command	)	:	

if	isinstance	(	command	,	six	.	string_types	)	:	
return	command	
else	:	
if	os	.	name	==	"str"	:	
return	"str"	.	join	(	command	)	
else	:	

command_string	=	"str"	
for	word	in	command	:	

command_string	+	=	"str"	+	word	.	replace	(	"str"	,	"str"	)	+	"str"	
return	command_string	[	:	-	1	]	


def	get_command_stderr	(	command	,	env	=	None	,	close_fds	=	True	)	:	

if	env	is	None	:	env	=	{	}	
if	os	.	name	==	"str"	:	


close_fds	=	False	

use_shell	=	isinstance	(	command	,	six	.	string_types	)	
process	=	subprocess	.	Popen	(	
command	,	
close_fds	=	close_fds	,	
env	=	env	,	
shell	=	use_shell	,	
stderr	=	subprocess	.	STDOUT	,	
stdout	=	subprocess	.	PIPE	)	
output	=	process	.	communicate	(	)	[	0	]	
exit_status	=	process	.	wait	(	)	
return	(	exit_status	,	output	)	


def	_quote_long_string	(	s	)	:	


if	isinstance	(	s	,	(	bytes	,	bytearray	)	)	:	
try	:	
s	=	s	.	decode	(	"str"	)	
except	UnicodeDecodeError	:	
s	=	str	(	s	)	
return	(	"str"	+	
s	+	"str"	+	
"str"	)	


class	_TestProgramManualRun	(	unittest	.	TestProgram	)	:	


def	runTests	(	self	,	do_run	=	False	)	:	

if	do_run	:	
unittest	.	TestProgram	.	runTests	(	self	)	


def	print_python_version	(	)	:	



sys	.	stderr	.	write	(	"str"	
"str"	.	format	(	
sys	.	version_info	,	
sys	.	executable	if	sys	.	executable	else	"str"	)	)	


def	main	(	*	args	,	*	*	kwargs	)	:	


print_python_version	(	)	
_run_in_app	(	run_tests	,	args	,	kwargs	)	


def	_is_in_app_main	(	)	:	


f	=	sys	.	_getframe	(	)	.	f_back	
while	f	:	
if	f	.	f_code	==	six	.	get_function_code	(	app	.	run	)	:	
return	True	
f	=	f	.	f_back	
return	False	


class	_SavedFlag	(	object	)	:	


def	__init__	(	self	,	flag	)	:	
self	.	flag	=	flag	
self	.	value	=	flag	.	value	
self	.	present	=	flag	.	present	

def	restore_flag	(	self	)	:	
self	.	flag	.	value	=	self	.	value	
self	.	flag	.	present	=	self	.	present	


def	_register_sigterm_with_faulthandler	(	)	:	


if	faulthandler	and	getattr	(	faulthandler	,	"str"	,	None	)	:	


try	:	
faulthandler	.	register	(	signal	.	SIGTERM	,	chain	=	True	)	
except	Exception	as	e	:	
sys	.	stderr	.	write	(	"str"	
"str"	%	e	)	


def	_run_in_app	(	function	,	args	,	kwargs	)	:	


if	_is_in_app_main	(	)	:	
_register_sigterm_with_faulthandler	(	)	



flag_objects	=	(	FLAGS	[	name	]	for	name	in	FLAGS	)	
saved_flags	=	dict	(	(	f	.	name	,	_SavedFlag	(	f	)	)	for	f	in	flag_objects	)	






FLAGS	.	set_default	(	"str"	,	True	)	

del	saved_flags	[	"str"	]	







argv	=	FLAGS	(	sys	.	argv	)	
for	saved_flag	in	six	.	itervalues	(	saved_flags	)	:	
saved_flag	.	restore_flag	(	)	

function	(	argv	,	args	,	kwargs	)	
else	:	


FLAGS	.	set_default	(	"str"	,	True	)	

def	main_function	(	argv	)	:	
_register_sigterm_with_faulthandler	(	)	
function	(	argv	,	args	,	kwargs	)	

app	.	run	(	main	=	main_function	)	


def	_is_suspicious_attribute	(	testCaseClass	,	name	)	:	


if	name	.	startswith	(	"str"	)	and	len	(	name	)	>	4	and	name	[	4	]	.	isupper	(	)	:	
attr	=	getattr	(	testCaseClass	,	name	)	
if	inspect	.	isfunction	(	attr	)	or	inspect	.	ismethod	(	attr	)	:	
args	=	inspect	.	getargspec	(	attr	)	
return	(	len	(	args	.	args	)	==	1	and	args	.	args	[	0	]	==	"str"	
and	args	.	varargs	is	None	and	args	.	keywords	is	None	)	
return	False	


class	TestLoader	(	unittest	.	TestLoader	)	:	


_ERROR_MSG	=	textwrap	.	dedent	(	"str"	)	

def	__init__	(	self	,	*	args	,	*	*	kwds	)	:	
super	(	TestLoader	,	self	)	.	__init__	(	*	args	,	*	*	kwds	)	
seed	=	_get_default_randomize_ordering_seed	(	)	
if	seed	:	
self	.	_seed	=	seed	
self	.	_random	=	random	.	Random	(	self	.	_seed	)	
else	:	
self	.	_seed	=	None	
self	.	_random	=	None	

def	getTestCaseNames	(	self	,	testCaseClass	)	:	

for	name	in	dir	(	testCaseClass	)	:	
if	_is_suspicious_attribute	(	testCaseClass	,	name	)	:	
raise	TypeError	(	TestLoader	.	_ERROR_MSG	%	name	)	
names	=	super	(	TestLoader	,	self	)	.	getTestCaseNames	(	testCaseClass	)	
if	self	.	_seed	is	not	None	:	
logging	.	info	(	"str"	,	self	.	_seed	)	
logging	.	info	(	"str"	
"str"	,	self	.	_seed	)	
self	.	_random	.	shuffle	(	names	)	
return	names	


def	get_default_xml_output_filename	(	)	:	

if	os	.	environ	.	get	(	"str"	)	:	
return	os	.	environ	[	"str"	]	
elif	os	.	environ	.	get	(	"str"	)	:	
return	os	.	path	.	join	(	os	.	path	.	dirname	(	FLAGS	.	test_tmpdir	)	,	"str"	)	
elif	os	.	environ	.	get	(	"str"	)	:	
return	os	.	path	.	join	(	
os	.	environ	[	"str"	]	,	
os	.	path	.	splitext	(	os	.	path	.	basename	(	sys	.	argv	[	0	]	)	)	[	0	]	+	"str"	)	


def	_setup_filtering	(	argv	)	:	


test_filter	=	os	.	environ	.	get	(	"str"	)	
if	argv	is	None	or	not	test_filter	:	
return	

argv	[	1	:	1	]	=	shlex	.	split	(	test_filter	)	


def	_setup_sharding	(	custom_loader	=	None	)	:	






if	"str"	in	os	.	environ	:	
try	:	
f	=	None	
try	:	
f	=	open	(	os	.	environ	[	"str"	]	,	"str"	)	
f	.	write	(	"str"	)	
except	IOError	:	
sys	.	stderr	.	write	(	"str"	
%	os	.	environ	[	"str"	]	)	
sys	.	exit	(	1	)	
finally	:	
if	f	is	not	None	:	f	.	close	(	)	

base_loader	=	custom_loader	or	TestLoader	(	)	
if	"str"	not	in	os	.	environ	:	

return	base_loader	

total_shards	=	int	(	os	.	environ	[	"str"	]	)	
shard_index	=	int	(	os	.	environ	[	"str"	]	)	

if	shard_index	<	0	or	shard_index	>	=	total_shards	:	
sys	.	stderr	.	write	(	"str"	%	
(	shard_index	,	total_shards	)	)	
sys	.	exit	(	1	)	



delegate_get_names	=	base_loader	.	getTestCaseNames	

bucket_iterator	=	itertools	.	cycle	(	xrange	(	total_shards	)	)	

def	getShardedTestCaseNames	(	testCaseClass	)	:	
filtered_names	=	[	]	
for	testcase	in	sorted	(	delegate_get_names	(	testCaseClass	)	)	:	
bucket	=	next	(	bucket_iterator	)	
if	bucket	==	shard_index	:	
filtered_names	.	append	(	testcase	)	
return	filtered_names	

base_loader	.	getTestCaseNames	=	getShardedTestCaseNames	
return	base_loader	



def	_run_and_get_tests_result	(	argv	,	args	,	kwargs	,	xml_test_runner_class	)	:	





_setup_filtering	(	argv	)	


kwargs	[	"str"	]	=	_setup_sharding	(	kwargs	.	get	(	"str"	,	None	)	)	




if	not	FLAGS	.	xml_output_file	:	
FLAGS	.	xml_output_file	=	get_default_xml_output_filename	(	)	
xml_output_file	=	FLAGS	.	xml_output_file	

xml_buffer	=	None	
if	xml_output_file	:	
xml_output_dir	=	os	.	path	.	dirname	(	xml_output_file	)	
if	xml_output_dir	and	not	os	.	path	.	isdir	(	xml_output_dir	)	:	
try	:	
os	.	makedirs	(	xml_output_dir	)	
except	OSError	as	e	:	

if	e	.	errno	!=	errno	.	EEXIST	:	
raise	


with	_open	(	xml_output_file	,	"str"	)	:	
pass	




if	(	kwargs	.	get	(	"str"	)	is	not	None	
and	not	hasattr	(	kwargs	[	"str"	]	,	"str"	)	)	:	
sys	.	stderr	.	write	(	"str"	
"str"	
%	(	kwargs	[	"str"	]	)	)	


kwargs	[	"str"	]	=	xml_test_runner_class	
if	kwargs	.	get	(	"str"	)	is	None	:	
kwargs	[	"str"	]	=	xml_test_runner_class	



xml_buffer	=	six	.	StringIO	(	)	
kwargs	[	"str"	]	.	set_default_xml_stream	(	xml_buffer	)	
elif	kwargs	.	get	(	"str"	)	is	None	:	
kwargs	[	"str"	]	=	_pretty_print_reporter	.	TextTestRunner	

if	FLAGS	.	pdb_post_mortem	:	
runner	=	kwargs	[	"str"	]	





if	(	(	isinstance	(	runner	,	type	)	and	
issubclass	(	runner	,	_pretty_print_reporter	.	TextTestRunner	)	)	or	
isinstance	(	runner	,	_pretty_print_reporter	.	TextTestRunner	)	)	:	
runner	.	run_for_debugging	=	True	


if	not	os	.	path	.	isdir	(	FLAGS	.	test_tmpdir	)	:	
try	:	
os	.	makedirs	(	FLAGS	.	test_tmpdir	)	
except	OSError	as	e	:	

if	e	.	errno	!=	errno	.	EEXIST	:	
raise	



kwargs	.	setdefault	(	"str"	,	argv	)	

try	:	
test_program	=	unittest	.	TestProgram	(	*	args	,	*	*	kwargs	)	
return	test_program	.	result	
finally	:	
if	xml_buffer	:	
try	:	
with	_open	(	xml_output_file	,	"str"	)	as	f	:	
f	.	write	(	xml_buffer	.	getvalue	(	)	)	
finally	:	
xml_buffer	.	close	(	)	


def	run_tests	(	argv	,	args	,	kwargs	)	:	



result	=	_run_and_get_tests_result	(	
argv	,	args	,	kwargs	,	xml_reporter	.	TextAndXMLTestRunner	)	
sys	.	exit	(	not	result	.	wasSuccessful	(	)	)	


def	_get_qualname	(	cls	)	:	

if	six	.	PY3	:	
name	=	cls	.	__qualname__	
else	:	
name	=	"str"	.	format	(	cls	.	__module__	,	cls	.	__name__	)	
return	name	.	replace	(	"str"	,	"str"	)	


def	_rmtree_ignore_errors	(	path	)	:	

if	os	.	path	.	isfile	(	path	)	:	
os	.	unlink	(	path	)	
else	:	
shutil	.	rmtree	(	path	,	ignore_errors	=	True	)	


def	_makedirs_exist_ok	(	dir_name	)	:	

if	six	.	PY3	:	
os	.	makedirs	(	dir_name	,	exist_ok	=	True	)	
else	:	

try	:	
os	.	makedirs	(	dir_name	)	
except	OSError	as	e	:	
if	e	.	errno	!=	errno	.	EEXIST	:	
raise	


def	_get_first_part	(	path	)	:	

parts	=	path	.	split	(	os	.	sep	,	1	)	
return	parts	[	0	]	
	