















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	sys	

from	absl	.	testing	import	absltest	


class	ClassA	(	absltest	.	TestCase	)	:	


def	testA	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testB	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testC	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	


class	ClassB	(	absltest	.	TestCase	)	:	


def	testA	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testB	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testC	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testD	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	

def	testE	(	self	)	:	
sys	.	stderr	.	write	(	"str"	)	
self	.	fail	(	"str"	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	