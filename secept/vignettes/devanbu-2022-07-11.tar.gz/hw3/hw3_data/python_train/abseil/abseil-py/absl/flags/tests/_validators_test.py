















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	warnings	


from	absl	.	flags	import	_defines	
from	absl	.	flags	import	_exceptions	
from	absl	.	flags	import	_flagvalues	
from	absl	.	flags	import	_validators	
from	absl	.	testing	import	absltest	


class	SingleFlagValidatorTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
super	(	SingleFlagValidatorTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	
self	.	call_args	=	[	]	

def	test_success	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	True	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	test_flag	)	
self	.	flag_values	.	test_flag	=	2	
self	.	assertEqual	(	2	,	self	.	flag_values	.	test_flag	)	
self	.	assertEqual	(	[	None	,	2	]	,	self	.	call_args	)	

def	test_default_value_not_used_success	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	True	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	1	,	self	.	flag_values	.	test_flag	)	
self	.	assertEqual	(	[	1	]	,	self	.	call_args	)	

def	test_validator_not_called_when_other_flag_is_changed	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	True	
_defines	.	DEFINE_integer	(	
"str"	,	1	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_integer	(	
"str"	,	2	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	1	,	self	.	flag_values	.	test_flag	)	
self	.	flag_values	.	other_flag	=	3	
self	.	assertEqual	(	[	1	]	,	self	.	call_args	)	

def	test_exception_raised_if_checker_fails	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	x	==	1	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
try	:	
self	.	flag_values	.	test_flag	=	2	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	1	,	2	]	,	self	.	call_args	)	

def	test_exception_raised_if_checker_raises_exception	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
if	x	==	1	:	
return	True	
raise	_exceptions	.	ValidationError	(	"str"	)	

_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
try	:	
self	.	flag_values	.	test_flag	=	2	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	1	,	2	]	,	self	.	call_args	)	

def	test_error_message_when_checker_returns_false_on_start	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	False	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
try	:	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	1	]	,	self	.	call_args	)	

def	test_error_message_when_checker_raises_exception_on_start	(	self	)	:	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
raise	_exceptions	.	ValidationError	(	"str"	)	

_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_validator	(	
"str"	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
try	:	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	1	]	,	self	.	call_args	)	

def	test_validators_checked_in_order	(	self	)	:	

def	required	(	x	)	:	
self	.	calls	.	append	(	"str"	)	
return	x	is	not	None	

def	even	(	x	)	:	
self	.	calls	.	append	(	"str"	)	
return	x	%	2	==	0	

self	.	calls	=	[	]	
self	.	_define_flag_and_validators	(	required	,	even	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	self	.	calls	)	

self	.	calls	=	[	]	
self	.	_define_flag_and_validators	(	even	,	required	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	self	.	calls	)	

def	_define_flag_and_validators	(	self	,	first_validator	,	second_validator	)	:	
local_flags	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_integer	(	
"str"	,	2	,	"str"	,	flag_values	=	local_flags	)	
_validators	.	register_validator	(	
"str"	,	first_validator	,	message	=	"str"	,	flag_values	=	local_flags	)	
_validators	.	register_validator	(	
"str"	,	second_validator	,	message	=	"str"	,	flag_values	=	local_flags	)	
argv	=	(	"str"	,	)	
local_flags	(	argv	)	

def	test_validator_as_decorator	(	self	)	:	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	

@_validators.validator	(	"str"	,	flag_values	=	self	.	flag_values	)	
def	checker	(	x	)	:	
self	.	call_args	.	append	(	x	)	
return	True	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	test_flag	)	
self	.	flag_values	.	test_flag	=	2	
self	.	assertEqual	(	2	,	self	.	flag_values	.	test_flag	)	
self	.	assertEqual	(	[	None	,	2	]	,	self	.	call_args	)	

self	.	assertTrue	(	checker	(	3	)	)	
self	.	assertEqual	(	[	None	,	2	,	3	]	,	self	.	call_args	)	


class	MultiFlagsValidatorTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
super	(	MultiFlagsValidatorTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	
self	.	call_args	=	[	]	
_defines	.	DEFINE_integer	(	
"str"	,	1	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_integer	(	
"str"	,	2	,	"str"	,	flag_values	=	self	.	flag_values	)	

def	test_success	(	self	)	:	
def	checker	(	flags_dict	)	:	
self	.	call_args	.	append	(	flags_dict	)	
return	True	
_validators	.	register_multi_flags_validator	(	
[	"str"	,	"str"	]	,	checker	,	flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	1	,	self	.	flag_values	.	foo	)	
self	.	assertEqual	(	2	,	self	.	flag_values	.	bar	)	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	]	,	self	.	call_args	)	
self	.	flag_values	.	foo	=	3	
self	.	assertEqual	(	3	,	self	.	flag_values	.	foo	)	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	3	,	"str"	:	2	}	]	,	
self	.	call_args	)	

def	test_validator_not_called_when_other_flag_is_changed	(	self	)	:	
def	checker	(	flags_dict	)	:	
self	.	call_args	.	append	(	flags_dict	)	
return	True	
_defines	.	DEFINE_integer	(	
"str"	,	3	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	register_multi_flags_validator	(	
[	"str"	,	"str"	]	,	checker	,	flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	flag_values	.	other_flag	=	3	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	]	,	self	.	call_args	)	

def	test_exception_raised_if_checker_fails	(	self	)	:	
def	checker	(	flags_dict	)	:	
self	.	call_args	.	append	(	flags_dict	)	
values	=	flags_dict	.	values	(	)	

return	len	(	set	(	values	)	)	==	len	(	values	)	
_validators	.	register_multi_flags_validator	(	
[	"str"	,	"str"	]	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
try	:	
self	.	flag_values	.	bar	=	1	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	1	}	]	,	
self	.	call_args	)	

def	test_exception_raised_if_checker_raises_exception	(	self	)	:	
def	checker	(	flags_dict	)	:	
self	.	call_args	.	append	(	flags_dict	)	
values	=	flags_dict	.	values	(	)	

if	len	(	set	(	values	)	)	!=	len	(	values	)	:	
raise	_exceptions	.	ValidationError	(	"str"	)	
return	True	

_validators	.	register_multi_flags_validator	(	
[	"str"	,	"str"	]	,	
checker	,	
message	=	"str"	,	
flag_values	=	self	.	flag_values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
try	:	
self	.	flag_values	.	bar	=	1	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	1	}	]	,	
self	.	call_args	)	

def	test_decorator	(	self	)	:	
@_validators.multi_flags_validator	(	
[	"str"	,	"str"	]	,	message	=	"str"	,	flag_values	=	self	.	flag_values	)	
def	checker	(	flags_dict	)	:	
self	.	call_args	.	append	(	flags_dict	)	
values	=	flags_dict	.	values	(	)	

return	len	(	set	(	values	)	)	==	len	(	values	)	

argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
try	:	
self	.	flag_values	.	bar	=	1	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	"str"	,	str	(	e	)	)	
self	.	assertEqual	(	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	1	}	]	,	
self	.	call_args	)	


class	MarkFlagsAsMutualExclusiveTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
super	(	MarkFlagsAsMutualExclusiveTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	

_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_multi_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_multi_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_boolean	(	
"str"	,	False	,	"str"	,	flag_values	=	self	.	flag_values	)	

def	_mark_flags_as_mutually_exclusive	(	self	,	flag_names	,	required	)	:	
_validators	.	mark_flags_as_mutual_exclusive	(	
flag_names	,	required	=	required	,	flag_values	=	self	.	flag_values	)	

def	test_no_flags_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	)	

self	.	flag_values	(	argv	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	flag_one	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	flag_two	)	

def	test_no_flags_present_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_one_flag_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	False	)	
self	.	flag_values	(	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	flag_one	)	

def	test_one_flag_present_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	True	)	
self	.	flag_values	(	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	flag_two	)	

def	test_one_flag_zero_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	True	)	
self	.	flag_values	(	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	0	,	self	.	flag_values	.	int_flag_one	)	

def	test_mutual_exclusion_with_extra_flags	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	"str"	,	"str"	)	

self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	flag_two	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	flag_three	)	

def	test_mutual_exclusion_with_zero	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_multiple_flags_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_multiple_flags_present_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_no_multiflags_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	multi_flag_one	)	
self	.	assertEqual	(	None	,	self	.	flag_values	.	multi_flag_two	)	

def	test_no_multistring_flags_present_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_one_multiflag_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	True	)	
self	.	flag_values	(	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	[	"str"	]	,	self	.	flag_values	.	multi_flag_one	)	

def	test_one_multiflag_present_repeated	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	True	)	
self	.	flag_values	(	(	"str"	,	"str"	,	"str"	)	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	self	.	flag_values	.	multi_flag_one	)	

def	test_multiple_multiflags_present	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_multiple_multiflags_present_required	(	self	)	:	
self	.	_mark_flags_as_mutually_exclusive	(	
[	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_flag_default_not_none_warning	(	self	)	:	
with	warnings	.	catch_warnings	(	record	=	True	)	as	caught_warnings	:	
warnings	.	simplefilter	(	"str"	)	
self	.	_mark_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	
False	)	
self	.	assertLen	(	caught_warnings	,	1	)	
self	.	assertIn	(	"str"	,	
str	(	caught_warnings	[	0	]	.	message	)	)	


class	MarkBoolFlagsAsMutualExclusiveTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
super	(	MarkBoolFlagsAsMutualExclusiveTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	

_defines	.	DEFINE_boolean	(	
"str"	,	False	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_boolean	(	
"str"	,	False	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_boolean	(	
"str"	,	True	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_integer	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	

def	_mark_bool_flags_as_mutually_exclusive	(	self	,	flag_names	,	required	)	:	
_validators	.	mark_bool_flags_as_mutual_exclusive	(	
flag_names	,	required	=	required	,	flag_values	=	self	.	flag_values	)	

def	test_no_flags_present	(	self	)	:	
self	.	_mark_bool_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	False	)	
self	.	flag_values	(	(	"str"	,	)	)	
self	.	assertEqual	(	False	,	self	.	flag_values	.	false_1	)	
self	.	assertEqual	(	False	,	self	.	flag_values	.	false_2	)	

def	test_no_flags_present_required	(	self	)	:	
self	.	_mark_bool_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	True	)	
argv	=	(	"str"	,	)	
expected	=	(	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_no_flags_present_with_default_true_required	(	self	)	:	
self	.	_mark_bool_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	True	)	
self	.	flag_values	(	(	"str"	,	)	)	
self	.	assertEqual	(	False	,	self	.	flag_values	.	false_1	)	
self	.	assertEqual	(	True	,	self	.	flag_values	.	true_1	)	

def	test_two_flags_true	(	self	)	:	
self	.	_mark_bool_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	False	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	)	

self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	IllegalFlagValueError	,	
expected	,	self	.	flag_values	,	argv	)	

def	test_non_bool_flag	(	self	)	:	
expected	=	(	"str"	
"str"	)	
with	self	.	assertRaisesWithLiteralMatch	(	_exceptions	.	ValidationError	,	
expected	)	:	
self	.	_mark_bool_flags_as_mutually_exclusive	(	[	"str"	,	"str"	]	,	
False	)	


class	MarkFlagAsRequiredTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
super	(	MarkFlagAsRequiredTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	

def	test_success	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	mark_flag_as_required	(	
"str"	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	string_flag	)	

def	test_catch_none_as_default	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	mark_flag_as_required	(	
"str"	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	)	
expected	=	(	
"str"	
"str"	)	
with	self	.	assertRaisesRegex	(	_exceptions	.	IllegalFlagValueError	,	expected	)	:	
self	.	flag_values	(	argv	)	

def	test_catch_setting_none_after_program_start	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	mark_flag_as_required	(	
"str"	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	string_flag	)	
expected	=	(	"str"	
"str"	)	
try	:	
self	.	flag_values	.	string_flag	=	None	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	expected	,	str	(	e	)	)	

def	test_flag_default_not_none_warning	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	self	.	flag_values	)	
with	warnings	.	catch_warnings	(	record	=	True	)	as	caught_warnings	:	
warnings	.	simplefilter	(	"str"	)	
_validators	.	mark_flag_as_required	(	
"str"	,	flag_values	=	self	.	flag_values	)	

self	.	assertLen	(	caught_warnings	,	1	)	
self	.	assertIn	(	"str"	,	
str	(	caught_warnings	[	0	]	.	message	)	)	


class	MarkFlagsAsRequiredTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
super	(	MarkFlagsAsRequiredTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	_flagvalues	.	FlagValues	(	)	

def	test_success	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
flag_names	=	[	"str"	,	"str"	]	
_validators	.	mark_flags_as_required	(	flag_names	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	string_flag_1	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	string_flag_2	)	

def	test_catch_none_as_default	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	flag_values	=	self	.	flag_values	)	
_validators	.	mark_flags_as_required	(	
[	"str"	,	"str"	]	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
expected	=	(	
"str"	
"str"	)	
with	self	.	assertRaisesRegex	(	_exceptions	.	IllegalFlagValueError	,	expected	)	:	
self	.	flag_values	(	argv	)	

def	test_catch_setting_none_after_program_start	(	self	)	:	
_defines	.	DEFINE_string	(	
"str"	,	
"str"	,	
"str"	,	
flag_values	=	self	.	flag_values	)	
_defines	.	DEFINE_string	(	
"str"	,	
"str"	,	
"str"	,	
flag_values	=	self	.	flag_values	)	
_validators	.	mark_flags_as_required	(	
[	"str"	,	"str"	]	,	flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	string_flag_1	)	
expected	=	(	
"str"	
"str"	)	
try	:	
self	.	flag_values	.	string_flag_1	=	None	
raise	AssertionError	(	"str"	)	
except	_exceptions	.	IllegalFlagValueError	as	e	:	
self	.	assertEqual	(	expected	,	str	(	e	)	)	

if	__name__	==	"str"	:	
absltest	.	main	(	)	
	