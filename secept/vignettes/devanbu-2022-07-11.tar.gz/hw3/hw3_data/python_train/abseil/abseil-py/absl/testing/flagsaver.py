















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	functools	
import	inspect	

from	absl	import	flags	
import	six	

FLAGS	=	flags	.	FLAGS	


def	flagsaver	(	*	args	,	*	*	kwargs	)	:	

if	not	args	:	
return	_FlagOverrider	(	*	*	kwargs	)	
elif	len	(	args	)	==	1	:	
if	kwargs	:	
raise	ValueError	(	
"str"	)	
func	=	args	[	0	]	
if	inspect	.	isclass	(	func	)	:	
raise	TypeError	(	"str"	)	
return	_wrap	(	func	,	{	}	)	
else	:	
raise	ValueError	(	
"str"	)	


def	save_flag_values	(	flag_values	=	FLAGS	)	:	

return	{	name	:	_copy_flag_dict	(	flag_values	[	name	]	)	for	name	in	flag_values	}	


def	restore_flag_values	(	saved_flag_values	,	flag_values	=	FLAGS	)	:	

new_flag_names	=	list	(	flag_values	)	
for	name	in	new_flag_names	:	
saved	=	saved_flag_values	.	get	(	name	)	
if	saved	is	None	:	

delattr	(	flag_values	,	name	)	
else	:	
if	flag_values	[	name	]	.	value	!=	saved	[	"str"	]	:	
flag_values	[	name	]	.	value	=	saved	[	"str"	]	
flag_values	[	name	]	.	__dict__	=	saved	


def	_wrap	(	func	,	overrides	)	:	

@functools.wraps	(	func	)	
def	_flagsaver_wrapper	(	*	args	,	*	*	kwargs	)	:	

with	_FlagOverrider	(	*	*	overrides	)	:	
return	func	(	*	args	,	*	*	kwargs	)	
return	_flagsaver_wrapper	


class	_FlagOverrider	(	object	)	:	


def	__init__	(	self	,	*	*	overrides	)	:	
self	.	_overrides	=	overrides	
self	.	_saved_flag_values	=	None	

def	__call__	(	self	,	func	)	:	
if	inspect	.	isclass	(	func	)	:	
raise	TypeError	(	"str"	)	
return	_wrap	(	func	,	self	.	_overrides	)	

def	__enter__	(	self	)	:	
self	.	_saved_flag_values	=	save_flag_values	(	FLAGS	)	
try	:	
for	name	,	value	in	six	.	iteritems	(	self	.	_overrides	)	:	
setattr	(	FLAGS	,	name	,	value	)	
except	:	

restore_flag_values	(	self	.	_saved_flag_values	,	FLAGS	)	
raise	

def	__exit__	(	self	,	exc_type	,	exc_value	,	traceback	)	:	
restore_flag_values	(	self	.	_saved_flag_values	,	FLAGS	)	


def	_copy_flag_dict	(	flag	)	:	

copy	=	flag	.	__dict__	.	copy	(	)	
copy	[	"str"	]	=	flag	.	value	
copy	[	"str"	]	=	list	(	flag	.	validators	)	
return	copy	
	