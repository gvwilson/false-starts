















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	import	flags	
from	absl	.	flags	import	_helpers	

FLAGS	=	flags	.	FLAGS	


def	define_flags	(	flag_values	=	FLAGS	)	:	



flags	.	DEFINE_boolean	(	"str"	,	True	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_boolean	(	"str"	,	False	,	
"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	5	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	6	,	"str"	,	
flag_values	=	flag_values	)	


def	remove_one_flag	(	flag_name	,	flag_values	=	FLAGS	)	:	

if	flag_name	in	flag_values	:	
flag_values	.	__delattr__	(	flag_name	)	


def	names_of_defined_flags	(	)	:	

return	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	


def	remove_flags	(	flag_values	=	FLAGS	)	:	

for	flag_name	in	names_of_defined_flags	(	)	:	
remove_one_flag	(	flag_name	,	flag_values	=	flag_values	)	


def	get_module_name	(	)	:	

return	_helpers	.	get_calling_module	(	)	


def	execute_code	(	code	,	global_dict	)	:	



exec	(	code	,	global_dict	)	


def	disclaim_key_flags	(	)	:	

flags	.	disclaim_key_flags	(	)	
	