















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	argparse	
import	sys	

from	absl	import	flags	


_BUILT_IN_FLAGS	=	frozenset	(	{	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
}	)	


class	ArgumentParser	(	argparse	.	ArgumentParser	)	:	


def	__init__	(	self	,	*	*	kwargs	)	:	

prefix_chars	=	kwargs	.	get	(	"str"	,	"str"	)	
if	prefix_chars	!=	"str"	:	
raise	ValueError	(	
"str"	
"str"	.	format	(	prefix_chars	)	)	


self	.	_inherited_absl_flags	=	kwargs	.	pop	(	"str"	,	flags	.	FLAGS	)	


super	(	ArgumentParser	,	self	)	.	__init__	(	*	*	kwargs	)	

if	self	.	add_help	:	


self	.	add_argument	(	

"str"	,	action	=	"str"	,	
default	=	argparse	.	SUPPRESS	,	help	=	argparse	.	SUPPRESS	)	
self	.	add_argument	(	
"str"	,	action	=	_HelpFullAction	,	
default	=	argparse	.	SUPPRESS	,	help	=	"str"	)	

if	self	.	_inherited_absl_flags	:	
self	.	add_argument	(	"str"	,	help	=	argparse	.	SUPPRESS	)	
self	.	_define_absl_flags	(	self	.	_inherited_absl_flags	)	

def	parse_known_args	(	self	,	args	=	None	,	namespace	=	None	)	:	
if	args	is	None	:	
args	=	sys	.	argv	[	1	:	]	
if	self	.	_inherited_absl_flags	:	



args	=	self	.	_inherited_absl_flags	.	read_flags_from_files	(	
args	,	force_gnu	=	True	)	

undefok_missing	=	object	(	)	
undefok	=	getattr	(	namespace	,	"str"	,	undefok_missing	)	

namespace	,	args	=	super	(	ArgumentParser	,	self	)	.	parse_known_args	(	
args	,	namespace	)	




if	undefok	is	not	undefok_missing	:	
namespace	.	undefok	=	undefok	

if	self	.	_inherited_absl_flags	:	





if	hasattr	(	namespace	,	"str"	)	:	
args	=	_strip_undefok_args	(	namespace	.	undefok	,	args	)	


del	namespace	.	undefok	
self	.	_inherited_absl_flags	.	mark_as_parsed	(	)	
try	:	
self	.	_inherited_absl_flags	.	_assert_all_validators	(	)	
except	flags	.	IllegalFlagValueError	as	e	:	
self	.	error	(	str	(	e	)	)	

return	namespace	,	args	

def	_define_absl_flags	(	self	,	absl_flags	)	:	

key_flags	=	set	(	absl_flags	.	get_key_flags_for_module	(	sys	.	argv	[	0	]	)	)	
for	name	in	absl_flags	:	
if	name	in	_BUILT_IN_FLAGS	:	

continue	
flag_instance	=	absl_flags	[	name	]	


if	name	==	flag_instance	.	name	:	


suppress	=	flag_instance	not	in	key_flags	
self	.	_define_absl_flag	(	flag_instance	,	suppress	)	

def	_define_absl_flag	(	self	,	flag_instance	,	suppress	)	:	

flag_name	=	flag_instance	.	name	
short_name	=	flag_instance	.	short_name	
argument_names	=	[	"str"	+	flag_name	]	
if	short_name	:	
argument_names	.	insert	(	0	,	"str"	+	short_name	)	
if	suppress	:	
helptext	=	argparse	.	SUPPRESS	
else	:	

helptext	=	flag_instance	.	help	.	replace	(	"str"	,	"str"	)	
if	flag_instance	.	boolean	:	

argument_names	.	append	(	"str"	+	flag_name	)	
self	.	add_argument	(	
*	argument_names	,	action	=	_BooleanFlagAction	,	help	=	helptext	,	
metavar	=	flag_instance	.	name	.	upper	(	)	,	
flag_instance	=	flag_instance	)	
else	:	
self	.	add_argument	(	
*	argument_names	,	action	=	_FlagAction	,	help	=	helptext	,	
metavar	=	flag_instance	.	name	.	upper	(	)	,	
flag_instance	=	flag_instance	)	


class	_FlagAction	(	argparse	.	Action	)	:	


def	__init__	(	self	,	option_strings	,	dest	,	help	,	metavar	,	flag_instance	)	:	

del	dest	
self	.	_flag_instance	=	flag_instance	
super	(	_FlagAction	,	self	)	.	__init__	(	
option_strings	=	option_strings	,	
dest	=	argparse	.	SUPPRESS	,	
help	=	help	,	
metavar	=	metavar	)	

def	__call__	(	self	,	parser	,	namespace	,	values	,	option_string	=	None	)	:	

self	.	_flag_instance	.	parse	(	values	)	
self	.	_flag_instance	.	using_default_value	=	False	


class	_BooleanFlagAction	(	argparse	.	Action	)	:	


def	__init__	(	self	,	option_strings	,	dest	,	help	,	metavar	,	flag_instance	)	:	

del	dest	
self	.	_flag_instance	=	flag_instance	
flag_names	=	[	self	.	_flag_instance	.	name	]	
if	self	.	_flag_instance	.	short_name	:	
flag_names	.	append	(	self	.	_flag_instance	.	short_name	)	
self	.	_flag_names	=	frozenset	(	flag_names	)	
super	(	_BooleanFlagAction	,	self	)	.	__init__	(	
option_strings	=	option_strings	,	
dest	=	argparse	.	SUPPRESS	,	
nargs	=	0	,	
help	=	help	,	
metavar	=	metavar	)	

def	__call__	(	self	,	parser	,	namespace	,	values	,	option_string	=	None	)	:	

if	not	isinstance	(	values	,	list	)	or	values	:	
raise	ValueError	(	"str"	)	
if	option_string	.	startswith	(	"str"	)	:	
option	=	option_string	[	2	:	]	
else	:	
option	=	option_string	[	1	:	]	
if	option	in	self	.	_flag_names	:	
self	.	_flag_instance	.	parse	(	"str"	)	
else	:	
if	not	option	.	startswith	(	"str"	)	or	option	[	2	:	]	not	in	self	.	_flag_names	:	
raise	ValueError	(	"str"	+	option_string	)	
self	.	_flag_instance	.	parse	(	"str"	)	
self	.	_flag_instance	.	using_default_value	=	False	


class	_HelpFullAction	(	argparse	.	Action	)	:	


def	__init__	(	self	,	option_strings	,	dest	,	default	,	help	)	:	

del	dest	,	default	
super	(	_HelpFullAction	,	self	)	.	__init__	(	
option_strings	=	option_strings	,	
dest	=	argparse	.	SUPPRESS	,	
default	=	argparse	.	SUPPRESS	,	
nargs	=	0	,	
help	=	help	)	

def	__call__	(	self	,	parser	,	namespace	,	values	,	option_string	=	None	)	:	





parser	.	print_help	(	)	

absl_flags	=	parser	.	_inherited_absl_flags	
if	absl_flags	:	
modules	=	sorted	(	absl_flags	.	flags_by_module_dict	(	)	)	
main_module	=	sys	.	argv	[	0	]	
if	main_module	in	modules	:	

modules	.	remove	(	main_module	)	
print	(	absl_flags	.	_get_help_for_modules	(	
modules	,	prefix	=	"str"	,	include_special_flags	=	True	)	)	
parser	.	exit	(	)	


def	_strip_undefok_args	(	undefok	,	args	)	:	

if	undefok	:	
undefok_names	=	set	(	name	.	strip	(	)	for	name	in	undefok	.	split	(	"str"	)	)	
undefok_names	|	=	set	(	"str"	+	name	for	name	in	undefok_names	)	

args	=	[	arg	for	arg	in	args	if	not	_is_undefok	(	arg	,	undefok_names	)	]	
return	args	


def	_is_undefok	(	arg	,	undefok_names	)	:	

if	not	arg	.	startswith	(	"str"	)	:	
return	False	
if	arg	.	startswith	(	"str"	)	:	
arg_without_dash	=	arg	[	2	:	]	
else	:	
arg_without_dash	=	arg	[	1	:	]	
if	"str"	in	arg_without_dash	:	
name	,	_	=	arg_without_dash	.	split	(	"str"	,	1	)	
else	:	
name	=	arg_without_dash	
if	name	in	undefok_names	:	
return	True	
return	False	
	