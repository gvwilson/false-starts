















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	contextlib	
import	io	
import	os	
import	shutil	
import	sys	
import	tempfile	
import	unittest	

from	absl	import	flags	
from	absl	.	_enum_module	import	enum	
from	absl	.	flags	import	_exceptions	
from	absl	.	flags	import	_helpers	
from	absl	.	flags	.	tests	import	module_bar	
from	absl	.	flags	.	tests	import	module_baz	
from	absl	.	flags	.	tests	import	module_foo	
from	absl	.	testing	import	absltest	
import	six	


FLAGS	=	flags	.	FLAGS	


@contextlib.contextmanager	
def	_use_gnu_getopt	(	flag_values	,	use_gnu_get_opt	)	:	
old_use_gnu_get_opt	=	flag_values	.	is_gnu_getopt	(	)	
flag_values	.	set_gnu_getopt	(	use_gnu_get_opt	)	
yield	
flag_values	.	set_gnu_getopt	(	old_use_gnu_get_opt	)	


class	FlagDictToArgsTest	(	absltest	.	TestCase	)	:	

def	test_flatten_google_flag_map	(	self	)	:	
arg_dict	=	{	
"str"	:	None	,	
"str"	:	False	,	
"str"	:	False	,	
"str"	:	True	,	
"str"	:	"str"	,	
"str"	:	42	,	
"str"	:	[	42	,	"str"	,	"str"	]	,	
}	
self	.	assertSameElements	(	
(	
"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	
"str"	)	,	
flags	.	flag_dict_to_args	(	arg_dict	)	)	


class	Fruit	(	enum	.	Enum	)	:	
apple	=	1	
orange	=	2	
APPLE	=	3	


class	EmptyEnum	(	enum	.	Enum	)	:	
pass	


class	FlagsUnitTest	(	absltest	.	TestCase	)	:	


maxDiff	=	None	

def	test_flags	(	self	)	:	


number_test_framework_flags	=	len	(	FLAGS	)	
repeat_help	=	"str"	
flags	.	DEFINE_integer	(	"str"	,	4	,	repeat_help	,	
lower_bound	=	0	,	short_name	=	"str"	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	1	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	1	,	"str"	)	
flags	.	DEFINE_float	(	"str"	,	3.14	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	3	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	0x7fffffff00000000	,	"str"	)	
flags	.	DEFINE_list	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_list	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_list	(	"str"	,	[	1	,	2	,	3	]	,	"str"	)	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	)	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	"str"	,	"str"	,	"str"	]	,	
"str"	,	case_sensitive	=	True	)	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	case_sensitive	=	False	)	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	case_sensitive	=	True	)	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	case_sensitive	=	False	)	
flags	.	DEFINE_string	(	"str"	,	None	,	"str"	,	
allow_overwrite	=	False	)	
flags	.	DEFINE_string	(	"str"	,	None	,	"str"	,	
allow_overwrite	=	False	)	



number_defined_flags	=	22	+	1	
self	.	assertEqual	(	len	(	FLAGS	)	,	
number_defined_flags	+	number_test_framework_flags	)	

self	.	assertEqual	(	FLAGS	.	repeat	,	4	)	
self	.	assertEqual	(	FLAGS	.	name	,	"str"	)	
self	.	assertEqual	(	FLAGS	.	debug	,	0	)	
self	.	assertEqual	(	FLAGS	.	q	,	1	)	
self	.	assertEqual	(	FLAGS	.	octal	,	0	o666	)	
self	.	assertEqual	(	FLAGS	.	decimal	,	666	)	
self	.	assertEqual	(	FLAGS	.	hexadecimal	,	0x666	)	
self	.	assertEqual	(	FLAGS	.	x	,	3	)	
self	.	assertEqual	(	FLAGS	.	l	,	0x7fffffff00000000	)	
self	.	assertEqual	(	FLAGS	.	args	,	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	FLAGS	.	letters	,	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	FLAGS	.	numbers	,	[	1	,	2	,	3	]	)	
self	.	assertIsNone	(	FLAGS	.	kwery	)	
self	.	assertIsNone	(	FLAGS	.	sense	)	
self	.	assertIsNone	(	FLAGS	.	cases	)	
self	.	assertIsNone	(	FLAGS	.	funny	)	
self	.	assertIsNone	(	FLAGS	.	blah	)	

flag_values	=	FLAGS	.	flag_values_dict	(	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	4	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	"str"	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	0	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	4	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	1	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	0	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	3	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	0x7fffffff00000000	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	flag_values	[	"str"	]	,	[	1	,	2	,	3	]	)	
self	.	assertIsNone	(	flag_values	[	"str"	]	)	
self	.	assertIsNone	(	flag_values	[	"str"	]	)	
self	.	assertIsNone	(	flag_values	[	"str"	]	)	
self	.	assertIsNone	(	flag_values	[	"str"	]	)	
self	.	assertIsNone	(	flag_values	[	"str"	]	)	


self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default_as_str	,	"str"	)	


keys	=	list	(	FLAGS	)	
keys	.	sort	(	)	
reg_flags	=	list	(	FLAGS	.	_flags	(	)	)	
reg_flags	.	sort	(	)	
self	.	assertEqual	(	keys	,	reg_flags	)	



argv	=	(	"str"	,	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	


self	.	assertEqual	(	len	(	FLAGS	)	,	
number_defined_flags	+	number_test_framework_flags	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertIn	(	"str"	,	FLAGS	)	


self	.	assertIn	(	"str"	,	FLAGS	)	
self	.	assertNotIn	(	"str"	,	FLAGS	)	


del	FLAGS	.	r	
self	.	assertEqual	(	len	(	FLAGS	)	,	
number_defined_flags	-	1	+	number_test_framework_flags	)	
self	.	assertNotIn	(	"str"	,	FLAGS	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
FLAGS	[	"str"	]	.	present	=	0	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertTrue	(	FLAGS	[	"str"	]	.	value	)	
FLAGS	.	unparse_flags	(	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	0	)	
self	.	assertFalse	(	FLAGS	[	"str"	]	.	value	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	0	)	
self	.	assertIsNone	(	FLAGS	[	"str"	]	.	value	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	value	,	"str"	)	
FLAGS	.	unparse_flags	(	)	


argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	x	,	0x12345	)	
self	.	assertEqual	(	type	(	FLAGS	.	x	)	,	int	)	

argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	x	,	0x1234567890ABCDEF1234567890ABCDEF	)	
self	.	assertIsInstance	(	FLAGS	.	x	,	six	.	integer_types	)	

argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	x	,	0	o12345	)	
self	.	assertEqual	(	type	(	FLAGS	.	x	)	,	int	)	


argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	x	,	12345	)	
self	.	assertEqual	(	type	(	FLAGS	.	x	)	,	int	)	

argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	x	,	123459	)	
self	.	assertEqual	(	type	(	FLAGS	.	x	)	,	int	)	

argv	=	(	"str"	,	"str"	,	"str"	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	FLAGS	(	argv	)	


flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test0	,	0	)	

flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test1	,	1	)	

FLAGS	.	test0	=	None	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test0	,	0	)	

FLAGS	.	test1	=	None	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test1	,	1	)	

FLAGS	.	test0	=	None	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test0	,	0	)	

FLAGS	.	test1	=	None	
argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	test1	,	1	)	


FLAGS	.	noexec	=	None	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	noexec	,	0	)	

FLAGS	.	noexec	=	None	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	noexec	,	1	)	


flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
argv	=	(	"str"	,	)	
argv	=	FLAGS	(	argv	)	
self	.	assertIsNone	(	FLAGS	.	testnone	)	


flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	None	,	"str"	)	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	"str"	)	,	1	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	"str"	)	,	0	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	"str"	)	,	"str"	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	"str"	)	,	"str"	)	


lists	=	[	[	"str"	,	"str"	,	"str"	,	"str"	]	,	
[	]	]	

flags	.	DEFINE_list	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_spaceseplist	(	"str"	,	"str"	,	"str"	)	
flags	.	DEFINE_spaceseplist	(	
"str"	,	"str"	,	
"str"	,	comma_compat	=	True	)	

for	name	,	sep	in	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	)	:	
for	lst	in	lists	:	
argv	=	(	"str"	,	"str"	%	(	name	,	sep	.	join	(	lst	)	)	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	getattr	(	FLAGS	,	name	)	,	lst	)	


flags_help	=	str	(	FLAGS	)	
self	.	assertNotEqual	(	flags_help	.	find	(	"str"	)	,	-	1	,	
"str"	)	
self	.	assertNotEqual	(	flags_help	.	find	(	repeat_help	)	,	-	1	,	
"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	2	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	0	)	


flags	.	DEFINE_multi_string	(	"str"	,	"str"	,	
"str"	,	
short_name	=	"str"	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	"str"	]	)	


multi_string_defs	=	[	"str"	,	"str"	]	
flags	.	DEFINE_multi_string	(	"str"	,	multi_string_defs	,	
"str"	,	
short_name	=	"str"	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	multi_string_defs	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	"str"	,	"str"	]	)	



argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	"str"	)	



argv	=	(	"str"	,	"str"	,	
"str"	,	"str"	)	
self	.	assertRaisesWithLiteralMatch	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
FLAGS	,	
argv	)	


argv	=	(	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	1	)	

argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	1	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	9	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	0	)	

argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	0	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	10	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	1	)	




old_testcomma_list	=	FLAGS	.	testcomma_list	
old_testspace_list	=	FLAGS	.	testspace_list	
old_testspace_or_comma_list	=	FLAGS	.	testspace_or_comma_list	

argv	=	(	"str"	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	)	

argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	serialize	(	)	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	serialize	(	)	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	serialize	(	)	,	"str"	)	

self	.	assertEqual	(	FLAGS	[	"str"	]	.	serialize	(	)	,	"str"	)	

testcomma_list1	=	[	"str"	,	"str"	]	
testspace_list1	=	[	"str"	,	"str"	,	"str"	]	
testspace_or_comma_list1	=	[	"str"	,	"str"	,	"str"	,	"str"	]	
FLAGS	.	testcomma_list	=	list	(	testcomma_list1	)	
FLAGS	.	testspace_list	=	list	(	testspace_list1	)	
FLAGS	.	testspace_or_comma_list	=	list	(	testspace_or_comma_list1	)	
argv	=	(	"str"	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	testcomma_list	,	testcomma_list1	)	
self	.	assertEqual	(	FLAGS	.	testspace_list	,	testspace_list1	)	
self	.	assertEqual	(	FLAGS	.	testspace_or_comma_list	,	testspace_or_comma_list1	)	

testcomma_list1	=	[	"str"	,	"str"	]	
testspace_list1	=	[	"str"	,	"str"	,	"str"	]	
testspace_or_comma_list1	=	[	"str"	,	"str"	,	"str"	]	
FLAGS	.	testcomma_list	=	list	(	testcomma_list1	)	
FLAGS	.	testspace_list	=	list	(	testspace_list1	)	
FLAGS	.	testspace_or_comma_list	=	list	(	testspace_or_comma_list1	)	
argv	=	(	"str"	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	,	
FLAGS	[	"str"	]	.	serialize	(	)	)	
argv	=	FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	testcomma_list	,	testcomma_list1	)	
self	.	assertEqual	(	FLAGS	.	testspace_list	,	testspace_list1	)	


self	.	assertEqual	(	FLAGS	.	testspace_or_comma_list	,	
[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	)	

FLAGS	.	testcomma_list	=	old_testcomma_list	
FLAGS	.	testspace_list	=	old_testspace_list	
FLAGS	.	testspace_or_comma_list	=	old_testspace_or_comma_list	




def	args_list	(	)	:	


flags_to_exclude	=	{	"str"	,	"str"	,	"str"	}	
flagnames	=	set	(	FLAGS	)	-	flags_to_exclude	

nonbool_flags	=	[	"str"	%	(	name	,	FLAGS	.	get_flag_value	(	name	,	None	)	)	
for	name	in	flagnames	
if	not	isinstance	(	FLAGS	[	name	]	,	flags	.	BooleanFlag	)	]	

truebool_flags	=	[	"str"	%	(	name	)	
for	name	in	flagnames	
if	isinstance	(	FLAGS	[	name	]	,	flags	.	BooleanFlag	)	and	
FLAGS	.	get_flag_value	(	name	,	None	)	]	
falsebool_flags	=	[	"str"	%	(	name	)	
for	name	in	flagnames	
if	isinstance	(	FLAGS	[	name	]	,	flags	.	BooleanFlag	)	and	
not	FLAGS	.	get_flag_value	(	name	,	None	)	]	
all_flags	=	nonbool_flags	+	truebool_flags	+	falsebool_flags	
all_flags	.	sort	(	)	
return	all_flags	

argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	

FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	3	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	"str"	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	0	)	
self	.	assertListEqual	(	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	,	args_list	(	)	)	

argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	3	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	"str"	)	
self	.	assertEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	1	)	



self	.	assertListEqual	(	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	,	args_list	(	)	)	





argv	=	(	"str"	,	"str"	)	
self	.	assertRaises	(	flags	.	IllegalFlagValueError	,	FLAGS	,	argv	)	
argv	=	(	"str"	,	"str"	)	
self	.	assertRaises	(	flags	.	IllegalFlagValueError	,	FLAGS	,	argv	)	


with	self	.	assertRaises	(	flags	.	DuplicateFlagError	)	:	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	)	


with	self	.	assertRaisesRegex	(	
flags	.	DuplicateFlagError	,	
"str"	)	:	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	)	
raise	AssertionError	(	"str"	)	


with	self	.	assertRaisesRegex	(	
flags	.	DuplicateFlagError	,	
"str"	)	:	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	



flagnames	=	[	"str"	]	
original_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_boolean	(	flagnames	[	0	]	,	False	,	"str"	,	
flag_values	=	original_flags	)	
duplicate_flags	=	module_foo	.	duplicate_flags	(	flagnames	)	
with	self	.	assertRaisesRegex	(	flags	.	DuplicateFlagError	,	
"str"	)	:	
original_flags	.	append_flag_values	(	duplicate_flags	)	


try	:	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	,	
allow_override	=	0	)	
flag	=	FLAGS	.	_flags	(	)	[	"str"	]	
self	.	assertEqual	(	flag	.	default	,	0	)	

flags	.	DEFINE_boolean	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
flag	=	FLAGS	.	_flags	(	)	[	"str"	]	
self	.	assertEqual	(	flag	.	default	,	1	)	
except	flags	.	DuplicateFlagError	:	
raise	AssertionError	(	"str"	)	


try	:	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
flag	=	FLAGS	.	_flags	(	)	[	"str"	]	
self	.	assertEqual	(	flag	.	default	,	0	)	

flags	.	DEFINE_boolean	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	0	)	
flag	=	FLAGS	.	_flags	(	)	[	"str"	]	
self	.	assertEqual	(	flag	.	default	,	1	)	
except	flags	.	DuplicateFlagError	:	
raise	AssertionError	(	"str"	)	



try	:	
sys	.	modules	.	pop	(	
"str"	)	
import	absl	.	flags	.	tests	.	module_baz	
del	absl	
except	flags	.	DuplicateFlagError	:	
raise	AssertionError	(	"str"	)	


flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
flags	.	DEFINE_boolean	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
self	.	assertEqual	(	str	(	FLAGS	)	.	find	(	"str"	)	,	-	1	)	
self	.	assertNotEqual	(	str	(	FLAGS	)	.	find	(	"str"	)	,	-	1	)	


new_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	new_flags	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	new_flags	)	
self	.	assertEqual	(	len	(	new_flags	.	_flags	(	)	)	,	2	)	
old_len	=	len	(	FLAGS	.	_flags	(	)	)	
FLAGS	.	append_flag_values	(	new_flags	)	
self	.	assertEqual	(	len	(	FLAGS	.	_flags	(	)	)	-	old_len	,	2	)	
self	.	assertEqual	(	"str"	in	FLAGS	.	_flags	(	)	,	True	)	
self	.	assertEqual	(	"str"	in	FLAGS	.	_flags	(	)	,	True	)	


FLAGS	.	remove_flag_values	(	new_flags	)	
self	.	assertEqual	(	len	(	FLAGS	.	_flags	(	)	)	,	old_len	)	
self	.	assertFalse	(	"str"	in	FLAGS	.	_flags	(	)	)	
self	.	assertFalse	(	"str"	in	FLAGS	.	_flags	(	)	)	


new_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	new_flags	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	new_flags	,	
short_name	=	"str"	)	
self	.	assertEqual	(	len	(	new_flags	.	_flags	(	)	)	,	3	)	
old_len	=	len	(	FLAGS	.	_flags	(	)	)	
FLAGS	.	append_flag_values	(	new_flags	)	
self	.	assertEqual	(	len	(	FLAGS	.	_flags	(	)	)	-	old_len	,	3	)	
self	.	assertIn	(	"str"	,	FLAGS	.	_flags	(	)	)	
self	.	assertIn	(	"str"	,	FLAGS	.	_flags	(	)	)	
self	.	assertIn	(	"str"	,	FLAGS	.	_flags	(	)	)	
self	.	assertEqual	(	FLAGS	.	_flags	(	)	[	"str"	]	,	FLAGS	.	_flags	(	)	[	"str"	]	)	


FLAGS	.	remove_flag_values	(	new_flags	)	
self	.	assertEqual	(	len	(	FLAGS	.	_flags	(	)	)	,	old_len	)	
self	.	assertFalse	(	"str"	in	FLAGS	.	_flags	(	)	)	
self	.	assertFalse	(	"str"	in	FLAGS	.	_flags	(	)	)	
self	.	assertFalse	(	"str"	in	FLAGS	.	_flags	(	)	)	


flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	
new_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	new_flags	)	
with	self	.	assertRaises	(	flags	.	DuplicateFlagError	)	:	
FLAGS	.	append_flag_values	(	new_flags	)	


with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	


with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	


with	self	.	assertRaises	(	flags	.	Error	)	:	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	


with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	

with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	


with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	


with	self	.	assertRaises	(	flags	.	UnrecognizedFlagError	)	:	
flags	.	DEFINE_alias	(	"str"	,	"str"	)	


flags	.	DEFINE_alias	(	"str"	,	"str"	)	
FLAGS	.	octal	=	0	o2222	
self	.	assertEqual	(	0	o2222	,	FLAGS	.	octal	)	
self	.	assertEqual	(	0	o2222	,	FLAGS	.	alias_octal	)	
FLAGS	.	alias_octal	=	0	o4444	
self	.	assertEqual	(	0	o4444	,	FLAGS	.	octal	)	
self	.	assertEqual	(	0	o4444	,	FLAGS	.	alias_octal	)	


flags	.	DEFINE_alias	(	"str"	,	"str"	)	
flags	.	DEFINE_alias	(	"str"	,	"str"	)	
flags	.	DEFINE_alias	(	"str"	,	"str"	)	
flags	.	DEFINE_alias	(	"str"	,	"str"	)	
flags	.	DEFINE_alias	(	"str"	,	"str"	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default	,	FLAGS	.	alias_name	)	
self	.	assertEqual	(	FLAGS	[	"str"	]	.	default	,	FLAGS	.	alias_debug	)	
self	.	assertEqual	(	
int	(	FLAGS	[	"str"	]	.	default	)	,	FLAGS	.	alias_decimal	)	
self	.	assertEqual	(	
float	(	FLAGS	[	"str"	]	.	default	)	,	FLAGS	.	alias_float	)	
self	.	assertSameElements	(	
FLAGS	[	"str"	]	.	default	,	FLAGS	.	alias_letters	)	


argv	=	(	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	)	
FLAGS	(	argv	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	name	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	alias_name	)	
self	.	assertTrue	(	FLAGS	.	debug	)	
self	.	assertTrue	(	FLAGS	.	alias_debug	)	
self	.	assertEqual	(	777	,	FLAGS	.	decimal	)	
self	.	assertEqual	(	777	,	FLAGS	.	alias_decimal	)	
self	.	assertSameElements	(	[	"str"	,	"str"	,	"str"	]	,	FLAGS	.	letters	)	
self	.	assertSameElements	(	[	"str"	,	"str"	,	"str"	]	,	FLAGS	.	alias_letters	)	


argv	=	(	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	)	
FLAGS	(	argv	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	name	)	
self	.	assertEqual	(	"str"	,	FLAGS	.	alias_name	)	
self	.	assertFalse	(	FLAGS	.	debug	)	
self	.	assertFalse	(	FLAGS	.	alias_debug	)	
self	.	assertEqual	(	888	,	FLAGS	.	decimal	)	
self	.	assertEqual	(	888	,	FLAGS	.	alias_decimal	)	
self	.	assertSameElements	(	[	"str"	,	"str"	,	"str"	]	,	FLAGS	.	letters	)	
self	.	assertSameElements	(	[	"str"	,	"str"	,	"str"	]	,	FLAGS	.	alias_letters	)	



flags	.	DEFINE_integer	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	0	)	
self	.	assertEqual	(	FLAGS	.	dup5	,	1	)	
self	.	assertEqual	(	FLAGS	.	dup5	,	1	)	
argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	
self	.	assertEqual	(	FLAGS	.	dup5	,	3	)	
flags	.	DEFINE_integer	(	"str"	,	2	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
self	.	assertEqual	(	FLAGS	.	dup5	,	3	)	


flags	.	DEFINE_integer	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	0	)	
self	.	assertEqual	(	FLAGS	.	dup6	,	1	)	
FLAGS	.	dup6	=	3	
self	.	assertEqual	(	FLAGS	.	dup6	,	3	)	
flags	.	DEFINE_integer	(	"str"	,	2	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
self	.	assertEqual	(	FLAGS	.	dup6	,	3	)	



flags	.	DEFINE_integer	(	"str"	,	1	,	"str"	,	short_name	=	"str"	,	
allow_override	=	0	)	
self	.	assertEqual	(	FLAGS	.	dup7	,	1	)	
FLAGS	.	dup7	=	1	
self	.	assertEqual	(	FLAGS	.	dup7	,	1	)	
flags	.	DEFINE_integer	(	"str"	,	2	,	"str"	,	short_name	=	"str"	,	
allow_override	=	1	)	
self	.	assertEqual	(	FLAGS	.	dup7	,	1	)	


helpstr	=	FLAGS	.	module_help	(	module_baz	)	

expected_help	=	"str"	+	module_baz	.	__name__	+	"str"	+	"str"	

self	.	assertMultiLineEqual	(	expected_help	,	helpstr	)	



helpstr	=	FLAGS	.	main_module_help	(	)	

expected_help	=	"str"	+	sys	.	argv	[	0	]	+	"str"	+	"str"	

self	.	assertMultiLineEqual	(	expected_help	,	helpstr	)	

def	test_string_flag_with_wrong_type	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_string	(	"str"	,	False	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_string	(	"str"	,	0	,	"str"	,	flag_values	=	fv	)	

def	test_integer_flag_with_wrong_type	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_integer	(	"str"	,	1e2	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_integer	(	"str"	,	[	]	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_integer	(	"str"	,	False	,	"str"	,	flag_values	=	fv	)	

def	test_float_flag_with_wrong_type	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_float	(	"str"	,	False	,	"str"	,	flag_values	=	fv	)	

def	test_enum_flag_with_empty_values	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	ValueError	)	:	
flags	.	DEFINE_enum	(	"str"	,	None	,	[	]	,	"str"	,	flag_values	=	fv	)	

def	test_define_enum_class_flag	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_enum_class	(	"str"	,	None	,	Fruit	,	"str"	,	flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertIsNone	(	fv	.	fruit	)	

def	test_parse_enum_class_flag	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_enum_class	(	"str"	,	None	,	Fruit	,	"str"	,	flag_values	=	fv	)	

argv	=	(	"str"	,	"str"	)	
argv	=	fv	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	fv	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	fv	[	"str"	]	.	value	,	Fruit	.	apple	)	
fv	.	unparse_flags	(	)	
argv	=	(	"str"	,	"str"	)	
argv	=	fv	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	fv	[	"str"	]	.	present	,	1	)	
self	.	assertEqual	(	fv	[	"str"	]	.	value	,	Fruit	.	APPLE	)	
fv	.	unparse_flags	(	)	

def	test_enum_class_flag_help_message	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_enum_class	(	"str"	,	None	,	Fruit	,	"str"	,	flag_values	=	fv	)	

helpstr	=	fv	.	main_module_help	(	)	
expected_help	=	"str"	%	sys	.	argv	[	0	]	

self	.	assertEqual	(	helpstr	,	expected_help	)	

def	test_enum_class_flag_with_wrong_default_value_type	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	_exceptions	.	IllegalFlagValueError	)	:	
flags	.	DEFINE_enum_class	(	"str"	,	1	,	Fruit	,	"str"	,	
flag_values	=	fv	)	

def	test_enum_class_flag_requires_enum_class	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	TypeError	)	:	
flags	.	DEFINE_enum_class	(	"str"	,	None	,	[	"str"	,	"str"	]	,	"str"	,	
flag_values	=	fv	)	

def	test_enum_class_flag_requires_non_empty_enum_class	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
with	self	.	assertRaises	(	ValueError	)	:	
flags	.	DEFINE_enum_class	(	"str"	,	None	,	EmptyEnum	,	"str"	,	
flag_values	=	fv	)	


class	MultiNumericalFlagsTest	(	absltest	.	TestCase	)	:	

def	test_multi_numerical_flags	(	self	)	:	


int_defaults	=	[	77	,	88	]	
flags	.	DEFINE_multi_integer	(	"str"	,	int_defaults	,	
"str"	,	
short_name	=	"str"	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	int_defaults	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	-	99	,	101	]	)	

float_defaults	=	[	2.2	,	3	]	
flags	.	DEFINE_multi_float	(	"str"	,	float_defaults	,	
"str"	,	
short_name	=	"str"	)	
for	(	expected	,	actual	)	in	zip	(	
float_defaults	,	FLAGS	.	get_flag_value	(	"str"	,	None	)	)	:	
self	.	assertAlmostEqual	(	expected	,	actual	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	
expected_floats	=	[	-	17.0	,	2.78e9	]	
for	(	expected	,	actual	)	in	zip	(	
expected_floats	,	FLAGS	.	get_flag_value	(	"str"	,	None	)	)	:	
self	.	assertAlmostEqual	(	expected	,	actual	)	

def	test_multi_numerical_with_tuples	(	self	)	:	

flags	.	DEFINE_multi_integer	(	
"str"	,	
(	77	,	88	)	,	
"str"	,	
short_name	=	"str"	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	77	,	88	]	)	

dict_with_float_keys	=	{	2.2	:	"str"	,	3	:	"str"	}	
float_defaults	=	dict_with_float_keys	.	keys	(	)	
flags	.	DEFINE_multi_float	(	
"str"	,	
float_defaults	,	
"str"	,	
short_name	=	"str"	)	
for	(	expected	,	actual	)	in	zip	(	float_defaults	,	
FLAGS	.	get_flag_value	(	"str"	,	None	)	)	:	
self	.	assertAlmostEqual	(	expected	,	actual	)	

def	test_single_value_default	(	self	)	:	

int_default	=	77	
flags	.	DEFINE_multi_integer	(	"str"	,	int_default	,	
"str"	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	int_default	]	)	

float_default	=	2.2	
flags	.	DEFINE_multi_float	(	"str"	,	float_default	,	
"str"	)	
actual	=	FLAGS	.	get_flag_value	(	"str"	,	None	)	
self	.	assertEqual	(	1	,	len	(	actual	)	)	
self	.	assertAlmostEqual	(	actual	[	0	]	,	float_default	)	

def	test_bad_multi_numerical_flags	(	self	)	:	



self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
flags	.	DEFINE_multi_integer	,	"str"	,	[	"str"	]	,	"str"	)	

self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	
"str"	
"str"	,	
flags	.	DEFINE_multi_float	,	"str"	,	[	"str"	]	,	"str"	)	


flags	.	DEFINE_multi_integer	(	"str"	,	"str"	,	
"str"	)	
argv	=	(	"str"	,	"str"	)	
self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
FLAGS	,	argv	)	

flags	.	DEFINE_multi_float	(	"str"	,	2.2	,	
"str"	)	
argv	=	(	"str"	,	"str"	)	
self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	
"str"	
"str"	,	
FLAGS	,	argv	)	


class	MultiEnumFlagsTest	(	absltest	.	TestCase	)	:	

def	test_multi_enum_flags	(	self	)	:	


enum_defaults	=	[	"str"	,	"str"	]	
flags	.	DEFINE_multi_enum	(	"str"	,	enum_defaults	,	
[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	
short_name	=	"str"	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	enum_defaults	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	
self	.	assertListEqual	(	
FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	"str"	,	"str"	]	)	

def	test_single_value_default	(	self	)	:	

enum_default	=	"str"	
flags	.	DEFINE_multi_enum	(	"str"	,	enum_default	,	
[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	enum_default	]	)	

def	test_case_sensitivity	(	self	)	:	


flags	.	DEFINE_multi_enum	(	"str"	,	[	"str"	]	,	
[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	
short_name	=	"str"	,	
case_sensitive	=	False	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
FLAGS	(	argv	)	
self	.	assertListEqual	(	FLAGS	.	get_flag_value	(	"str"	,	None	)	,	[	"str"	,	"str"	]	)	


flags	.	DEFINE_multi_enum	(	"str"	,	[	"str"	]	,	
[	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	,	
short_name	=	"str"	,	
case_sensitive	=	True	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
FLAGS	,	argv	)	

def	test_bad_multi_enum_flags	(	self	)	:	



self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
flags	.	DEFINE_multi_enum	,	"str"	,	[	"str"	]	,	
[	"str"	,	"str"	,	"str"	]	,	"str"	)	

self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
flags	.	DEFINE_multi_enum	,	"str"	,	[	1234	]	,	
[	"str"	,	"str"	,	"str"	]	,	"str"	)	


flags	.	DEFINE_multi_enum	(	"str"	,	"str"	,	
[	"str"	,	"str"	,	"str"	]	,	
"str"	)	
argv	=	(	"str"	,	"str"	)	
self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	,	
FLAGS	,	argv	)	


class	MultiEnumClassFlagsTest	(	absltest	.	TestCase	)	:	

def	test_define_results_in_registered_flag_with_none	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	None	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertIsNone	(	fv	.	fruit	)	

def	test_define_results_in_registered_flag_with_string	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	"str"	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertListEqual	(	fv	.	fruit	,	[	Fruit	.	apple	]	)	

def	test_define_results_in_registered_flag_with_enum	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	Fruit	.	APPLE	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertListEqual	(	fv	.	fruit	,	[	Fruit	.	APPLE	]	)	

def	test_define_results_in_registered_flag_with_string_list	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	[	"str"	,	"str"	]	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertListEqual	(	fv	.	fruit	,	[	Fruit	.	apple	,	Fruit	.	APPLE	]	)	

def	test_define_results_in_registered_flag_with_enum_list	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	[	Fruit	.	APPLE	,	Fruit	.	orange	]	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	

self	.	assertListEqual	(	fv	.	fruit	,	[	Fruit	.	APPLE	,	Fruit	.	orange	]	)	

def	test_from_command_line_returns_multiple	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	[	Fruit	.	APPLE	]	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
enum_defaults	,	Fruit	,	
"str"	,	
flag_values	=	fv	)	
argv	=	(	"str"	,	"str"	,	"str"	)	
fv	(	argv	)	
self	.	assertListEqual	(	fv	.	fruit	,	[	Fruit	.	apple	,	Fruit	.	orange	]	)	

def	test_bad_multi_enum_class_flags_from_definition	(	self	)	:	
with	self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	)	:	
flags	.	DEFINE_multi_enum_class	(	"str"	,	[	"str"	]	,	Fruit	,	"str"	)	

def	test_bad_multi_enum_class_flags_from_commandline	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	
enum_defaults	=	[	Fruit	.	APPLE	]	
flags	.	DEFINE_multi_enum_class	(	"str"	,	enum_defaults	,	Fruit	,	"str"	,	
flag_values	=	fv	)	
argv	=	(	"str"	,	"str"	)	
with	self	.	assertRaisesRegex	(	
flags	.	IllegalFlagValueError	,	
"str"	)	:	
fv	(	argv	)	


class	UnicodeFlagsTest	(	absltest	.	TestCase	)	:	


def	test_unicode_default_and_helpstring	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	b	"str"	.	decode	(	"str"	)	,	
b	"str"	.	decode	(	"str"	)	)	
argv	=	(	"str"	,	)	
FLAGS	(	argv	)	

argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	

def	test_unicode_in_list	(	self	)	:	
flags	.	DEFINE_list	(	"str"	,	[	"str"	,	b	"str"	.	decode	(	"str"	)	,	
b	"str"	.	decode	(	"str"	)	]	,	
b	"str"	.	decode	(	"str"	)	)	
argv	=	(	"str"	,	)	
FLAGS	(	argv	)	

argv	=	(	"str"	,	"str"	)	
FLAGS	(	argv	)	

def	test_xmloutput	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	b	"str"	.	decode	(	"str"	)	,	
b	"str"	.	decode	(	"str"	)	)	
flags	.	DEFINE_list	(	"str"	,	[	"str"	,	b	"str"	.	decode	(	"str"	)	,	
b	"str"	.	decode	(	"str"	)	]	,	
b	"str"	.	decode	(	"str"	)	)	
flags	.	DEFINE_list	(	"str"	,	[	"str"	,	"str"	,	"str"	]	,	
b	"str"	.	decode	(	"str"	)	)	

outfile	=	io	.	StringIO	(	)	if	six	.	PY3	else	io	.	BytesIO	(	)	
FLAGS	.	write_help_in_xml_format	(	outfile	)	
actual_output	=	outfile	.	getvalue	(	)	
if	six	.	PY2	:	
actual_output	=	actual_output	.	decode	(	"str"	)	


self	.	assertIn	(	b	"str"	
b	"str"	
b	"str"	
b	"str"	.	decode	(	"str"	)	,	
actual_output	)	
if	six	.	PY2	:	
self	.	assertIn	(	b	"str"	
b	"str"	
b	"str"	
b	"str"	
b	"str"	.	decode	(	"str"	)	,	
actual_output	)	
else	:	
self	.	assertIn	(	b	"str"	
b	"str"	
b	"str"	
b	"str"	
b	"str"	.	decode	(	"str"	)	,	
actual_output	)	
self	.	assertIn	(	b	"str"	
b	"str"	
b	"str"	
b	"str"	
b	"str"	.	decode	(	"str"	)	,	
actual_output	)	


class	LoadFromFlagFileTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
self	.	flag_values	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	12345	,	"str"	,	
lower_bound	=	0	,	flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_list	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
self	.	tmp_path	=	None	
self	.	flag_values	.	mark_as_parsed	(	)	

def	tearDown	(	self	)	:	
self	.	_remove_test_files	(	)	

def	_setup_test_files	(	self	)	:	



self	.	assertFalse	(	self	.	tmp_path	)	
self	.	tmp_path	=	tempfile	.	mkdtemp	(	)	

tmp_flag_file_1	=	open	(	self	.	tmp_path	+	"str"	,	"str"	)	
tmp_flag_file_2	=	open	(	self	.	tmp_path	+	"str"	,	"str"	)	
tmp_flag_file_3	=	open	(	self	.	tmp_path	+	"str"	,	"str"	)	
tmp_flag_file_4	=	open	(	self	.	tmp_path	+	"str"	,	"str"	)	


tmp_flag_file_1	.	write	(	"str"	)	
tmp_flag_file_1	.	write	(	"str"	)	
tmp_flag_file_1	.	write	(	"str"	)	
tmp_flag_file_1	.	write	(	"str"	)	
tmp_flag_file_1	.	write	(	"str"	)	
file_list	=	[	tmp_flag_file_1	.	name	]	

tmp_flag_file_2	.	write	(	"str"	)	
tmp_flag_file_2	.	write	(	"str"	%	tmp_flag_file_1	.	name	)	
tmp_flag_file_2	.	write	(	"str"	)	
tmp_flag_file_2	.	write	(	"str"	)	
tmp_flag_file_2	.	write	(	"str"	)	
file_list	.	append	(	tmp_flag_file_2	.	name	)	

tmp_flag_file_3	.	write	(	"str"	%	tmp_flag_file_3	.	name	)	
tmp_flag_file_3	.	write	(	"str"	)	
tmp_flag_file_3	.	write	(	"str"	)	
tmp_flag_file_3	.	write	(	"str"	)	
file_list	.	append	(	tmp_flag_file_3	.	name	)	

tmp_flag_file_4	.	write	(	"str"	%	tmp_flag_file_3	.	name	)	
tmp_flag_file_4	.	write	(	"str"	)	
tmp_flag_file_4	.	write	(	"str"	)	
os	.	chmod	(	self	.	tmp_path	+	"str"	,	0	)	
file_list	.	append	(	tmp_flag_file_4	.	name	)	

tmp_flag_file_1	.	close	(	)	
tmp_flag_file_2	.	close	(	)	
tmp_flag_file_3	.	close	(	)	
tmp_flag_file_4	.	close	(	)	

return	file_list	

def	_remove_test_files	(	self	)	:	

if	self	.	tmp_path	:	
shutil	.	rmtree	(	self	.	tmp_path	,	ignore_errors	=	True	)	
self	.	tmp_path	=	None	

def	_read_flags_from_files	(	self	,	argv	,	force_gnu	)	:	
return	argv	[	:	1	]	+	self	.	flag_values	.	read_flags_from_files	(	
argv	[	1	:	]	,	force_gnu	=	force_gnu	)	


def	test_method_flagfiles_1	(	self	)	:	

fake_cmd_line	=	"str"	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
self	.	flag_values	(	fake_argv	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_boolflag	,	1	)	
self	.	assertListEqual	(	
fake_argv	,	self	.	_read_flags_from_files	(	fake_argv	,	False	)	)	

def	test_method_flagfiles_2	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	"str"	%	tmp_files	[	0	]	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	




expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	
test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	


def	test_method_flagfiles_3	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	1	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	

expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	
test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	


def	test_method_flagfiles_3_spaces	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	1	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	

expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	
test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_3_spaces_boolean	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	1	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	

expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	%	tmp_files	[	1	]	]	
with	_use_gnu_getopt	(	self	.	flag_values	,	False	)	:	
test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_4	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	2	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	]	

test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_5	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	"str"	%	tmp_files	[	0	]	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	%	tmp_files	[	0	]	]	

test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_6	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	0	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	%	tmp_files	[	0	]	]	

with	_use_gnu_getopt	(	self	.	flag_values	,	False	)	:	
test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_7	(	self	)	:	

self	.	flag_values	.	set_gnu_getopt	(	)	
tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	0	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	

test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_8	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	0	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	

test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	True	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

def	test_method_flagfiles_repeated_non_circular	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	(	tmp_files	[	1	]	,	tmp_files	[	0	]	)	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
expected_results	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	

test_results	=	self	.	_read_flags_from_files	(	fake_argv	,	False	)	
self	.	assertListEqual	(	expected_results	,	test_results	)	

@unittest.skipIf	(	
os	.	name	==	"str"	,	
"str"	)	
def	test_method_flagfiles_no_permissions	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	3	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
self	.	assertRaises	(	flags	.	CantOpenFlagFileError	,	
self	.	_read_flags_from_files	,	fake_argv	,	True	)	

def	test_method_flagfiles_not_found	(	self	)	:	

tmp_files	=	self	.	_setup_test_files	(	)	

fake_cmd_line	=	(	"str"	
%	tmp_files	[	3	]	)	
fake_argv	=	fake_cmd_line	.	split	(	"str"	)	
self	.	assertRaises	(	flags	.	CantOpenFlagFileError	,	
self	.	_read_flags_from_files	,	fake_argv	,	True	)	

def	test_flagfiles_user_path_expansion	(	self	)	:	

fake_flagfile_item_style_1	=	"str"	
fake_flagfile_item_style_2	=	"str"	

expected_results	=	os	.	path	.	expanduser	(	"str"	)	

test_results	=	self	.	flag_values	.	_extract_filename	(	
fake_flagfile_item_style_1	)	
self	.	assertEqual	(	expected_results	,	test_results	)	

test_results	=	self	.	flag_values	.	_extract_filename	(	
fake_flagfile_item_style_2	)	
self	.	assertEqual	(	expected_results	,	test_results	)	

def	test_no_touchy_non_flags	(	self	)	:	

fake_argv	=	[	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	]	
with	_use_gnu_getopt	(	self	.	flag_values	,	False	)	:	
argv	=	self	.	flag_values	(	fake_argv	)	
self	.	assertListEqual	(	argv	,	fake_argv	[	:	1	]	+	fake_argv	[	2	:	]	)	

def	test_parse_flags_after_args_if_using_gnugetopt	(	self	)	:	

self	.	flag_values	.	set_gnu_getopt	(	)	
fake_argv	=	[	"str"	,	"str"	,	
"str"	,	"str"	]	
argv	=	self	.	flag_values	(	fake_argv	)	
self	.	assertListEqual	(	argv	,	[	"str"	,	"str"	]	)	

def	test_set_default	(	self	)	:	



self	.	flag_values	.	set_default	(	"str"	,	"str"	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_message1	,	"str"	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default_as_str	,	
"str"	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_message1	,	"str"	)	


self	.	flag_values	.	set_default	(	"str"	,	None	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_number	,	None	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default_as_str	,	None	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_number	,	56	)	


self	.	flag_values	.	set_default	(	"str"	,	0	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default	,	0	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_number	,	56	)	
self	.	assertEqual	(	
self	.	flag_values	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_number	,	56	)	


self	.	flag_values	.	set_default	(	"str"	,	"str"	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default	,	"str"	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_message1	,	"str"	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default_as_str	,	"str"	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_message1	,	"str"	)	


self	.	flag_values	.	set_default	(	"str"	,	False	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_boolflag	,	False	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default_as_str	,	
"str"	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	.	unittest_boolflag	,	True	)	


self	.	flag_values	.	set_default	(	"str"	,	"str"	)	
self	.	assertListEqual	(	self	.	flag_values	.	UnitTestList	,	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	flag_values	[	"str"	]	.	default_as_str	,	
"str"	)	
self	.	flag_values	(	[	"str"	,	"str"	]	)	
self	.	assertListEqual	(	self	.	flag_values	.	UnitTestList	,	[	"str"	,	"str"	,	"str"	]	)	


with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
self	.	flag_values	.	set_default	(	"str"	,	"str"	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
self	.	flag_values	.	set_default	(	"str"	,	-	1	)	


class	FlagsParsingTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
self	.	flag_values	=	flags	.	FlagValues	(	)	

def	test_two_dash_arg_first	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	
"str"	,	
"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	twodash_name	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	)	

def	test_two_dash_arg_middle	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	
"str"	,	
"str"	,	
"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	twodash2_name	)	
self	.	assertEqual	(	"str"	,	self	.	flag_values	.	twodash2_blame	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	)	

def	test_one_dash_arg_first	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	
"str"	,	
"str"	)	
with	_use_gnu_getopt	(	self	.	flag_values	,	False	)	:	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	3	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	)	
self	.	assertEqual	(	argv	[	2	]	,	"str"	)	

def	test_unrecognized_flags	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	self	.	flag_values	)	

try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	
self	.	assertEqual	(	e	.	flagvalue	,	"str"	)	


try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	
self	.	assertEqual	(	e	.	flagvalue	,	"str"	)	


try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	
self	.	assertEqual	(	e	.	flagvalue	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	


try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	

try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	



argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	
"str"	,	
"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	


try	:	
argv	=	(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	


try	:	

argv	=	(	"str"	,	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	:	
raise	AssertionError	(	"str"	)	
except	flags	.	Error	:	
pass	


argv	=	(	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	)	
argv	=	self	.	flag_values	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	


argv	=	(	"str"	,	"str"	,	"str"	)	
with	self	.	assertRaises	(	flags	.	Error	)	:	
self	.	flag_values	(	argv	)	


class	NonGlobalFlagsTest	(	absltest	.	TestCase	)	:	

def	test_nonglobal_flags	(	self	)	:	

nonglobal_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	nonglobal_flags	)	
argv	=	(	"str"	,	
"str"	,	
"str"	)	
argv	=	nonglobal_flags	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	2	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	argv	[	1	]	,	"str"	,	"str"	)	
self	.	assertEqual	(	nonglobal_flags	[	"str"	]	.	value	,	"str"	)	

def	test_unrecognized_nonglobal_flags	(	self	)	:	

nonglobal_flags	=	flags	.	FlagValues	(	)	
argv	=	(	"str"	,	
"str"	)	
try	:	
argv	=	nonglobal_flags	(	argv	)	
raise	AssertionError	(	"str"	)	
except	flags	.	UnrecognizedFlagError	as	e	:	
self	.	assertEqual	(	e	.	flagname	,	"str"	)	

argv	=	(	"str"	,	
"str"	,	
"str"	)	

argv	=	nonglobal_flags	(	argv	)	
self	.	assertEqual	(	len	(	argv	)	,	1	,	"str"	)	
self	.	assertEqual	(	argv	[	0	]	,	"str"	,	"str"	)	

def	test_create_flag_errors	(	self	)	:	




_	=	flags	.	Error	(	)	
_	=	flags	.	Error	(	"str"	)	
_	=	flags	.	DuplicateFlagError	(	)	
_	=	flags	.	DuplicateFlagError	(	"str"	)	
_	=	flags	.	IllegalFlagValueError	(	)	
_	=	flags	.	IllegalFlagValueError	(	"str"	)	

def	test_flag_values_del_attr	(	self	)	:	

default_value	=	"str"	

flag_values	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_string	(	"str"	,	default_value	,	"str"	,	
flag_values	=	flag_values	)	

flag_values	.	mark_as_parsed	(	)	
self	.	assertEqual	(	flag_values	.	delattr_foo	,	default_value	)	
flag_obj	=	flag_values	[	"str"	]	

self	.	assertTrue	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	
del	flag_values	.	delattr_foo	
self	.	assertFalse	(	"str"	in	flag_values	.	_flags	(	)	)	
self	.	assertFalse	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	


flags	.	DEFINE_integer	(	"str"	,	3	,	"str"	,	
flag_values	=	flag_values	)	
del	flag_values	.	delattr_foo	

self	.	assertFalse	(	"str"	in	flag_values	)	


flags	.	DEFINE_string	(	"str"	,	default_value	,	"str"	,	
short_name	=	"str"	,	flag_values	=	flag_values	)	
flag_obj	=	flag_values	[	"str"	]	
self	.	assertTrue	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	
del	flag_values	.	x5	
self	.	assertTrue	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	
del	flag_values	.	delattr_bar	
self	.	assertFalse	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	


flags	.	DEFINE_string	(	"str"	,	default_value	,	"str"	,	
short_name	=	"str"	,	flag_values	=	flag_values	)	
flag_obj	=	flag_values	[	"str"	]	
self	.	assertTrue	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	
del	flag_values	.	delattr_bar	
self	.	assertTrue	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	
del	flag_values	.	x5	
self	.	assertFalse	(	flag_values	.	_flag_is_registered	(	flag_obj	)	)	

self	.	assertFalse	(	"str"	in	flag_values	)	
self	.	assertFalse	(	"str"	in	flag_values	)	

def	test_list_flag_format	(	self	)	:	

flags	.	DEFINE_list	(	"str"	,	"str"	,	"str"	)	

def	_check_parsing	(	listval	)	:	

argv	=	FLAGS	(	[	"str"	,	"str"	+	listval	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	argv	)	
return	FLAGS	.	listflag	


self	.	assertEqual	(	_check_parsing	(	"str"	)	,	[	"str"	,	"str"	]	)	

self	.	assertEqual	(	_check_parsing	(	"str"	)	,	[	"str"	,	"str"	]	)	

self	.	assertRaises	(	
flags	.	IllegalFlagValueError	,	_check_parsing	,	"str"	)	

self	.	assertRaises	(	
flags	.	IllegalFlagValueError	,	_check_parsing	,	"str"	)	

def	test_flag_definition_via_setitem	(	self	)	:	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
flag_values	=	flags	.	FlagValues	(	)	
flag_values	[	"str"	]	=	"str"	


class	KeyFlagsTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	flag_values	=	flags	.	FlagValues	(	)	

def	_get_names_of_defined_flags	(	self	,	module	,	flag_values	)	:	

return	[	f	.	name	for	f	in	flag_values	.	_get_flags_defined_by_module	(	module	)	]	

def	_get_names_of_key_flags	(	self	,	module	,	flag_values	)	:	

return	[	f	.	name	for	f	in	flag_values	.	get_key_flags_for_module	(	module	)	]	

def	_assert_lists_have_same_elements	(	self	,	list_1	,	list_2	)	:	


list_1	=	list	(	list_1	)	
list_1	.	sort	(	)	
list_2	=	list	(	list_2	)	
list_2	.	sort	(	)	
self	.	assertListEqual	(	list_1	,	list_2	)	

def	test_key_flags	(	self	)	:	
flag_values	=	flags	.	FlagValues	(	)	


self	.	assertListEqual	(	self	.	_get_names_of_key_flags	(	module_foo	,	flag_values	)	,	
[	]	)	
self	.	assertListEqual	(	self	.	_get_names_of_key_flags	(	module_bar	,	flag_values	)	,	
[	]	)	
self	.	assertListEqual	(	self	.	_get_names_of_defined_flags	(	module_foo	,	
flag_values	)	,	
[	]	)	
self	.	assertListEqual	(	self	.	_get_names_of_defined_flags	(	module_bar	,	
flag_values	)	,	
[	]	)	


module_foo	.	define_flags	(	flag_values	=	flag_values	)	

try	:	


for	module	in	[	module_foo	,	module_bar	]	:	
self	.	_assert_lists_have_same_elements	(	
flag_values	.	_get_flags_defined_by_module	(	module	)	,	
flag_values	.	get_key_flags_for_module	(	module	)	)	

self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_defined_flags	(	module	,	flag_values	)	,	
module	.	names_of_defined_flags	(	)	)	




module_foo	.	declare_key_flags	(	flag_values	=	flag_values	)	


self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_defined_flags	(	module_foo	,	flag_values	)	,	
module_foo	.	names_of_defined_flags	(	)	)	


self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	module_foo	,	flag_values	)	,	
module_foo	.	names_of_declared_key_flags	(	)	)	





module_foo	.	declare_extra_key_flags	(	flag_values	=	flag_values	)	


self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	module_foo	,	flag_values	)	,	
module_foo	.	names_of_declared_key_flags	(	)	+	
module_foo	.	names_of_declared_extra_key_flags	(	)	)	
finally	:	
module_foo	.	remove_flags	(	flag_values	=	flag_values	)	

def	test_key_flags_with_non_default_flag_values_object	(	self	)	:	









fv	=	flags	.	FlagValues	(	)	



self	.	assertListEqual	(	
self	.	_get_names_of_key_flags	(	module_bar	,	fv	)	,	
[	]	)	
self	.	assertListEqual	(	
self	.	_get_names_of_defined_flags	(	module_bar	,	fv	)	,	
[	]	)	

module_bar	.	define_flags	(	flag_values	=	fv	)	



self	.	_assert_lists_have_same_elements	(	
fv	.	_get_flags_defined_by_module	(	module_bar	)	,	
fv	.	get_key_flags_for_module	(	module_bar	)	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_defined_flags	(	module_bar	,	fv	)	,	
module_bar	.	names_of_defined_flags	(	)	)	






main_module	=	sys	.	argv	[	0	]	
names_of_flags_defined_by_bar	=	module_bar	.	names_of_defined_flags	(	)	
flag_name_0	=	names_of_flags_defined_by_bar	[	0	]	
flag_name_2	=	names_of_flags_defined_by_bar	[	2	]	

flags	.	declare_key_flag	(	flag_name_0	,	flag_values	=	fv	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	main_module	,	fv	)	,	
[	flag_name_0	]	)	

flags	.	declare_key_flag	(	flag_name_2	,	flag_values	=	fv	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	main_module	,	fv	)	,	
[	flag_name_0	,	flag_name_2	]	)	


flags	.	declare_key_flag	(	"str"	,	flag_values	=	fv	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	main_module	,	fv	)	,	
[	flag_name_0	,	flag_name_2	,	"str"	]	)	

flags	.	adopt_module_key_flags	(	module_bar	,	fv	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	main_module	,	fv	)	,	
names_of_flags_defined_by_bar	+	[	"str"	]	)	


flags	.	adopt_module_key_flags	(	flags	,	flag_values	=	fv	)	
self	.	_assert_lists_have_same_elements	(	
self	.	_get_names_of_key_flags	(	main_module	,	fv	)	,	
names_of_flags_defined_by_bar	+	[	"str"	,	"str"	]	)	

def	test_main_module_help_with_key_flags	(	self	)	:	





expected_help	=	"str"	
self	.	assertMultiLineEqual	(	expected_help	,	
self	.	flag_values	.	main_module_help	(	)	)	




flags	.	DEFINE_integer	(	"str"	,	1	,	
"str"	,	
flag_values	=	self	.	flag_values	)	

try	:	
main_module_int_fg_help	=	(	
"str"	
"str"	
"str"	)	

expected_help	+	=	"str"	%	(	sys	.	argv	[	0	]	,	main_module_int_fg_help	)	
self	.	assertMultiLineEqual	(	expected_help	,	
self	.	flag_values	.	main_module_help	(	)	)	



flags	.	declare_key_flag	(	"str"	,	flag_values	=	self	.	flag_values	)	
self	.	assertMultiLineEqual	(	expected_help	,	
self	.	flag_values	.	main_module_help	(	)	)	



module_foo	.	define_flags	(	flag_values	=	self	.	flag_values	)	
self	.	assertMultiLineEqual	(	expected_help	,	
self	.	flag_values	.	main_module_help	(	)	)	

flags	.	declare_key_flag	(	"str"	,	flag_values	=	self	.	flag_values	)	
tmod_foo_bool_help	=	(	
"str"	
"str"	)	
expected_help	+	=	"str"	+	tmod_foo_bool_help	
self	.	assertMultiLineEqual	(	expected_help	,	
self	.	flag_values	.	main_module_help	(	)	)	

flags	.	declare_key_flag	(	"str"	,	flag_values	=	self	.	flag_values	)	
tmod_bar_z_help	=	(	
"str"	
"str"	)	



expected_help	=	(	"str"	%	
(	sys	.	argv	[	0	]	,	
main_module_int_fg_help	,	
tmod_bar_z_help	,	
tmod_foo_bool_help	)	)	
self	.	assertMultiLineEqual	(	self	.	flag_values	.	main_module_help	(	)	,	
expected_help	)	

finally	:	

self	.	flag_values	.	__delattr__	(	"str"	)	
module_foo	.	remove_flags	(	flag_values	=	self	.	flag_values	)	

def	test_adoptmodule_key_flags	(	self	)	:	


self	.	assertRaises	(	flags	.	Error	,	
flags	.	adopt_module_key_flags	,	
"str"	)	

def	test_disclaimkey_flags	(	self	)	:	
original_disclaim_module_ids	=	_helpers	.	disclaim_module_ids	
_helpers	.	disclaim_module_ids	=	set	(	_helpers	.	disclaim_module_ids	)	
try	:	
module_bar	.	disclaim_key_flags	(	)	
module_foo	.	define_bar_flags	(	flag_values	=	self	.	flag_values	)	
module_name	=	self	.	flag_values	.	find_module_defining_flag	(	"str"	)	
self	.	assertEqual	(	module_foo	.	__name__	,	module_name	)	
finally	:	
_helpers	.	disclaim_module_ids	=	original_disclaim_module_ids	


class	FindModuleTest	(	absltest	.	TestCase	)	:	


def	test_find_module_defining_flag	(	self	)	:	
self	.	assertEqual	(	"str"	,	FLAGS	.	find_module_defining_flag	(	
"str"	,	"str"	)	)	
self	.	assertEqual	(	
module_baz	.	__name__	,	FLAGS	.	find_module_defining_flag	(	"str"	)	)	

def	test_find_module_id_defining_flag	(	self	)	:	
self	.	assertEqual	(	"str"	,	FLAGS	.	find_module_id_defining_flag	(	
"str"	,	"str"	)	)	
self	.	assertEqual	(	
id	(	module_baz	)	,	FLAGS	.	find_module_id_defining_flag	(	"str"	)	)	

def	test_find_module_defining_flag_passing_module_name	(	self	)	:	
my_flags	=	flags	.	FlagValues	(	)	
module_name	=	sys	.	__name__	
flags	.	DEFINE_boolean	(	"str"	,	True	,	
"str"	,	
flag_values	=	my_flags	,	
module_name	=	module_name	)	
self	.	assertEqual	(	module_name	,	
my_flags	.	find_module_defining_flag	(	"str"	)	)	

def	test_find_module_id_defining_flag_passing_module_name	(	self	)	:	
my_flags	=	flags	.	FlagValues	(	)	
module_name	=	sys	.	__name__	
flags	.	DEFINE_boolean	(	"str"	,	True	,	
"str"	,	
flag_values	=	my_flags	,	
module_name	=	module_name	)	
self	.	assertEqual	(	id	(	sys	)	,	
my_flags	.	find_module_id_defining_flag	(	"str"	)	)	


class	FlagsErrorMessagesTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
self	.	flag_values	=	flags	.	FlagValues	(	)	

def	test_integer_error_text	(	self	)	:	

flags	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	lower_bound	=	1	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	lower_bound	=	0	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	-	4	,	"str"	,	upper_bound	=	-	1	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	-	4	,	"str"	,	upper_bound	=	0	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	19	,	"str"	,	lower_bound	=	4	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	-	19	,	"str"	,	upper_bound	=	4	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	lower_bound	=	0	,	
upper_bound	=	10000	,	flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	0	,	"str"	,	lower_bound	=	-	1	,	
upper_bound	=	1	,	flag_values	=	self	.	flag_values	)	

self	.	_check_error_message	(	"str"	,	-	4	,	"str"	)	
self	.	_check_error_message	(	"str"	,	-	4	,	"str"	)	
self	.	_check_error_message	(	"str"	,	0	,	"str"	)	
self	.	_check_error_message	(	"str"	,	4	,	"str"	)	
self	.	_check_error_message	(	"str"	,	-	4	,	"str"	)	
self	.	_check_error_message	(	"str"	,	4	,	
"str"	)	
self	.	_check_error_message	(	"str"	,	-	5	,	"str"	)	
self	.	_check_error_message	(	"str"	,	5	,	"str"	)	

def	test_float_error_text	(	self	)	:	
flags	.	DEFINE_float	(	"str"	,	4	,	"str"	,	lower_bound	=	1	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	4	,	"str"	,	lower_bound	=	0	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	-	4	,	"str"	,	upper_bound	=	-	1	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	-	4	,	"str"	,	upper_bound	=	0	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	19	,	"str"	,	lower_bound	=	4	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	-	19	,	"str"	,	upper_bound	=	4	,	
flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	4	,	"str"	,	lower_bound	=	0	,	
upper_bound	=	10000	,	flag_values	=	self	.	flag_values	)	
flags	.	DEFINE_float	(	"str"	,	0	,	"str"	,	lower_bound	=	-	1	,	
upper_bound	=	1	,	flag_values	=	self	.	flag_values	)	

self	.	_check_error_message	(	"str"	,	0.5	,	"str"	)	
self	.	_check_error_message	(	"str"	,	-	4.0	,	"str"	)	
self	.	_check_error_message	(	"str"	,	0.5	,	"str"	)	
self	.	_check_error_message	(	"str"	,	4.0	,	"str"	)	
self	.	_check_error_message	(	"str"	,	-	4.0	,	"str"	)	
self	.	_check_error_message	(	"str"	,	4.0	,	
"str"	)	
self	.	_check_error_message	(	"str"	,	5.0	,	"str"	)	

def	_check_error_message	(	self	,	flag_name	,	flag_value	,	
expected_message_suffix	)	:	


try	:	
self	.	flag_values	.	__setattr__	(	flag_name	,	flag_value	)	
raise	AssertionError	(	"str"	)	
except	flags	.	IllegalFlagValueError	as	e	:	
expected	=	(	"str"	%	
{	"str"	:	flag_name	,	"str"	:	flag_value	,	
"str"	:	expected_message_suffix	}	)	
self	.	assertEqual	(	str	(	e	)	,	expected	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	