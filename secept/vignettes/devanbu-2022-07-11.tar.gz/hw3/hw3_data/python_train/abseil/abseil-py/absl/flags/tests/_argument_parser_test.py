














from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	.	_enum_module	import	enum	
from	absl	.	flags	import	_argument_parser	
from	absl	.	testing	import	absltest	
import	six	


class	ArgumentParserTest	(	absltest	.	TestCase	)	:	

def	test_instance_cache	(	self	)	:	
parser1	=	_argument_parser	.	FloatParser	(	)	
parser2	=	_argument_parser	.	FloatParser	(	)	
self	.	assertIs	(	parser1	,	parser2	)	

def	test_parse_wrong_type	(	self	)	:	
parser	=	_argument_parser	.	ArgumentParser	(	)	
with	self	.	assertRaises	(	TypeError	)	:	
parser	.	parse	(	0	)	

if	bytes	is	not	str	:	

with	self	.	assertRaises	(	TypeError	)	:	
parser	.	parse	(	b	"str"	)	


class	BooleanParserTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	parser	=	_argument_parser	.	BooleanParser	(	)	

def	test_parse_bytes	(	self	)	:	
if	six	.	PY2	:	
self	.	assertTrue	(	self	.	parser	.	parse	(	b	"str"	)	)	
else	:	
with	self	.	assertRaises	(	TypeError	)	:	
self	.	parser	.	parse	(	b	"str"	)	

def	test_parse_str	(	self	)	:	
self	.	assertTrue	(	self	.	parser	.	parse	(	"str"	)	)	

def	test_parse_unicode	(	self	)	:	
self	.	assertTrue	(	self	.	parser	.	parse	(	"str"	)	)	

def	test_parse_wrong_type	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
self	.	parser	.	parse	(	1.234	)	

def	test_parse_str_false	(	self	)	:	
self	.	assertFalse	(	self	.	parser	.	parse	(	"str"	)	)	

def	test_parse_integer	(	self	)	:	
self	.	assertTrue	(	self	.	parser	.	parse	(	1	)	)	

def	test_parse_invalid_integer	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
self	.	parser	.	parse	(	-	1	)	

def	test_parse_invalid_str	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
self	.	parser	.	parse	(	"str"	)	


class	FloatParserTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	parser	=	_argument_parser	.	FloatParser	(	)	

def	test_parse_string	(	self	)	:	
self	.	assertEqual	(	1.5	,	self	.	parser	.	parse	(	"str"	)	)	

def	test_parse_wrong_type	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
self	.	parser	.	parse	(	False	)	


class	IntegerParserTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	parser	=	_argument_parser	.	IntegerParser	(	)	

def	test_parse_string	(	self	)	:	
self	.	assertEqual	(	1	,	self	.	parser	.	parse	(	"str"	)	)	

def	test_parse_wrong_type	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
self	.	parser	.	parse	(	1e2	)	
with	self	.	assertRaises	(	TypeError	)	:	
self	.	parser	.	parse	(	False	)	


class	EnumParserTest	(	absltest	.	TestCase	)	:	

def	test_empty_values	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
_argument_parser	.	EnumParser	(	[	]	)	

def	test_parse	(	self	)	:	
parser	=	_argument_parser	.	EnumParser	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	parser	.	parse	(	"str"	)	)	

def	test_parse_not_found	(	self	)	:	
parser	=	_argument_parser	.	EnumParser	(	[	"str"	,	"str"	]	)	
with	self	.	assertRaises	(	ValueError	)	:	
parser	.	parse	(	"str"	)	


class	Fruit	(	enum	.	Enum	)	:	
APPLE	=	1	
BANANA	=	2	


class	EmptyEnum	(	enum	.	Enum	)	:	
pass	


class	EnumClassParserTest	(	absltest	.	TestCase	)	:	

def	test_requires_enum	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
_argument_parser	.	EnumClassParser	(	[	"str"	,	"str"	]	)	

def	test_requires_non_empty_enum_class	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
_argument_parser	.	EnumClassParser	(	EmptyEnum	)	

def	test_parse_string	(	self	)	:	
parser	=	_argument_parser	.	EnumClassParser	(	Fruit	)	
self	.	assertEqual	(	Fruit	.	APPLE	,	parser	.	parse	(	"str"	)	)	

def	test_parse_literal	(	self	)	:	
parser	=	_argument_parser	.	EnumClassParser	(	Fruit	)	
self	.	assertEqual	(	Fruit	.	APPLE	,	parser	.	parse	(	Fruit	.	APPLE	)	)	

def	test_parse_not_found	(	self	)	:	
parser	=	_argument_parser	.	EnumClassParser	(	Fruit	)	
with	self	.	assertRaises	(	ValueError	)	:	
parser	.	parse	(	"str"	)	

def	test_serialize_parse	(	self	)	:	
serializer	=	_argument_parser	.	EnumClassSerializer	(	)	
val1	=	Fruit	.	BANANA	
parser	=	_argument_parser	.	EnumClassParser	(	Fruit	)	
serialized	=	serializer	.	serialize	(	val1	)	
self	.	assertEqual	(	serialized	,	"str"	)	
val2	=	parser	.	parse	(	serialized	)	
self	.	assertEqual	(	val1	,	val2	)	


class	HelperFunctionsTest	(	absltest	.	TestCase	)	:	

def	test_is_integer_type	(	self	)	:	
self	.	assertTrue	(	_argument_parser	.	_is_integer_type	(	1	)	)	

self	.	assertFalse	(	_argument_parser	.	_is_integer_type	(	False	)	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	