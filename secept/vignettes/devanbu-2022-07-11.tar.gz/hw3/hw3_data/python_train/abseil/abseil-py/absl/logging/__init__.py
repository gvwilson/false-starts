















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	getpass	
import	io	
import	itertools	
import	logging	
import	os	
import	socket	
import	struct	
import	sys	
import	time	
import	timeit	
import	traceback	
import	warnings	

from	absl	import	flags	
from	absl	.	logging	import	converter	
import	six	

if	six	.	PY2	:	
import	thread	as	_thread_lib	
else	:	
import	threading	as	_thread_lib	


FLAGS	=	flags	.	FLAGS	



FATAL	=	converter	.	ABSL_FATAL	
ERROR	=	converter	.	ABSL_ERROR	
WARNING	=	converter	.	ABSL_WARNING	
WARN	=	converter	.	ABSL_WARNING	
INFO	=	converter	.	ABSL_INFO	
DEBUG	=	converter	.	ABSL_DEBUG	


ABSL_LOGGING_PREFIX_REGEX	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	



_THREAD_ID_MASK	=	2	*	*	(	struct	.	calcsize	(	"str"	)	*	8	)	-	1	



_ABSL_LOG_FATAL	=	"str"	


_CRITICAL_PREFIX	=	"str"	


_LOGGING_FILE_PREFIX	=	os	.	path	.	join	(	"str"	,	"str"	)	


_absl_logger	=	None	

_absl_handler	=	None	


_CPP_NAME_TO_LEVELS	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	
}	

_CPP_LEVEL_TO_NAMES	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	


class	_VerbosityFlag	(	flags	.	Flag	)	:	


def	__init__	(	self	,	*	args	,	*	*	kwargs	)	:	
super	(	_VerbosityFlag	,	self	)	.	__init__	(	
flags	.	IntegerParser	(	)	,	
flags	.	ArgumentSerializer	(	)	,	
*	args	,	*	*	kwargs	)	

@property	
def	value	(	self	)	:	
return	self	.	_value	

@value.setter	
def	value	(	self	,	v	)	:	
self	.	_value	=	v	
self	.	_update_logging_levels	(	)	

def	_update_logging_levels	(	self	)	:	

if	not	_absl_logger	:	
return	

if	self	.	_value	<	=	converter	.	ABSL_DEBUG	:	
standard_verbosity	=	converter	.	absl_to_standard	(	self	.	_value	)	
else	:	

standard_verbosity	=	logging	.	DEBUG	-	(	self	.	_value	-	1	)	


if	_absl_handler	in	logging	.	root	.	handlers	:	


_absl_logger	.	setLevel	(	logging	.	NOTSET	)	
logging	.	root	.	setLevel	(	standard_verbosity	)	
else	:	
_absl_logger	.	setLevel	(	standard_verbosity	)	


class	_StderrthresholdFlag	(	flags	.	Flag	)	:	


def	__init__	(	self	,	*	args	,	*	*	kwargs	)	:	
super	(	_StderrthresholdFlag	,	self	)	.	__init__	(	
flags	.	ArgumentParser	(	)	,	
flags	.	ArgumentSerializer	(	)	,	
*	args	,	*	*	kwargs	)	

@property	
def	value	(	self	)	:	
return	self	.	_value	

@value.setter	
def	value	(	self	,	v	)	:	
if	v	in	_CPP_LEVEL_TO_NAMES	:	


cpp_value	=	int	(	v	)	
v	=	_CPP_LEVEL_TO_NAMES	[	v	]	
elif	v	.	lower	(	)	in	_CPP_NAME_TO_LEVELS	:	
v	=	v	.	lower	(	)	
if	v	==	"str"	:	
v	=	"str"	
cpp_value	=	int	(	_CPP_NAME_TO_LEVELS	[	v	]	)	
else	:	
raise	ValueError	(	
"str"	
"str"	
"str"	%	v	)	

self	.	_value	=	v	


flags	.	DEFINE_boolean	(	"str"	,	
False	,	
"str"	,	allow_override_cpp	=	True	)	
flags	.	DEFINE_boolean	(	"str"	,	
False	,	
"str"	,	allow_override_cpp	=	True	)	
flags	.	DEFINE_string	(	"str"	,	
os	.	getenv	(	"str"	,	"str"	)	,	
"str"	,	
allow_override_cpp	=	True	)	
flags	.	DEFINE_flag	(	_VerbosityFlag	(	
"str"	,	-	1	,	
"str"	
"str"	
"str"	
"str"	,	
short_name	=	"str"	,	allow_hide_cpp	=	True	)	)	
flags	.	DEFINE_flag	(	_StderrthresholdFlag	(	
"str"	,	"str"	,	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	,	allow_hide_cpp	=	True	)	)	
flags	.	DEFINE_boolean	(	"str"	,	True	,	
"str"	
"str"	
"str"	
"str"	)	


def	get_verbosity	(	)	:	

return	FLAGS	[	"str"	]	.	value	


def	set_verbosity	(	v	)	:	

try	:	
new_level	=	int	(	v	)	
except	ValueError	:	
new_level	=	converter	.	ABSL_NAMES	[	v	.	upper	(	)	]	
FLAGS	.	verbosity	=	new_level	


def	set_stderrthreshold	(	s	)	:	

if	s	in	converter	.	ABSL_LEVELS	:	
FLAGS	.	stderrthreshold	=	converter	.	ABSL_LEVELS	[	s	]	
elif	isinstance	(	s	,	str	)	and	s	.	upper	(	)	in	converter	.	ABSL_NAMES	:	
FLAGS	.	stderrthreshold	=	s	
else	:	
raise	ValueError	(	
"str"	
"str"	
"str"	
"str"	.	format	(	s	,	type	(	s	)	)	)	


def	fatal	(	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	FATAL	,	msg	,	*	args	,	*	*	kwargs	)	


def	error	(	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	ERROR	,	msg	,	*	args	,	*	*	kwargs	)	


def	warning	(	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	WARNING	,	msg	,	*	args	,	*	*	kwargs	)	


if	six	.	PY2	:	
warn	=	warning	
else	:	

def	warn	(	msg	,	*	args	,	*	*	kwargs	)	:	

warnings	.	warn	(	"str"	,	
DeprecationWarning	,	2	)	
log	(	WARNING	,	msg	,	*	args	,	*	*	kwargs	)	


def	info	(	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	INFO	,	msg	,	*	args	,	*	*	kwargs	)	


def	debug	(	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	DEBUG	,	msg	,	*	args	,	*	*	kwargs	)	


def	exception	(	msg	,	*	args	)	:	

error	(	msg	,	*	args	,	exc_info	=	True	)	



_log_counter_per_token	=	{	}	


def	_get_next_log_count_per_token	(	token	)	:	



return	next	(	_log_counter_per_token	.	setdefault	(	token	,	itertools	.	count	(	)	)	)	


def	log_every_n	(	level	,	msg	,	n	,	*	args	)	:	

count	=	_get_next_log_count_per_token	(	get_absl_logger	(	)	.	findCaller	(	)	)	
log_if	(	level	,	msg	,	not	(	count	%	n	)	,	*	args	)	





_log_timer_per_token	=	{	}	


def	_seconds_have_elapsed	(	token	,	num_seconds	)	:	

now	=	timeit	.	default_timer	(	)	
then	=	_log_timer_per_token	.	get	(	token	,	None	)	
if	then	is	None	or	(	now	-	then	)	>	=	num_seconds	:	
_log_timer_per_token	[	token	]	=	now	
return	True	
else	:	
return	False	


def	log_every_n_seconds	(	level	,	msg	,	n_seconds	,	*	args	)	:	

should_log	=	_seconds_have_elapsed	(	get_absl_logger	(	)	.	findCaller	(	)	,	n_seconds	)	
log_if	(	level	,	msg	,	should_log	,	*	args	)	


def	log_first_n	(	level	,	msg	,	n	,	*	args	)	:	

count	=	_get_next_log_count_per_token	(	get_absl_logger	(	)	.	findCaller	(	)	)	
log_if	(	level	,	msg	,	count	<	n	,	*	args	)	


def	log_if	(	level	,	msg	,	condition	,	*	args	)	:	

if	condition	:	
log	(	level	,	msg	,	*	args	)	


def	log	(	level	,	msg	,	*	args	,	*	*	kwargs	)	:	

if	level	>	converter	.	ABSL_DEBUG	:	



standard_level	=	converter	.	STANDARD_DEBUG	-	(	level	-	1	)	
else	:	
if	level	<	converter	.	ABSL_FATAL	:	
level	=	converter	.	ABSL_FATAL	
standard_level	=	converter	.	absl_to_standard	(	level	)	




if	not	logging	.	root	.	handlers	:	
logging	.	basicConfig	(	)	

_absl_logger	.	log	(	standard_level	,	msg	,	*	args	,	*	*	kwargs	)	


def	vlog	(	level	,	msg	,	*	args	,	*	*	kwargs	)	:	

log	(	level	,	msg	,	*	args	,	*	*	kwargs	)	


def	vlog_is_on	(	level	)	:	


if	level	>	converter	.	ABSL_DEBUG	:	



standard_level	=	converter	.	STANDARD_DEBUG	-	(	level	-	1	)	
else	:	
if	level	<	converter	.	ABSL_FATAL	:	
level	=	converter	.	ABSL_FATAL	
standard_level	=	converter	.	absl_to_standard	(	level	)	
return	_absl_logger	.	isEnabledFor	(	standard_level	)	


def	flush	(	)	:	

get_absl_handler	(	)	.	flush	(	)	


def	level_debug	(	)	:	

return	get_verbosity	(	)	>	=	DEBUG	


def	level_info	(	)	:	

return	get_verbosity	(	)	>	=	INFO	


def	level_warning	(	)	:	

return	get_verbosity	(	)	>	=	WARNING	


level_warn	=	level_warning	


def	level_error	(	)	:	

return	get_verbosity	(	)	>	=	ERROR	


def	get_log_file_name	(	level	=	INFO	)	:	

if	level	not	in	converter	.	ABSL_LEVELS	:	
raise	ValueError	(	"str"	.	format	(	level	)	)	
stream	=	get_absl_handler	(	)	.	python_handler	.	stream	
if	(	stream	==	sys	.	stderr	or	stream	==	sys	.	stdout	or	
not	hasattr	(	stream	,	"str"	)	)	:	
return	"str"	
else	:	
return	stream	.	name	


def	find_log_dir_and_names	(	program_name	=	None	,	log_dir	=	None	)	:	

if	not	program_name	:	



program_name	=	os	.	path	.	splitext	(	os	.	path	.	basename	(	sys	.	argv	[	0	]	)	)	[	0	]	



program_name	=	"str"	%	program_name	

actual_log_dir	=	find_log_dir	(	log_dir	=	log_dir	)	

try	:	
username	=	getpass	.	getuser	(	)	
except	KeyError	:	

if	hasattr	(	os	,	"str"	)	:	

username	=	str	(	os	.	getuid	(	)	)	
else	:	
username	=	"str"	
hostname	=	socket	.	gethostname	(	)	
file_prefix	=	"str"	%	(	program_name	,	hostname	,	username	)	

return	actual_log_dir	,	file_prefix	,	program_name	


def	find_log_dir	(	log_dir	=	None	)	:	


if	log_dir	:	

dirs	=	[	log_dir	]	
elif	FLAGS	[	"str"	]	.	value	:	


dirs	=	[	FLAGS	[	"str"	]	.	value	]	
else	:	
dirs	=	[	"str"	,	"str"	]	


for	d	in	dirs	:	
if	os	.	path	.	isdir	(	d	)	and	os	.	access	(	d	,	os	.	W_OK	)	:	
return	d	
_absl_logger	.	fatal	(	"str"	,	dirs	)	


def	get_absl_log_prefix	(	record	)	:	

created_tuple	=	time	.	localtime	(	record	.	created	)	
created_microsecond	=	int	(	record	.	created	%	1.0	*	1e6	)	

critical_prefix	=	"str"	
level	=	record	.	levelno	
if	_is_non_absl_fatal_record	(	record	)	:	


level	=	logging	.	ERROR	
critical_prefix	=	_CRITICAL_PREFIX	
severity	=	converter	.	get_initial_for_level	(	level	)	

return	"str"	%	(	
severity	,	
created_tuple	.	tm_mon	,	
created_tuple	.	tm_mday	,	
created_tuple	.	tm_hour	,	
created_tuple	.	tm_min	,	
created_tuple	.	tm_sec	,	
created_microsecond	,	
_get_thread_id	(	)	,	
record	.	filename	,	
record	.	lineno	,	
critical_prefix	)	


def	skip_log_prefix	(	func	)	:	

if	callable	(	func	)	:	
func_code	=	getattr	(	func	,	"str"	,	None	)	
if	func_code	is	None	:	
raise	ValueError	(	"str"	)	
file_name	=	func_code	.	co_filename	
func_name	=	func_code	.	co_name	
func_lineno	=	func_code	.	co_firstlineno	
elif	isinstance	(	func	,	six	.	string_types	)	:	
file_name	=	get_absl_logger	(	)	.	findCaller	(	)	[	0	]	
func_name	=	func	
func_lineno	=	None	
else	:	
raise	TypeError	(	"str"	)	
ABSLLogger	.	register_frame_to_skip	(	file_name	,	func_name	,	func_lineno	)	
return	func	


def	_is_non_absl_fatal_record	(	log_record	)	:	
return	(	log_record	.	levelno	>	=	logging	.	FATAL	and	
not	log_record	.	__dict__	.	get	(	_ABSL_LOG_FATAL	,	False	)	)	


def	_is_absl_fatal_record	(	log_record	)	:	
return	(	log_record	.	levelno	>	=	logging	.	FATAL	and	
log_record	.	__dict__	.	get	(	_ABSL_LOG_FATAL	,	False	)	)	



_warn_preinit_stderr	=	True	


class	PythonHandler	(	logging	.	StreamHandler	)	:	


def	__init__	(	self	,	stream	=	None	,	formatter	=	None	)	:	
super	(	PythonHandler	,	self	)	.	__init__	(	stream	)	
self	.	setFormatter	(	formatter	or	PythonFormatter	(	)	)	

def	start_logging_to_file	(	self	,	program_name	=	None	,	log_dir	=	None	)	:	

FLAGS	.	logtostderr	=	False	

actual_log_dir	,	file_prefix	,	symlink_prefix	=	find_log_dir_and_names	(	
program_name	=	program_name	,	log_dir	=	log_dir	)	

basename	=	"str"	%	(	
file_prefix	,	
time	.	strftime	(	"str"	,	time	.	localtime	(	time	.	time	(	)	)	)	,	
os	.	getpid	(	)	)	
filename	=	os	.	path	.	join	(	actual_log_dir	,	basename	)	

if	six	.	PY2	:	
self	.	stream	=	open	(	filename	,	"str"	)	
else	:	
self	.	stream	=	open	(	filename	,	"str"	,	encoding	=	"str"	)	


if	getattr	(	os	,	"str"	,	None	)	:	

symlink	=	os	.	path	.	join	(	actual_log_dir	,	symlink_prefix	+	"str"	)	
try	:	
if	os	.	path	.	islink	(	symlink	)	:	
os	.	unlink	(	symlink	)	
os	.	symlink	(	os	.	path	.	basename	(	filename	)	,	symlink	)	
except	EnvironmentError	:	



pass	

def	use_absl_log_file	(	self	,	program_name	=	None	,	log_dir	=	None	)	:	

if	FLAGS	[	"str"	]	.	value	:	
self	.	stream	=	sys	.	stderr	
else	:	
self	.	start_logging_to_file	(	program_name	=	program_name	,	log_dir	=	log_dir	)	

def	flush	(	self	)	:	

self	.	acquire	(	)	
try	:	
self	.	stream	.	flush	(	)	
except	(	EnvironmentError	,	ValueError	)	:	

pass	
finally	:	
self	.	release	(	)	

def	_log_to_stderr	(	self	,	record	)	:	



old_stream	=	self	.	stream	
self	.	stream	=	sys	.	stderr	
try	:	
super	(	PythonHandler	,	self	)	.	emit	(	record	)	
finally	:	
self	.	stream	=	old_stream	

def	emit	(	self	,	record	)	:	







level	=	record	.	levelno	
if	not	FLAGS	.	is_parsed	(	)	:	
global	_warn_preinit_stderr	
if	_warn_preinit_stderr	:	
sys	.	stderr	.	write	(	
"str"	)	
_warn_preinit_stderr	=	False	
self	.	_log_to_stderr	(	record	)	
elif	FLAGS	[	"str"	]	.	value	:	
self	.	_log_to_stderr	(	record	)	
else	:	
super	(	PythonHandler	,	self	)	.	emit	(	record	)	
stderr_threshold	=	converter	.	string_to_standard	(	
FLAGS	[	"str"	]	.	value	)	
if	(	(	FLAGS	[	"str"	]	.	value	or	level	>	=	stderr_threshold	)	and	
self	.	stream	!=	sys	.	stderr	)	:	
self	.	_log_to_stderr	(	record	)	

if	_is_absl_fatal_record	(	record	)	:	
self	.	flush	(	)	



os	.	abort	(	)	

def	close	(	self	)	:	

self	.	acquire	(	)	
try	:	
self	.	flush	(	)	
try	:	



if	self	.	stream	not	in	(	sys	.	stderr	,	sys	.	stdout	)	and	(	
not	hasattr	(	self	.	stream	,	"str"	)	or	not	self	.	stream	.	isatty	(	)	)	:	
self	.	stream	.	close	(	)	
except	ValueError	:	

pass	
super	(	PythonHandler	,	self	)	.	close	(	)	
finally	:	
self	.	release	(	)	


class	ABSLHandler	(	logging	.	Handler	)	:	


def	__init__	(	self	,	python_logging_formatter	)	:	
super	(	ABSLHandler	,	self	)	.	__init__	(	)	

self	.	_python_handler	=	PythonHandler	(	formatter	=	python_logging_formatter	)	
self	.	activate_python_handler	(	)	

def	format	(	self	,	record	)	:	
return	self	.	_current_handler	.	format	(	record	)	

def	setFormatter	(	self	,	fmt	)	:	
self	.	_current_handler	.	setFormatter	(	fmt	)	

def	emit	(	self	,	record	)	:	
self	.	_current_handler	.	emit	(	record	)	

def	flush	(	self	)	:	
self	.	_current_handler	.	flush	(	)	

def	close	(	self	)	:	
super	(	ABSLHandler	,	self	)	.	close	(	)	
self	.	_current_handler	.	close	(	)	

def	handle	(	self	,	record	)	:	
rv	=	self	.	filter	(	record	)	
if	rv	:	
return	self	.	_current_handler	.	handle	(	record	)	
return	rv	

@property	
def	python_handler	(	self	)	:	
return	self	.	_python_handler	

def	activate_python_handler	(	self	)	:	

self	.	_current_handler	=	self	.	_python_handler	

def	use_absl_log_file	(	self	,	program_name	=	None	,	log_dir	=	None	)	:	
self	.	_current_handler	.	use_absl_log_file	(	program_name	,	log_dir	)	

def	start_logging_to_file	(	self	,	program_name	=	None	,	log_dir	=	None	)	:	
self	.	_current_handler	.	start_logging_to_file	(	program_name	,	log_dir	)	


class	PythonFormatter	(	logging	.	Formatter	)	:	


def	format	(	self	,	record	)	:	

if	(	not	FLAGS	[	"str"	]	.	value	and	
FLAGS	[	"str"	]	.	value	==	converter	.	ABSL_INFO	and	
record	.	levelno	==	logging	.	INFO	and	
_absl_handler	.	python_handler	.	stream	==	sys	.	stderr	)	:	
prefix	=	"str"	
else	:	
prefix	=	get_absl_log_prefix	(	record	)	
return	prefix	+	super	(	PythonFormatter	,	self	)	.	format	(	record	)	


class	ABSLLogger	(	logging	.	getLoggerClass	(	)	)	:	

_frames_to_skip	=	set	(	)	

def	findCaller	(	self	,	stack_info	=	False	)	:	

f_to_skip	=	ABSLLogger	.	_frames_to_skip	


frame	=	sys	.	_getframe	(	2	)	

while	frame	:	
code	=	frame	.	f_code	
if	(	_LOGGING_FILE_PREFIX	not	in	code	.	co_filename	and	
(	code	.	co_filename	,	code	.	co_name	,	
code	.	co_firstlineno	)	not	in	f_to_skip	and	
(	code	.	co_filename	,	code	.	co_name	)	not	in	f_to_skip	)	:	
if	six	.	PY2	and	not	stack_info	:	
return	(	code	.	co_filename	,	frame	.	f_lineno	,	code	.	co_name	)	
else	:	
sinfo	=	None	
if	stack_info	:	
out	=	io	.	StringIO	(	)	
out	.	write	(	"str"	)	
traceback	.	print_stack	(	frame	,	file	=	out	)	
sinfo	=	out	.	getvalue	(	)	.	rstrip	(	"str"	)	
return	(	code	.	co_filename	,	frame	.	f_lineno	,	code	.	co_name	,	sinfo	)	
frame	=	frame	.	f_back	

def	critical	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	CRITICAL	,	msg	,	*	args	,	*	*	kwargs	)	

def	fatal	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	FATAL	,	msg	,	*	args	,	*	*	kwargs	)	

def	error	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	ERROR	,	msg	,	*	args	,	*	*	kwargs	)	

def	warn	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

if	six	.	PY3	:	
warnings	.	warn	(	"str"	,	
DeprecationWarning	,	2	)	
self	.	log	(	logging	.	WARN	,	msg	,	*	args	,	*	*	kwargs	)	

def	warning	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	WARNING	,	msg	,	*	args	,	*	*	kwargs	)	

def	info	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	INFO	,	msg	,	*	args	,	*	*	kwargs	)	

def	debug	(	self	,	msg	,	*	args	,	*	*	kwargs	)	:	

self	.	log	(	logging	.	DEBUG	,	msg	,	*	args	,	*	*	kwargs	)	

def	log	(	self	,	level	,	msg	,	*	args	,	*	*	kwargs	)	:	

if	level	>	=	logging	.	FATAL	:	



extra	=	kwargs	.	setdefault	(	"str"	,	{	}	)	
extra	[	_ABSL_LOG_FATAL	]	=	True	
super	(	ABSLLogger	,	self	)	.	log	(	level	,	msg	,	*	args	,	*	*	kwargs	)	

def	handle	(	self	,	record	)	:	

if	self	.	filter	(	record	)	:	
self	.	callHandlers	(	record	)	

@classmethod	
def	register_frame_to_skip	(	cls	,	file_name	,	function_name	,	line_number	=	None	)	:	

if	line_number	is	not	None	:	
cls	.	_frames_to_skip	.	add	(	(	file_name	,	function_name	,	line_number	)	)	
else	:	
cls	.	_frames_to_skip	.	add	(	(	file_name	,	function_name	)	)	


def	_get_thread_id	(	)	:	

thread_id	=	_thread_lib	.	get_ident	(	)	
return	thread_id	&	_THREAD_ID_MASK	


def	get_absl_logger	(	)	:	

return	_absl_logger	


def	get_absl_handler	(	)	:	

return	_absl_handler	


def	use_python_logging	(	quiet	=	False	)	:	

get_absl_handler	(	)	.	activate_python_handler	(	)	
if	not	quiet	:	
info	(	"str"	)	


_attempted_to_remove_stderr_stream_handlers	=	False	


def	use_absl_handler	(	)	:	

global	_attempted_to_remove_stderr_stream_handlers	
if	not	_attempted_to_remove_stderr_stream_handlers	:	




handlers	=	[	
h	for	h	in	logging	.	root	.	handlers	
if	isinstance	(	h	,	logging	.	StreamHandler	)	and	h	.	stream	==	sys	.	stderr	]	
for	h	in	handlers	:	
logging	.	root	.	removeHandler	(	h	)	
_attempted_to_remove_stderr_stream_handlers	=	True	

absl_handler	=	get_absl_handler	(	)	
if	absl_handler	not	in	logging	.	root	.	handlers	:	
logging	.	root	.	addHandler	(	absl_handler	)	
FLAGS	[	"str"	]	.	_update_logging_levels	(	)	


def	_initialize	(	)	:	

global	_absl_logger	,	_absl_handler	

if	_absl_logger	:	
return	

original_logger_class	=	logging	.	getLoggerClass	(	)	
logging	.	setLoggerClass	(	ABSLLogger	)	
_absl_logger	=	logging	.	getLogger	(	"str"	)	
logging	.	setLoggerClass	(	original_logger_class	)	

python_logging_formatter	=	PythonFormatter	(	)	
_absl_handler	=	ABSLHandler	(	python_logging_formatter	)	


_initialize	(	)	
	