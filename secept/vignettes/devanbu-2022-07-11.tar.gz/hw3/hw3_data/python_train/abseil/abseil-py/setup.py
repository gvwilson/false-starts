















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	os	
import	platform	
import	sys	

try	:	
import	setuptools	
except	ImportError	:	
from	ez_setup	import	use_setuptools	
use_setuptools	(	)	
import	setuptools	

py_version	=	platform	.	python_version_tuple	(	)	
if	py_version	<	(	"str"	,	"str"	)	or	py_version	[	0	]	==	"str"	and	py_version	<	(	"str"	,	"str"	)	:	
raise	RuntimeError	(	"str"	)	

INSTALL_REQUIRES	=	[	
"str"	,	
]	

setuptools_version	=	tuple	(	
int	(	x	)	for	x	in	setuptools	.	__version__	.	split	(	"str"	)	[	:	2	]	)	










if	setuptools_version	<	(	36	,	2	)	:	
if	sys	.	version_info	[	0	:	2	]	<	(	3	,	4	)	:	
INSTALL_REQUIRES	.	append	(	"str"	)	
else	:	


INSTALL_REQUIRES	.	append	(	"str"	)	

_README_PATH	=	os	.	path	.	join	(	
os	.	path	.	dirname	(	os	.	path	.	realpath	(	__file__	)	)	,	"str"	)	
with	open	(	_README_PATH	,	"str"	)	as	fp	:	
LONG_DESCRIPTION	=	fp	.	read	(	)	.	decode	(	"str"	)	

setuptools	.	setup	(	
name	=	"str"	,	
version	=	"str"	,	
description	=	(	
"str"	
"str"	)	,	
long_description	=	LONG_DESCRIPTION	,	
long_description_content_type	=	"str"	,	
author	=	"str"	,	
url	=	"str"	,	
packages	=	setuptools	.	find_packages	(	exclude	=	[	
"str"	,	"str"	,	"str"	,	"str"	,	
]	)	,	
install_requires	=	INSTALL_REQUIRES	,	
include_package_data	=	True	,	
license	=	"str"	,	
classifiers	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	,	
)	
	