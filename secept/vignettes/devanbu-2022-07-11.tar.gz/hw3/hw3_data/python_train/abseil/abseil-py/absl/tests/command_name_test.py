
















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	ctypes	
import	errno	
import	os	
import	unittest	

from	absl	import	command_name	
from	absl	.	testing	import	absltest	
import	mock	


def	_get_kernel_process_name	(	)	:	

try	:	
with	open	(	"str"	,	"str"	)	as	status_file	:	
for	line	in	status_file	:	
if	line	.	startswith	(	"str"	)	:	
return	line	.	split	(	"str"	,	2	)	[	1	]	.	strip	(	)	.	encode	(	"str"	,	"str"	)	
return	b	"str"	
except	IOError	:	
return	b	"str"	


def	_is_prctl_syscall_available	(	)	:	
try	:	
libc	=	ctypes	.	CDLL	(	"str"	,	use_errno	=	True	)	
except	OSError	:	
return	False	
zero	=	ctypes	.	c_ulong	(	0	)	
try	:	
status	=	libc	.	prctl	(	zero	,	zero	,	zero	,	zero	,	zero	)	
except	AttributeError	:	
return	False	
if	status	<	0	and	errno	.	ENOSYS	==	ctypes	.	get_errno	(	)	:	
return	False	
return	True	


@unittest.skipIf	(	not	_get_kernel_process_name	(	)	,	
"str"	)	
class	CommandNameTest	(	absltest	.	TestCase	)	:	

def	assertProcessNameSimilarTo	(	self	,	new_name	)	:	
if	not	isinstance	(	new_name	,	bytes	)	:	
new_name	=	new_name	.	encode	(	"str"	,	"str"	)	
actual_name	=	_get_kernel_process_name	(	)	
self	.	assertTrue	(	actual_name	)	
self	.	assertTrue	(	new_name	.	startswith	(	actual_name	)	,	
msg	=	"str"	.	format	(	new_name	,	actual_name	)	)	

@unittest.skipIf	(	not	os	.	access	(	"str"	,	os	.	W_OK	)	,	
"str"	)	
def	test_set_kernel_process_name	(	self	)	:	
new_name	=	"str"	
command_name	.	set_kernel_process_name	(	new_name	)	
self	.	assertProcessNameSimilarTo	(	new_name	)	

@unittest.skipIf	(	not	_is_prctl_syscall_available	(	)	,	
"str"	)	
def	test_set_kernel_process_name_no_proc_file	(	self	)	:	
new_name	=	b	"str"	
mock_open	=	mock	.	mock_open	(	)	
with	mock	.	patch	.	object	(	command_name	,	"str"	,	mock_open	,	create	=	True	)	:	
mock_open	.	side_effect	=	IOError	(	"str"	)	
command_name	.	set_kernel_process_name	(	new_name	)	
mock_open	.	assert_called_with	(	"str"	,	mock	.	ANY	)	
self	.	assertProcessNameSimilarTo	(	new_name	)	

def	test_set_kernel_process_name_failure	(	self	)	:	
starting_name	=	_get_kernel_process_name	(	)	
new_name	=	b	"str"	
mock_open	=	mock	.	mock_open	(	)	
mock_ctypes_cdll	=	mock	.	patch	(	"str"	)	
with	mock	.	patch	.	object	(	command_name	,	"str"	,	mock_open	,	create	=	True	)	:	
with	mock	.	patch	(	"str"	)	as	mock_ctypes_cdll	:	
mock_open	.	side_effect	=	IOError	(	"str"	)	
mock_libc	=	mock	.	Mock	(	[	"str"	]	)	
mock_ctypes_cdll	.	return_value	=	mock_libc	
command_name	.	set_kernel_process_name	(	new_name	)	
mock_open	.	assert_called_with	(	"str"	,	mock	.	ANY	)	
self	.	assertEqual	(	1	,	mock_libc	.	prctl	.	call_count	)	
self	.	assertEqual	(	starting_name	,	_get_kernel_process_name	(	)	)	

def	test_make_process_name_useful	(	self	)	:	
test_name	=	"str"	
with	mock	.	patch	(	"str"	,	[	test_name	]	)	:	
command_name	.	make_process_name_useful	(	)	
self	.	assertProcessNameSimilarTo	(	test_name	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	