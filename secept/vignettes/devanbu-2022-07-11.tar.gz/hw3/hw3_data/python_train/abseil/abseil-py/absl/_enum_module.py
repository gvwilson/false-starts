















import	sys	
import	six	

try	:	
import	enum	
except	ImportError	:	
if	six	.	PY3	:	

raise	
for	i	,	path	in	enumerate	(	sys	.	path	)	:	
if	"str"	in	path	:	
sys	.	path	[	i	]	=	path	+	"str"	

import	enum	
	