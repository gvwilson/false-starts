















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	sys	

from	absl	import	app	
from	absl	import	flags	
from	absl	import	logging	

FLAGS	=	flags	.	FLAGS	

flags	.	DEFINE_string	(	"str"	,	None	,	"str"	)	


def	main	(	argv	)	:	
del	argv	

print	(	"str"	.	format	(	sys	.	version_info	)	,	
file	=	sys	.	stderr	)	
logging	.	info	(	"str"	,	FLAGS	.	echo	)	


if	__name__	==	"str"	:	
app	.	run	(	main	)	
	