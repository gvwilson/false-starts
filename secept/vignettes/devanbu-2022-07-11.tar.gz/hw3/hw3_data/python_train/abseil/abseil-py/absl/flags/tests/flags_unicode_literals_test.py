















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	
from	__future__	import	unicode_literals	

from	absl	import	flags	
from	absl	.	testing	import	absltest	


flags	.	DEFINE_string	(	"str"	,	"str"	,	
"str"	)	


class	FlagsUnicodeLiteralsTest	(	absltest	.	TestCase	)	:	

def	testUnicodeFlagNameAndValueAreGood	(	self	)	:	
alleged_mountain_lion	=	flags	.	FLAGS	.	seen_in_crittenden	
self	.	assertTrue	(	
isinstance	(	alleged_mountain_lion	,	type	(	"str"	)	)	,	
msg	=	"str"	.	format	(	
type	(	"str"	)	,	type	(	alleged_mountain_lion	)	)	)	
self	.	assertEqual	(	alleged_mountain_lion	,	"str"	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	