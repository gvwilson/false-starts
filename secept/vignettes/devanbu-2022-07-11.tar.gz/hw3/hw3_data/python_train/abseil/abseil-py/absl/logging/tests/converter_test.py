















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	logging	

from	absl	import	logging	as	absl_logging	
from	absl	.	logging	import	converter	
from	absl	.	testing	import	absltest	


class	ConverterTest	(	absltest	.	TestCase	)	:	


def	test_absl_to_cpp	(	self	)	:	
self	.	assertEqual	(	0	,	converter	.	absl_to_cpp	(	absl_logging	.	DEBUG	)	)	
self	.	assertEqual	(	0	,	converter	.	absl_to_cpp	(	absl_logging	.	INFO	)	)	
self	.	assertEqual	(	1	,	converter	.	absl_to_cpp	(	absl_logging	.	WARN	)	)	
self	.	assertEqual	(	2	,	converter	.	absl_to_cpp	(	absl_logging	.	ERROR	)	)	
self	.	assertEqual	(	3	,	converter	.	absl_to_cpp	(	absl_logging	.	FATAL	)	)	

with	self	.	assertRaises	(	TypeError	)	:	
converter	.	absl_to_cpp	(	"str"	)	

def	test_absl_to_standard	(	self	)	:	
self	.	assertEqual	(	
logging	.	DEBUG	,	converter	.	absl_to_standard	(	absl_logging	.	DEBUG	)	)	
self	.	assertEqual	(	
logging	.	INFO	,	converter	.	absl_to_standard	(	absl_logging	.	INFO	)	)	
self	.	assertEqual	(	
logging	.	WARNING	,	converter	.	absl_to_standard	(	absl_logging	.	WARN	)	)	
self	.	assertEqual	(	
logging	.	WARN	,	converter	.	absl_to_standard	(	absl_logging	.	WARN	)	)	
self	.	assertEqual	(	
logging	.	ERROR	,	converter	.	absl_to_standard	(	absl_logging	.	ERROR	)	)	
self	.	assertEqual	(	
logging	.	FATAL	,	converter	.	absl_to_standard	(	absl_logging	.	FATAL	)	)	
self	.	assertEqual	(	
logging	.	CRITICAL	,	converter	.	absl_to_standard	(	absl_logging	.	FATAL	)	)	

self	.	assertEqual	(	9	,	converter	.	absl_to_standard	(	2	)	)	
self	.	assertEqual	(	8	,	converter	.	absl_to_standard	(	3	)	)	

with	self	.	assertRaises	(	TypeError	)	:	
converter	.	absl_to_standard	(	"str"	)	

def	test_standard_to_absl	(	self	)	:	
self	.	assertEqual	(	
absl_logging	.	DEBUG	,	converter	.	standard_to_absl	(	logging	.	DEBUG	)	)	
self	.	assertEqual	(	
absl_logging	.	INFO	,	converter	.	standard_to_absl	(	logging	.	INFO	)	)	
self	.	assertEqual	(	
absl_logging	.	WARN	,	converter	.	standard_to_absl	(	logging	.	WARN	)	)	
self	.	assertEqual	(	
absl_logging	.	WARN	,	converter	.	standard_to_absl	(	logging	.	WARNING	)	)	
self	.	assertEqual	(	
absl_logging	.	ERROR	,	converter	.	standard_to_absl	(	logging	.	ERROR	)	)	
self	.	assertEqual	(	
absl_logging	.	FATAL	,	converter	.	standard_to_absl	(	logging	.	FATAL	)	)	
self	.	assertEqual	(	
absl_logging	.	FATAL	,	converter	.	standard_to_absl	(	logging	.	CRITICAL	)	)	

self	.	assertEqual	(	2	,	converter	.	standard_to_absl	(	logging	.	DEBUG	-	1	)	)	
self	.	assertEqual	(	3	,	converter	.	standard_to_absl	(	logging	.	DEBUG	-	2	)	)	

with	self	.	assertRaises	(	TypeError	)	:	
converter	.	standard_to_absl	(	"str"	)	

def	test_standard_to_cpp	(	self	)	:	
self	.	assertEqual	(	0	,	converter	.	standard_to_cpp	(	logging	.	DEBUG	)	)	
self	.	assertEqual	(	0	,	converter	.	standard_to_cpp	(	logging	.	INFO	)	)	
self	.	assertEqual	(	1	,	converter	.	standard_to_cpp	(	logging	.	WARN	)	)	
self	.	assertEqual	(	1	,	converter	.	standard_to_cpp	(	logging	.	WARNING	)	)	
self	.	assertEqual	(	2	,	converter	.	standard_to_cpp	(	logging	.	ERROR	)	)	
self	.	assertEqual	(	3	,	converter	.	standard_to_cpp	(	logging	.	FATAL	)	)	
self	.	assertEqual	(	3	,	converter	.	standard_to_cpp	(	logging	.	CRITICAL	)	)	

with	self	.	assertRaises	(	TypeError	)	:	
converter	.	standard_to_cpp	(	"str"	)	

def	test_get_initial_for_level	(	self	)	:	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	CRITICAL	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	ERROR	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	WARNING	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	INFO	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	DEBUG	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	logging	.	NOTSET	)	)	

self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	51	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	49	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	41	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	39	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	31	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	29	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	21	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	19	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	11	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	9	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	1	)	)	
self	.	assertEqual	(	"str"	,	converter	.	get_initial_for_level	(	-	1	)	)	

def	test_string_to_standard	(	self	)	:	
self	.	assertEqual	(	logging	.	DEBUG	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	INFO	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	WARNING	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	WARNING	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	ERROR	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	CRITICAL	,	converter	.	string_to_standard	(	"str"	)	)	

self	.	assertEqual	(	logging	.	DEBUG	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	INFO	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	WARNING	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	WARNING	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	ERROR	,	converter	.	string_to_standard	(	"str"	)	)	
self	.	assertEqual	(	logging	.	CRITICAL	,	converter	.	string_to_standard	(	"str"	)	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	