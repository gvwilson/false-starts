















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	import	flags	
from	absl	.	flags	import	_validators	
from	absl	.	testing	import	absltest	
import	mock	


class	NumericFlagBoundsTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
super	(	NumericFlagBoundsTest	,	self	)	.	setUp	(	)	
self	.	flag_values	=	flags	.	FlagValues	(	)	

def	test_no_validator_if_no_bounds	(	self	)	:	

with	mock	.	patch	.	object	(	_validators	,	"str"	
)	as	register_validator	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	
lower_bound	=	0	,	flag_values	=	self	.	flag_values	)	
register_validator	.	assert_called_once_with	(	
"str"	,	mock	.	ANY	,	flag_values	=	self	.	flag_values	)	
with	mock	.	patch	.	object	(	_validators	,	"str"	
)	as	register_validator	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	
flag_values	=	self	.	flag_values	)	
register_validator	.	assert_not_called	(	)	

def	test_success	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	5	,	"str"	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	13	,	self	.	flag_values	.	int_flag	)	
self	.	flag_values	.	int_flag	=	25	
self	.	assertEqual	(	25	,	self	.	flag_values	.	int_flag	)	

def	test_success_if_none	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	
lower_bound	=	0	,	upper_bound	=	5	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	)	
self	.	flag_values	(	argv	)	
self	.	assertIsNone	(	self	.	flag_values	.	int_flag	)	

def	test_success_if_exactly_equals	(	self	)	:	
flags	.	DEFINE_float	(	"str"	,	None	,	"str"	,	
lower_bound	=	1	,	upper_bound	=	1	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	1	,	self	.	flag_values	.	float_flag	)	

def	test_exception_if_smaller	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	
lower_bound	=	0	,	upper_bound	=	5	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
try	:	
self	.	flag_values	(	argv	)	
except	flags	.	IllegalFlagValueError	as	e	:	
text	=	"str"	
self	.	assertEqual	(	text	,	str	(	e	)	)	


class	SettingFlagAfterStartTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	flag_values	=	flags	.	FlagValues	(	)	

def	test_success	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	13	,	self	.	flag_values	.	int_flag	)	
self	.	flag_values	.	int_flag	=	25	
self	.	assertEqual	(	25	,	self	.	flag_values	.	int_flag	)	

def	test_exception_if_setting_integer_flag_outside_bounds	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	None	,	"str"	,	lower_bound	=	0	,	
flag_values	=	self	.	flag_values	)	
argv	=	(	"str"	,	"str"	)	
self	.	flag_values	(	argv	)	
self	.	assertEqual	(	13	,	self	.	flag_values	.	int_flag	)	
with	self	.	assertRaises	(	flags	.	IllegalFlagValueError	)	:	
self	.	flag_values	.	int_flag	=	-	2	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	