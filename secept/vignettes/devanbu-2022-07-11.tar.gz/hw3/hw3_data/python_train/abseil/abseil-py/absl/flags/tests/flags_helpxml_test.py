















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	io	
import	os	
import	string	
import	sys	
import	xml	.	dom	.	minidom	
import	xml	.	sax	.	saxutils	

from	absl	import	flags	
from	absl	.	_enum_module	import	enum	
from	absl	.	flags	import	_helpers	
from	absl	.	flags	.	tests	import	module_bar	
from	absl	.	testing	import	absltest	
import	six	


class	CreateXMLDOMElement	(	absltest	.	TestCase	)	:	

def	_check	(	self	,	name	,	value	,	expected_output	)	:	
doc	=	xml	.	dom	.	minidom	.	Document	(	)	
node	=	_helpers	.	create_xml_dom_element	(	doc	,	name	,	value	)	
output	=	node	.	toprettyxml	(	"str"	,	encoding	=	"str"	)	
self	.	assertEqual	(	expected_output	,	output	)	

def	test_create_xml_dom_element	(	self	)	:	
self	.	_check	(	"str"	,	"str"	,	b	"str"	)	
self	.	_check	(	"str"	,	"str"	,	b	"str"	)	
self	.	_check	(	"str"	,	"str"	,	
b	"str"	)	


bytes_with_invalid_unicodes	=	b	"str"	
if	six	.	PY2	:	


self	.	_check	(	"str"	,	bytes_with_invalid_unicodes	,	b	"str"	)	
else	:	


self	.	_check	(	"str"	,	bytes_with_invalid_unicodes	,	
b	"str"	)	



self	.	_check	(	"str"	,	"str"	,	b	"str"	)	


self	.	_check	(	"str"	,	"str"	,	b	"str"	)	


def	_list_separators_in_xmlformat	(	separators	,	indent	=	"str"	)	:	

result	=	"str"	
separators	=	list	(	separators	)	
separators	.	sort	(	)	
for	sep_char	in	separators	:	
result	+	=	(	"str"	%	
(	indent	,	repr	(	sep_char	)	)	)	
return	result	


class	FlagCreateXMLDOMElement	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	


self	.	fv	=	flags	.	FlagValues	(	)	

def	_check_flag_help_in_xml	(	self	,	flag_name	,	module_name	,	
expected_output	,	is_key	=	False	)	:	
flag_obj	=	self	.	fv	[	flag_name	]	
doc	=	xml	.	dom	.	minidom	.	Document	(	)	
element	=	flag_obj	.	_create_xml_dom_element	(	doc	,	module_name	,	is_key	=	is_key	)	
output	=	element	.	toprettyxml	(	indent	=	"str"	)	
self	.	assertMultiLineEqual	(	expected_output	,	output	)	

def	test_flag_help_in_xml_int	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	17	,	"str"	,	flag_values	=	self	.	fv	)	
expected_output_pattern	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	
expected_output_pattern	%	17	)	


self	.	fv	[	"str"	]	.	value	=	20	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	
expected_output_pattern	%	20	)	

def	test_flag_help_in_xml_int_with_bounds	(	self	)	:	
flags	.	DEFINE_integer	(	"str"	,	17	,	"str"	,	
lower_bound	=	5	,	upper_bound	=	27	,	
flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	,	
is_key	=	True	)	

def	test_flag_help_in_xml_string	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_string_with_xmlillegal_chars	(	self	)	:	
flags	.	DEFINE_string	(	"str"	,	"str"	,	
"str"	,	flag_values	=	self	.	fv	)	


expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_boolean	(	self	)	:	
flags	.	DEFINE_boolean	(	"str"	,	False	,	"str"	,	
flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	,	
is_key	=	True	)	

def	test_flag_help_in_xml_enum	(	self	)	:	
flags	.	DEFINE_enum	(	"str"	,	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_enum_class	(	self	)	:	
class	Version	(	enum	.	Enum	)	:	
STABLE	=	0	
EXPERIMENTAL	=	1	

flags	.	DEFINE_enum_class	(	"str"	,	"str"	,	Version	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_comma_separated_list	(	self	)	:	
flags	.	DEFINE_list	(	"str"	,	"str"	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_list_as_default_argument_comma_separated_list	(	self	)	:	
flags	.	DEFINE_list	(	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_none_as_default_arguments_comma_separated_list	(	self	)	:	
flags	.	DEFINE_list	(	"str"	,	None	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_space_separated_list	(	self	)	:	
flags	.	DEFINE_spaceseplist	(	"str"	,	"str"	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_separators	=	sorted	(	string	.	whitespace	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	.	replace	(	"str"	,	
_list_separators_in_xmlformat	(	expected_separators	,	
indent	=	"str"	)	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_space_separated_list_with_comma_compat	(	self	)	:	
flags	.	DEFINE_spaceseplist	(	"str"	,	"str"	,	
"str"	,	comma_compat	=	True	,	
flag_values	=	self	.	fv	)	
expected_separators	=	sorted	(	string	.	whitespace	+	"str"	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	.	replace	(	"str"	,	
_list_separators_in_xmlformat	(	expected_separators	,	
indent	=	"str"	)	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_multi_string	(	self	)	:	
flags	.	DEFINE_multi_string	(	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_multi_int	(	self	)	:	
flags	.	DEFINE_multi_integer	(	"str"	,	[	5	,	7	,	23	]	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_multi_enum	(	self	)	:	
flags	.	DEFINE_multi_enum	(	"str"	,	[	"str"	,	"str"	]	,	
[	"str"	,	"str"	,	"str"	]	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_multi_enum_class_singleton_default	(	self	)	:	
class	Fruit	(	enum	.	Enum	)	:	
ORANGE	=	0	
BANANA	=	1	

flags	.	DEFINE_multi_enum_class	(	"str"	,	[	"str"	]	,	
Fruit	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	

def	test_flag_help_in_xml_multi_enum_class_list_default	(	self	)	:	
class	Fruit	(	enum	.	Enum	)	:	
ORANGE	=	0	
BANANA	=	1	

flags	.	DEFINE_multi_enum_class	(	"str"	,	[	"str"	,	"str"	]	,	
Fruit	,	
"str"	,	flag_values	=	self	.	fv	)	
expected_output	=	(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	)	
self	.	_check_flag_help_in_xml	(	"str"	,	"str"	,	expected_output	)	









EXPECTED_HELP_XML_START	=	"str"	

EXPECTED_HELP_XML_FOR_FLAGS_FROM_MAIN_MODULE	=	"str"	

EXPECTED_HELP_XML_FOR_FLAGS_FROM_MODULE_BAR	=	"str"	

EXPECTED_HELP_XML_END	=	"str"	


class	WriteHelpInXMLFormatTest	(	absltest	.	TestCase	)	:	


def	test_write_help_in_xmlformat	(	self	)	:	
fv	=	flags	.	FlagValues	(	)	

flags	.	DEFINE_integer	(	"str"	,	17	,	"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_integer	(	"str"	,	17	,	"str"	,	
lower_bound	=	5	,	upper_bound	=	27	,	flag_values	=	fv	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	fv	)	
flags	.	DEFINE_boolean	(	"str"	,	False	,	"str"	,	
flag_values	=	fv	)	
flags	.	DEFINE_enum	(	"str"	,	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_list	(	"str"	,	"str"	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_list	(	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_spaceseplist	(	"str"	,	"str"	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_multi_string	(	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_multi_integer	(	"str"	,	[	5	,	7	,	23	]	,	
"str"	,	flag_values	=	fv	)	
flags	.	DEFINE_multi_enum	(	"str"	,	[	"str"	,	"str"	]	,	
[	"str"	,	"str"	,	"str"	]	,	
"str"	,	flag_values	=	fv	)	

module_bar	.	define_flags	(	flag_values	=	fv	)	



flags	.	declare_key_flag	(	"str"	,	flag_values	=	fv	)	
flags	.	declare_key_flag	(	"str"	,	flag_values	=	fv	)	


sio	=	io	.	StringIO	(	)	if	six	.	PY3	else	io	.	BytesIO	(	)	
fv	.	write_help_in_xml_format	(	sio	)	


expected_output_template	=	EXPECTED_HELP_XML_START	
main_module_name	=	sys	.	argv	[	0	]	
module_bar_name	=	module_bar	.	__name__	

if	main_module_name	<	module_bar_name	:	
expected_output_template	+	=	EXPECTED_HELP_XML_FOR_FLAGS_FROM_MAIN_MODULE	
expected_output_template	+	=	EXPECTED_HELP_XML_FOR_FLAGS_FROM_MODULE_BAR	
else	:	
expected_output_template	+	=	EXPECTED_HELP_XML_FOR_FLAGS_FROM_MODULE_BAR	
expected_output_template	+	=	EXPECTED_HELP_XML_FOR_FLAGS_FROM_MAIN_MODULE	

expected_output_template	+	=	EXPECTED_HELP_XML_END	


whitespace_separators	=	_list_separators_in_xmlformat	(	string	.	whitespace	,	
indent	=	"str"	)	
expected_output	=	(	
expected_output_template	%	
{	"str"	:	os	.	path	.	basename	(	sys	.	argv	[	0	]	)	,	
"str"	:	sys	.	modules	[	"str"	]	.	__doc__	,	
"str"	:	main_module_name	,	
"str"	:	module_bar_name	,	
"str"	:	whitespace_separators	}	)	

actual_output	=	sio	.	getvalue	(	)	
self	.	assertMultiLineEqual	(	expected_output	,	actual_output	)	



xml	.	dom	.	minidom	.	parseString	(	actual_output	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	