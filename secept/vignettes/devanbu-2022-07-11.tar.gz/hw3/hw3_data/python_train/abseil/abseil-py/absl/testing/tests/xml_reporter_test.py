













from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	datetime	
import	os	
import	re	
import	subprocess	
import	sys	
import	tempfile	
import	threading	
import	time	
import	unittest	
from	xml	.	etree	import	ElementTree	
from	xml	.	parsers	import	expat	

from	absl	import	logging	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	
from	absl	.	testing	import	xml_reporter	
from	absl	.	third_party	import	unittest3_backport	
import	mock	
import	six	


class	StringIOWriteLn	(	six	.	StringIO	)	:	

def	writeln	(	self	,	line	)	:	
self	.	write	(	line	+	"str"	)	


class	MockTest	(	absltest	.	TestCase	)	:	
failureException	=	AssertionError	

def	__init__	(	self	,	name	)	:	
super	(	MockTest	,	self	)	.	__init__	(	)	
self	.	name	=	name	

def	id	(	self	)	:	
return	self	.	name	

def	runTest	(	self	)	:	
return	

def	shortDescription	(	self	)	:	
return	"str"	



def	xml_escaped_exception_type	(	exception_type	)	:	
return	xml_reporter	.	_escape_xml_attr	(	str	(	exception_type	)	)	


OUTPUT_STRING	=	"str"	.	join	(	[	
"str"	,	
"str"	
"str"	,	
"str"	
"str"	,	
"str"	
"str"	
"str"	,	"str"	,	"str"	,	
"str"	
]	)	

FAILURE_MESSAGE	=	"str"	.	format	(	xml_escaped_exception_type	(	AssertionError	)	)	

ERROR_MESSAGE	=	"str"	.	format	(	xml_escaped_exception_type	(	ValueError	)	)	

UNICODE_MESSAGE	=	"str"	.	format	(	
"str"	if	six	.	PY2	else	"str"	,	
xml_escaped_exception_type	(	AssertionError	)	)	

NEWLINE_MESSAGE	=	"str"	.	format	(	
"str"	,	
xml_escaped_exception_type	(	AssertionError	)	,	
"str"	,	
"str"	)	

UNEXPECTED_SUCCESS_MESSAGE	=	"str"	.	join	(	[	
"str"	,	
"str"	
"str"	
"str"	]	)	

UNICODE_ERROR_MESSAGE	=	UNICODE_MESSAGE	%	(	"str"	,	"str"	)	
NEWLINE_ERROR_MESSAGE	=	NEWLINE_MESSAGE	%	(	"str"	,	"str"	)	


class	TextAndXMLTestResultTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	stream	=	StringIOWriteLn	(	)	
self	.	xml_stream	=	six	.	StringIO	(	)	

def	_make_result	(	self	,	times	)	:	
timer	=	mock	.	Mock	(	)	
timer	.	side_effect	=	times	
return	xml_reporter	.	_TextAndXMLTestResult	(	self	.	xml_stream	,	self	.	stream	,	
"str"	,	0	,	timer	)	

def	_assert_match	(	self	,	regex	,	output	)	:	
self	.	assertRegex	(	output	,	regex	)	

def	_assert_valid_xml	(	self	,	xml_output	)	:	
try	:	
expat	.	ParserCreate	(	)	.	Parse	(	xml_output	)	
except	expat	.	ExpatError	as	e	:	
raise	AssertionError	(	"str"	.	format	(	e	,	xml_output	)	)	

def	_simulate_error_test	(	self	,	test	,	result	)	:	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_sample_error	(	)	)	
result	.	stopTest	(	test	)	

def	_simulate_failing_test	(	self	,	test	,	result	)	:	
result	.	startTest	(	test	)	
result	.	addFailure	(	test	,	self	.	get_sample_failure	(	)	)	
result	.	stopTest	(	test	)	

def	_simulate_passing_test	(	self	,	test	,	result	)	:	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	

def	test_with_passing_test	(	self	)	:	
start_time	=	0	
end_time	=	2	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_passing_subtest	(	self	)	:	
start_time	=	0	
end_time	=	2	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
if	six	.	PY3	:	
subtest	=	unittest	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
else	:	
subtest	=	unittest3_backport	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSubTest	(	test	,	subtest	,	None	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_passing_subtest_with_dots_in_parameter_name	(	self	)	:	
start_time	=	0	
end_time	=	2	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
if	six	.	PY3	:	
subtest	=	unittest	.	case	.	_SubTest	(	test	,	"str"	,	{	"str"	:	"str"	}	)	
else	:	




subtest	=	unittest3_backport	.	case	.	_SubTest	(	test	,	"str"	,	
[	{	"str"	:	"str"	}	]	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSubTest	(	test	,	subtest	,	None	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	get_sample_error	(	self	)	:	
try	:	
int	(	"str"	)	
except	ValueError	:	
error_values	=	sys	.	exc_info	(	)	
return	error_values	

def	get_sample_failure	(	self	)	:	
try	:	
raise	AssertionError	(	"str"	)	
except	AssertionError	:	
error_values	=	sys	.	exc_info	(	)	
return	error_values	

def	get_newline_message_sample_failure	(	self	)	:	
try	:	
raise	AssertionError	(	"str"	)	
except	AssertionError	:	
error_values	=	sys	.	exc_info	(	)	
return	error_values	

def	get_unicode_sample_failure	(	self	)	:	
try	:	
raise	AssertionError	(	"str"	)	
except	AssertionError	:	
error_values	=	sys	.	exc_info	(	)	
return	error_values	

def	get_terminal_escape_sample_failure	(	self	)	:	
try	:	
raise	AssertionError	(	"str"	)	
except	AssertionError	:	
error_values	=	sys	.	exc_info	(	)	
return	error_values	

def	test_with_failing_test	(	self	)	:	
start_time	=	10	
end_time	=	20	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addFailure	(	test	,	self	.	get_sample_failure	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
FAILURE_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_failing_subtest	(	self	)	:	
start_time	=	10	
end_time	=	20	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
if	six	.	PY3	:	
subtest	=	unittest	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
else	:	
subtest	=	unittest3_backport	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSubTest	(	test	,	subtest	,	self	.	get_sample_failure	(	)	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
FAILURE_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_error_test	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_sample_error	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
xml	=	self	.	xml_stream	.	getvalue	(	)	

self	.	_assert_valid_xml	(	xml	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
ERROR_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	xml	)	

def	test_with_error_subtest	(	self	)	:	
start_time	=	10	
end_time	=	20	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
if	six	.	PY3	:	
subtest	=	unittest	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
else	:	
subtest	=	unittest3_backport	.	case	.	_SubTest	(	test	,	"str"	,	None	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSubTest	(	test	,	subtest	,	self	.	get_sample_error	(	)	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
ERROR_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_fail_and_error_test	(	self	)	:	

start_time	=	123	
end_time	=	456	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addFailure	(	test	,	self	.	get_sample_failure	(	)	)	

result	.	addError	(	test	,	self	.	get_sample_error	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
xml	=	self	.	xml_stream	.	getvalue	(	)	

self	.	_assert_valid_xml	(	xml	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	

"str"	:	
FAILURE_MESSAGE	+	ERROR_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	xml	)	

def	test_with_error_and_fail_test	(	self	)	:	

start_time	=	123	
end_time	=	456	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_sample_error	(	)	)	
result	.	addFailure	(	test	,	self	.	get_sample_failure	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
xml	=	self	.	xml_stream	.	getvalue	(	)	

self	.	_assert_valid_xml	(	xml	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	

"str"	:	
ERROR_MESSAGE	+	FAILURE_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	xml	)	

def	test_with_newline_error_test	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_newline_message_sample_failure	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
xml	=	self	.	xml_stream	.	getvalue	(	)	

self	.	_assert_valid_xml	(	xml	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
NEWLINE_ERROR_MESSAGE	
}	+	"str"	
self	.	_assert_match	(	expected_re	,	xml	)	

def	test_with_unicode_error_test	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_unicode_sample_failure	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
xml	=	self	.	xml_stream	.	getvalue	(	)	

self	.	_assert_valid_xml	(	xml	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
UNICODE_ERROR_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	xml	)	

def	test_with_terminal_escape_error	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addError	(	test	,	self	.	get_terminal_escape_sample_failure	(	)	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

self	.	_assert_valid_xml	(	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_expected_failure_test	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	
error_values	=	"str"	

try	:	
raise	RuntimeError	(	"str"	)	
except	RuntimeError	:	
error_values	=	sys	.	exc_info	(	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addExpectedFailure	(	test	,	error_values	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	re	.	compile	(	expected_re	,	re	.	DOTALL	)	,	
self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_unexpected_success_error_test	(	self	)	:	
start_time	=	100	
end_time	=	200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addUnexpectedSuccess	(	test	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
1	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
UNEXPECTED_SUCCESS_MESSAGE	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_with_skipped_test	(	self	)	:	
start_time	=	100	
end_time	=	100	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSkip	(	test	,	"str"	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_suite_time	(	self	)	:	
start_time1	=	100	
end_time1	=	200	
start_time2	=	400	
end_time2	=	700	
name	=	"str"	
result	=	self	.	_make_result	(	(	start_time1	,	start_time1	,	end_time1	,	
start_time2	,	end_time2	,	end_time2	)	)	

test	=	MockTest	(	"str"	%	name	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	

test	=	MockTest	(	"str"	%	name	)	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	max	(	end_time1	,	end_time2	)	-	min	(	start_time1	,	start_time2	)	
timestamp	=	datetime	.	datetime	.	utcfromtimestamp	(	start_time1	)	.	isoformat	(	)	
expected_prefix	=	"str"	%	(	run_time	,	timestamp	,	run_time	,	timestamp	)	
xml_output	=	self	.	xml_stream	.	getvalue	(	)	
self	.	assertTrue	(	
xml_output	.	startswith	(	expected_prefix	)	,	
"str"	%	(	expected_prefix	,	xml_output	)	)	

def	test_with_no_suite_name	(	self	)	:	
start_time	=	1000	
end_time	=	1200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	

test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	test_unnamed_parameterized_testcase	(	self	)	:	


class	ParameterizedTest	(	parameterized	.	TestCase	)	:	

@parameterized.parameters	(	(	"str"	,	)	)	
def	test_prefix	(	self	,	case	)	:	
self	.	assertTrue	(	case	.	startswith	(	"str"	)	)	

start_time	=	1000	
end_time	=	1200	
result	=	self	.	_make_result	(	(	start_time	,	start_time	,	end_time	,	end_time	)	)	
test	=	ParameterizedTest	(	methodName	=	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	
result	.	addSuccess	(	test	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	
result	.	printErrors	(	)	

run_time	=	end_time	-	start_time	
classname	=	xml_reporter	.	_escape_xml_attr	(	
unittest	.	util	.	strclass	(	test	.	__class__	)	)	
expected_re	=	OUTPUT_STRING	%	{	
"str"	:	
"str"	,	
"str"	:	
1	,	
"str"	:	
0	,	
"str"	:	
0	,	
"str"	:	
run_time	,	
"str"	:	
datetime	.	datetime	.	utcfromtimestamp	(	start_time	)	.	isoformat	(	)	,	
"str"	:	
re	.	escape	(	"str"	)	,	
"str"	:	
classname	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	,	
"str"	:	
"str"	
}	
self	.	_assert_match	(	expected_re	,	self	.	xml_stream	.	getvalue	(	)	)	

def	teststop_test_without_pending_test	(	self	)	:	
end_time	=	1200	
result	=	self	.	_make_result	(	(	end_time	,	)	)	

test	=	MockTest	(	"str"	)	
result	.	stopTest	(	test	)	
result	.	stopTestRun	(	)	


def	test_text_and_xmltest_runner	(	self	)	:	
runner	=	xml_reporter	.	TextAndXMLTestRunner	(	self	.	xml_stream	,	self	.	stream	,	
"str"	,	1	)	
result1	=	runner	.	_makeResult	(	)	
result2	=	xml_reporter	.	_TextAndXMLTestResult	(	None	,	None	,	None	,	0	,	None	)	
self	.	failUnless	(	type	(	result1	)	is	type	(	result2	)	)	

def	test_timing_with_time_stub	(	self	)	:	

try	:	
saved_time	=	time	.	time	
time	.	time	=	lambda	:	-	1	
reporter	=	xml_reporter	.	_TextAndXMLTestResult	(	self	.	xml_stream	,	
self	.	stream	,	
"str"	,	0	)	
test	=	MockTest	(	"str"	)	
reporter	.	startTest	(	test	)	
self	.	failIf	(	reporter	.	start_time	==	-	1	)	
finally	:	
time	.	time	=	saved_time	

def	test_concurrent_add_and_delete_pending_test_case_result	(	self	)	:	

result	=	xml_reporter	.	_TextAndXMLTestResult	(	None	,	self	.	stream	,	None	,	0	,	
None	)	
def	add_and_delete_pending_test_case_result	(	test_name	)	:	
test	=	MockTest	(	test_name	)	
result	.	addSuccess	(	test	)	
result	.	delete_pending_test_case_result	(	test	)	

for	i	in	range	(	50	)	:	
add_and_delete_pending_test_case_result	(	"str"	%	i	)	
self	.	assertEqual	(	result	.	pending_test_case_results	,	{	}	)	

def	test_concurrent_test_runs	(	self	)	:	

num_passing_tests	=	20	
num_failing_tests	=	20	
num_error_tests	=	20	
total_num_tests	=	num_passing_tests	+	num_failing_tests	+	num_error_tests	

times	=	[	0	]	+	[	i	for	i	in	range	(	2	*	total_num_tests	)	
]	+	[	2	*	total_num_tests	-	1	]	
result	=	self	.	_make_result	(	times	)	
threads	=	[	]	
names	=	[	]	
result	.	startTestRun	(	)	
for	i	in	range	(	num_passing_tests	)	:	
name	=	"str"	%	i	
names	.	append	(	name	)	
test_name	=	"str"	%	name	




test	=	MockTest	(	test_name	)	
threads	.	append	(	threading	.	Thread	(	
target	=	self	.	_simulate_passing_test	,	args	=	(	test	,	result	)	)	)	
for	i	in	range	(	num_failing_tests	)	:	
name	=	"str"	%	i	
names	.	append	(	name	)	
test_name	=	"str"	%	name	
test	=	MockTest	(	test_name	)	
threads	.	append	(	threading	.	Thread	(	
target	=	self	.	_simulate_failing_test	,	args	=	(	test	,	result	)	)	)	
for	i	in	range	(	num_error_tests	)	:	
name	=	"str"	%	i	
names	.	append	(	name	)	
test_name	=	"str"	%	name	
test	=	MockTest	(	test_name	)	
threads	.	append	(	threading	.	Thread	(	
target	=	self	.	_simulate_error_test	,	args	=	(	test	,	result	)	)	)	
for	t	in	threads	:	
t	.	start	(	)	
for	t	in	threads	:	
t	.	join	(	)	

result	.	stopTestRun	(	)	
result	.	printErrors	(	)	
tests_not_in_xml	=	[	]	
for	tn	in	names	:	
if	tn	not	in	self	.	xml_stream	.	getvalue	(	)	:	
tests_not_in_xml	.	append	(	tn	)	
msg	=	(	"str"	
"str"	%	(	
total_num_tests	,	len	(	tests_not_in_xml	)	,	tests_not_in_xml	)	)	
self	.	assertEqual	(	[	]	,	tests_not_in_xml	,	msg	)	

def	test_add_failure_during_stop_test	(	self	)	:	

result	=	self	.	_make_result	(	(	0	,	2	)	)	
test	=	MockTest	(	"str"	)	
result	.	startTestRun	(	)	
result	.	startTest	(	test	)	



with	mock	.	patch	.	object	(	
unittest3_backport	.	TextTestResult	,	
"str"	,	
side_effect	=	lambda	t	:	result	.	addFailure	(	t	,	self	.	get_sample_failure	(	)	)	)	:	



stop_test_thread	=	threading	.	Thread	(	target	=	result	.	stopTest	,	args	=	(	test	,	)	)	
stop_test_thread	.	daemon	=	True	
stop_test_thread	.	start	(	)	

stop_test_thread	.	join	(	10.0	)	
self	.	assertFalse	(	stop_test_thread	.	is_alive	(	)	,	
"str"	)	


class	XMLTest	(	absltest	.	TestCase	)	:	

def	test_escape_xml	(	self	)	:	
self	.	assertEqual	(	xml_reporter	.	_escape_xml_attr	(	"str"	)	,	
"str"	)	


class	XmlReporterFixtureTest	(	absltest	.	TestCase	)	:	

def	_get_helper	(	self	)	:	
binary_name	=	"str"	
return	_bazelize_command	.	get_executable_path	(	binary_name	)	

def	_run_test_and_get_xml	(	self	,	flag	)	:	


xml_fhandle	,	xml_fname	=	tempfile	.	mkstemp	(	)	
os	.	close	(	xml_fhandle	)	

try	:	
binary	=	self	.	_get_helper	(	)	
args	=	[	binary	,	flag	,	"str"	%	xml_fname	]	
ret	=	subprocess	.	call	(	args	)	
self	.	assertNotEqual	(	ret	,	0	)	

xml	=	ElementTree	.	parse	(	xml_fname	)	.	getroot	(	)	
finally	:	
os	.	remove	(	xml_fname	)	

return	xml	

def	_run_test	(	self	,	flag	,	num_errors	,	num_failures	,	suites	)	:	
xml_fhandle	,	xml_fname	=	tempfile	.	mkstemp	(	)	
os	.	close	(	xml_fhandle	)	

try	:	
binary	=	self	.	_get_helper	(	)	
args	=	[	binary	,	flag	,	"str"	%	xml_fname	]	
ret	=	subprocess	.	call	(	args	)	
self	.	assertNotEqual	(	ret	,	0	)	

xml	=	ElementTree	.	parse	(	xml_fname	)	.	getroot	(	)	
logging	.	info	(	"str"	,	ElementTree	.	tostring	(	xml	)	)	
finally	:	
os	.	remove	(	xml_fname	)	

self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	num_errors	)	
self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	num_failures	)	
self	.	assertLen	(	xml	,	len	(	suites	)	)	
actual_suites	=	sorted	(	
xml	.	findall	(	"str"	)	,	key	=	lambda	x	:	x	.	attrib	[	"str"	]	)	
suites	=	sorted	(	suites	,	key	=	lambda	x	:	x	[	"str"	]	)	
for	actual_suite	,	expected_suite	in	zip	(	actual_suites	,	suites	)	:	
self	.	assertEqual	(	actual_suite	.	attrib	[	"str"	]	,	expected_suite	[	"str"	]	)	
self	.	assertLen	(	actual_suite	,	len	(	expected_suite	[	"str"	]	)	)	
actual_cases	=	sorted	(	actual_suite	.	findall	(	"str"	)	,	
key	=	lambda	x	:	x	.	attrib	[	"str"	]	)	
expected_cases	=	sorted	(	expected_suite	[	"str"	]	,	key	=	lambda	x	:	x	[	"str"	]	)	
for	actual_case	,	expected_case	in	zip	(	actual_cases	,	expected_cases	)	:	
self	.	assertEqual	(	actual_case	.	attrib	[	"str"	]	,	expected_case	[	"str"	]	)	
self	.	assertEqual	(	actual_case	.	attrib	[	"str"	]	,	
expected_case	[	"str"	]	)	
if	"str"	in	expected_case	:	
actual_error	=	actual_case	.	find	(	"str"	)	
self	.	assertEqual	(	actual_error	.	attrib	[	"str"	]	,	
expected_case	[	"str"	]	)	
if	"str"	in	expected_case	:	
actual_failure	=	actual_case	.	find	(	"str"	)	
self	.	assertEqual	(	actual_failure	.	attrib	[	"str"	]	,	
expected_case	[	"str"	]	)	

return	xml	

def	_test_for_error	(	self	,	flag	,	message	)	:	

ret	,	xml	=	self	.	_run_test_with_subprocess	(	flag	)	
self	.	assertNotEqual	(	ret	,	0	)	
self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	1	)	
self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	0	)	
for	msg	in	xml	.	iter	(	"str"	)	:	
if	msg	.	attrib	[	"str"	]	==	message	:	
break	
else	:	
self	.	fail	(	msg	=	"str"	%	(	
message	,	ElementTree	.	tostring	(	xml	)	)	)	

def	_test_for_failure	(	self	,	flag	,	message	)	:	

ret	,	xml	=	self	.	_run_test_with_subprocess	(	flag	)	
self	.	assertNotEqual	(	ret	,	0	)	
self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	0	)	
self	.	assertEqual	(	int	(	xml	.	attrib	[	"str"	]	)	,	1	)	
for	msg	in	xml	.	iter	(	"str"	)	:	
if	msg	.	attrib	[	"str"	]	==	message	:	
break	
else	:	
self	.	fail	(	msg	=	"str"	%	message	)	

def	test_set_up_module_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_tear_down_module_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	}	]	}	,	
{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_set_up_class_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_tear_down_class_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	}	,	
{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_set_up_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_tear_down_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_test_error	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_set_up_failure	(	self	)	:	
if	six	.	PY2	:	





self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	
else	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	0	,	
num_failures	=	1	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_tear_down_failure	(	self	)	:	
if	six	.	PY2	:	

self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	1	,	
num_failures	=	0	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	
else	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	0	,	
num_failures	=	1	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	

def	test_test_fail	(	self	)	:	
self	.	_run_test	(	
flag	=	"str"	,	
num_errors	=	0	,	
num_failures	=	1	,	
suites	=	[	{	"str"	:	"str"	,	
"str"	:	[	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	]	}	]	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	