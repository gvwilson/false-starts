















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	copy	
import	pickle	

from	absl	.	_enum_module	import	enum	
from	absl	.	flags	import	_argument_parser	
from	absl	.	flags	import	_exceptions	
from	absl	.	flags	import	_flag	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	


class	FlagTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	flag	=	_flag	.	Flag	(	
_argument_parser	.	ArgumentParser	(	)	,	
_argument_parser	.	ArgumentSerializer	(	)	,	
"str"	,	"str"	,	"str"	)	

def	test_default_unparsed	(	self	)	:	
flag	=	_flag	.	Flag	(	
_argument_parser	.	ArgumentParser	(	)	,	
_argument_parser	.	ArgumentSerializer	(	)	,	
"str"	,	"str"	,	"str"	)	
self	.	assertEqual	(	"str"	,	flag	.	default_unparsed	)	

flag	=	_flag	.	Flag	(	
_argument_parser	.	IntegerParser	(	)	,	
_argument_parser	.	ArgumentSerializer	(	)	,	
"str"	,	"str"	,	"str"	)	
self	.	assertEqual	(	"str"	,	flag	.	default_unparsed	)	

flag	=	_flag	.	Flag	(	
_argument_parser	.	IntegerParser	(	)	,	
_argument_parser	.	ArgumentSerializer	(	)	,	
"str"	,	1	,	"str"	)	
self	.	assertEqual	(	1	,	flag	.	default_unparsed	)	

def	test_set_default_overrides_current_value	(	self	)	:	
self	.	assertEqual	(	"str"	,	self	.	flag	.	value	)	
self	.	flag	.	_set_default	(	"str"	)	
self	.	assertEqual	(	"str"	,	self	.	flag	.	value	)	

def	test_set_default_overrides_current_value_when_not_using_default	(	self	)	:	
self	.	flag	.	using_default_value	=	False	
self	.	assertEqual	(	"str"	,	self	.	flag	.	value	)	
self	.	flag	.	_set_default	(	"str"	)	
self	.	assertEqual	(	"str"	,	self	.	flag	.	value	)	

def	test_pickle	(	self	)	:	
with	self	.	assertRaisesRegexp	(	TypeError	,	"str"	)	:	
pickle	.	dumps	(	self	.	flag	)	

def	test_copy	(	self	)	:	
self	.	flag	.	value	=	"str"	

with	self	.	assertRaisesRegexp	(	
TypeError	,	"str"	)	:	
copy	.	copy	(	self	.	flag	)	

flag2	=	copy	.	deepcopy	(	self	.	flag	)	
self	.	assertEqual	(	flag2	.	value	,	"str"	)	

flag2	.	value	=	"str"	
self	.	assertEqual	(	flag2	.	value	,	"str"	)	
self	.	assertEqual	(	self	.	flag	.	value	,	"str"	)	


class	BooleanFlagTest	(	parameterized	.	TestCase	)	:	

@parameterized.parameters	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	)	
def	test_help_text	(	self	,	helptext_input	,	helptext_output	)	:	
f	=	_flag	.	BooleanFlag	(	"str"	,	False	,	helptext_input	)	
self	.	assertEqual	(	helptext_output	,	f	.	help	)	


class	EnumFlagTest	(	parameterized	.	TestCase	)	:	

@parameterized.parameters	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	)	
def	test_help_text	(	self	,	helptext_input	,	helptext_output	)	:	
f	=	_flag	.	EnumFlag	(	"str"	,	"str"	,	helptext_input	,	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	helptext_output	,	f	.	help	)	

def	test_empty_values	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
_flag	.	EnumFlag	(	"str"	,	None	,	"str"	,	[	]	)	


class	Fruit	(	enum	.	Enum	)	:	
APPLE	=	1	
ORANGE	=	2	


class	EmptyEnum	(	enum	.	Enum	)	:	
pass	


class	EnumClassFlagTest	(	parameterized	.	TestCase	)	:	

@parameterized.parameters	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	)	
def	test_help_text	(	self	,	helptext_input	,	helptext_output	)	:	
f	=	_flag	.	EnumClassFlag	(	"str"	,	None	,	helptext_input	,	Fruit	)	
self	.	assertEqual	(	helptext_output	,	f	.	help	)	

def	test_requires_enum	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
_flag	.	EnumClassFlag	(	"str"	,	None	,	"str"	,	[	"str"	,	"str"	]	)	

def	test_requires_non_empty_enum_class	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
_flag	.	EnumClassFlag	(	"str"	,	None	,	"str"	,	EmptyEnum	)	

def	test_accepts_literal_default	(	self	)	:	
f	=	_flag	.	EnumClassFlag	(	"str"	,	Fruit	.	APPLE	,	"str"	,	Fruit	)	
self	.	assertEqual	(	Fruit	.	APPLE	,	f	.	value	)	

def	test_accepts_string_default	(	self	)	:	
f	=	_flag	.	EnumClassFlag	(	"str"	,	"str"	,	"str"	,	Fruit	)	
self	.	assertEqual	(	Fruit	.	ORANGE	,	f	.	value	)	

def	test_default_value_does_not_exist	(	self	)	:	
with	self	.	assertRaises	(	_exceptions	.	IllegalFlagValueError	)	:	
_flag	.	EnumClassFlag	(	"str"	,	"str"	,	"str"	,	Fruit	)	


class	MultiEnumClassFlagTest	(	parameterized	.	TestCase	)	:	

@parameterized.named_parameters	(	
(	"str"	,	"str"	,	"str"	
"str"	)	,	
(	"str"	,	"str"	,	
"str"	
"str"	)	)	
def	test_help_text	(	self	,	helptext_input	,	helptext_output	)	:	
f	=	_flag	.	MultiEnumClassFlag	(	"str"	,	None	,	helptext_input	,	Fruit	)	
self	.	assertEqual	(	helptext_output	,	f	.	help	)	

def	test_requires_enum	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
_flag	.	MultiEnumClassFlag	(	"str"	,	None	,	"str"	,	[	"str"	,	"str"	]	)	

def	test_requires_non_empty_enum_class	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
_flag	.	MultiEnumClassFlag	(	"str"	,	None	,	"str"	,	EmptyEnum	)	

def	test_accepts_literal_default	(	self	)	:	
f	=	_flag	.	MultiEnumClassFlag	(	"str"	,	Fruit	.	APPLE	,	"str"	,	
Fruit	)	
self	.	assertListEqual	(	[	Fruit	.	APPLE	]	,	f	.	value	)	

def	test_accepts_list_of_literal_default	(	self	)	:	
f	=	_flag	.	MultiEnumClassFlag	(	"str"	,	[	Fruit	.	APPLE	,	Fruit	.	ORANGE	]	,	
"str"	,	Fruit	)	
self	.	assertListEqual	(	[	Fruit	.	APPLE	,	Fruit	.	ORANGE	]	,	f	.	value	)	

def	test_accepts_string_default	(	self	)	:	
f	=	_flag	.	MultiEnumClassFlag	(	"str"	,	"str"	,	"str"	,	
Fruit	)	
self	.	assertListEqual	(	[	Fruit	.	ORANGE	]	,	f	.	value	)	

def	test_accepts_list_of_string_default	(	self	)	:	
f	=	_flag	.	MultiEnumClassFlag	(	"str"	,	[	"str"	,	"str"	]	,	
"str"	,	Fruit	)	
self	.	assertListEqual	(	[	Fruit	.	ORANGE	,	Fruit	.	APPLE	]	,	f	.	value	)	

def	test_default_value_does_not_exist	(	self	)	:	
with	self	.	assertRaises	(	_exceptions	.	IllegalFlagValueError	)	:	
_flag	.	MultiEnumClassFlag	(	"str"	,	"str"	,	"str"	,	Fruit	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	