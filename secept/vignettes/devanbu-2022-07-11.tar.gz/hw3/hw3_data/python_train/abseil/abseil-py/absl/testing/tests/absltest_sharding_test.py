















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	os	
import	subprocess	

from	absl	import	flags	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	

FLAGS	=	flags	.	FLAGS	
NUM_TEST_METHODS	=	8	


class	TestShardingTest	(	absltest	.	TestCase	)	:	


def	setUp	(	self	)	:	
self	.	_test_name	=	"str"	
self	.	_shard_file	=	None	

def	tearDown	(	self	)	:	
if	self	.	_shard_file	is	not	None	and	os	.	path	.	exists	(	self	.	_shard_file	)	:	
os	.	unlink	(	self	.	_shard_file	)	

def	_run_sharded	(	self	,	total_shards	,	shard_index	,	shard_file	=	None	)	:	

env	=	{	"str"	:	str	(	total_shards	)	,	
"str"	:	str	(	shard_index	)	}	
if	"str"	in	os	.	environ	:	


env	[	"str"	]	=	os	.	environ	[	"str"	]	
if	shard_file	:	
self	.	_shard_file	=	shard_file	
env	[	"str"	]	=	shard_file	
if	os	.	path	.	exists	(	shard_file	)	:	
os	.	unlink	(	shard_file	)	

proc	=	subprocess	.	Popen	(	
args	=	[	_bazelize_command	.	get_executable_path	(	self	.	_test_name	)	]	,	
env	=	env	,	
stdout	=	subprocess	.	PIPE	,	
stderr	=	subprocess	.	STDOUT	,	
universal_newlines	=	True	)	
stdout	=	proc	.	communicate	(	)	[	0	]	

if	shard_file	:	
self	.	assertTrue	(	os	.	path	.	exists	(	shard_file	)	)	

return	(	stdout	,	proc	.	wait	(	)	)	

def	_assert_sharding_correctness	(	self	,	total_shards	)	:	


outerr_by_shard	=	[	]	
combined_outerr	=	[	]	
exit_code_by_shard	=	[	]	

for	i	in	range	(	total_shards	)	:	
(	out	,	exit_code	)	=	self	.	_run_sharded	(	total_shards	,	i	)	
method_list	=	[	x	for	x	in	out	.	split	(	"str"	)	if	x	.	startswith	(	"str"	)	]	
outerr_by_shard	.	append	(	method_list	)	
combined_outerr	.	extend	(	method_list	)	
exit_code_by_shard	.	append	(	exit_code	)	

self	.	assertEquals	(	1	,	len	(	[	x	for	x	in	exit_code_by_shard	if	x	!=	0	]	)	,	
"str"	)	


self	.	assertEquals	(	NUM_TEST_METHODS	,	len	(	combined_outerr	)	,	
"str"	)	
self	.	assertEquals	(	NUM_TEST_METHODS	,	len	(	set	(	combined_outerr	)	)	,	
"str"	)	


for	i	in	range	(	len	(	outerr_by_shard	)	)	:	
self	.	assertGreaterEqual	(	len	(	outerr_by_shard	[	i	]	)	,	
(	NUM_TEST_METHODS	/	total_shards	)	-	1	,	
"str"	%	
(	i	,	len	(	outerr_by_shard	)	)	)	

def	test_shard_file	(	self	)	:	
self	.	_run_sharded	(	3	,	1	,	os	.	path	.	join	(	FLAGS	.	test_tmpdir	,	"str"	)	)	

def	test_zero_shards	(	self	)	:	
out	,	exit_code	=	self	.	_run_sharded	(	0	,	0	)	
self	.	assertEquals	(	1	,	exit_code	)	
self	.	assertGreaterEqual	(	out	.	find	(	"str"	)	,	
0	,	"str"	%	(	out	)	)	

def	test_with_four_shards	(	self	)	:	
self	.	_assert_sharding_correctness	(	4	)	

def	test_with_one_shard	(	self	)	:	
self	.	_assert_sharding_correctness	(	1	)	

def	test_with_ten_shards	(	self	)	:	
self	.	_assert_sharding_correctness	(	10	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	