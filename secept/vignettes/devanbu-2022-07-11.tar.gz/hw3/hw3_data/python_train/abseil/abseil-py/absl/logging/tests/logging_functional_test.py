















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	fnmatch	
import	os	
import	re	
import	shutil	
import	subprocess	
import	sys	
import	tempfile	

from	absl	import	flags	
from	absl	import	logging	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	
import	six	

FLAGS	=	flags	.	FLAGS	

_PY_VLOG3_LOG_MESSAGE	=	"str"	

_PY_VLOG2_LOG_MESSAGE	=	"str"	


_PY_DEBUG_LOG_MESSAGE	=	"str"	

_PY_INFO_LOG_MESSAGE	=	"str"	

_PY_INFO_LOG_MESSAGE_NOPREFIX	=	"str"	

_PY_WARNING_LOG_MESSAGE	=	"str"	

if	sys	.	version_info	[	0	:	2	]	==	(	3	,	4	)	:	
_FAKE_ERROR_EXTRA_MESSAGE	=	"str"	
else	:	
_FAKE_ERROR_EXTRA_MESSAGE	=	"str"	

_PY_ERROR_LOG_MESSAGE	=	"str"	.	format	(	fake_error_extra	=	_FAKE_ERROR_EXTRA_MESSAGE	)	


_CRITICAL_DOWNGRADE_TO_ERROR_MESSAGE	=	"str"	


_VERBOSITY_FLAG_TEST_PARAMETERS	=	(	
(	"str"	,	logging	.	FATAL	)	,	
(	"str"	,	logging	.	ERROR	)	,	
(	"str"	,	logging	.	WARN	)	,	
(	"str"	,	logging	.	INFO	)	,	
(	"str"	,	logging	.	DEBUG	)	,	
(	"str"	,	1	)	,	
(	"str"	,	2	)	,	
(	"str"	,	3	)	)	


def	_get_fatal_log_expectation	(	testcase	,	message	,	include_stacktrace	)	:	

def	assert_logs	(	logs	)	:	
if	os	.	name	==	"str"	:	




logs	=	"str"	.	join	(	logs	.	split	(	"str"	)	[	:	-	3	]	)	
format_string	=	(	
"str"	
"str"	)	
expected_logs	=	format_string	%	message	
if	include_stacktrace	:	
expected_logs	+	=	"str"	
if	six	.	PY3	:	
faulthandler_start	=	"str"	
testcase	.	assertIn	(	faulthandler_start	,	logs	)	
log_message	=	logs	.	split	(	faulthandler_start	)	[	0	]	
testcase	.	assertEqual	(	_munge_log	(	expected_logs	)	,	_munge_log	(	log_message	)	)	

return	assert_logs	


def	_munge_log	(	buf	)	:	



buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	


buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	


matched	=	re	.	match	(	"str"	
"str"	,	
buf	)	
if	matched	:	
threadid	=	matched	.	group	(	3	)	
if	int	(	threadid	)	<	0	:	
raise	AssertionError	(	"str"	%	(	threadid	,	buf	)	)	


buf	=	re	.	sub	(	"str"	+	logging	.	ABSL_LOGGING_PREFIX_REGEX	,	
"str"	,	
buf	)	


buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	



buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	(	"str"	
"str"	
"str"	)	,	
"str"	,	
buf	)	
buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	

if	os	.	name	==	"str"	:	


buf	=	re	.	sub	(	"str"	,	
"str"	,	
buf	)	

return	buf	


def	_verify_status	(	expected	,	actual	,	output	)	:	
if	expected	!=	actual	:	
raise	AssertionError	(	
"str"	
"str"	%	(	actual	,	expected	,	output	)	)	


def	_verify_ok	(	status	,	output	)	:	

_verify_status	(	0	,	status	,	output	)	


def	_verify_fatal	(	status	,	output	)	:	




expected_exit_code	=	3	if	os	.	name	==	"str"	else	-	6	
_verify_status	(	expected_exit_code	,	status	,	output	)	


def	_verify_assert	(	status	,	output	)	:	

_verify_status	(	1	,	status	,	output	)	


class	FunctionalTest	(	parameterized	.	TestCase	)	:	


def	_get_helper	(	self	)	:	
helper_name	=	"str"	
return	_bazelize_command	.	get_executable_path	(	helper_name	)	

def	_get_logs	(	self	,	
verbosity	,	
include_info_prefix	=	True	)	:	
logs	=	[	]	
if	verbosity	>	=	3	:	
logs	.	append	(	_PY_VLOG3_LOG_MESSAGE	)	
if	verbosity	>	=	2	:	
logs	.	append	(	_PY_VLOG2_LOG_MESSAGE	)	
if	verbosity	>	=	logging	.	DEBUG	:	
logs	.	append	(	_PY_DEBUG_LOG_MESSAGE	)	

if	verbosity	>	=	logging	.	INFO	:	
if	include_info_prefix	:	
logs	.	append	(	_PY_INFO_LOG_MESSAGE	)	
else	:	
logs	.	append	(	_PY_INFO_LOG_MESSAGE_NOPREFIX	)	
if	verbosity	>	=	logging	.	WARN	:	
logs	.	append	(	_PY_WARNING_LOG_MESSAGE	)	
if	verbosity	>	=	logging	.	ERROR	:	
logs	.	append	(	_PY_ERROR_LOG_MESSAGE	)	

expected_logs	=	"str"	.	join	(	logs	)	
if	six	.	PY3	:	

expected_logs	=	expected_logs	.	replace	(	
"str"	,	"str"	)	
return	expected_logs	

def	setUp	(	self	)	:	
self	.	_log_dir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	

def	tearDown	(	self	)	:	
shutil	.	rmtree	(	self	.	_log_dir	)	

def	_exec_test	(	self	,	
verify_exit_fn	,	
expected_logs	,	
test_name	=	"str"	,	
pass_logtostderr	=	False	,	
use_absl_log_file	=	False	,	
show_info_prefix	=	1	,	
extra_args	=	(	)	)	:	

args	=	[	"str"	%	self	.	_log_dir	]	
if	pass_logtostderr	:	
args	.	append	(	"str"	)	
if	not	show_info_prefix	:	
args	.	append	(	"str"	)	
args	+	=	extra_args	


env	=	os	.	environ	.	copy	(	)	
env	.	update	(	{	
"str"	:	test_name	,	
"str"	:	"str"	%	(	use_absl_log_file	,	)	,	
}	)	
cmd	=	[	self	.	_get_helper	(	)	]	+	args	

print	(	"str"	%	env	,	file	=	sys	.	stderr	)	
print	(	"str"	%	cmd	,	file	=	sys	.	stderr	)	
process	=	subprocess	.	Popen	(	
cmd	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	STDOUT	,	env	=	env	,	
universal_newlines	=	True	)	
output	,	_	=	process	.	communicate	(	)	
status	=	process	.	returncode	


verify_exit_fn	(	status	,	output	)	


if	expected_logs	is	None	:	
return	


logs	=	os	.	listdir	(	self	.	_log_dir	)	
logs	=	fnmatch	.	filter	(	logs	,	"str"	)	
logs	.	append	(	"str"	)	


matched	=	[	]	
unmatched	=	[	]	
unexpected	=	logs	[	:	]	
for	log_prefix	,	log_type	,	expected	in	expected_logs	:	

if	log_prefix	==	"str"	:	
assert	log_type	is	None	
pattern	=	"str"	
else	:	
pattern	=	"str"	%	(	log_prefix	,	log_type	)	


for	basename	in	logs	:	
if	re	.	match	(	pattern	,	basename	)	:	
matched	.	append	(	[	expected	,	basename	]	)	
unexpected	.	remove	(	basename	)	
break	
else	:	
unmatched	.	append	(	pattern	)	


errors	=	"str"	
if	unmatched	:	
errors	+	=	"str"	%	(	
"str"	.	join	(	unmatched	)	)	
if	unexpected	:	
if	errors	:	
errors	+	=	"str"	
errors	+	=	"str"	%	(	
"str"	.	join	(	unexpected	)	)	
if	errors	:	
raise	AssertionError	(	errors	)	


for	(	expected	,	basename	)	in	matched	:	
if	expected	is	None	:	
continue	

if	basename	==	"str"	:	
actual	=	output	
else	:	
path	=	os	.	path	.	join	(	self	.	_log_dir	,	basename	)	
if	six	.	PY2	:	
f	=	open	(	path	)	
else	:	
f	=	open	(	path	,	encoding	=	"str"	)	
with	f	:	
actual	=	f	.	read	(	)	

if	callable	(	expected	)	:	
try	:	
expected	(	actual	)	
except	AssertionError	:	
print	(	"str"	.	format	(	
basename	,	actual	)	,	file	=	sys	.	stderr	)	
raise	
elif	isinstance	(	expected	,	str	)	:	
self	.	assertMultiLineEqual	(	_munge_log	(	expected	)	,	_munge_log	(	actual	)	,	
"str"	%	basename	)	
else	:	
self	.	fail	(	
"str"	.	format	(	
expected	,	type	(	expected	)	)	)	

@parameterized.named_parameters	(	
(	"str"	,	False	)	,	
(	"str"	,	True	)	)	
def	test_py_logging	(	self	,	logtostderr	)	:	

self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	logging	.	INFO	)	]	]	,	
pass_logtostderr	=	logtostderr	)	

def	test_py_logging_use_absl_log_file	(	self	)	:	

self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	"str"	]	,	
[	"str"	,	"str"	,	self	.	_get_logs	(	logging	.	INFO	)	]	]	,	
use_absl_log_file	=	True	)	

def	test_py_logging_use_absl_log_file_logtostderr	(	self	)	:	


self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	logging	.	INFO	)	]	]	,	
pass_logtostderr	=	True	,	
use_absl_log_file	=	True	)	

@parameterized.named_parameters	(	
(	"str"	,	False	)	,	
(	"str"	,	True	)	)	
def	test_py_logging_noshowprefixforinfo	(	self	,	logtostderr	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	logging	.	INFO	,	
include_info_prefix	=	False	)	]	]	,	
pass_logtostderr	=	logtostderr	,	
show_info_prefix	=	0	)	

def	test_py_logging_noshowprefixforinfo_use_absl_log_file	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	"str"	]	,	
[	"str"	,	"str"	,	self	.	_get_logs	(	logging	.	INFO	)	]	]	,	
show_info_prefix	=	0	,	
use_absl_log_file	=	True	)	

def	test_py_logging_noshowprefixforinfo_use_absl_log_file_logtostderr	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	logging	.	INFO	,	
include_info_prefix	=	False	)	]	]	,	
pass_logtostderr	=	True	,	
show_info_prefix	=	0	,	
use_absl_log_file	=	True	)	

def	test_py_logging_noshowprefixforinfo_verbosity	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	logging	.	DEBUG	)	]	]	,	
pass_logtostderr	=	True	,	
show_info_prefix	=	0	,	
use_absl_log_file	=	True	,	
extra_args	=	[	"str"	]	)	

def	test_py_logging_fatal_main_thread_only	(	self	)	:	
self	.	_exec_test	(	
_verify_fatal	,	
[	[	"str"	,	None	,	_get_fatal_log_expectation	(	
self	,	"str"	,	False	)	]	]	,	
test_name	=	"str"	)	

def	test_py_logging_fatal_with_other_threads	(	self	)	:	
self	.	_exec_test	(	
_verify_fatal	,	
[	[	"str"	,	None	,	_get_fatal_log_expectation	(	
self	,	"str"	,	False	)	]	]	,	
test_name	=	"str"	)	

def	test_py_logging_fatal_non_main_thread	(	self	)	:	
self	.	_exec_test	(	
_verify_fatal	,	
[	[	"str"	,	None	,	_get_fatal_log_expectation	(	
self	,	"str"	,	False	)	]	]	,	
test_name	=	"str"	)	

def	test_py_logging_critical_non_absl	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	_CRITICAL_DOWNGRADE_TO_ERROR_MESSAGE	]	]	,	
test_name	=	"str"	)	

def	test_py_logging_skip_log_prefix	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	"str"	]	]	,	
test_name	=	"str"	)	

def	test_py_logging_flush	(	self	)	:	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	"str"	]	]	,	
test_name	=	"str"	)	

@parameterized.named_parameters	(	*	_VERBOSITY_FLAG_TEST_PARAMETERS	)	
def	test_py_logging_verbosity_stderr	(	self	,	verbosity	)	:	

v_flag	=	"str"	%	verbosity	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	self	.	_get_logs	(	verbosity	)	]	]	,	
extra_args	=	[	v_flag	]	)	

@parameterized.named_parameters	(	*	_VERBOSITY_FLAG_TEST_PARAMETERS	)	
def	test_py_logging_verbosity_file	(	self	,	verbosity	)	:	

v_flag	=	"str"	%	verbosity	
self	.	_exec_test	(	
_verify_ok	,	
[	[	"str"	,	None	,	"str"	]	,	


[	"str"	,	"str"	,	self	.	_get_logs	(	verbosity	)	]	]	,	
use_absl_log_file	=	True	,	
extra_args	=	[	v_flag	]	)	

def	test_stderrthreshold_py_logging	(	self	)	:	


stderr_logs	=	"str"	

expected_logs	=	[	
[	"str"	,	None	,	stderr_logs	]	,	
[	"str"	,	"str"	,	None	]	,	
]	

extra_args	=	[	"str"	]	

self	.	_exec_test	(	
_verify_ok	,	
expected_logs	,	
test_name	=	"str"	,	
extra_args	=	extra_args	,	
use_absl_log_file	=	True	)	

def	test_std_logging_py_logging	(	self	)	:	

stderr_logs	=	"str"	
expected_logs	=	[	[	"str"	,	None	,	stderr_logs	]	]	

extra_args	=	[	"str"	,	"str"	]	
self	.	_exec_test	(	
_verify_ok	,	
expected_logs	,	
test_name	=	"str"	,	
extra_args	=	extra_args	)	

def	test_bad_exc_info_py_logging	(	self	)	:	

def	assert_stderr	(	stderr	)	:	


self	.	assertIn	(	"str"	,	stderr	)	
self	.	assertIn	(	"str"	,	stderr	)	

expected_logs	=	[	
[	"str"	,	None	,	assert_stderr	]	,	
[	"str"	,	"str"	,	"str"	]	]	

self	.	_exec_test	(	
_verify_ok	,	
expected_logs	,	
test_name	=	"str"	,	
use_absl_log_file	=	True	)	

def	test_none_exc_info_py_logging	(	self	)	:	

if	six	.	PY2	:	
expected_stderr	=	"str"	
expected_info	=	"str"	
else	:	
if	sys	.	version_info	[	0	:	2	]	==	(	3	,	4	)	:	

def	expected_stderr	(	stderr	)	:	
regex	=	"str"	
if	not	re	.	search	(	regex	,	stderr	,	flags	=	re	.	DOTALL	|	re	.	MULTILINE	)	:	
self	.	fail	(	"str"	%	(	regex	,	stderr	)	)	
expected_info	=	"str"	
else	:	
expected_stderr	=	"str"	
expected_info	=	"str"	

if	(	3	,	5	,	0	)	<	=	sys	.	version_info	[	:	3	]	<	=	(	3	,	5	,	2	)	:	
expected_info	+	=	"str"	
else	:	
expected_info	+	=	"str"	

expected_logs	=	[	
[	"str"	,	None	,	expected_stderr	]	,	
[	"str"	,	"str"	,	expected_info	]	]	

self	.	_exec_test	(	
_verify_ok	,	
expected_logs	,	
test_name	=	"str"	,	
use_absl_log_file	=	True	)	

def	test_unicode_py_logging	(	self	)	:	

def	get_stderr_message	(	stderr	,	name	)	:	
match	=	re	.	search	(	
"str"	.	format	(	name	,	name	)	,	
stderr	,	re	.	MULTILINE	|	re	.	DOTALL	)	
self	.	assertTrue	(	
match	,	"str"	.	format	(	name	)	)	
return	match	.	group	(	1	)	

def	assert_stderr_python2	(	stderr	)	:	


for	name	in	(	"str"	,	"str"	,	"str"	)	:	
self	.	assertEqual	(	"str"	,	get_stderr_message	(	stderr	,	name	)	)	


for	name	in	(	
"str"	,	"str"	,	"str"	)	:	
self	.	assertIn	(	"str"	,	
get_stderr_message	(	stderr	,	name	)	)	
self	.	assertIn	(	"str"	,	
get_stderr_message	(	stderr	,	name	)	)	


self	.	assertIn	(	"str"	,	
get_stderr_message	(	stderr	,	"str"	)	)	
self	.	assertIn	(	"str"	,	
get_stderr_message	(	stderr	,	"str"	)	)	

def	assert_stderr_python3	(	stderr	)	:	


for	name	in	(	
"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	
"str"	)	:	
logging	.	info	(	"str"	,	name	)	
self	.	assertEqual	(	"str"	,	get_stderr_message	(	stderr	,	name	)	)	

expected_logs	=	[	[	
"str"	,	None	,	
assert_stderr_python2	if	six	.	PY2	else	assert_stderr_python3	]	]	

if	six	.	PY2	:	

info_log	=	"str"	.	encode	(	"str"	)	
else	:	

info_log	=	"str"	
expected_logs	.	append	(	[	"str"	,	"str"	,	info_log	]	)	

self	.	_exec_test	(	
_verify_ok	,	
expected_logs	,	
test_name	=	"str"	,	
use_absl_log_file	=	True	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	