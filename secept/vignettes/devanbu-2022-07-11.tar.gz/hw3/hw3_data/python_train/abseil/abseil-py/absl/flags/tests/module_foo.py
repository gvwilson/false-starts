















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	import	flags	
from	absl	.	flags	import	_helpers	
from	absl	.	flags	.	tests	import	module_bar	

FLAGS	=	flags	.	FLAGS	


DECLARED_KEY_FLAGS	=	[	"str"	,	"str"	,	"str"	,	

"str"	]	


def	define_flags	(	flag_values	=	FLAGS	)	:	

module_bar	.	define_flags	(	flag_values	=	flag_values	)	


flags	.	DEFINE_boolean	(	"str"	,	True	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	
flag_values	=	flag_values	)	
flags	.	DEFINE_integer	(	"str"	,	3	,	"str"	,	
flag_values	=	flag_values	)	


def	declare_key_flags	(	flag_values	=	FLAGS	)	:	

for	flag_name	in	DECLARED_KEY_FLAGS	:	
flags	.	declare_key_flag	(	flag_name	,	flag_values	=	flag_values	)	


def	declare_extra_key_flags	(	flag_values	=	FLAGS	)	:	

flags	.	adopt_module_key_flags	(	module_bar	,	flag_values	=	flag_values	)	


def	names_of_defined_flags	(	)	:	

return	[	"str"	,	"str"	,	"str"	]	


def	names_of_declared_key_flags	(	)	:	

return	names_of_defined_flags	(	)	+	DECLARED_KEY_FLAGS	


def	names_of_declared_extra_key_flags	(	)	:	

names_of_extra_key_flags	=	list	(	module_bar	.	names_of_defined_flags	(	)	)	
for	flag_name	in	names_of_declared_key_flags	(	)	:	
while	flag_name	in	names_of_extra_key_flags	:	
names_of_extra_key_flags	.	remove	(	flag_name	)	
return	names_of_extra_key_flags	


def	remove_flags	(	flag_values	=	FLAGS	)	:	

for	flag_name	in	names_of_defined_flags	(	)	:	
module_bar	.	remove_one_flag	(	flag_name	,	flag_values	=	flag_values	)	
module_bar	.	remove_flags	(	flag_values	=	flag_values	)	


def	get_module_name	(	)	:	

return	_helpers	.	get_calling_module	(	)	


def	duplicate_flags	(	flagnames	=	None	)	:	

flag_values	=	flags	.	FlagValues	(	)	
for	name	in	flagnames	:	
flags	.	DEFINE_boolean	(	name	,	False	,	"str"	%	(	name	,	)	,	
flag_values	=	flag_values	)	
return	flag_values	


def	define_bar_flags	(	flag_values	=	FLAGS	)	:	

module_bar	.	define_flags	(	flag_values	)	
	