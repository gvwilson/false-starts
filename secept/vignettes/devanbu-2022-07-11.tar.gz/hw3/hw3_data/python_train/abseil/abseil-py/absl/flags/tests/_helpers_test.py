















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	sys	

from	absl	.	flags	import	_helpers	
from	absl	.	flags	.	tests	import	module_bar	
from	absl	.	flags	.	tests	import	module_foo	
from	absl	.	testing	import	absltest	


class	FlagSuggestionTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	longopts	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	

def	test_damerau_levenshtein_id	(	self	)	:	
self	.	assertEqual	(	0	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	

def	test_damerau_levenshtein_empty	(	self	)	:	
self	.	assertEqual	(	5	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	6	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	

def	test_damerau_levenshtein_commutative	(	self	)	:	
self	.	assertEqual	(	2	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	
self	.	assertEqual	(	2	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	

def	test_damerau_levenshtein_transposition	(	self	)	:	
self	.	assertEqual	(	1	,	_helpers	.	_damerau_levenshtein	(	"str"	,	"str"	)	)	

def	test_mispelled_suggestions	(	self	)	:	
suggestions	=	_helpers	.	get_flag_suggestions	(	"str"	,	
self	.	longopts	)	
self	.	assertEqual	(	[	"str"	]	,	suggestions	)	

def	test_ambiguous_prefix_suggestion	(	self	)	:	
suggestions	=	_helpers	.	get_flag_suggestions	(	"str"	,	self	.	longopts	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	suggestions	)	

def	test_misspelled_ambiguous_prefix_suggestion	(	self	)	:	
suggestions	=	_helpers	.	get_flag_suggestions	(	"str"	,	self	.	longopts	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	suggestions	)	

def	test_crazy_suggestion	(	self	)	:	
suggestions	=	_helpers	.	get_flag_suggestions	(	"str"	,	self	.	longopts	)	
self	.	assertEqual	(	[	]	,	suggestions	)	

def	test_suggestions_are_sorted	(	self	)	:	
sorted_flags	=	sorted	(	[	"str"	,	"str"	,	"str"	]	)	
misspelt_flag	=	"str"	
suggestions	=	_helpers	.	get_flag_suggestions	(	misspelt_flag	,	
reversed	(	sorted_flags	)	)	
self	.	assertEqual	(	sorted_flags	,	suggestions	)	


class	GetCallingModuleTest	(	absltest	.	TestCase	)	:	


def	test_get_calling_module	(	self	)	:	
self	.	assertEqual	(	_helpers	.	get_calling_module	(	)	,	sys	.	argv	[	0	]	)	
self	.	assertEqual	(	module_foo	.	get_module_name	(	)	,	
"str"	)	
self	.	assertEqual	(	module_bar	.	get_module_name	(	)	,	
"str"	)	






code	=	(	"str"	
"str"	)	
exec	(	code	)	




exec	(	code	,	{	}	)	





exec	(	code	,	dict	(	vars	(	self	)	)	)	







global_dict	=	{	}	
exec	(	code	,	global_dict	)	
self	.	assertEqual	(	global_dict	[	"str"	]	,	
sys	.	argv	[	0	]	)	

global_dict	=	{	}	
module_bar	.	execute_code	(	code	,	global_dict	)	
self	.	assertEqual	(	global_dict	[	"str"	]	,	
"str"	)	

def	test_get_calling_module_with_iteritems_error	(	self	)	:	


orig_sys_modules	=	sys	.	modules	



class	SysModulesMock	(	dict	)	:	

def	__init__	(	self	,	original_content	)	:	
dict	.	__init__	(	self	,	original_content	)	

def	iteritems	(	self	)	:	

raise	RuntimeError	(	"str"	)	

sys	.	modules	=	SysModulesMock	(	orig_sys_modules	)	
try	:	

self	.	assertEqual	(	_helpers	.	get_calling_module	(	)	,	sys	.	argv	[	0	]	)	
self	.	assertEqual	(	module_foo	.	get_module_name	(	)	,	
"str"	)	
finally	:	
sys	.	modules	=	orig_sys_modules	


class	IsBytesOrString	(	absltest	.	TestCase	)	:	

def	test_bytes	(	self	)	:	
self	.	assertTrue	(	_helpers	.	is_bytes_or_string	(	b	"str"	)	)	

def	test_str	(	self	)	:	
self	.	assertTrue	(	_helpers	.	is_bytes_or_string	(	"str"	)	)	

def	test_unicode	(	self	)	:	
self	.	assertTrue	(	_helpers	.	is_bytes_or_string	(	"str"	)	)	

def	test_list	(	self	)	:	
self	.	assertFalse	(	_helpers	.	is_bytes_or_string	(	[	"str"	]	)	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	