















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	csv	
import	io	
import	string	

from	absl	.	flags	import	_helpers	
import	six	


def	_is_integer_type	(	instance	)	:	

return	(	isinstance	(	instance	,	six	.	integer_types	)	and	
not	isinstance	(	instance	,	bool	)	)	


class	_ArgumentParserCache	(	type	)	:	


_instances	=	{	}	

def	__call__	(	cls	,	*	args	,	*	*	kwargs	)	:	

if	kwargs	:	
return	type	.	__call__	(	cls	,	*	args	,	*	*	kwargs	)	
else	:	
instances	=	cls	.	_instances	
key	=	(	cls	,	)	+	tuple	(	args	)	
try	:	
return	instances	[	key	]	
except	KeyError	:	

return	instances	.	setdefault	(	key	,	type	.	__call__	(	cls	,	*	args	)	)	
except	TypeError	:	


return	type	.	__call__	(	cls	,	*	args	)	


class	ArgumentParser	(	six	.	with_metaclass	(	_ArgumentParserCache	,	object	)	)	:	


syntactic_help	=	"str"	

def	parse	(	self	,	argument	)	:	

if	not	isinstance	(	argument	,	six	.	string_types	)	:	
raise	TypeError	(	"str"	.	format	(	
type	(	argument	)	)	)	
return	argument	

def	flag_type	(	self	)	:	

return	"str"	

def	_custom_xml_dom_elements	(	self	,	doc	)	:	

del	doc	
return	[	]	


class	ArgumentSerializer	(	object	)	:	


def	serialize	(	self	,	value	)	:	

return	_helpers	.	str_or_unicode	(	value	)	


class	NumericParser	(	ArgumentParser	)	:	


def	is_outside_bounds	(	self	,	val	)	:	

return	(	(	self	.	lower_bound	is	not	None	and	val	<	self	.	lower_bound	)	or	
(	self	.	upper_bound	is	not	None	and	val	>	self	.	upper_bound	)	)	

def	parse	(	self	,	argument	)	:	

val	=	self	.	convert	(	argument	)	
if	self	.	is_outside_bounds	(	val	)	:	
raise	ValueError	(	"str"	%	(	val	,	self	.	syntactic_help	)	)	
return	val	

def	_custom_xml_dom_elements	(	self	,	doc	)	:	
elements	=	[	]	
if	self	.	lower_bound	is	not	None	:	
elements	.	append	(	_helpers	.	create_xml_dom_element	(	
doc	,	"str"	,	self	.	lower_bound	)	)	
if	self	.	upper_bound	is	not	None	:	
elements	.	append	(	_helpers	.	create_xml_dom_element	(	
doc	,	"str"	,	self	.	upper_bound	)	)	
return	elements	

def	convert	(	self	,	argument	)	:	

raise	NotImplementedError	


class	FloatParser	(	NumericParser	)	:	

number_article	=	"str"	
number_name	=	"str"	
syntactic_help	=	"str"	.	join	(	(	number_article	,	number_name	)	)	

def	__init__	(	self	,	lower_bound	=	None	,	upper_bound	=	None	)	:	
super	(	FloatParser	,	self	)	.	__init__	(	)	
self	.	lower_bound	=	lower_bound	
self	.	upper_bound	=	upper_bound	
sh	=	self	.	syntactic_help	
if	lower_bound	is	not	None	and	upper_bound	is	not	None	:	
sh	=	(	"str"	%	(	sh	,	lower_bound	,	upper_bound	)	)	
elif	lower_bound	==	0	:	
sh	=	"str"	%	self	.	number_name	
elif	upper_bound	==	0	:	
sh	=	"str"	%	self	.	number_name	
elif	upper_bound	is	not	None	:	
sh	=	"str"	%	(	self	.	number_name	,	upper_bound	)	
elif	lower_bound	is	not	None	:	
sh	=	"str"	%	(	self	.	number_name	,	lower_bound	)	
self	.	syntactic_help	=	sh	

def	convert	(	self	,	argument	)	:	

if	(	_is_integer_type	(	argument	)	or	isinstance	(	argument	,	float	)	or	
isinstance	(	argument	,	six	.	string_types	)	)	:	
return	float	(	argument	)	
else	:	
raise	TypeError	(	
"str"	.	format	(	
type	(	argument	)	)	)	

def	flag_type	(	self	)	:	

return	"str"	


class	IntegerParser	(	NumericParser	)	:	

number_article	=	"str"	
number_name	=	"str"	
syntactic_help	=	"str"	.	join	(	(	number_article	,	number_name	)	)	

def	__init__	(	self	,	lower_bound	=	None	,	upper_bound	=	None	)	:	
super	(	IntegerParser	,	self	)	.	__init__	(	)	
self	.	lower_bound	=	lower_bound	
self	.	upper_bound	=	upper_bound	
sh	=	self	.	syntactic_help	
if	lower_bound	is	not	None	and	upper_bound	is	not	None	:	
sh	=	(	"str"	%	(	sh	,	lower_bound	,	upper_bound	)	)	
elif	lower_bound	==	1	:	
sh	=	"str"	%	self	.	number_name	
elif	upper_bound	==	-	1	:	
sh	=	"str"	%	self	.	number_name	
elif	lower_bound	==	0	:	
sh	=	"str"	%	self	.	number_name	
elif	upper_bound	==	0	:	
sh	=	"str"	%	self	.	number_name	
elif	upper_bound	is	not	None	:	
sh	=	"str"	%	(	self	.	number_name	,	upper_bound	)	
elif	lower_bound	is	not	None	:	
sh	=	"str"	%	(	self	.	number_name	,	lower_bound	)	
self	.	syntactic_help	=	sh	

def	convert	(	self	,	argument	)	:	

if	_is_integer_type	(	argument	)	:	
return	argument	
elif	isinstance	(	argument	,	six	.	string_types	)	:	
base	=	10	
if	len	(	argument	)	>	2	and	argument	[	0	]	==	"str"	:	
if	argument	[	1	]	==	"str"	:	
base	=	8	
elif	argument	[	1	]	==	"str"	:	
base	=	16	
return	int	(	argument	,	base	)	
else	:	
raise	TypeError	(	"str"	.	format	(	
type	(	argument	)	)	)	

def	flag_type	(	self	)	:	

return	"str"	


class	BooleanParser	(	ArgumentParser	)	:	


def	parse	(	self	,	argument	)	:	

if	isinstance	(	argument	,	six	.	string_types	)	:	
if	argument	.	lower	(	)	in	(	"str"	,	"str"	,	"str"	)	:	
return	True	
elif	argument	.	lower	(	)	in	(	"str"	,	"str"	,	"str"	)	:	
return	False	
else	:	
raise	ValueError	(	"str"	,	argument	)	
elif	isinstance	(	argument	,	six	.	integer_types	)	:	


bool_value	=	bool	(	argument	)	
if	argument	==	bool_value	:	
return	bool_value	
else	:	
raise	ValueError	(	"str"	,	argument	)	

raise	TypeError	(	"str"	,	argument	)	

def	flag_type	(	self	)	:	

return	"str"	


class	EnumParser	(	ArgumentParser	)	:	


def	__init__	(	self	,	enum_values	,	case_sensitive	=	True	)	:	

if	not	enum_values	:	
raise	ValueError	(	
"str"	.	format	(	enum_values	)	)	
super	(	EnumParser	,	self	)	.	__init__	(	)	
self	.	enum_values	=	enum_values	
self	.	case_sensitive	=	case_sensitive	

def	parse	(	self	,	argument	)	:	

if	self	.	case_sensitive	:	
if	argument	not	in	self	.	enum_values	:	
raise	ValueError	(	"str"	%	
"str"	.	join	(	self	.	enum_values	)	)	
else	:	
return	argument	
else	:	
if	argument	.	upper	(	)	not	in	[	value	.	upper	(	)	for	value	in	self	.	enum_values	]	:	
raise	ValueError	(	"str"	%	
"str"	.	join	(	self	.	enum_values	)	)	
else	:	
return	[	value	for	value	in	self	.	enum_values	
if	value	.	upper	(	)	==	argument	.	upper	(	)	]	[	0	]	

def	flag_type	(	self	)	:	

return	"str"	


class	EnumClassParser	(	ArgumentParser	)	:	


def	__init__	(	self	,	enum_class	)	:	



import	enum	

if	not	issubclass	(	enum_class	,	enum	.	Enum	)	:	
raise	TypeError	(	"str"	.	format	(	enum_class	)	)	
if	not	enum_class	.	__members__	:	
raise	ValueError	(	"str"	
.	format	(	enum_class	)	)	

super	(	EnumClassParser	,	self	)	.	__init__	(	)	
self	.	enum_class	=	enum_class	

def	parse	(	self	,	argument	)	:	

if	isinstance	(	argument	,	self	.	enum_class	)	:	
return	argument	
if	argument	not	in	self	.	enum_class	.	__members__	:	
raise	ValueError	(	"str"	%	
"str"	.	join	(	self	.	enum_class	.	__members__	.	keys	(	)	)	)	
else	:	
return	self	.	enum_class	[	argument	]	

def	flag_type	(	self	)	:	

return	"str"	


class	ListSerializer	(	ArgumentSerializer	)	:	

def	__init__	(	self	,	list_sep	)	:	
self	.	list_sep	=	list_sep	

def	serialize	(	self	,	value	)	:	

return	self	.	list_sep	.	join	(	[	_helpers	.	str_or_unicode	(	x	)	for	x	in	value	]	)	


class	EnumClassListSerializer	(	ListSerializer	)	:	

def	serialize	(	self	,	value	)	:	

if	isinstance	(	value	,	list	)	:	
return	self	.	list_sep	.	join	(	_helpers	.	str_or_unicode	(	x	.	name	)	for	x	in	value	)	
else	:	
return	_helpers	.	str_or_unicode	(	value	.	name	)	


class	CsvListSerializer	(	ArgumentSerializer	)	:	

def	__init__	(	self	,	list_sep	)	:	
self	.	list_sep	=	list_sep	

def	serialize	(	self	,	value	)	:	

if	six	.	PY2	:	

output	=	io	.	BytesIO	(	)	
csv	.	writer	(	output	)	.	writerow	(	[	unicode	(	x	)	.	encode	(	"str"	)	for	x	in	value	]	)	
serialized_value	=	output	.	getvalue	(	)	.	decode	(	"str"	)	.	strip	(	)	
else	:	

output	=	io	.	StringIO	(	)	
csv	.	writer	(	output	)	.	writerow	(	[	str	(	x	)	for	x	in	value	]	)	
serialized_value	=	output	.	getvalue	(	)	.	strip	(	)	



return	_helpers	.	str_or_unicode	(	serialized_value	)	


class	EnumClassSerializer	(	ArgumentSerializer	)	:	


def	serialize	(	self	,	value	)	:	

return	_helpers	.	str_or_unicode	(	value	.	name	)	


class	BaseListParser	(	ArgumentParser	)	:	


def	__init__	(	self	,	token	=	None	,	name	=	None	)	:	
assert	name	
super	(	BaseListParser	,	self	)	.	__init__	(	)	
self	.	_token	=	token	
self	.	_name	=	name	
self	.	syntactic_help	=	"str"	%	self	.	_name	

def	parse	(	self	,	argument	)	:	

if	isinstance	(	argument	,	list	)	:	
return	argument	
elif	not	argument	:	
return	[	]	
else	:	
return	[	s	.	strip	(	)	for	s	in	argument	.	split	(	self	.	_token	)	]	

def	flag_type	(	self	)	:	

return	"str"	%	self	.	_name	


class	ListParser	(	BaseListParser	)	:	


def	__init__	(	self	)	:	
super	(	ListParser	,	self	)	.	__init__	(	"str"	,	"str"	)	

def	parse	(	self	,	argument	)	:	

if	isinstance	(	argument	,	list	)	:	
return	argument	
elif	not	argument	:	
return	[	]	
else	:	
try	:	
return	[	s	.	strip	(	)	for	s	in	list	(	csv	.	reader	(	[	argument	]	,	strict	=	True	)	)	[	0	]	]	
except	csv	.	Error	as	e	:	





raise	ValueError	(	"str"	
%	(	argument	,	self	.	flag_type	(	)	,	e	)	)	

def	_custom_xml_dom_elements	(	self	,	doc	)	:	
elements	=	super	(	ListParser	,	self	)	.	_custom_xml_dom_elements	(	doc	)	
elements	.	append	(	_helpers	.	create_xml_dom_element	(	
doc	,	"str"	,	repr	(	"str"	)	)	)	
return	elements	


class	WhitespaceSeparatedListParser	(	BaseListParser	)	:	


def	__init__	(	self	,	comma_compat	=	False	)	:	

self	.	_comma_compat	=	comma_compat	
name	=	"str"	if	self	.	_comma_compat	else	"str"	
super	(	WhitespaceSeparatedListParser	,	self	)	.	__init__	(	None	,	name	)	

def	parse	(	self	,	argument	)	:	

if	isinstance	(	argument	,	list	)	:	
return	argument	
elif	not	argument	:	
return	[	]	
else	:	
if	self	.	_comma_compat	:	
argument	=	argument	.	replace	(	"str"	,	"str"	)	
return	argument	.	split	(	)	

def	_custom_xml_dom_elements	(	self	,	doc	)	:	
elements	=	super	(	WhitespaceSeparatedListParser	,	self	
)	.	_custom_xml_dom_elements	(	doc	)	
separators	=	list	(	string	.	whitespace	)	
if	self	.	_comma_compat	:	
separators	.	append	(	"str"	)	
separators	.	sort	(	)	
for	sep_char	in	separators	:	
elements	.	append	(	_helpers	.	create_xml_dom_element	(	
doc	,	"str"	,	repr	(	sep_char	)	)	)	
return	elements	
	