















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	sys	

from	absl	.	flags	import	_helpers	


_helpers	.	disclaim_module_ids	.	add	(	id	(	sys	.	modules	[	__name__	]	)	)	


class	Error	(	Exception	)	:	



class	CantOpenFlagFileError	(	Error	)	:	



class	DuplicateFlagError	(	Error	)	:	


@classmethod	
def	from_flag	(	cls	,	flagname	,	flag_values	,	other_flag_values	=	None	)	:	

first_module	=	flag_values	.	find_module_defining_flag	(	
flagname	,	default	=	"str"	)	
if	other_flag_values	is	None	:	
second_module	=	_helpers	.	get_calling_module	(	)	
else	:	
second_module	=	other_flag_values	.	find_module_defining_flag	(	
flagname	,	default	=	"str"	)	
flag_summary	=	flag_values	[	flagname	]	.	help	
msg	=	(	"str"	
"str"	)	%	(	
flagname	,	first_module	,	second_module	,	flag_summary	)	
return	cls	(	msg	)	


class	IllegalFlagValueError	(	Error	)	:	



class	UnrecognizedFlagError	(	Error	)	:	


def	__init__	(	self	,	flagname	,	flagvalue	=	"str"	,	suggestions	=	None	)	:	
self	.	flagname	=	flagname	
self	.	flagvalue	=	flagvalue	
if	suggestions	:	


tip	=	"str"	%	"str"	.	join	(	suggestions	)	
else	:	
tip	=	"str"	
super	(	UnrecognizedFlagError	,	self	)	.	__init__	(	
"str"	%	(	flagname	,	tip	)	)	


class	UnparsedFlagAccessError	(	Error	)	:	



class	ValidationError	(	Error	)	:	



class	FlagNameConflictsWithMethodError	(	Error	)	:	

	