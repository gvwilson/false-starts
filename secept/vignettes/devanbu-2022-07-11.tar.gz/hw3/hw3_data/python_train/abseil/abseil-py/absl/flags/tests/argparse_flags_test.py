















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	os	
import	subprocess	
import	sys	
import	tempfile	

from	absl	import	flags	
from	absl	import	logging	
from	absl	.	flags	import	argparse_flags	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	
import	mock	
import	six	


FLAGS	=	flags	.	FLAGS	


class	ArgparseFlagsTest	(	parameterized	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	_absl_flags	=	flags	.	FlagValues	(	)	
flags	.	DEFINE_bool	(	
"str"	,	None	,	"str"	,	
short_name	=	"str"	,	flag_values	=	self	.	_absl_flags	)	


flags	.	DEFINE_bool	(	
"str"	,	None	,	"str"	,	
flag_values	=	self	.	_absl_flags	)	
flags	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	
short_name	=	"str"	,	flag_values	=	self	.	_absl_flags	)	
flags	.	DEFINE_integer	(	
"str"	,	1	,	"str"	,	
flag_values	=	self	.	_absl_flags	)	
flags	.	DEFINE_float	(	
"str"	,	1	,	"str"	,	
flag_values	=	self	.	_absl_flags	)	
flags	.	DEFINE_enum	(	
"str"	,	"str"	,	[	"str"	,	"str"	]	,	"str"	,	
flag_values	=	self	.	_absl_flags	)	

def	test_dash_as_prefix_char_only	(	self	)	:	
with	self	.	assertRaises	(	ValueError	)	:	
argparse_flags	.	ArgumentParser	(	prefix_chars	=	"str"	)	

def	test_default_inherited_absl_flags_value	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	)	
self	.	assertIs	(	parser	.	_inherited_absl_flags	,	flags	.	FLAGS	)	

def	test_parse_absl_flags	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
self	.	assertFalse	(	self	.	_absl_flags	.	is_parsed	(	)	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	

parser	.	parse_args	(	
[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_string	,	"str"	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_integer	,	2	)	
self	.	assertTrue	(	self	.	_absl_flags	.	is_parsed	(	)	)	
self	.	assertFalse	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertFalse	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	
self	.	assertTrue	(	self	.	_absl_flags	[	"str"	]	.	using_default_value	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	]	,	True	)	,	
(	"str"	,	[	"str"	]	,	False	)	,	
(	"str"	,	[	"str"	]	,	SystemExit	)	,	
(	"str"	,	[	"str"	,	"str"	]	,	SystemExit	)	,	
(	"str"	,	[	"str"	]	,	SystemExit	)	,	
(	"str"	,	[	"str"	]	,	True	)	,	
(	"str"	,	[	"str"	]	,	SystemExit	)	,	
(	"str"	,	[	"str"	]	,	SystemExit	)	,	
(	"str"	,	[	"str"	]	,	SystemExit	)	,	
)	
def	test_parse_boolean_flags	(	self	,	args	,	expected	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
self	.	assertIsNone	(	self	.	_absl_flags	[	"str"	]	.	value	)	
self	.	assertIsNone	(	self	.	_absl_flags	[	"str"	]	.	value	)	
if	isinstance	(	expected	,	bool	)	:	
parser	.	parse_args	(	args	)	
self	.	assertEqual	(	expected	,	self	.	_absl_flags	.	absl_bool	)	
self	.	assertEqual	(	expected	,	self	.	_absl_flags	.	b	)	
else	:	
with	self	.	assertRaises	(	expected	)	:	
parser	.	parse_args	(	args	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	]	,	True	)	,	
(	"str"	,	[	"str"	]	,	False	)	,	
)	
def	test_parse_boolean_existing_no_prefix	(	self	,	args	,	expected	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
self	.	assertIsNone	(	self	.	_absl_flags	[	"str"	]	.	value	)	
parser	.	parse_args	(	args	)	
self	.	assertEqual	(	expected	,	self	.	_absl_flags	.	notice	)	

def	test_unrecognized_flag	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	[	"str"	]	)	

def	test_absl_validators	(	self	)	:	

@flags.validator	(	"str"	,	flag_values	=	self	.	_absl_flags	)	
def	ensure_positive	(	value	)	:	
return	value	>	0	

parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	[	"str"	,	"str"	]	)	

del	ensure_positive	

@parameterized.named_parameters	(	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	SystemExit	)	,	
(	"str"	,	"str"	,	SystemExit	)	,	
(	"str"	,	"str"	,	"str"	)	,	
)	
def	test_dashes	(	self	,	argument	,	expected	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
if	isinstance	(	expected	,	six	.	string_types	)	:	
parser	.	parse_args	(	[	argument	]	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_string	,	expected	)	
else	:	
with	self	.	assertRaises	(	expected	)	:	
parser	.	parse_args	(	[	argument	]	)	

def	test_absl_flags_not_added_to_namespace	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
args	=	parser	.	parse_args	(	[	"str"	]	)	
self	.	assertIsNone	(	getattr	(	args	,	"str"	,	None	)	)	

def	test_mixed_flags_and_positional	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	metavar	=	"str"	,	type	=	int	,	nargs	=	"str"	,	
help	=	"str"	)	

args	=	parser	.	parse_args	(	
[	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_string	,	"str"	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_integer	,	2	)	
self	.	assertEqual	(	args	.	header	,	"str"	)	
self	.	assertListEqual	(	args	.	integers	,	[	3	,	4	]	)	

def	test_subparsers	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
subparsers	=	parser	.	add_subparsers	(	help	=	"str"	)	

sub_parser	=	subparsers	.	add_parser	(	
"str"	,	help	=	"str"	,	inherited_absl_flags	=	self	.	_absl_flags	)	
sub_parser	.	add_argument	(	"str"	,	help	=	"str"	)	

def	sub_command_func	(	)	:	
pass	

sub_parser	.	set_defaults	(	command	=	sub_command_func	)	

args	=	parser	.	parse_args	(	[	
"str"	,	"str"	,	"str"	,	
"str"	,	"str"	]	)	

self	.	assertEqual	(	args	.	header	,	"str"	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_string	,	"str"	)	
self	.	assertEqual	(	args	.	command	,	sub_command_func	)	
self	.	assertEqual	(	self	.	_absl_flags	.	absl_integer	,	2	)	
self	.	assertEqual	(	args	.	sub_flag	,	"str"	)	

def	test_subparsers_no_inherit_in_subparser	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
subparsers	=	parser	.	add_subparsers	(	help	=	"str"	)	

subparsers	.	add_parser	(	
"str"	,	help	=	"str"	,	


inherited_absl_flags	=	None	)	

with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	[	"str"	,	"str"	]	)	

def	test_help_main_module_flags	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
help_message	=	parser	.	format_help	(	)	


self	.	assertIn	(	"str"	,	help_message	)	

self	.	assertIn	(	"str"	,	help_message	)	

self	.	assertIn	(	"str"	,	help_message	)	
self	.	assertIn	(	"str"	,	help_message	)	

def	test_help_non_main_module_flags	(	self	)	:	
flags	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	
module_name	=	"str"	,	flag_values	=	self	.	_absl_flags	)	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
help_message	=	parser	.	format_help	(	)	


self	.	assertNotIn	(	"str"	,	help_message	)	

def	test_help_non_main_module_key_flags	(	self	)	:	
flags	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	
module_name	=	"str"	,	flag_values	=	self	.	_absl_flags	)	
flags	.	declare_key_flag	(	"str"	,	flag_values	=	self	.	_absl_flags	)	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
help_message	=	parser	.	format_help	(	)	



self	.	assertIn	(	"str"	,	help_message	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
)	
def	test_help_flags	(	self	,	args	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	args	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
(	"str"	,	[	"str"	]	)	,	
)	
def	test_no_help_flags	(	self	,	args	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	,	add_help	=	False	)	
with	mock	.	patch	.	object	(	parser	,	"str"	)	:	
with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	args	)	
parser	.	print_help	.	assert_not_called	(	)	

def	test_helpfull_message	(	self	)	:	
flags	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	
module_name	=	"str"	,	flag_values	=	self	.	_absl_flags	)	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
with	self	.	assertRaises	(	SystemExit	)	,	mock	.	patch	.	object	(	sys	,	"str"	,	new	=	six	.	StringIO	(	)	)	as	mock_stdout	:	
parser	.	parse_args	(	[	"str"	]	)	
stdout_message	=	mock_stdout	.	getvalue	(	)	
logging	.	info	(	"str"	,	stdout_message	)	
self	.	assertIn	(	"str"	,	stdout_message	)	
self	.	assertIn	(	"str"	,	stdout_message	)	

self	.	assertNotIn	(	sys	.	argv	[	0	]	,	stdout_message	)	

self	.	assertIn	(	"str"	,	stdout_message	)	
self	.	assertIn	(	"str"	,	stdout_message	)	
self	.	assertIn	(	"str"	,	stdout_message	)	

@parameterized.named_parameters	(	
(	"str"	,	
(	"str"	,	"str"	,	"str"	)	,	
"str"	)	,	
(	"str"	,	
(	"str"	,	"str"	,	"str"	)	,	
"str"	)	,	
)	
def	test_flagfile	(	self	,	cmd_args	,	expected_absl_string_value	)	:	

self	.	_absl_flags	.	set_gnu_getopt	(	False	)	

parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	metavar	=	"str"	,	type	=	int	,	nargs	=	"str"	,	
help	=	"str"	)	
flagfile	=	tempfile	.	NamedTemporaryFile	(	dir	=	FLAGS	.	test_tmpdir	,	delete	=	False	)	
self	.	addCleanup	(	os	.	unlink	,	flagfile	.	name	)	
with	flagfile	:	
flagfile	.	write	(	b	"str"	)	

expand_flagfile	=	lambda	x	:	x	+	flagfile	.	name	if	x	==	"str"	else	x	
cmd_args	=	[	expand_flagfile	(	x	)	for	x	in	cmd_args	]	
args	=	parser	.	parse_args	(	cmd_args	)	

self	.	assertEqual	(	[	1	]	,	args	.	integers	)	
self	.	assertEqual	(	"str"	,	args	.	header	)	
self	.	assertEqual	(	expected_absl_string_value	,	self	.	_absl_flags	.	absl_string	)	

@parameterized.parameters	(	
(	"str"	,	{	"str"	}	,	False	)	,	
(	"str"	,	{	"str"	}	,	False	)	,	
(	"str"	,	set	(	)	,	False	)	,	
(	"str"	,	{	"str"	}	,	True	)	,	
(	"str"	,	{	"str"	}	,	True	)	,	
(	"str"	,	{	"str"	}	,	True	)	,	
)	
def	test_is_undefok	(	self	,	arg	,	undefok_names	,	is_undefok	)	:	
self	.	assertEqual	(	is_undefok	,	argparse_flags	.	_is_undefok	(	arg	,	undefok_names	)	)	

@parameterized.named_parameters	(	
(	"str"	,	"str"	,	[	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	,	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	,	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	]	,	[	]	)	,	
(	"str"	,	"str"	,	[	"str"	,	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	)	,	
)	
def	test_strip_undefok_args	(	self	,	undefok	,	args	,	expected_args	)	:	
actual_args	=	argparse_flags	.	_strip_undefok_args	(	undefok	,	args	)	
self	.	assertListEqual	(	expected_args	,	actual_args	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	,	"str"	]	)	,	
)	
def	test_undefok_flag_correct_use	(	self	,	cmd_args	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
args	=	parser	.	parse_args	(	cmd_args	)	

sentinel	=	object	(	)	
self	.	assertIs	(	sentinel	,	getattr	(	args	,	"str"	,	sentinel	)	)	

def	test_undefok_flag_existing	(	self	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
parser	.	parse_args	(	
[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	self	.	_absl_flags	.	absl_string	)	

@parameterized.named_parameters	(	
(	"str"	,	[	"str"	,	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	
def	test_undefok_flag_incorrect_use	(	self	,	cmd_args	)	:	
parser	=	argparse_flags	.	ArgumentParser	(	
inherited_absl_flags	=	self	.	_absl_flags	)	
with	self	.	assertRaises	(	SystemExit	)	:	
parser	.	parse_args	(	cmd_args	)	


class	ArgparseWithAppRunTest	(	parameterized	.	TestCase	)	:	

@parameterized.named_parameters	(	
(	"str"	,	
"str"	,	"str"	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	)	,	
(	"str"	,	
"str"	,	"str"	,	
[	"str"	,	"str"	,	
"str"	,	"str"	]	,	
[	"str"	,	"str"	,	"str"	]	)	,	
(	"str"	,	
"str"	,	"str"	,	
[	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	]	,	
[	"str"	,	"str"	,	"str"	]	)	,	
)	
def	test_argparse_with_app_run	(	
self	,	main_func_name	,	flags_parser_func_name	,	args	,	output_strings	)	:	
env	=	os	.	environ	.	copy	(	)	
env	[	"str"	]	=	main_func_name	
env	[	"str"	]	=	flags_parser_func_name	
helper	=	_bazelize_command	.	get_executable_path	(	
"str"	,	add_version_suffix	=	False	)	
try	:	
stdout	=	subprocess	.	check_output	(	
[	helper	]	+	args	,	env	=	env	,	universal_newlines	=	True	)	
except	subprocess	.	CalledProcessError	as	e	:	
error_info	=	(	"str"	
"str"	
"str"	
"str"	
"str"	)	
error_info	=	error_info	.	format	(	e	.	cmd	,	e	.	returncode	,	
e	.	output	+	"str"	if	e	.	output	else	"str"	)	
print	(	error_info	,	file	=	sys	.	stderr	)	
raise	

for	output_string	in	output_strings	:	
self	.	assertIn	(	output_string	,	stdout	)	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	