















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	collections	
import	copy	
import	pickle	
import	types	
import	unittest	

from	absl	import	logging	
from	absl	.	flags	import	_defines	
from	absl	.	flags	import	_exceptions	
from	absl	.	flags	import	_flagvalues	
from	absl	.	flags	import	_helpers	
from	absl	.	flags	.	tests	import	module_foo	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	parameterized	
import	mock	
import	six	


class	FlagValuesTest	(	absltest	.	TestCase	)	:	

def	test_bool_flags	(	self	)	:	
for	arg	,	expected	in	(	(	"str"	,	True	)	,	
(	"str"	,	True	)	,	
(	"str"	,	False	)	,	
(	"str"	,	False	)	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_boolean	(	"str"	,	None	,	"str"	,	flag_values	=	fv	)	
fv	(	(	"str"	,	arg	)	)	
self	.	assertIs	(	expected	,	fv	.	nothing	)	

for	arg	in	(	"str"	,	"str"	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_boolean	(	"str"	,	None	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	ValueError	)	:	
fv	(	(	"str"	,	arg	)	)	

def	test_boolean_flag_parser_gets_string_argument	(	self	)	:	
for	arg	,	expected	in	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_boolean	(	"str"	,	None	,	"str"	,	flag_values	=	fv	)	
with	mock	.	patch	.	object	(	fv	[	"str"	]	.	parser	,	"str"	)	as	mock_parse	:	
fv	(	(	"str"	,	arg	)	)	
mock_parse	.	assert_called_once_with	(	expected	)	

def	test_unregistered_flags_are_cleaned_up	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
module	,	module_name	=	_helpers	.	get_calling_module_object_and_name	(	)	


_defines	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	flag_values	=	fv	,	short_name	=	"str"	)	
old_cores_flag	=	fv	[	"str"	]	
fv	.	register_key_flag_for_module	(	module_name	,	old_cores_flag	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	old_cores_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	old_cores_flag	]	}	)	
self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	
{	module_name	:	[	old_cores_flag	]	}	)	


_defines	.	DEFINE_integer	(	
"str"	,	4	,	"str"	,	flag_values	=	fv	,	short_name	=	"str"	,	allow_override	=	True	)	
new_cores_flag	=	fv	[	"str"	]	
self	.	assertNotEqual	(	old_cores_flag	,	new_cores_flag	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	new_cores_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	new_cores_flag	]	}	)	


self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	{	module_name	:	[	]	}	)	


_defines	.	DEFINE_integer	(	
"str"	,	
0	,	
"str"	,	
flag_values	=	fv	,	
short_name	=	"str"	,	
allow_override	=	True	)	
old_changelist_flag	=	fv	[	"str"	]	
fv	.	register_key_flag_for_module	(	module_name	,	old_changelist_flag	)	

self	.	assertEqual	(	fv	[	"str"	]	,	old_changelist_flag	)	
self	.	assertNotEqual	(	fv	[	"str"	]	,	new_cores_flag	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	new_cores_flag	,	old_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	new_cores_flag	,	old_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	
{	module_name	:	[	old_changelist_flag	]	}	)	


_defines	.	DEFINE_integer	(	
"str"	,	
0	,	
"str"	,	
flag_values	=	fv	,	
short_name	=	"str"	,	
allow_override	=	True	)	
new_changelist_flag	=	fv	[	"str"	]	
self	.	assertNotEqual	(	old_changelist_flag	,	new_changelist_flag	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	new_cores_flag	,	
old_changelist_flag	,	
new_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	new_cores_flag	,	
old_changelist_flag	,	
new_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	
{	module_name	:	[	old_changelist_flag	]	}	)	



del	fv	.	changelist	
self	.	assertNotIn	(	"str"	,	fv	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	new_cores_flag	,	
old_changelist_flag	,	
new_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	new_cores_flag	,	
old_changelist_flag	,	
new_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	
{	module_name	:	[	old_changelist_flag	]	}	)	


del	fv	.	l	
self	.	assertNotIn	(	"str"	,	fv	)	
self	.	assertEqual	(	fv	.	flags_by_module_dict	(	)	,	
{	module_name	:	[	new_cores_flag	,	
old_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	flags_by_module_id_dict	(	)	,	
{	id	(	module	)	:	[	new_cores_flag	,	
old_changelist_flag	]	}	)	
self	.	assertEqual	(	fv	.	key_flags_by_module_dict	(	)	,	
{	module_name	:	[	old_changelist_flag	]	}	)	

def	_test_find_module_or_id_defining_flag	(	self	,	test_id	)	:	

fv	=	_flagvalues	.	FlagValues	(	)	
current_module	,	current_module_name	=	(	
_helpers	.	get_calling_module_object_and_name	(	)	)	
alt_module_name	=	_flagvalues	.	__name__	

if	test_id	:	
current_module_or_id	=	id	(	current_module	)	
alt_module_or_id	=	id	(	_flagvalues	)	
testing_fn	=	fv	.	find_module_id_defining_flag	
else	:	
current_module_or_id	=	current_module_name	
alt_module_or_id	=	alt_module_name	
testing_fn	=	fv	.	find_module_defining_flag	


_defines	.	DEFINE_integer	(	"str"	,	4	,	"str"	,	flag_values	=	fv	,	short_name	=	"str"	)	
module_or_id_cores	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_cores	,	current_module_or_id	)	
module_or_id_c	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_c	,	current_module_or_id	)	


_defines	.	DEFINE_integer	(	
"str"	,	
4	,	
"str"	,	
flag_values	=	fv	,	
module_name	=	alt_module_name	,	
short_name	=	"str"	,	
allow_override	=	True	)	
module_or_id_cores	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_cores	,	alt_module_or_id	)	
module_or_id_c	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_c	,	alt_module_or_id	)	


_defines	.	DEFINE_integer	(	
"str"	,	
0	,	
"str"	,	
flag_values	=	fv	,	
short_name	=	"str"	,	
allow_override	=	True	)	
module_or_id_cores	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_cores	,	alt_module_or_id	)	
module_or_id_changelist	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_changelist	,	current_module_or_id	)	
module_or_id_c	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_c	,	current_module_or_id	)	


_defines	.	DEFINE_integer	(	
"str"	,	
0	,	
"str"	,	
flag_values	=	fv	,	
module_name	=	alt_module_name	,	
short_name	=	"str"	,	
allow_override	=	True	)	
module_or_id_cores	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_cores	,	alt_module_or_id	)	
module_or_id_changelist	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_changelist	,	alt_module_or_id	)	
module_or_id_c	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_c	,	current_module_or_id	)	
module_or_id_l	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_l	,	alt_module_or_id	)	


del	fv	.	changelist	
module_or_id_changelist	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_changelist	,	None	)	
module_or_id_c	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_c	,	current_module_or_id	)	
module_or_id_l	=	testing_fn	(	"str"	)	
self	.	assertEqual	(	module_or_id_l	,	alt_module_or_id	)	

def	test_find_module_defining_flag	(	self	)	:	
self	.	_test_find_module_or_id_defining_flag	(	test_id	=	False	)	

def	test_find_module_id_defining_flag	(	self	)	:	
self	.	_test_find_module_or_id_defining_flag	(	test_id	=	True	)	

def	test_set_default	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
fv	.	mark_as_parsed	(	)	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
fv	.	set_default	(	"str"	,	1	)	
_defines	.	DEFINE_integer	(	"str"	,	0	,	"str"	,	flag_values	=	fv	)	
self	.	assertEqual	(	0	,	fv	.	changelist	)	
fv	.	set_default	(	"str"	,	2	)	
self	.	assertEqual	(	2	,	fv	.	changelist	)	

def	test_default_gnu_getopt_value	(	self	)	:	
self	.	assertTrue	(	_flagvalues	.	FlagValues	(	)	.	is_gnu_getopt	(	)	)	

def	test_known_only_flags_in_gnustyle	(	self	)	:	

def	run_test	(	argv	,	defined_py_flags	,	expected_argv	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
fv	.	set_gnu_getopt	(	True	)	
for	f	in	defined_py_flags	:	
if	f	.	startswith	(	"str"	)	:	
_defines	.	DEFINE_boolean	(	f	,	False	,	"str"	,	flag_values	=	fv	)	
else	:	
_defines	.	DEFINE_string	(	f	,	"str"	,	"str"	,	flag_values	=	fv	)	
output_argv	=	fv	(	argv	,	known_only	=	True	)	
self	.	assertEqual	(	expected_argv	,	output_argv	)	

run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	"str"	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	(	"str"	
"str"	)	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	
expected_argv	=	"str"	.	split	(	"str"	)	)	
run_test	(	
argv	=	(	"str"	
"str"	)	.	split	(	"str"	)	,	
defined_py_flags	=	[	"str"	]	,	


expected_argv	=	"str"	.	split	(	"str"	)	)	

def	test_invalid_flag_name	(	self	)	:	
with	self	.	assertRaises	(	_exceptions	.	Error	)	:	
_defines	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	

with	self	.	assertRaises	(	_exceptions	.	Error	)	:	
_defines	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	

with	self	.	assertRaises	(	_exceptions	.	Error	)	:	
_defines	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	

with	self	.	assertRaises	(	_exceptions	.	Error	)	:	
_defines	.	DEFINE_boolean	(	"str"	,	0	,	"str"	)	

with	self	.	assertRaises	(	_exceptions	.	Error	)	:	
_defines	.	DEFINE_boolean	(	1	,	0	,	"str"	)	

def	test_len	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
self	.	assertEqual	(	0	,	len	(	fv	)	)	
self	.	assertFalse	(	fv	)	

_defines	.	DEFINE_boolean	(	"str"	,	False	,	"str"	,	flag_values	=	fv	)	
self	.	assertEqual	(	1	,	len	(	fv	)	)	
self	.	assertTrue	(	fv	)	

_defines	.	DEFINE_boolean	(	
"str"	,	False	,	"str"	,	short_name	=	"str"	,	flag_values	=	fv	)	
self	.	assertEqual	(	3	,	len	(	fv	)	)	
self	.	assertTrue	(	fv	)	

def	test_pickle	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
with	self	.	assertRaisesRegexp	(	TypeError	,	"str"	)	:	
pickle	.	dumps	(	fv	)	

def	test_copy	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_integer	(	"str"	,	0	,	"str"	,	flag_values	=	fv	)	
fv	(	[	"str"	,	"str"	]	)	

with	self	.	assertRaisesRegexp	(	
TypeError	,	"str"	)	:	
copy	.	copy	(	fv	)	

fv2	=	copy	.	deepcopy	(	fv	)	
self	.	assertEqual	(	fv2	.	answer	,	1	)	

fv2	.	answer	=	42	
self	.	assertEqual	(	fv2	.	answer	,	42	)	
self	.	assertEqual	(	fv	.	answer	,	1	)	

def	test_conflicting_flags	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
with	self	.	assertRaises	(	_exceptions	.	FlagNameConflictsWithMethodError	)	:	
_defines	.	DEFINE_boolean	(	"str"	,	False	,	"str"	,	flag_values	=	fv	)	
_defines	.	DEFINE_boolean	(	
"str"	,	
False	,	
"str"	,	
flag_values	=	fv	,	
allow_using_method_names	=	True	)	
self	.	assertFalse	(	fv	[	"str"	]	.	value	)	
self	.	assertIsInstance	(	fv	.	is_gnu_getopt	,	types	.	MethodType	)	

def	test_get_help	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
self	.	assertMultiLineEqual	(	"str"	,	fv	.	get_help	(	)	)	

module_foo	.	define_flags	(	fv	)	
self	.	assertMultiLineEqual	(	"str"	,	fv	.	get_help	(	)	)	

self	.	assertMultiLineEqual	(	"str"	,	fv	.	get_help	(	prefix	=	"str"	)	)	

self	.	assertMultiLineEqual	(	"str"	,	fv	.	get_help	(	include_special_flags	=	False	)	)	

def	test_str	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
self	.	assertEqual	(	str	(	fv	)	,	fv	.	get_help	(	)	)	
module_foo	.	define_flags	(	fv	)	
self	.	assertEqual	(	str	(	fv	)	,	fv	.	get_help	(	)	)	

def	test_empty_argv	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
with	self	.	assertRaises	(	ValueError	)	:	
fv	(	[	]	)	

def	test_invalid_argv	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
with	self	.	assertRaises	(	TypeError	)	:	
fv	(	"str"	)	
with	self	.	assertRaises	(	TypeError	)	:	
fv	(	b	"str"	)	
with	self	.	assertRaises	(	TypeError	)	:	
fv	(	"str"	)	

def	test_flags_dir	(	self	)	:	
flag_values	=	_flagvalues	.	FlagValues	(	)	
flag_name1	=	"str"	
flag_name2	=	"str"	
flag_name3	=	"str"	
description	=	"str"	
_defines	.	DEFINE_boolean	(	
flag_name1	,	None	,	description	,	flag_values	=	flag_values	)	
_defines	.	DEFINE_string	(	
flag_name2	,	None	,	description	,	flag_values	=	flag_values	)	
self	.	assertEqual	(	sorted	(	[	flag_name1	,	flag_name2	]	)	,	dir	(	flag_values	)	)	

_defines	.	DEFINE_float	(	
flag_name3	,	None	,	description	,	flag_values	=	flag_values	)	
self	.	assertEqual	(	
sorted	(	[	flag_name1	,	flag_name2	,	flag_name3	]	)	,	dir	(	flag_values	)	)	

def	test_flags_into_string_deterministic	(	self	)	:	
flag_values	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	flag_values	,	module_name	=	"str"	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	flag_values	,	module_name	=	"str"	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	flag_values	,	module_name	=	"str"	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	flag_values	,	module_name	=	"str"	)	

expected	=	(	"str"	
"str"	
"str"	
"str"	)	

flags_by_module_items	=	sorted	(	
flag_values	.	flags_by_module_dict	(	)	.	items	(	)	,	reverse	=	True	)	
for	_	,	module_flags	in	flags_by_module_items	:	
module_flags	.	sort	(	reverse	=	True	)	

flag_values	.	__dict__	[	"str"	]	=	collections	.	OrderedDict	(	
flags_by_module_items	)	

actual	=	flag_values	.	flags_into_string	(	)	
self	.	assertEqual	(	expected	,	actual	)	


class	FlagValuesLoggingTest	(	absltest	.	TestCase	)	:	


def	test_logging_do_not_recurse	(	self	)	:	
logging	.	info	(	"str"	)	
try	:	
raise	ValueError	(	"str"	)	
except	ValueError	:	
logging	.	exception	(	"str"	)	


class	FlagSubstrMatchingTests	(	parameterized	.	TestCase	)	:	


def	_get_test_flag_values	(	self	)	:	

flag_values	=	_flagvalues	.	FlagValues	(	)	

_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	flag_values	)	
_defines	.	DEFINE_boolean	(	"str"	,	0	,	"str"	,	flag_values	=	flag_values	)	

return	flag_values	



FAIL_TEST_CASES	=	[	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	)	,	
]	

@parameterized.parameters	(	FAIL_TEST_CASES	)	
def	test_raise	(	self	,	*	argv	)	:	

fv	=	self	.	_get_test_flag_values	(	)	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
fv	(	argv	)	

@parameterized.parameters	(	
FAIL_TEST_CASES	+	[	(	"str"	,	"str"	,	"str"	)	]	)	
def	test_gnu_getopt_raise	(	self	,	*	argv	)	:	

fv	=	self	.	_get_test_flag_values	(	)	
fv	.	set_gnu_getopt	(	)	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
fv	(	argv	)	


class	SettingUnknownFlagTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	setter_called	=	0	

def	set_undef	(	self	,	unused_name	,	unused_val	)	:	
self	.	setter_called	+	=	1	

def	test_raise_on_undefined	(	self	)	:	
new_flags	=	_flagvalues	.	FlagValues	(	)	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
new_flags	.	undefined_flag	=	0	

def	test_not_raise	(	self	)	:	
new_flags	=	_flagvalues	.	FlagValues	(	)	
new_flags	.	_register_unknown_flag_setter	(	self	.	set_undef	)	
new_flags	.	undefined_flag	=	0	
self	.	assertEqual	(	self	.	setter_called	,	1	)	

def	test_not_raise_on_undefined_if_undefok	(	self	)	:	
new_flags	=	_flagvalues	.	FlagValues	(	)	
args	=	[	"str"	,	"str"	,	"str"	,	"str"	]	
unparsed	=	new_flags	(	args	,	known_only	=	True	)	
self	.	assertEqual	(	[	"str"	]	,	unparsed	)	

def	test_re_raise_undefined	(	self	)	:	
def	setter	(	unused_name	,	unused_val	)	:	
raise	NameError	(	)	
new_flags	=	_flagvalues	.	FlagValues	(	)	
new_flags	.	_register_unknown_flag_setter	(	setter	)	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
new_flags	.	undefined_flag	=	0	

def	test_re_raise_invalid	(	self	)	:	
def	setter	(	unused_name	,	unused_val	)	:	
raise	ValueError	(	)	
new_flags	=	_flagvalues	.	FlagValues	(	)	
new_flags	.	_register_unknown_flag_setter	(	setter	)	
with	self	.	assertRaises	(	_exceptions	.	IllegalFlagValueError	)	:	
new_flags	.	undefined_flag	=	0	


class	FlagsDashSyntaxTest	(	absltest	.	TestCase	)	:	

def	setUp	(	self	)	:	
self	.	fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	flag_values	=	self	.	fv	,	short_name	=	"str"	)	

def	test_long_name_one_dash	(	self	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	self	.	fv	.	long_name	)	

def	test_long_name_two_dashes	(	self	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	self	.	fv	.	long_name	)	

def	test_long_name_three_dashes	(	self	)	:	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	

def	test_short_name_one_dash	(	self	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	self	.	fv	.	s	)	

def	test_short_name_two_dashes	(	self	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	self	.	fv	.	s	)	

def	test_short_name_three_dashes	(	self	)	:	
with	self	.	assertRaises	(	_exceptions	.	UnrecognizedFlagError	)	:	
self	.	fv	(	[	"str"	,	"str"	]	)	


class	UnparseFlagsTest	(	absltest	.	TestCase	)	:	

def	test_using_default_value_none	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	None	,	"str"	,	flag_values	=	fv	)	
self	.	assertTrue	(	fv	[	"str"	]	.	using_default_value	)	
fv	(	[	"str"	,	"str"	]	)	
self	.	assertFalse	(	fv	[	"str"	]	.	using_default_value	)	
fv	.	unparse_flags	(	)	
self	.	assertTrue	(	fv	[	"str"	]	.	using_default_value	)	
fv	(	[	"str"	,	"str"	]	)	
self	.	assertFalse	(	fv	[	"str"	]	.	using_default_value	)	
fv	.	unparse_flags	(	)	
self	.	assertTrue	(	fv	[	"str"	]	.	using_default_value	)	

def	test_using_default_value_not_none	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	

fv	.	mark_as_parsed	(	)	
self	.	assertTrue	(	fv	[	"str"	]	.	using_default_value	)	

fv	(	[	"str"	,	"str"	]	)	
self	.	assertFalse	(	fv	[	"str"	]	.	using_default_value	)	

fv	(	[	"str"	,	"str"	]	)	
self	.	assertFalse	(	fv	[	"str"	]	.	using_default_value	)	

fv	.	unparse_flags	(	)	
self	.	assertTrue	(	fv	[	"str"	]	.	using_default_value	)	

fv	(	[	"str"	,	"str"	]	)	
self	.	assertFalse	(	fv	[	"str"	]	.	using_default_value	)	

def	test_allow_overwrite_false	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	
"str"	,	None	,	"str"	,	allow_overwrite	=	False	,	flag_values	=	fv	)	
_defines	.	DEFINE_string	(	
"str"	,	"str"	,	"str"	,	allow_overwrite	=	False	,	flag_values	=	fv	)	

fv	.	mark_as_parsed	(	)	
self	.	assertEqual	(	"str"	,	fv	.	default_foo	)	
self	.	assertEqual	(	None	,	fv	.	default_none	)	

fv	(	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	fv	.	default_foo	)	
self	.	assertEqual	(	"str"	,	fv	.	default_none	)	

fv	.	unparse_flags	(	)	
self	.	assertEqual	(	"str"	,	fv	[	"str"	]	.	value	)	
self	.	assertEqual	(	None	,	fv	[	"str"	]	.	value	)	

fv	(	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	"str"	,	fv	.	default_foo	)	
self	.	assertEqual	(	"str"	,	fv	.	default_none	)	

def	test_multi_string_default_none	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_multi_string	(	"str"	,	None	,	"str"	,	flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	
self	.	assertEqual	(	None	,	fv	.	foo	)	
fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	]	,	fv	.	foo	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	None	,	fv	[	"str"	]	.	value	)	
fv	(	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	fv	.	foo	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	None	,	fv	[	"str"	]	.	value	)	

def	test_multi_string_default_string	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_multi_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	
expected_default	=	[	"str"	]	
fv	.	mark_as_parsed	(	)	
self	.	assertEqual	(	expected_default	,	fv	.	foo	)	
fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	]	,	fv	.	foo	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	expected_default	,	fv	[	"str"	]	.	value	)	
fv	(	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	fv	[	"str"	]	.	value	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	expected_default	,	fv	[	"str"	]	.	value	)	

def	test_multi_string_default_list	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_multi_string	(	
"str"	,	[	"str"	,	"str"	,	"str"	]	,	"str"	,	flag_values	=	fv	)	
expected_default	=	[	"str"	,	"str"	,	"str"	]	
fv	.	mark_as_parsed	(	)	
self	.	assertEqual	(	expected_default	,	fv	.	foo	)	
fv	(	[	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	]	,	fv	.	foo	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	expected_default	,	fv	[	"str"	]	.	value	)	
fv	(	[	"str"	,	"str"	,	"str"	]	)	
self	.	assertEqual	(	[	"str"	,	"str"	]	,	fv	.	foo	)	
fv	.	unparse_flags	(	)	
self	.	assertEqual	(	expected_default	,	fv	[	"str"	]	.	value	)	


class	UnparsedFlagAccessTest	(	absltest	.	TestCase	)	:	

def	test_unparsed_flag_access	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	_exceptions	.	UnparsedFlagAccessError	)	:	
_	=	fv	.	name	

@unittest.skipIf	(	six	.	PY3	,	"str"	)	
def	test_hasattr_logs_in_py2	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	
with	mock	.	patch	.	object	(	_flagvalues	.	logging	,	"str"	)	as	mock_error	:	
self	.	assertFalse	(	hasattr	(	fv	,	"str"	)	)	
mock_error	.	assert_called_once	(	)	

@unittest.skipIf	(	six	.	PY2	,	"str"	)	
def	test_hasattr_raises_in_py3	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	
with	self	.	assertRaises	(	_exceptions	.	UnparsedFlagAccessError	)	:	
_	=	hasattr	(	fv	,	"str"	)	

def	test_unparsed_flags_access_raises_after_unparse_flags	(	self	)	:	
fv	=	_flagvalues	.	FlagValues	(	)	
_defines	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	fv	)	
fv	.	mark_as_parsed	(	)	
self	.	assertEqual	(	fv	.	a_str	,	"str"	)	
fv	.	unparse_flags	(	)	
with	self	.	assertRaises	(	_exceptions	.	UnparsedFlagAccessError	)	:	
_	=	fv	.	a_str	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	