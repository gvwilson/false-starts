

from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	unittest	

from	absl	.	testing	import	absltest	
from	absl	.	testing	import	xml_reporter	
import	mock	
import	six	


class	MockTestResult	(	xml_reporter	.	_TextAndXMLTestResult	)	:	

def	__init__	(	self	)	:	
super	(	MockTestResult	,	self	)	.	__init__	(	six	.	StringIO	(	)	,	six	.	StringIO	(	)	,	
"str"	,	False	)	
self	.	subtest_success	=	[	]	
self	.	subtest_failure	=	[	]	

def	addSubTest	(	self	,	test	,	subtest	,	err	)	:	
super	(	MockTestResult	,	self	)	.	addSubTest	(	test	,	subtest	,	err	)	

if	six	.	PY2	:	
params	=	{	}	
for	param	in	subtest	.	params	:	
for	param_name	,	param_value	in	param	.	items	(	)	:	
params	[	param_name	]	=	param_value	
else	:	
params	=	dict	(	subtest	.	params	)	
if	err	is	not	None	:	
self	.	addSubTestFailure	(	params	)	
else	:	
self	.	addSubTestSuccess	(	params	)	

def	addSubTestFailure	(	self	,	params	)	:	
self	.	subtest_failure	.	append	(	params	)	

def	addSubTestSuccess	(	self	,	params	)	:	
self	.	subtest_success	.	append	(	params	)	


class	MockTestResultWithoutSubTest	(	xml_reporter	.	_TextAndXMLTestResult	)	:	


def	__init__	(	self	)	:	
super	(	MockTestResultWithoutSubTest	,	self	)	.	__init__	(	six	.	StringIO	(	)	,	
six	.	StringIO	(	)	,	
"str"	,	
False	)	

@property	
def	addSubTest	(	self	)	:	
raise	AttributeError	


class	Unittest3BackportTest	(	absltest	.	TestCase	)	:	

def	test_subtest_pass	(	self	)	:	

class	Foo	(	absltest	.	TestCase	)	:	

def	runTest	(	self	)	:	
for	i	in	[	1	,	2	]	:	
with	self	.	subTest	(	i	=	i	)	:	
for	j	in	[	2	,	3	]	:	
with	self	.	subTest	(	j	=	j	)	:	
pass	

result	=	MockTestResult	(	)	
Foo	(	)	.	run	(	result	)	
expected_success	=	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	1	,	"str"	:	3	}	,	{	"str"	:	1	}	,	
{	"str"	:	2	,	"str"	:	2	}	,	{	"str"	:	2	,	"str"	:	3	}	,	{	"str"	:	2	}	]	
self	.	assertListEqual	(	result	.	subtest_success	,	expected_success	)	

def	test_subtest_fail	(	self	)	:	
class	Foo	(	absltest	.	TestCase	)	:	

def	runTest	(	self	)	:	
for	i	in	[	1	,	2	]	:	
with	self	.	subTest	(	i	=	i	)	:	
for	j	in	[	2	,	3	]	:	
with	self	.	subTest	(	j	=	j	)	:	
if	j	==	2	:	
self	.	fail	(	"str"	)	

result	=	MockTestResult	(	)	
Foo	(	)	.	run	(	result	)	



expected_success	=	[	{	"str"	:	1	,	"str"	:	3	}	,	{	"str"	:	2	,	"str"	:	3	}	]	
expected_failure	=	[	{	"str"	:	1	,	"str"	:	2	}	,	{	"str"	:	2	,	"str"	:	2	}	]	
self	.	assertListEqual	(	expected_success	,	result	.	subtest_success	)	
self	.	assertListEqual	(	expected_failure	,	result	.	subtest_failure	)	

def	test_subtest_expected_failure	(	self	)	:	
class	Foo	(	absltest	.	TestCase	)	:	

@unittest.expectedFailure	
def	runTest	(	self	)	:	
for	i	in	[	1	,	2	,	3	]	:	
with	self	.	subTest	(	i	=	i	)	:	
self	.	assertEqual	(	i	,	2	)	

foo	=	Foo	(	)	
with	mock	.	patch	.	object	(	foo	,	"str"	,	
autospec	=	True	)	as	mock_subtest_expected_failure	:	
result	=	MockTestResult	(	)	
foo	.	run	(	result	)	
self	.	assertEqual	(	mock_subtest_expected_failure	.	call_count	,	1	)	

def	test_subtest_unexpected_success	(	self	)	:	
class	Foo	(	absltest	.	TestCase	)	:	

@unittest.expectedFailure	
def	runTest	(	self	)	:	
for	i	in	[	1	,	2	,	3	]	:	
with	self	.	subTest	(	i	=	i	)	:	
self	.	assertEqual	(	i	,	i	)	

foo	=	Foo	(	)	
with	mock	.	patch	.	object	(	foo	,	"str"	,	
autospec	=	True	)	as	mock_subtest_unexpected_success	:	
result	=	MockTestResult	(	)	
foo	.	run	(	result	)	
self	.	assertEqual	(	mock_subtest_unexpected_success	.	call_count	,	1	)	

def	test_subtest_fail_fast	(	self	)	:	


class	Foo	(	absltest	.	TestCase	)	:	

def	runTest	(	self	)	:	
with	self	.	subTest	(	i	=	1	)	:	
self	.	fail	(	"str"	)	
with	self	.	subTest	(	i	=	2	)	:	
self	.	fail	(	"str"	)	
self	.	fail	(	"str"	)	

result	=	MockTestResult	(	)	
result	.	failfast	=	True	
Foo	(	)	.	run	(	result	)	
expected_failure	=	[	{	"str"	:	1	}	]	
self	.	assertListEqual	(	expected_failure	,	result	.	subtest_failure	)	

def	test_subtest_skip	(	self	)	:	


class	Foo	(	absltest	.	TestCase	)	:	

@unittest.skip	(	"str"	)	
def	runTest	(	self	)	:	
for	i	in	[	1	,	2	,	3	]	:	
with	self	.	subTest	(	i	=	i	)	:	
self	.	assertEqual	(	i	,	i	)	

foo	=	Foo	(	)	
result	=	MockTestResult	(	)	

with	mock	.	patch	.	object	(	foo	,	"str"	,	autospec	=	True	)	as	mock_test_skip	:	
with	mock	.	patch	.	object	(	result	,	"str"	,	
autospec	=	True	)	as	mock_subtest_success	:	
foo	.	run	(	result	)	
self	.	assertEqual	(	mock_test_skip	.	call_count	,	1	)	
self	.	assertEqual	(	mock_subtest_success	.	call_count	,	0	)	

@mock.patch.object	(	MockTestResultWithoutSubTest	,	"str"	,	autospec	=	True	)	
def	test_subtest_legacy	(	self	,	mock_test_fail	)	:	



class	Foo	(	absltest	.	TestCase	)	:	

def	runTest	(	self	)	:	
for	i	in	[	1	,	2	,	3	]	:	
with	self	.	subTest	(	i	=	i	)	:	
if	i	==	1	:	
self	.	fail	(	"str"	)	
for	j	in	[	2	,	3	]	:	
with	self	.	subTest	(	j	=	j	)	:	
if	i	*	j	==	6	:	
raise	RuntimeError	(	"str"	)	

result	=	MockTestResultWithoutSubTest	(	)	

Foo	(	)	.	run	(	result	)	
self	.	assertEqual	(	mock_test_fail	.	call_count	,	1	)	

if	__name__	==	"str"	:	
absltest	.	main	(	)	
	