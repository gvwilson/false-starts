















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	codecs	
import	contextlib	
import	os	
import	re	
import	subprocess	
import	sys	
import	tempfile	
import	unittest	

from	absl	import	app	
from	absl	import	flags	
from	absl	.	_enum_module	import	enum	
from	absl	.	testing	import	_bazelize_command	
from	absl	.	testing	import	absltest	
from	absl	.	testing	import	flagsaver	
from	absl	.	tests	import	app_test_helper	
import	mock	
import	six	


FLAGS	=	flags	.	FLAGS	


mock_stdio_type	=	six	.	StringIO	

_newline_regex	=	re	.	compile	(	"str"	)	


@contextlib.contextmanager	
def	patch_main_module_docstring	(	docstring	)	:	
old_doc	=	sys	.	modules	[	"str"	]	.	__doc__	
sys	.	modules	[	"str"	]	.	__doc__	=	docstring	
yield	
sys	.	modules	[	"str"	]	.	__doc__	=	old_doc	


def	_normalize_newlines	(	s	)	:	
return	re	.	sub	(	"str"	,	"str"	,	s	)	


class	UnitTests	(	absltest	.	TestCase	)	:	

def	test_install_exception_handler	(	self	)	:	
with	self	.	assertRaises	(	TypeError	)	:	
app	.	install_exception_handler	(	1	)	

def	test_usage	(	self	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stderr	:	
app	.	usage	(	)	
self	.	assertIn	(	__doc__	,	mock_stderr	.	getvalue	(	)	)	

self	.	assertIn	(	"str"	,	mock_stderr	.	getvalue	(	)	)	

def	test_usage_shorthelp	(	self	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stderr	:	
app	.	usage	(	shorthelp	=	True	)	

self	.	assertNotIn	(	"str"	,	mock_stderr	.	getvalue	(	)	)	

def	test_usage_writeto_stderr	(	self	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stdout	:	
app	.	usage	(	writeto_stdout	=	True	)	
self	.	assertIn	(	__doc__	,	mock_stdout	.	getvalue	(	)	)	

def	test_usage_detailed_error	(	self	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stderr	:	
app	.	usage	(	detailed_error	=	"str"	)	
self	.	assertIn	(	"str"	,	mock_stderr	.	getvalue	(	)	)	

def	test_usage_exitcode	(	self	)	:	




if	six	.	PY2	:	
stderr	=	codecs	.	getwriter	(	"str"	)	(	sys	.	stderr	)	
else	:	
stderr	=	sys	.	stderr	

with	mock	.	patch	.	object	(	sys	,	"str"	,	new	=	stderr	)	:	
try	:	
app	.	usage	(	exitcode	=	2	)	
self	.	fail	(	"str"	)	
except	SystemExit	as	e	:	
self	.	assertEqual	(	2	,	e	.	code	)	

def	test_usage_expands_docstring	(	self	)	:	
with	patch_main_module_docstring	(	"str"	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stderr	:	
app	.	usage	(	)	
self	.	assertIn	(	"str"	.	format	(	sys	.	argv	[	0	]	)	,	
mock_stderr	.	getvalue	(	)	)	

def	test_usage_does_not_expand_bad_docstring	(	self	)	:	
with	patch_main_module_docstring	(	"str"	)	:	
with	mock	.	patch	.	object	(	
sys	,	"str"	,	new	=	mock_stdio_type	(	)	)	as	mock_stderr	:	
app	.	usage	(	)	
self	.	assertIn	(	"str"	,	mock_stderr	.	getvalue	(	)	)	

@flagsaver.flagsaver	
def	test_register_and_parse_flags_with_usage_exits_on_only_check_args	(	self	)	:	
done	=	app	.	_register_and_parse_flags_with_usage	.	done	
try	:	
app	.	_register_and_parse_flags_with_usage	.	done	=	False	
with	self	.	assertRaises	(	SystemExit	)	:	
app	.	_register_and_parse_flags_with_usage	(	
argv	=	[	"str"	,	"str"	]	)	
finally	:	
app	.	_register_and_parse_flags_with_usage	.	done	=	done	

def	test_register_and_parse_flags_with_usage_exits_on_second_run	(	self	)	:	
with	self	.	assertRaises	(	SystemError	)	:	
app	.	_register_and_parse_flags_with_usage	(	)	


class	FunctionalTests	(	absltest	.	TestCase	)	:	


helper_type	=	"str"	

def	run_helper	(	self	,	expect_success	,	
expected_stdout_substring	=	None	,	expected_stderr_substring	=	None	,	
arguments	=	(	)	,	
env_overrides	=	None	)	:	
env	=	os	.	environ	.	copy	(	)	
env	[	"str"	]	=	self	.	helper_type	
env	[	"str"	]	=	"str"	
if	env_overrides	:	
env	.	update	(	env_overrides	)	

helper	=	"str"	.	format	(	self	.	helper_type	)	
process	=	subprocess	.	Popen	(	
[	_bazelize_command	.	get_executable_path	(	helper	)	]	+	list	(	arguments	)	,	
stdout	=	subprocess	.	PIPE	,	
stderr	=	subprocess	.	PIPE	,	env	=	env	,	universal_newlines	=	False	)	
stdout	,	stderr	=	process	.	communicate	(	)	



stdout	=	_normalize_newlines	(	stdout	.	decode	(	"str"	)	)	
stderr	=	_normalize_newlines	(	stderr	.	decode	(	"str"	)	)	

message	=	(	"str"	
"str"	
"str"	
"str"	
"str"	.	format	(	
command	=	"str"	.	join	(	[	helper	]	+	list	(	arguments	)	)	,	
exitcode	=	process	.	returncode	,	
stdout	=	stdout	or	"str"	,	
stderr	=	stderr	or	"str"	)	)	
if	expect_success	:	
self	.	assertEqual	(	0	,	process	.	returncode	,	msg	=	message	)	
else	:	
self	.	assertNotEqual	(	0	,	process	.	returncode	,	msg	=	message	)	

if	expected_stdout_substring	:	
self	.	assertIn	(	expected_stdout_substring	,	stdout	,	message	)	
if	expected_stderr_substring	:	
self	.	assertIn	(	expected_stderr_substring	,	stderr	,	message	)	

return	process	.	returncode	,	stdout	,	stderr	

def	test_help	(	self	)	:	
_	,	_	,	stderr	=	self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stdout_substring	=	app_test_helper	.	__doc__	)	
self	.	assertNotIn	(	"str"	,	stderr	)	

def	test_helpfull_basic	(	self	)	:	
self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	

expected_stdout_substring	=	"str"	)	

def	test_helpfull_unicode_flag_help	(	self	)	:	
_	,	stdout	,	_	=	self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stdout_substring	=	"str"	)	

self	.	assertIn	(	"str"	,	stdout	)	

if	six	.	PY2	:	


self	.	assertIn	(	repr	(	"str"	)	,	stdout	)	
else	:	

self	.	assertIn	(	"str"	,	stdout	)	

def	test_helpshort	(	self	)	:	
_	,	_	,	stderr	=	self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stdout_substring	=	app_test_helper	.	__doc__	)	
self	.	assertNotIn	(	"str"	,	stderr	)	

def	test_custom_main	(	self	)	:	
self	.	run_helper	(	
True	,	
env_overrides	=	{	"str"	:	"str"	}	,	
expected_stdout_substring	=	"str"	)	

def	test_custom_argv	(	self	)	:	
self	.	run_helper	(	
True	,	
expected_stdout_substring	=	"str"	,	
env_overrides	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	)	

def	test_gwq_status_file_on_exception	(	self	)	:	
if	self	.	helper_type	==	"str"	:	

return	

tmpdir	=	tempfile	.	mkdtemp	(	dir	=	FLAGS	.	test_tmpdir	)	
self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
env_overrides	=	{	"str"	:	tmpdir	}	)	
with	open	(	os	.	path	.	join	(	tmpdir	,	"str"	)	)	as	status_file	:	
self	.	assertIn	(	"str"	,	status_file	.	read	(	)	)	

@unittest.skipIf	(	six	.	PY2	,	
"str"	)	
def	test_faulthandler_dumps_stack_on_sigsegv	(	self	)	:	
return_code	,	_	,	_	=	self	.	run_helper	(	
False	,	
expected_stderr_substring	=	"str"	,	
arguments	=	[	"str"	]	)	

expected_return_code	=	3	if	os	.	name	==	"str"	else	-	11	
self	.	assertEqual	(	expected_return_code	,	return_code	)	

def	test_top_level_exception	(	self	)	:	
self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stderr_substring	=	"str"	)	

def	test_only_check_args	(	self	)	:	
self	.	run_helper	(	
True	,	
arguments	=	[	"str"	,	"str"	]	)	

def	test_only_check_args_failure	(	self	)	:	
self	.	run_helper	(	
False	,	
arguments	=	[	"str"	,	"str"	]	,	
expected_stderr_substring	=	"str"	)	

def	test_usage_error	(	self	)	:	
exitcode	,	_	,	_	=	self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stderr_substring	=	app_test_helper	.	__doc__	)	
self	.	assertEqual	(	1	,	exitcode	)	

def	test_usage_error_exitcode	(	self	)	:	
exitcode	,	_	,	_	=	self	.	run_helper	(	
False	,	
arguments	=	[	"str"	,	"str"	]	,	
expected_stderr_substring	=	app_test_helper	.	__doc__	)	
self	.	assertEqual	(	88	,	exitcode	)	

def	test_exception_handler	(	self	)	:	
exception_handler_messages	=	(	
"str"	)	
self	.	run_helper	(	
False	,	
arguments	=	[	"str"	]	,	
expected_stdout_substring	=	exception_handler_messages	)	

def	test_exception_handler_not_called	(	self	)	:	
_	,	_	,	stdout	=	self	.	run_helper	(	True	)	
self	.	assertNotIn	(	"str"	,	stdout	)	

def	test_print_init_callbacks	(	self	)	:	
_	,	stdout	,	_	=	self	.	run_helper	(	
expect_success	=	True	,	arguments	=	[	"str"	]	)	
self	.	assertIn	(	"str"	,	stdout	)	
self	.	assertIn	(	"str"	,	stdout	)	


class	FlagValuesExternalizationTest	(	absltest	.	TestCase	)	:	


@flagsaver.flagsaver	
def	test_nohelp_doesnt_show_help	(	self	)	:	
with	self	.	assertRaisesWithPredicateMatch	(	SystemExit	,	
lambda	e	:	e	.	code	==	1	)	:	
app	.	run	(	
len	,	
argv	=	[	
"str"	,	"str"	,	"str"	,	"str"	,	
"str"	
]	)	

@flagsaver.flagsaver	
def	test_serialize_roundtrip	(	self	)	:	


flags	.	DEFINE_string	(	"str"	,	"str"	,	"str"	,	flag_values	=	FLAGS	)	

flags	.	DEFINE_multi_enum	(	"str"	,	
[	"str"	,	"str"	]	,	[	"str"	,	"str"	,	"str"	]	,	
"str"	,	
flag_values	=	FLAGS	)	

class	Fruit	(	enum	.	Enum	)	:	
APPLE	=	1	
ORANGE	=	2	
TOMATO	=	3	
flags	.	DEFINE_multi_enum_class	(	"str"	,	
[	"str"	,	"str"	]	,	Fruit	,	
"str"	,	
flag_values	=	FLAGS	)	

new_flag_values	=	flags	.	FlagValues	(	)	
new_flag_values	.	append_flag_values	(	FLAGS	)	

FLAGS	.	testflag	=	"str"	
FLAGS	.	test_multi_enum_flag	=	[	"str"	,	"str"	]	
FLAGS	.	test_multi_enum_class_flag	=	[	Fruit	.	ORANGE	,	Fruit	.	APPLE	]	
argv	=	[	"str"	]	+	FLAGS	.	flags_into_string	(	)	.	splitlines	(	)	

self	.	assertNotEqual	(	new_flag_values	[	"str"	]	,	FLAGS	.	testflag	)	
self	.	assertNotEqual	(	new_flag_values	[	"str"	]	,	
FLAGS	.	test_multi_enum_flag	)	
self	.	assertNotEqual	(	new_flag_values	[	"str"	]	,	
FLAGS	.	test_multi_enum_class_flag	)	
new_flag_values	(	argv	)	
self	.	assertEqual	(	new_flag_values	.	testflag	,	FLAGS	.	testflag	)	
self	.	assertEqual	(	new_flag_values	.	test_multi_enum_flag	,	
FLAGS	.	test_multi_enum_flag	)	
self	.	assertEqual	(	new_flag_values	.	test_multi_enum_class_flag	,	
FLAGS	.	test_multi_enum_class_flag	)	
del	FLAGS	.	testflag	
del	FLAGS	.	test_multi_enum_flag	
del	FLAGS	.	test_multi_enum_class_flag	


if	__name__	==	"str"	:	
absltest	.	main	(	)	
	