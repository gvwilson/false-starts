















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

import	collections	
import	os	
import	re	
import	struct	
import	sys	
import	textwrap	
try	:	
import	fcntl	
except	ImportError	:	
fcntl	=	None	
try	:	

import	termios	
except	ImportError	:	
termios	=	None	

import	six	
from	six	.	moves	import	range	


_DEFAULT_HELP_WIDTH	=	80	
_MIN_HELP_WIDTH	=	40	











_SUGGESTION_ERROR_RATE_THRESHOLD	=	0.50	




_ILLEGAL_XML_CHARS_REGEX	=	re	.	compile	(	
"str"	)	




disclaim_module_ids	=	set	(	[	id	(	sys	.	modules	[	__name__	]	)	]	)	





SPECIAL_FLAGS	=	None	





FLAGS_MODULE	=	None	


class	_ModuleObjectAndName	(	
collections	.	namedtuple	(	"str"	,	"str"	)	)	:	



def	get_module_object_and_name	(	globals_dict	)	:	

name	=	globals_dict	.	get	(	"str"	,	None	)	
module	=	sys	.	modules	.	get	(	name	,	None	)	

return	_ModuleObjectAndName	(	module	,	
(	sys	.	argv	[	0	]	if	name	==	"str"	else	name	)	)	


def	get_calling_module_object_and_name	(	)	:	

for	depth	in	range	(	1	,	sys	.	getrecursionlimit	(	)	)	:	


globals_for_frame	=	sys	.	_getframe	(	depth	)	.	f_globals	
module	,	module_name	=	get_module_object_and_name	(	globals_for_frame	)	
if	id	(	module	)	not	in	disclaim_module_ids	and	module_name	is	not	None	:	
return	_ModuleObjectAndName	(	module	,	module_name	)	
raise	AssertionError	(	"str"	)	


def	get_calling_module	(	)	:	

return	get_calling_module_object_and_name	(	)	.	module_name	


def	str_or_unicode	(	value	)	:	

try	:	
return	str	(	value	)	
except	UnicodeEncodeError	:	
return	unicode	(	value	)	


def	create_xml_dom_element	(	doc	,	name	,	value	)	:	

s	=	str_or_unicode	(	value	)	
if	six	.	PY2	and	not	isinstance	(	s	,	unicode	)	:	

s	=	s	.	decode	(	"str"	,	"str"	)	
if	isinstance	(	value	,	bool	)	:	

s	=	s	.	lower	(	)	

s	=	_ILLEGAL_XML_CHARS_REGEX	.	sub	(	"str"	,	s	)	

e	=	doc	.	createElement	(	name	)	
e	.	appendChild	(	doc	.	createTextNode	(	s	)	)	
return	e	


def	get_help_width	(	)	:	

if	not	sys	.	stdout	.	isatty	(	)	or	termios	is	None	or	fcntl	is	None	:	
return	_DEFAULT_HELP_WIDTH	
try	:	
data	=	fcntl	.	ioctl	(	sys	.	stdout	,	termios	.	TIOCGWINSZ	,	"str"	)	
columns	=	struct	.	unpack	(	"str"	,	data	)	[	1	]	


if	columns	>	=	_MIN_HELP_WIDTH	:	
return	columns	

return	int	(	os	.	getenv	(	"str"	,	_DEFAULT_HELP_WIDTH	)	)	

except	(	TypeError	,	IOError	,	struct	.	error	)	:	
return	_DEFAULT_HELP_WIDTH	


def	get_flag_suggestions	(	attempt	,	longopt_list	)	:	


if	len	(	attempt	)	<	=	2	or	not	longopt_list	:	
return	[	]	

option_names	=	[	v	.	split	(	"str"	)	[	0	]	for	v	in	longopt_list	]	



distances	=	[	(	_damerau_levenshtein	(	attempt	,	option	[	0	:	len	(	attempt	)	]	)	,	option	)	
for	option	in	option_names	]	

distances	.	sort	(	)	

least_errors	,	_	=	distances	[	0	]	

if	least_errors	>	=	_SUGGESTION_ERROR_RATE_THRESHOLD	*	len	(	attempt	)	:	
return	[	]	

suggestions	=	[	]	
for	errors	,	name	in	distances	:	
if	errors	==	least_errors	:	
suggestions	.	append	(	name	)	
else	:	
break	
return	suggestions	


def	_damerau_levenshtein	(	a	,	b	)	:	

memo	=	{	}	

def	distance	(	x	,	y	)	:	

if	(	x	,	y	)	in	memo	:	
return	memo	[	x	,	y	]	
if	not	x	:	
d	=	len	(	y	)	
elif	not	y	:	
d	=	len	(	x	)	
else	:	
d	=	min	(	
distance	(	x	[	1	:	]	,	y	)	+	1	,	
distance	(	x	,	y	[	1	:	]	)	+	1	,	
distance	(	x	[	1	:	]	,	y	[	1	:	]	)	+	(	x	[	0	]	!=	y	[	0	]	)	)	
if	len	(	x	)	>	=	2	and	len	(	y	)	>	=	2	and	x	[	0	]	==	y	[	1	]	and	x	[	1	]	==	y	[	0	]	:	

t	=	distance	(	x	[	2	:	]	,	y	[	2	:	]	)	+	1	
if	d	>	t	:	
d	=	t	

memo	[	x	,	y	]	=	d	
return	d	
return	distance	(	a	,	b	)	


def	text_wrap	(	text	,	length	=	None	,	indent	=	"str"	,	firstline_indent	=	None	)	:	


if	length	is	None	:	
length	=	get_help_width	(	)	
if	indent	is	None	:	
indent	=	"str"	
if	firstline_indent	is	None	:	
firstline_indent	=	indent	

if	len	(	indent	)	>	=	length	:	
raise	ValueError	(	"str"	)	
if	len	(	firstline_indent	)	>	=	length	:	
raise	ValueError	(	"str"	)	

text	=	text	.	expandtabs	(	4	)	

result	=	[	]	


wrapper	=	textwrap	.	TextWrapper	(	
width	=	length	,	initial_indent	=	firstline_indent	,	subsequent_indent	=	indent	)	
subsequent_wrapper	=	textwrap	.	TextWrapper	(	
width	=	length	,	initial_indent	=	indent	,	subsequent_indent	=	indent	)	





for	paragraph	in	(	p	.	strip	(	)	for	p	in	text	.	splitlines	(	)	)	:	
if	paragraph	:	
result	.	extend	(	wrapper	.	wrap	(	paragraph	)	)	
else	:	
result	.	append	(	"str"	)	

wrapper	=	subsequent_wrapper	

return	"str"	.	join	(	result	)	


def	flag_dict_to_args	(	flag_map	)	:	

for	key	,	value	in	six	.	iteritems	(	flag_map	)	:	
if	value	is	None	:	
yield	"str"	%	key	
elif	isinstance	(	value	,	bool	)	:	
if	value	:	
yield	"str"	%	key	
else	:	
yield	"str"	%	key	
elif	isinstance	(	value	,	(	bytes	,	type	(	"str"	)	)	)	:	

yield	"str"	%	(	key	,	value	)	
else	:	

try	:	
yield	"str"	%	(	key	,	"str"	.	join	(	str	(	item	)	for	item	in	value	)	)	
except	TypeError	:	

yield	"str"	%	(	key	,	value	)	


def	trim_docstring	(	docstring	)	:	

if	not	docstring	:	
return	"str"	


max_indent	=	1	<<	29	



lines	=	docstring	.	expandtabs	(	)	.	splitlines	(	)	


indent	=	max_indent	
for	line	in	lines	[	1	:	]	:	
stripped	=	line	.	lstrip	(	)	
if	stripped	:	
indent	=	min	(	indent	,	len	(	line	)	-	len	(	stripped	)	)	

trimmed	=	[	lines	[	0	]	.	strip	(	)	]	
if	indent	<	max_indent	:	
for	line	in	lines	[	1	:	]	:	
trimmed	.	append	(	line	[	indent	:	]	.	rstrip	(	)	)	

while	trimmed	and	not	trimmed	[	-	1	]	:	
trimmed	.	pop	(	)	
while	trimmed	and	not	trimmed	[	0	]	:	
trimmed	.	pop	(	0	)	

return	"str"	.	join	(	trimmed	)	


def	doc_to_help	(	doc	)	:	





doc	=	doc	.	strip	(	)	


whitespace_only_line	=	re	.	compile	(	"str"	,	re	.	M	)	
doc	=	whitespace_only_line	.	sub	(	"str"	,	doc	)	


doc	=	trim_docstring	(	doc	)	







doc	=	re	.	sub	(	"str"	,	"str"	,	doc	,	flags	=	re	.	M	)	

return	doc	


def	is_bytes_or_string	(	maybe_string	)	:	
if	str	is	bytes	:	
return	isinstance	(	maybe_string	,	basestring	)	
else	:	
return	isinstance	(	maybe_string	,	(	str	,	bytes	)	)	
	