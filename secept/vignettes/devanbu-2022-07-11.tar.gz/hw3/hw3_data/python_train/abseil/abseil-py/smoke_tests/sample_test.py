















from	__future__	import	absolute_import	
from	__future__	import	division	
from	__future__	import	print_function	

from	absl	.	testing	import	absltest	


class	SampleTest	(	absltest	.	TestCase	)	:	

def	test_subtest	(	self	)	:	
for	i	in	(	1	,	2	)	:	
with	self	.	subTest	(	i	=	i	)	:	
self	.	assertEqual	(	i	,	i	)	
print	(	"str"	)	

if	__name__	==	"str"	:	
absltest	.	main	(	)	
	