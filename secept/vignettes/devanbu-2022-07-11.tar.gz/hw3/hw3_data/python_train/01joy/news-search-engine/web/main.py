
__author__	=	"str"	

from	flask	import	Flask	,	render_template	,	request	

from	search_engine	import	SearchEngine	

import	xml	.	etree	.	ElementTree	as	ET	
import	sqlite3	
import	configparser	
import	time	

import	jieba	

app	=	Flask	(	__name__	)	

doc_dir_path	=	"str"	
db_path	=	"str"	
global	page	
global	keys	


def	init	(	)	:	
config	=	configparser	.	ConfigParser	(	)	
config	.	read	(	"str"	,	"str"	)	
global	dir_path	,	db_path	
dir_path	=	config	[	"str"	]	[	"str"	]	
db_path	=	config	[	"str"	]	[	"str"	]	


@app.route	(	"str"	)	
def	main	(	)	:	
init	(	)	
return	render_template	(	"str"	,	error	=	True	)	



@app.route	(	"str"	,	methods	=	[	"str"	]	)	
def	search	(	)	:	
try	:	
global	keys	
global	checked	
checked	=	[	"str"	,	"str"	,	"str"	]	
keys	=	request	.	form	[	"str"	]	

if	keys	not	in	[	"str"	]	:	
print	(	time	.	clock	(	)	)	
flag	,	page	=	searchidlist	(	keys	)	
if	flag	==	0	:	
return	render_template	(	"str"	,	error	=	False	)	
docs	=	cut_page	(	page	,	0	)	
print	(	time	.	clock	(	)	)	
return	render_template	(	"str"	,	checked	=	checked	,	key	=	keys	,	docs	=	docs	,	page	=	page	,	
error	=	True	)	
else	:	
return	render_template	(	"str"	,	error	=	False	)	

except	:	
print	(	"str"	)	


def	searchidlist	(	key	,	selected	=	0	)	:	
global	page	
global	doc_id	
se	=	SearchEngine	(	"str"	,	"str"	)	
flag	,	id_scores	=	se	.	search	(	key	,	selected	)	

doc_id	=	[	i	for	i	,	s	in	id_scores	]	
page	=	[	]	
for	i	in	range	(	1	,	(	len	(	doc_id	)	/	/	10	+	2	)	)	:	
page	.	append	(	i	)	
return	flag	,	page	


def	cut_page	(	page	,	no	)	:	
docs	=	find	(	doc_id	[	no	*	10	:	page	[	no	]	*	10	]	)	
return	docs	



def	find	(	docid	,	extra	=	False	)	:	
docs	=	[	]	
global	dir_path	,	db_path	
for	id	in	docid	:	
root	=	ET	.	parse	(	dir_path	+	"str"	%	id	)	.	getroot	(	)	
url	=	root	.	find	(	"str"	)	.	text	
title	=	root	.	find	(	"str"	)	.	text	
body	=	root	.	find	(	"str"	)	.	text	
snippet	=	root	.	find	(	"str"	)	.	text	[	0	:	120	]	+	"str"	
time	=	root	.	find	(	"str"	)	.	text	.	split	(	"str"	)	[	0	]	
datetime	=	root	.	find	(	"str"	)	.	text	
doc	=	{	"str"	:	url	,	"str"	:	title	,	"str"	:	snippet	,	"str"	:	datetime	,	"str"	:	time	,	"str"	:	body	,	
"str"	:	id	,	"str"	:	[	]	}	
if	extra	:	
temp_doc	=	get_k_nearest	(	db_path	,	id	)	
for	i	in	temp_doc	:	
root	=	ET	.	parse	(	dir_path	+	"str"	%	i	)	.	getroot	(	)	
title	=	root	.	find	(	"str"	)	.	text	
doc	[	"str"	]	.	append	(	{	"str"	:	i	,	"str"	:	title	}	)	
docs	.	append	(	doc	)	
return	docs	


@app.route	(	"str"	,	methods	=	[	"str"	]	)	
def	next_page	(	page_no	)	:	
try	:	
page_no	=	int	(	page_no	)	
docs	=	cut_page	(	page	,	(	page_no	-	1	)	)	
return	render_template	(	"str"	,	checked	=	checked	,	key	=	keys	,	docs	=	docs	,	page	=	page	,	
error	=	True	)	
except	:	
print	(	"str"	)	


@app.route	(	"str"	,	methods	=	[	"str"	]	)	
def	high_search	(	key	)	:	
try	:	
selected	=	int	(	request	.	form	[	"str"	]	)	
for	i	in	range	(	3	)	:	
if	i	==	selected	:	
checked	[	i	]	=	"str"	
else	:	
checked	[	i	]	=	"str"	
flag	,	page	=	searchidlist	(	key	,	selected	)	
if	flag	==	0	:	
return	render_template	(	"str"	,	error	=	False	)	
docs	=	cut_page	(	page	,	0	)	
return	render_template	(	"str"	,	checked	=	checked	,	key	=	keys	,	docs	=	docs	,	page	=	page	,	
error	=	True	)	
except	:	
print	(	"str"	)	


@app.route	(	"str"	,	methods	=	[	"str"	,	"str"	]	)	
def	content	(	id	)	:	
try	:	
doc	=	find	(	[	id	]	,	extra	=	True	)	
return	render_template	(	"str"	,	doc	=	doc	[	0	]	)	
except	:	
print	(	"str"	)	


def	get_k_nearest	(	db_path	,	docid	,	k	=	5	)	:	
conn	=	sqlite3	.	connect	(	db_path	)	
c	=	conn	.	cursor	(	)	
c	.	execute	(	"str"	,	(	docid	,	)	)	
docs	=	c	.	fetchone	(	)	

conn	.	close	(	)	
return	docs	[	1	:	1	+	(	k	if	k	<	5	else	5	)	]	


if	__name__	==	"str"	:	
jieba	.	initialize	(	)	
app	.	run	(	)	
	