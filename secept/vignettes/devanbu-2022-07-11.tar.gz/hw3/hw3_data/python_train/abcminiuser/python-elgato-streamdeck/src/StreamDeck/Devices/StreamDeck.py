






from	abc	import	ABC	,	abstractmethod	

import	threading	


class	StreamDeck	(	ABC	)	:	


KEY_COUNT	=	None	
KEY_COLS	=	None	
KEY_ROWS	=	None	

KEY_PIXEL_WIDTH	=	None	
KEY_PIXEL_HEIGHT	=	None	
KEY_IMAGE_CODEC	=	None	
KEY_FLIP	=	None	
KEY_ROTATION	=	None	

DECK_TYPE	=	None	

def	__init__	(	self	,	device	)	:	
self	.	device	=	device	
self	.	last_key_states	=	[	False	]	*	self	.	KEY_COUNT	
self	.	read_thread	=	None	
self	.	run_read_thread	=	False	
self	.	key_callback	=	None	

def	__del__	(	self	)	:	

try	:	
self	.	_setup_reader	(	None	)	

self	.	device	.	close	(	)	
except	(	IOError	,	ValueError	)	:	
pass	

@abstractmethod	
def	_read_key_states	(	self	)	:	

pass	

@abstractmethod	
def	_reset_key_stream	(	self	)	:	

pass	

def	_read	(	self	)	:	

while	self	.	run_read_thread	:	
try	:	
new_key_states	=	self	.	_read_key_states	(	)	

if	self	.	key_callback	is	not	None	:	
for	k	,	(	old	,	new	)	in	enumerate	(	zip	(	self	.	last_key_states	,	new_key_states	)	)	:	
if	old	!=	new	:	
self	.	key_callback	(	self	,	k	,	new	)	

self	.	last_key_states	=	new_key_states	
except	(	IOError	,	ValueError	)	:	
self	.	run_read_thread	=	False	

def	_setup_reader	(	self	,	callback	)	:	

if	self	.	read_thread	is	not	None	:	
self	.	run_read_thread	=	False	
self	.	read_thread	.	join	(	)	

if	callback	is	not	None	:	
self	.	run_read_thread	=	True	
self	.	read_thread	=	threading	.	Thread	(	target	=	callback	)	
self	.	read_thread	.	daemon	=	True	
self	.	read_thread	.	start	(	)	

def	open	(	self	)	:	

self	.	device	.	open	(	)	

self	.	_reset_key_stream	(	)	
self	.	_setup_reader	(	self	.	_read	)	

def	close	(	self	)	:	

self	.	device	.	close	(	)	

def	connected	(	self	)	:	

return	self	.	device	.	connected	(	)	

def	id	(	self	)	:	

return	self	.	device	.	path	(	)	

def	key_count	(	self	)	:	

return	self	.	KEY_COUNT	

def	deck_type	(	self	)	:	

return	self	.	DECK_TYPE	

def	key_layout	(	self	)	:	

return	self	.	KEY_ROWS	,	self	.	KEY_COLS	

def	key_image_format	(	self	)	:	

return	{	
"str"	:	(	self	.	KEY_PIXEL_WIDTH	,	self	.	KEY_PIXEL_HEIGHT	)	,	
"str"	:	self	.	KEY_IMAGE_FORMAT	,	
"str"	:	self	.	KEY_FLIP	,	
"str"	:	self	.	KEY_ROTATION	,	
}	

def	set_key_callback	(	self	,	callback	)	:	

self	.	key_callback	=	callback	

def	set_key_callback_async	(	self	,	async_callback	,	loop	=	None	)	:	

import	asyncio	

loop	=	loop	or	asyncio	.	get_event_loop	(	)	

def	callback	(	*	args	)	:	
asyncio	.	run_coroutine_threadsafe	(	async_callback	(	*	args	)	,	loop	)	

self	.	set_key_callback	(	callback	)	

def	key_states	(	self	)	:	

return	self	.	last_key_states	

@abstractmethod	
def	reset	(	self	)	:	

pass	

@abstractmethod	
def	set_brightness	(	self	,	percent	)	:	

pass	

@abstractmethod	
def	get_serial_number	(	self	)	:	

pass	

@abstractmethod	
def	get_firmware_version	(	self	)	:	

pass	

@abstractmethod	
def	set_key_image	(	self	,	key	,	image	)	:	

pass	
	