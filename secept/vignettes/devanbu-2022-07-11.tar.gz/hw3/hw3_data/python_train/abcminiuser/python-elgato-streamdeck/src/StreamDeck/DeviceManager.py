






from		.	Devices	.	StreamDeckOriginal	import	StreamDeckOriginal	
from		.	Devices	.	StreamDeckMini	import	StreamDeckMini	
from		.	Devices	.	StreamDeckXL	import	StreamDeckXL	
from		.	Transport	.	Dummy	import	Dummy	
from		.	Transport	.	HID	import	HID	
from		.	Transport	.	HIDAPI	import	HIDAPI	


class	ProbeError	(	Exception	)	:	
pass	


class	DeviceManager	:	


USB_VID_ELGATO	=	0x0fd9	
USB_PID_STREAMDECK_ORIGINAL	=	0x0060	
USB_PID_STREAMDECK_MINI	=	0x0063	
USB_PID_STREAMDECK_XL	=	0x006c	

@staticmethod	
def	_get_transport	(	transport	)	:	


transports	=	{	
"str"	:	Dummy	,	
"str"	:	HID	,	
"str"	:	HIDAPI	,	
}	

if	transport	:	
transport_class	=	transports	.	get	(	transport	)	

if	transport_class	is	None	:	
raise	ProbeError	(	"str"	.	format	(	transport	)	)	

try	:	
transport_class	.	probe	(	)	
return	transport_class	(	)	
except	Exception	as	transport_error	:	
raise	ProbeError	(	"str"	.	format	(	transport	)	,	transport_error	)	
else	:	
probe_errors	=	{	}	

for	transport_name	,	transport_class	in	transports	.	items	(	)	:	
if	transport_name	==	"str"	:	
continue	

try	:	
transport_class	.	probe	(	)	
return	transport_class	(	)	
except	Exception	as	transport_error	:	
probe_errors	[	transport_name	]	=	transport_error	

raise	ProbeError	(	"str"	,	probe_errors	)	

def	__init__	(	self	,	transport	=	None	)	:	

self	.	transport	=	self	.	_get_transport	(	transport	)	

def	enumerate	(	self	)	:	


products	=	[	
(	self	.	USB_VID_ELGATO	,	self	.	USB_PID_STREAMDECK_ORIGINAL	,	StreamDeckOriginal	)	,	
(	self	.	USB_VID_ELGATO	,	self	.	USB_PID_STREAMDECK_MINI	,	StreamDeckMini	)	,	
(	self	.	USB_VID_ELGATO	,	self	.	USB_PID_STREAMDECK_XL	,	StreamDeckXL	)	,	
]	

streamdecks	=	list	(	)	

for	vid	,	pid	,	class_type	in	products	:	
found_devices	=	self	.	transport	.	enumerate	(	vid	=	vid	,	pid	=	pid	)	
streamdecks	.	extend	(	[	class_type	(	d	)	for	d	in	found_devices	]	)	

return	streamdecks	
	