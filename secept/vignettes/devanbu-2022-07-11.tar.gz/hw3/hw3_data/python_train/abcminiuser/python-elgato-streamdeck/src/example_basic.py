











import	os	
import	threading	
from	PIL	import	Image	,	ImageDraw	,	ImageFont	
from	StreamDeck	.	DeviceManager	import	DeviceManager	
from	StreamDeck	.	ImageHelpers	import	PILHelper	



ASSETS_PATH	=	os	.	path	.	join	(	os	.	path	.	dirname	(	__file__	)	,	"str"	)	




def	render_key_image	(	deck	,	icon_filename	,	font_filename	,	label_text	)	:	

image	=	PILHelper	.	create_image	(	deck	)	



icon	=	Image	.	open	(	icon_filename	)	.	convert	(	"str"	)	
icon	.	thumbnail	(	(	image	.	width	,	image	.	height	-	20	)	,	Image	.	LANCZOS	)	
icon_pos	=	(	(	image	.	width	-	icon	.	width	)	/	/	2	,	0	)	
image	.	paste	(	icon	,	icon_pos	,	icon	)	



draw	=	ImageDraw	.	Draw	(	image	)	
font	=	ImageFont	.	truetype	(	font_filename	,	14	)	
label_w	,	label_h	=	draw	.	textsize	(	label_text	,	font	=	font	)	
label_pos	=	(	(	image	.	width	-	label_w	)	/	/	2	,	image	.	height	-	20	)	
draw	.	text	(	label_pos	,	text	=	label_text	,	font	=	font	,	fill	=	"str"	)	

return	PILHelper	.	to_native_format	(	deck	,	image	)	



def	get_key_style	(	deck	,	key	,	state	)	:	

exit_key_index	=	deck	.	key_count	(	)	-	1	

if	key	==	exit_key_index	:	
name	=	"str"	
icon	=	"str"	.	format	(	"str"	)	
font	=	"str"	
label	=	"str"	if	state	else	"str"	
else	:	
name	=	"str"	
icon	=	"str"	.	format	(	"str"	if	state	else	"str"	)	
font	=	"str"	
label	=	"str"	if	state	else	"str"	.	format	(	key	)	

return	{	
"str"	:	name	,	
"str"	:	os	.	path	.	join	(	ASSETS_PATH	,	icon	)	,	
"str"	:	os	.	path	.	join	(	ASSETS_PATH	,	font	)	,	
"str"	:	label	
}	




def	update_key_image	(	deck	,	key	,	state	)	:	

key_style	=	get_key_style	(	deck	,	key	,	state	)	


image	=	render_key_image	(	deck	,	key_style	[	"str"	]	,	key_style	[	"str"	]	,	key_style	[	"str"	]	)	


deck	.	set_key_image	(	key	,	image	)	




def	key_change_callback	(	deck	,	key	,	state	)	:	

print	(	"str"	.	format	(	deck	.	id	(	)	,	key	,	state	)	,	flush	=	True	)	


update_key_image	(	deck	,	key	,	state	)	


if	state	:	
key_style	=	get_key_style	(	deck	,	key	,	state	)	


if	key_style	[	"str"	]	==	"str"	:	

deck	.	reset	(	)	


deck	.	close	(	)	


if	__name__	==	"str"	:	
streamdecks	=	DeviceManager	(	)	.	enumerate	(	)	

print	(	"str"	.	format	(	len	(	streamdecks	)	)	)	

for	index	,	deck	in	enumerate	(	streamdecks	)	:	
deck	.	open	(	)	
deck	.	reset	(	)	

print	(	"str"	.	format	(	deck	.	deck_type	(	)	,	deck	.	get_serial_number	(	)	)	)	


deck	.	set_brightness	(	30	)	


for	key	in	range	(	deck	.	key_count	(	)	)	:	
update_key_image	(	deck	,	key	,	False	)	


deck	.	set_key_callback	(	key_change_callback	)	



for	t	in	threading	.	enumerate	(	)	:	
if	t	is	threading	.	currentThread	(	)	:	
continue	

if	t	.	is_alive	(	)	:	
t	.	join	(	)	
	