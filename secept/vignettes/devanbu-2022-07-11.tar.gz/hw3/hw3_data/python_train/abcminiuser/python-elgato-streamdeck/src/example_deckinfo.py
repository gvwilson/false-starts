











from	StreamDeck	.	DeviceManager	import	DeviceManager	



def	print_deck_info	(	index	,	deck	)	:	
image_format	=	deck	.	key_image_format	(	)	

flip_description	=	{	
(	False	,	False	)	:	"str"	,	
(	True	,	False	)	:	"str"	,	
(	False	,	True	)	:	"str"	,	
(	True	,	True	)	:	"str"	,	
}	

print	(	"str"	.	format	(	index	,	deck	.	deck_type	(	)	)	)	
print	(	"str"	.	format	(	deck	.	id	(	)	)	)	
print	(	"str"	.	format	(	deck	.	get_serial_number	(	)	)	)	
print	(	"str"	.	format	(	deck	.	get_firmware_version	(	)	)	)	
print	(	"str"	.	format	(	
deck	.	key_count	(	)	,	
deck	.	key_layout	(	)	[	0	]	,	
deck	.	key_layout	(	)	[	1	]	)	)	
print	(	"str"	.	format	(	
image_format	[	"str"	]	[	0	]	,	
image_format	[	"str"	]	[	1	]	,	
image_format	[	"str"	]	,	
image_format	[	"str"	]	,	
flip_description	[	image_format	[	"str"	]	]	)	)	


if	__name__	==	"str"	:	
streamdecks	=	DeviceManager	(	)	.	enumerate	(	)	

print	(	"str"	.	format	(	len	(	streamdecks	)	)	)	

for	index	,	deck	in	enumerate	(	streamdecks	)	:	
deck	.	open	(	)	
deck	.	reset	(	)	

print_deck_info	(	index	,	deck	)	

deck	.	close	(	)	
	