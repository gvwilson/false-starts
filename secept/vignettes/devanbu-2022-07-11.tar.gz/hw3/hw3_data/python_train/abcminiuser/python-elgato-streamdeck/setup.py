import	setuptools	

with	open	(	"str"	,	"str"	)	as	f	:	
version	=	f	.	read	(	)	.	strip	(	)	

with	open	(	"str"	,	"str"	)	as	f	:	
long_description	=	f	.	read	(	)	

setuptools	.	setup	(	
name	=	"str"	,	
version	=	version	,	
description	=	"str"	,	
author	=	"str"	,	
author_email	=	"str"	,	
url	=	"str"	,	
package_dir	=	{	"str"	:	"str"	}	,	
packages	=	setuptools	.	find_packages	(	where	=	"str"	)	,	
install_requires	=	[	]	,	
license	=	"str"	,	
long_description	=	long_description	,	
long_description_content_type	=	"str"	,	
include_package_data	=	True	,	
)	
	