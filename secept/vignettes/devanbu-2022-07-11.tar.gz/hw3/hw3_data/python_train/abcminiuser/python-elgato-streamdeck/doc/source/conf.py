


















import	os	
import	sys	

import	sphinx_rtd_theme	

ROOT_PATH	=	os	.	path	.	join	(	os	.	path	.	dirname	(	__file__	)	,	"str"	,	"str"	)	

with	open	(	os	.	path	.	join	(	ROOT_PATH	,	"str"	)	,	"str"	)	as	f	:	
package_version	=	f	.	read	(	)	.	strip	(	)	

sys	.	path	.	insert	(	0	,	os	.	path	.	abspath	(	os	.	path	.	join	(	ROOT_PATH	,	"str"	)	)	)	











extensions	=	[	"str"	,	"str"	]	


templates_path	=	[	"str"	]	





source_suffix	=	[	"str"	,	"str"	]	


master_doc	=	"str"	


project	=	"str"	
copyright	=	"str"	
author	=	"str"	






version	=	package_version	

release	=	package_version	






language	=	None	




exclude_patterns	=	[	]	


pygments_style	=	"str"	


todo_include_todos	=	False	

autoclass_content	=	"str"	






html_theme	=	"str"	
html_theme_path	=	[	sphinx_rtd_theme	.	get_html_theme_path	(	)	]	










html_static_path	=	[	]	

html_extra_path	=	[	os	.	path	.	join	(	ROOT_PATH	,	"str"	)	]	






html_sidebars	=	{	
"str"	:	[	
"str"	,	
"str"	,	
]	
}	





htmlhelp_basename	=	"str"	




latex_elements	=	{	















}	




latex_documents	=	[	
(	master_doc	,	"str"	,	"str"	,	
"str"	,	"str"	)	,	
]	






man_pages	=	[	
(	master_doc	,	"str"	,	"str"	,	
[	author	]	,	1	)	
]	







texinfo_documents	=	[	
(	master_doc	,	"str"	,	"str"	,	
author	,	"str"	,	"str"	,	
"str"	)	,	
]	
	