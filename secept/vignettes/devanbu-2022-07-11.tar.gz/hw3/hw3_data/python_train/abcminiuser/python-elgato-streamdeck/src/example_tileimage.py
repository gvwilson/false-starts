












import	os	
import	threading	
from	PIL	import	Image	
from	StreamDeck	.	DeviceManager	import	DeviceManager	
from	StreamDeck	.	ImageHelpers	import	PILHelper	



ASSETS_PATH	=	os	.	path	.	join	(	os	.	path	.	dirname	(	__file__	)	,	"str"	)	




def	create_full_deck_sized_image	(	deck	,	image_filename	)	:	
key_width	,	key_height	=	deck	.	key_image_format	(	)	[	"str"	]	
key_rows	,	key_cols	=	deck	.	key_layout	(	)	

full_deck_image_size	=	(	key_width	*	key_cols	,	key_height	*	key_rows	)	



image	=	Image	.	open	(	os	.	path	.	join	(	ASSETS_PATH	,	image_filename	)	)	.	convert	(	"str"	)	
return	image	.	resize	(	full_deck_image_size	,	Image	.	LANCZOS	)	




def	crop_key_image_from_deck_sized_image	(	deck	,	image	,	key	)	:	
key_width	,	key_height	=	deck	.	key_image_format	(	)	[	"str"	]	
key_rows	,	key_cols	=	deck	.	key_layout	(	)	


row	=	key	/	/	key_cols	
col	=	key	%	key_cols	



region	=	(	col	*	key_width	,	row	*	key_height	,	(	col	+	1	)	*	key_width	,	(	row	+	1	)	*	key_height	)	
segment	=	image	.	crop	(	region	)	



key_image	=	PILHelper	.	create_image	(	deck	)	
key_image	.	paste	(	segment	)	

return	PILHelper	.	to_native_format	(	deck	,	key_image	)	



def	key_change_callback	(	deck	,	key	,	state	)	:	

deck	.	reset	(	)	


deck	.	close	(	)	


if	__name__	==	"str"	:	
streamdecks	=	DeviceManager	(	)	.	enumerate	(	)	

print	(	"str"	.	format	(	len	(	streamdecks	)	)	)	

for	index	,	deck	in	enumerate	(	streamdecks	)	:	
deck	.	open	(	)	
deck	.	reset	(	)	

print	(	"str"	.	format	(	deck	.	deck_type	(	)	,	deck	.	get_serial_number	(	)	)	)	


deck	.	set_brightness	(	30	)	



image	=	create_full_deck_sized_image	(	deck	,	"str"	)	

for	k	in	range	(	deck	.	key_count	(	)	)	:	


key_image	=	crop_key_image_from_deck_sized_image	(	deck	,	image	,	k	)	


deck	.	set_key_image	(	k	,	key_image	)	


deck	.	set_key_callback	(	key_change_callback	)	



for	t	in	threading	.	enumerate	(	)	:	
if	t	is	threading	.	currentThread	(	)	:	
continue	

if	t	.	is_alive	(	)	:	
t	.	join	(	)	
	