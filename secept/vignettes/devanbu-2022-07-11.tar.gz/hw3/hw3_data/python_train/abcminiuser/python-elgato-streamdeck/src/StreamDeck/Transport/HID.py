








from		.	Transport	import	Transport	


class	HID	(	Transport	)	:	


class	Device	(	Transport	.	Device	)	:	
def	__init__	(	self	,	device_info	)	:	

import	hid	

self	.	hid_info	=	device_info	
self	.	hid	=	hid	.	Device	(	vid	=	device_info	[	"str"	]	,	pid	=	device_info	[	"str"	]	)	

def	__del__	(	self	)	:	

try	:	
self	.	hid	.	close	(	)	
except	(	IOError	,	ValueError	)	:	
pass	

def	open	(	self	)	:	

import	hid	

self	.	hid	=	hid	.	Device	(	path	=	self	.	hid_info	[	"str"	]	)	

def	close	(	self	)	:	

self	.	hid	.	close	(	)	

def	connected	(	self	)	:	

import	hid	

devices	=	hid	.	enumerate	(	)	
return	any	(	[	d	[	"str"	]	==	self	.	hid_info	[	"str"	]	for	d	in	devices	]	)	

def	path	(	self	)	:	

return	self	.	hid_info	[	"str"	]	

def	write_feature	(	self	,	payload	)	:	

if	type	(	payload	)	is	bytearray	:	
payload	=	bytes	(	payload	)	

return	self	.	hid	.	send_feature_report	(	payload	)	

def	read_feature	(	self	,	report_id	,	length	)	:	

return	self	.	hid	.	get_feature_report	(	report_id	,	length	)	

def	write	(	self	,	payload	)	:	

if	type	(	payload	)	is	bytearray	:	
payload	=	bytes	(	payload	)	

return	self	.	hid	.	write	(	payload	)	

def	read	(	self	,	length	)	:	

return	self	.	hid	.	read	(	length	)	

@staticmethod	
def	probe	(	)	:	


import	hid	
hid	.	enumerate	(	vid	=	0	,	pid	=	0	)	

def	enumerate	(	self	,	vid	,	pid	)	:	


if	vid	is	None	:	
vid	=	0	

if	pid	is	None	:	
pid	=	0	

import	hid	
devices	=	hid	.	enumerate	(	vid	=	vid	,	pid	=	pid	)	

return	[	HID	.	Device	(	d	)	for	d	in	devices	]	
	