






from	abc	import	ABC	,	abstractmethod	


class	Transport	(	ABC	)	:	


class	Device	(	ABC	)	:	


@abstractmethod	
def	open	(	self	)	:	

pass	

@abstractmethod	
def	close	(	self	)	:	

pass	

@abstractmethod	
def	connected	(	self	)	:	

pass	

@abstractmethod	
def	path	(	self	)	:	

pass	

@abstractmethod	
def	write_feature	(	self	,	payload	)	:	

pass	

@abstractmethod	
def	read_feature	(	self	,	report_id	,	length	)	:	

pass	

@abstractmethod	
def	write	(	self	,	payload	)	:	

pass	

@abstractmethod	
def	read	(	self	,	length	)	:	

pass	

@abstractmethod	
def	probe	(	)	:	

pass	

@abstractmethod	
def	enumerate	(	self	,	vid	,	pid	)	:	

pass	
	