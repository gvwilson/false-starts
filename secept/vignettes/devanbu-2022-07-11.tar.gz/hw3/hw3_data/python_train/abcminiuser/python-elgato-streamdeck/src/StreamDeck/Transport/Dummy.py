






import	logging	
import	binascii	

from		.	Transport	import	Transport	


class	Dummy	(	Transport	)	:	


class	Device	(	Transport	.	Device	)	:	
def	__init__	(	self	,	device_id	)	:	
self	.	id	=	device_id	

def	open	(	self	)	:	
logging	.	info	(	"str"	)	

def	close	(	self	)	:	
logging	.	info	(	"str"	)	

def	connected	(	self	)	:	
return	True	

def	path	(	self	)	:	
return	self	.	id	

def	write_feature	(	self	,	payload	)	:	
logging	.	info	(	"str"	,	len	(	payload	)	,	binascii	.	hexlify	(	payload	)	)	
return	True	

def	read_feature	(	self	,	report_id	,	length	)	:	
logging	.	info	(	"str"	,	length	)	
raise	IOError	(	"str"	)	

def	write	(	self	,	payload	)	:	
logging	.	info	(	"str"	,	len	(	payload	)	,	binascii	.	hexlify	(	payload	)	)	
return	True	

def	read	(	self	,	length	)	:	
logging	.	info	(	"str"	,	length	)	
raise	IOError	(	"str"	)	

@staticmethod	
def	probe	(	)	:	
pass	

def	enumerate	(	self	,	vid	,	pid	)	:	
return	[	Dummy	.	Device	(	"str"	.	format	(	vid	,	pid	)	)	]	
	