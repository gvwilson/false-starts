






import	io	


def	create_image	(	deck	,	background	=	"str"	)	:	

from	PIL	import	Image	

image_format	=	deck	.	key_image_format	(	)	

return	Image	.	new	(	"str"	,	image_format	[	"str"	]	,	background	)	


def	to_native_format	(	deck	,	image	)	:	

from	PIL	import	Image	

image_format	=	deck	.	key_image_format	(	)	

if	image_format	[	"str"	]	:	
image	=	image	.	rotate	(	image_format	[	"str"	]	)	

if	image_format	[	"str"	]	[	0	]	:	
image	=	image	.	transpose	(	Image	.	FLIP_LEFT_RIGHT	)	

if	image_format	[	"str"	]	[	1	]	:	
image	=	image	.	transpose	(	Image	.	FLIP_TOP_BOTTOM	)	

if	image	.	size	!=	image_format	[	"str"	]	:	
image	.	thumbnail	(	image_format	[	"str"	]	)	


compressed_image	=	io	.	BytesIO	(	)	
image	.	save	(	compressed_image	,	image_format	[	"str"	]	)	
return	compressed_image	.	getbuffer	(	)	
	