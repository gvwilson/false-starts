


import	tensorflow	as	tf	
import	tflearn	
from	tflearn	.	data_preprocessing	import	ImagePreprocessing	
import	os	
from	tflearn	.	data_utils	import	shuffle	
import	numpy	as	np	
import	pickle	
from	tflearn	.	data_utils	import	image_preloader	

def	vgg16_base	(	input	)	:	

x	=	tflearn	.	conv_2d	(	input	,	64	,	3	,	activation	=	"str"	,	scope	=	"str"	,	trainable	=	False	)	
x	=	tflearn	.	conv_2d	(	x	,	64	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	max_pool_2d	(	x	,	2	,	strides	=	2	,	name	=	"str"	)	

x	=	tflearn	.	conv_2d	(	x	,	128	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	128	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	max_pool_2d	(	x	,	2	,	strides	=	2	,	name	=	"str"	)	

x	=	tflearn	.	conv_2d	(	x	,	256	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	256	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	256	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	max_pool_2d	(	x	,	2	,	strides	=	2	,	name	=	"str"	)	

x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	max_pool_2d	(	x	,	2	,	strides	=	2	,	name	=	"str"	)	

x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	conv_2d	(	x	,	512	,	3	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	max_pool_2d	(	x	,	2	,	strides	=	2	,	name	=	"str"	)	

x	=	tflearn	.	fully_connected	(	x	,	4096	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	dropout	(	x	,	0.5	,	name	=	"str"	)	

x	=	tflearn	.	fully_connected	(	x	,	4096	,	activation	=	"str"	,	scope	=	"str"	)	
x	=	tflearn	.	dropout	(	x	,	0.5	,	name	=	"str"	)	


x	=	tflearn	.	fully_connected	(	x	,	100	,	activation	=	"str"	,	scope	=	"str"	,	restore	=	False	)	
return	x	





num_classes	=	100	


img_prep	=	ImagePreprocessing	(	)	
img_prep	.	add_featurewise_zero_center	(	mean	=	[	123.68	,	116.779	,	103.939	]	,	
per_channel	=	True	)	


x	=	tflearn	.	input_data	(	shape	=	[	None	,	224	,	224	,	3	]	,	name	=	"str"	,	
data_preprocessing	=	img_prep	)	
softmax	=	vgg16_base	(	x	)	

sgd	=	tflearn	.	SGD	(	learning_rate	=	0.001	,	lr_decay	=	0.96	,	decay_step	=	500	)	
regression	=	tflearn	.	regression	(	softmax	,	optimizer	=	sgd	,	
loss	=	"str"	)	

model	=	tflearn	.	DNN	(	regression	,	checkpoint_path	=	"str"	,	
best_checkpoint_path	=	"str"	,	max_checkpoints	=	3	,	tensorboard_verbose	=	2	,	
tensorboard_dir	=	"str"	)	


model	.	load	(	"str"	,	weights_only	=	True	)	


vgg_weights_dict	=	{	}	
vgg_layers	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	

for	layer_name	in	vgg_layers	:	
print	layer_name	
base_layer	=	tflearn	.	variables	.	get_layer_variables_by_name	(	layer_name	)	
vgg_weights_dict	[	layer_name	]	=	[	model	.	get_weights	(	base_layer	[	0	]	)	,	model	.	get_weights	(	base_layer	[	1	]	)	]	

pickle	.	dump	(	vgg_weights_dict	,	open	(	"str"	,	"str"	)	)	
	