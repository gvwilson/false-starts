from	tflearn	.	data_utils	import	build_hdf5_image_dataset	
import	h5py	

new_train	=	"str"	
new_val	=	"str"	
new_test	=	"str"	


build_hdf5_image_dataset	(	new_val	,	image_shape	=	(	224	,	224	)	,	mode	=	"str"	,	output_path	=	"str"	,	categorical_labels	=	True	,	normalize	=	False	)	
print	"str"	
build_hdf5_image_dataset	(	new_test	,	image_shape	=	(	224	,	224	)	,	mode	=	"str"	,	output_path	=	"str"	,	categorical_labels	=	True	,	normalize	=	False	)	
print	"str"	
build_hdf5_image_dataset	(	new_train	,	image_shape	=	(	488	,	488	)	,	mode	=	"str"	,	output_path	=	"str"	,	categorical_labels	=	True	,	normalize	=	False	)	
print	"str"	
	