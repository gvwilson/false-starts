print	(	"str"	)	
bl_info	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	(	2	,	0	,	5	)	,	
"str"	:	(	2	,	79	,	0	)	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	

import	bpy	
import	bpy	.	utils	.	previews	
import	nodeitems_utils	
import	random	
import	requests	
import	math	

from	bpy	.	types	import	NodeTree	,	Node	,	NodeSocket	,	Operator	
from	bpy	.	props	import	IntProperty	,	FloatProperty	,	EnumProperty	,	BoolProperty	,	StringProperty	,	FloatVectorProperty	,	PointerProperty	,	BoolVectorProperty	
from	nodeitems_utils	import	NodeCategory	,	NodeItem	,	NodeItemCustom	,	_node_categories	
from	mathutils	import	Vector	


class	ScPreferences	(	bpy	.	types	.	AddonPreferences	)	:	
bl_idname	=	__name__	

prop_addon_location	=	StringProperty	(	name	=	"str"	,	default	=	bpy	.	utils	.	user_resource	(	"str"	,	"str"	)	+	__name__	+	"str"	)	

def	draw	(	self	,	context	)	:	
layout	=	self	.	layout	
layout	.	prop	(	self	,	"str"	)	
layout	.	operator	(	"str"	)	
class	ScAddonUpdater	(	Operator	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
bl_options	=	{	"str"	,	"str"	}	

def	execute	(	self	,	context	)	:	
user_prefs	=	context	.	user_preferences	
addon_prefs	=	user_prefs	.	addons	[	__name__	]	.	preferences	
print	(	"str"	)	
r	=	requests	.	get	(	"str"	)	
print	(	"str"	)	
f	=	open	(	addon_prefs	.	prop_addon_location	,	"str"	,	encoding	=	"str"	)	
f	.	write	(	r	.	text	)	
print	(	"str"	)	
f	.	close	(	)	
return	{	"str"	}	





class	ScNodeSocket	:	
prop_prop	=	StringProperty	(	default	=	"str"	)	
color	=	(	1.0	,	1.0	,	1.0	,	1.0	)	
mirror_prop	=	True	
friends	=	[	]	
def	draw_color	(	self	,	context	,	node	)	:	
return	self	.	color	
def	draw	(	self	,	context	,	layout	,	node	,	text	)	:	
if	(	not	self	.	is_output	)	and	(	not	self	.	is_linked	)	and	(	self	.	mirror_prop	)	:	
layout	.	prop	(	node	,	self	.	prop_prop	,	text	=	self	.	name	)	
else	:	
layout	.	label	(	self	.	name	)	
def	execute	(	self	)	:	
if	(	self	.	is_output	)	:	
return	self	.	node	.	execute	(	)	


elif	(	self	.	is_linked	)	:	
return	self	.	links	[	0	]	.	from_socket	.	execute	(	)	
elif	(	self	.	mirror_prop	)	:	
return	eval	(	"str"	+	self	.	prop_prop	)	
else	:	
return	None	

class	ScMeshSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	1.0	,	1.0	,	1.0	)	
mirror_prop	=	False	
class	ScMeshRefSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	1.0	,	1.0	,	1.0	)	
friends	=	[	"str"	]	
class	ScMeshArraySocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	1.0	,	1.0	,	0.5	)	
mirror_prop	=	False	
friends	=	[	"str"	,	"str"	]	
class	ScComponentSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.0	,	0.0	,	0.0	,	1.0	)	
mirror_prop	=	False	
class	ScObjectSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.5	,	0.5	,	0.5	,	1.0	)	
mirror_prop	=	False	
friends	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
class	ScBoolSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	0.0	,	0.0	,	1.0	)	
class	ScIntSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.0	,	0.7	,	1.0	,	1.0	)	
class	ScFloatSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.0	,	1.0	,	0.0	,	1.0	)	
class	ScFloatVectorSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	1.0	,	0.0	,	1.0	)	
class	ScAngleSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.0	,	0.0	,	0.5	,	1.0	)	
friends	=	[	"str"	]	
class	ScAngleVectorSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.3	,	0.3	,	1.0	,	1.0	)	
friends	=	[	"str"	]	
class	ScStringSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	0.0	,	1.0	,	1.0	)	
class	ScUniversalSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	1.0	,	1.0	,	0.0	)	
mirror_prop	=	False	
friends	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
class	ScInfoSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	1.0	,	0.5	,	0.5	,	1.0	)	
mirror_prop	=	False	
class	ScCurveSocket	(	NodeSocket	,	ScNodeSocket	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
color	=	(	0.3	,	0.5	,	0.0	,	1.0	)	
mirror_prop	=	False	





class	ScNode	:	
first_time	=	BoolProperty	(	default	=	True	)	
node_color	=	(	1	,	1	,	1	)	
@classmethod	
def	poll	(	cls	,	ntree	)	:	
return	ntree	.	bl_idname	==	"str"	
def	update_value	(	self	,	context	)	:	
bpy	.	ops	.	sc	.	execute_node_op	(	)	
return	None	
def	init	(	self	,	context	)	:	
self	.	hide	=	self	.	id_data	.	prop_collapse	
self	.	use_custom_color	=	True	
self	.	color	=	self	.	node_color	
def	override	(	self	,	mesh	=	False	,	edit	=	False	)	:	
window	=	bpy	.	data	.	window_managers	[	"str"	]	.	windows	[	0	]	
screen	=	window	.	screen	
area	=	[	i	for	i	in	screen	.	areas	if	i	.	type	==	"str"	]	[	0	]	
space	=	area	.	spaces	[	0	]	
scene	=	bpy	.	data	.	scenes	[	0	]	
region	=	[	i	for	i	in	area	.	regions	if	i	.	type	==	"str"	]	[	0	]	
ret	=	{	"str"	:	window	,	"str"	:	screen	,	"str"	:	area	,	"str"	:	space	,	"str"	:	scene	,	"str"	:	region	,	"str"	:	bpy	.	context	.	gpencil_data	}	
if	(	mesh	)	:	
try	:	
ret	[	"str"	]	=	self	.	mesh	
if	(	edit	)	:	
ret	[	"str"	]	=	self	.	mesh	
except	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	ret	
def	draw_buttons	(	self	,	context	,	layout	)	:	

pass	
def	pre_execute	(	self	)	:	

return	True	
def	post_execute	(	self	)	:	

pass	
def	execute	(	self	)	:	
if	not	self	.	pre_execute	(	)	:	
return	None	
self	.	functionality	(	)	
ret_data	=	self	.	post_execute	(	)	
if	(	self	.	first_time	)	:	
self	.	first_time	=	False	
return	ret_data	
def	functionality	(	self	)	:	

pass	

class	ScInputNode	(	ScNode	)	:	
node_color	=	(	0.5	,	0.0	,	0.0	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	bpy	.	context	.	active_object	==	None	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
removeMesh	(	self	.	mesh	)	
return	True	

def	post_execute	(	self	)	:	
self	.	mesh	=	bpy	.	context	.	active_object	
return	self	.	mesh	
class	ScTransformNode	(	ScNode	)	:	
node_color	=	(	0.0	,	0.5	,	0.0	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	context	.	scene	.	objects	.	active	=	self	.	mesh	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScModifierNode	(	ScNode	)	:	
node_color	=	(	0.0	,	0.0	,	0.5	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	context	.	scene	.	objects	.	active	=	self	.	mesh	
return	True	

def	post_execute	(	self	)	:	
bpy	.	ops	.	object	.	modifier_apply	(	modifier	=	self	.	mesh	.	modifiers	[	0	]	.	name	)	
return	self	.	mesh	
class	ScConversionNode	(	ScNode	)	:	
node_color	=	(	0.0	,	0.5	,	0.5	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	0	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	context	.	scene	.	objects	.	active	=	self	.	mesh	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScSelectionNode	(	ScNode	)	:	
node_color	=	(	0.5	,	0.0	,	0.5	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScDeletionNode	(	ScNode	)	:	
node_color	=	(	0.5	,	0.5	,	0.0	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScEditOperatorNode	(	ScNode	)	:	
node_color	=	(	0.5	,	0.5	,	0.5	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScObjectOperatorNode	(	ScNode	)	:	
node_color	=	(	0.3	,	0.7	,	0.0	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScCurveOperatorNode	(	ScNode	)	:	
node_color	=	(	0.3	,	0.7	,	0.7	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	ScConstantNode	(	ScNode	)	:	
node_color	=	(	0.3	,	0.0	,	0.7	)	

def	init	(	self	,	context	)	:	
self	.	use_custom_color	=	True	
self	.	color	=	self	.	node_color	
class	ScUtilityNode	(	ScNode	)	:	
node_color	=	(	0.7	,	0.3	,	0.0	)	
class	ScControlNode	(	ScNode	)	:	
node_color	=	(	0.0	,	0.3	,	0.7	)	
class	ScSettingNode	(	ScNode	)	:	
node_color	=	(	0.7	,	0.0	,	0.3	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
super	(	)	.	init	(	context	)	

def	post_execute	(	self	)	:	
return	self	.	inputs	[	0	]	.	execute	(	)	
class	ScOutputNode	(	ScNode	)	:	
node_color	=	(	0.0	,	0.7	,	0.3	)	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	move	(	len	(	self	.	inputs	)	-	1	,	0	)	
self	.	use_custom_color	=	True	
self	.	color	=	self	.	node_color	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	




class	ScRealtimeMeshOp	(	Operator	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
bl_options	=	{	"str"	,	"str"	}	

node	=	None	
node_tree	=	None	

@classmethod	
def	poll	(	cls	,	context	)	:	
if	(	context	.	space_data	.	type	==	"str"	)	:	
return	context	.	space_data	.	tree_type	==	"str"	
return	False	

def	execute	(	self	,	context	)	:	
bpy	.	ops	.	sc	.	execute_node_op	(	)	
return	{	"str"	}	

def	modal	(	self	,	context	,	event	)	:	
if	(	event	.	type	==	"str"	)	:	
print	(	"str"	)	
return	{	"str"	}	
elif	(	event	.	type	==	"str"	)	:	
node	=	context	.	space_data	.	node_tree	.	nodes	.	active	
if	(	not	node	==	self	.	node	)	:	
print	(	"str"	)	
self	.	node	=	node	
self	.	execute	(	context	)	
return	{	"str"	}	

def	invoke	(	self	,	context	,	event	)	:	
context	.	window_manager	.	modal_handler_add	(	self	)	
print	(	"str"	)	
return	{	"str"	}	
class	ScSaveSelectionOp	(	Operator	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
bl_options	=	{	"str"	,	"str"	}	

@classmethod	
def	poll	(	cls	,	context	)	:	
if	(	context	.	space_data	.	type	==	"str"	)	:	
return	context	.	space_data	.	tree_type	==	"str"	
return	False	

def	execute	(	self	,	context	)	:	
node	=	context	.	space_data	.	node_tree	.	nodes	.	active	
if	(	node	==	None	)	:	
print	(	"str"	)	
return	{	"str"	}	
node	.	save_selection	(	)	
return	{	"str"	}	
class	ScExecuteNodeOp	(	Operator	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
bl_options	=	{	"str"	,	"str"	}	

@classmethod	
def	poll	(	cls	,	context	)	:	
if	(	context	.	space_data	.	type	==	"str"	)	:	
return	context	.	space_data	.	tree_type	==	"str"	
return	False	

def	execute	(	self	,	context	)	:	
node	=	context	.	space_data	.	node_tree	.	nodes	.	active	
if	(	not	node	==	None	)	:	
print	(	"str"	+	node	.	name	+	"str"	)	
for	group	in	bpy	.	data	.	node_groups	:	
for	node	in	group	.	nodes	:	
try	:	
node	.	first_time	=	True	
node	.	last_time	=	False	
except	:	
print	(	"str"	+	node	.	name	+	"str"	)	
node	.	execute	(	)	
return	{	"str"	}	
print	(	"str"	)	
return	{	"str"	}	
def	toList	(	string	)	:	
string	=	string	.	replace	(	"str"	,	"str"	)	
string	=	string	.	replace	(	"str"	,	"str"	)	
list_string	=	string	.	rsplit	(	"str"	)	
if	(	not	list_string	==	[	"str"	]	)	:	
return	[	int	(	i	)	for	i	in	list_string	]	
return	[	]	
def	focusMesh	(	mesh	,	deselect	=	True	,	meshes	=	None	)	:	
active	=	bpy	.	context	.	scene	.	objects	.	active	
if	not	active	==	None	:	
if	not	active	.	mode	==	"str"	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
if	deselect	:	
bpy	.	ops	.	object	.	select_all	(	action	=	"str"	)	
if	not	meshes	==	None	:	
for	m	in	meshes	:	
m	.	select	=	True	
bpy	.	context	.	scene	.	objects	.	active	=	mesh	
mesh	.	select	=	True	
def	removeMesh	(	mesh	,	remove_object	=	True	)	:	
if	(	not	mesh	==	None	)	:	
try	:	
name	=	mesh	.	name	
if	(	remove_object	)	:	
bpy	.	data	.	objects	.	remove	(	bpy	.	data	.	objects	[	name	]	)	
bpy	.	data	.	meshes	.	remove	(	bpy	.	data	.	meshes	[	name	]	)	
except	:	
print	(	"str"	+	name	+	"str"	)	
def	removeCurve	(	curve	,	remove_object	=	True	)	:	
if	(	not	curve	==	None	)	:	
try	:	
name	=	curve	.	name	
if	(	remove_object	)	:	
bpy	.	data	.	objects	.	remove	(	bpy	.	data	.	objects	[	name	]	)	
bpy	.	data	.	curves	.	remove	(	bpy	.	data	.	curves	[	name	]	)	
except	:	
print	(	"str"	+	name	+	"str"	)	





class	PlaneNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_plane_add	(	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	CubeNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_cube_add	(	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	CircleNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_vertices	=	IntProperty	(	name	=	"str"	,	default	=	32	,	min	=	3	,	max	=	1000000	,	update	=	ScNode	.	update_value	)	
prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_end	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_circle_add	(	vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	fill_type	=	self	.	prop_end	)	
class	UVSphereNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_segments	=	IntProperty	(	name	=	"str"	,	default	=	32	,	min	=	3	,	max	=	10000	,	update	=	ScNode	.	update_value	)	
prop_rings	=	IntProperty	(	name	=	"str"	,	default	=	16	,	min	=	3	,	max	=	10000	,	update	=	ScNode	.	update_value	)	
prop_size	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_uv_sphere_add	(	segments	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	ring_count	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	size	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	IcoSphereNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_subdivisions	=	IntProperty	(	name	=	"str"	,	default	=	2	,	min	=	1	,	max	=	10	,	update	=	ScNode	.	update_value	)	
prop_size	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_ico_sphere_add	(	subdivisions	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	size	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	CylinderNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_vertices	=	IntProperty	(	name	=	"str"	,	default	=	32	,	min	=	3	,	max	=	1000000	,	update	=	ScNode	.	update_value	)	
prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_depth	=	FloatProperty	(	name	=	"str"	,	default	=	2.0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_end	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_cylinder_add	(	vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	depth	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	end_fill_type	=	self	.	prop_end	)	
class	ConeNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_vertices	=	IntProperty	(	name	=	"str"	,	default	=	32	,	min	=	3	,	max	=	1000000	,	update	=	ScNode	.	update_value	)	
prop_radius1	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
prop_radius2	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
prop_depth	=	FloatProperty	(	name	=	"str"	,	default	=	2.0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_end	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_cone_add	(	vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	radius1	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	radius2	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	depth	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	end_fill_type	=	self	.	prop_end	)	

























class	GridNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_x	=	IntProperty	(	name	=	"str"	,	default	=	10	,	min	=	2	,	max	=	10000000	,	update	=	ScNode	.	update_value	)	
prop_y	=	IntProperty	(	name	=	"str"	,	default	=	10	,	min	=	2	,	max	=	10000000	,	update	=	ScNode	.	update_value	)	
prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_grid_add	(	x_subdivisions	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	y_subdivisions	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SuzanneNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_radius	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	primitive_monkey_add	(	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	CustomMeshNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_mesh	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	pre_execute	(	self	)	:	
if	(	self	.	prop_mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
focusMesh	(	self	.	prop_mesh	)	
bpy	.	ops	.	object	.	duplicate	(	)	
class	CustomCurveNode	(	Node	,	ScInputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_curve	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Curve	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	hide	=	True	
self	.	use_custom_color	=	True	
self	.	color	=	self	.	node_color	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	pre_execute	(	self	)	:	
if	(	self	.	prop_curve	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
if	(	not	bpy	.	context	.	active_object	==	None	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
removeCurve	(	self	.	mesh	)	
return	True	

def	functionality	(	self	)	:	
focusMesh	(	bpy	.	data	.	objects	[	self	.	prop_curve	.	name	]	)	
bpy	.	ops	.	object	.	duplicate	(	)	

class	LocationNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_location	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
self	.	mesh	.	location	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	RotationNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_rotation	=	FloatVectorProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
self	.	mesh	.	rotation_euler	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	ScaleNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_scale	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	1.0	,	1.0	,	1.0	)	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
self	.	mesh	.	scale	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	TranslateNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_constraint_axis	=	BoolVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	transform	.	translate	(	self	.	override	(	)	,	value	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	constraint_axis	=	self	.	prop_constraint_axis	,	constraint_orientation	=	self	.	override	(	)	[	"str"	]	.	transform_orientation	)	
class	RotateNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_constraint_axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	transform	.	rotate	(	self	.	override	(	)	,	value	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	axis	=	(	1.0	,	1.0	,	1.0	)	,	constraint_axis	=	(	self	.	prop_constraint_axis	==	"str"	,	self	.	prop_constraint_axis	==	"str"	,	self	.	prop_constraint_axis	==	"str"	)	)	
class	ResizeNode	(	Node	,	ScTransformNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	1.0	,	1.0	,	1.0	)	,	update	=	ScNode	.	update_value	)	
prop_constraint_axis	=	BoolVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	transform	.	resize	(	self	.	override	(	)	,	value	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	constraint_axis	=	self	.	prop_constraint_axis	,	constraint_orientation	=	self	.	override	(	)	[	"str"	]	.	transform_orientation	)	

class	ArrayModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

fit_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
count	=	IntProperty	(	name	=	"str"	,	default	=	2	,	min	=	1	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
fit_length	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
curve	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
use_constant_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
constant_offset_displace	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_merge_vertices	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_merge_vertices_cap	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
merge_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.01	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
use_relative_offset	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
relative_offset_displace	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	1.0	,	0.0	,	0.0	)	,	update	=	ScNode	.	update_value	)	
use_object_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
offset_object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
start_cap	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
end_cap	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
if	self	.	fit_type	==	"str"	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	fit_type	=	self	.	fit_type	
self	.	mesh	.	modifiers	[	0	]	.	count	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	fit_length	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	curve	=	self	.	curve	
self	.	mesh	.	modifiers	[	0	]	.	use_constant_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	constant_offset_displace	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_merge_vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_merge_vertices_cap	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	merge_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_relative_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	relative_offset_displace	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_object_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	offset_object	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	start_cap	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	end_cap	=	self	.	inputs	[	"str"	]	.	execute	(	)	

def	post_execute	(	self	)	:	
focusMesh	(	self	.	mesh	)	
return	super	(	)	.	post_execute	(	)	
class	BevelModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

width	=	FloatProperty	(	name	=	"str"	,	default	=	0.1	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
segments	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	0	,	max	=	100	,	update	=	ScNode	.	update_value	)	
profile	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
material	=	IntProperty	(	name	=	"str"	,	default	=	-	1	,	min	=	0	,	max	=	32767	,	update	=	ScNode	.	update_value	)	
use_only_vertices	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_clamp_overlap	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
loop_slide	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
limit_method	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
angle_limit	=	FloatProperty	(	name	=	"str"	,	default	=	0.523599	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
offset_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
col	=	layout	.	column	(	)	
col	.	prop	(	self	,	"str"	)	
col	.	prop	(	self	,	"str"	)	
col	.	prop	(	self	,	"str"	)	
layout	.	label	(	text	=	"str"	)	
layout	.	row	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	
if	self	.	limit_method	==	"str"	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	label	(	text	=	"str"	)	
layout	.	row	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	width	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	segments	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	profile	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	material	=	self	.	material	
self	.	mesh	.	modifiers	[	0	]	.	use_only_vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_clamp_overlap	=	self	.	use_clamp_overlap	
self	.	mesh	.	modifiers	[	0	]	.	loop_slide	=	self	.	loop_slide	
self	.	mesh	.	modifiers	[	0	]	.	limit_method	=	self	.	limit_method	
self	.	mesh	.	modifiers	[	0	]	.	angle_limit	=	self	.	angle_limit	
self	.	mesh	.	modifiers	[	0	]	.	offset_type	=	self	.	offset_type	
class	BooleanModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_obj	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Object	)	
prop_overlap	=	FloatProperty	(	name	=	"str"	,	default	=	0.000001	,	min	=	0.0	,	max	=	1.0	,	precision	=	6	,	update	=	ScNode	.	update_value	)	
prop_draw_mode	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	label	(	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	pre_execute	(	self	)	:	
self	.	prop_obj	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	prop_obj	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
self	.	mesh	.	select	=	True	
self	.	prop_obj	.	select	=	False	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	operation	=	self	.	prop_op	
self	.	mesh	.	modifiers	[	0	]	.	object	=	self	.	prop_obj	
self	.	mesh	.	modifiers	[	0	]	.	double_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_obj	.	draw_type	=	self	.	prop_draw_mode	
class	CastModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

cast_type	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	update	=	ScNode	.	update_value	)	
use_x	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_y	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_z	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	update	=	ScNode	.	update_value	)	
radius	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
size	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
use_radius_as_size	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
use_transform	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop	(	self	,	"str"	,	text	=	"str"	)	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	cast_type	=	self	.	cast_type	
self	.	mesh	.	modifiers	[	0	]	.	use_x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_y	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_z	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	size	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_radius_as_size	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	object	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_transform	=	self	.	inputs	[	"str"	]	.	execute	(	)	

def	post_execute	(	self	)	:	
focusMesh	(	self	.	mesh	)	
return	super	(	)	.	post_execute	(	)	
class	CorrectiveSmoothModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

factor	=	FloatProperty	(	default	=	0.5	,	soft_min	=	0.0	,	soft_max	=	1.0	,	update	=	ScNode	.	update_value	)	
iterations	=	IntProperty	(	name	=	"str"	,	default	=	5	,	min	=	-	32768	,	max	=	32767	,	soft_min	=	0	,	soft_max	=	200	,	update	=	ScNode	.	update_value	)	
smooth_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
use_only_smooth	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_pin_boundary	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
invert_vertex_group	=	BoolProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	label	(	text	=	"str"	)	
split	=	layout	.	split	(	)	
col	=	split	.	column	(	)	
row	=	col	.	row	(	align	=	True	)	
row	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
row	.	prop	(	self	,	"str"	,	text	=	"str"	,	icon	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	smooth_type	=	self	.	smooth_type	
self	.	mesh	.	modifiers	[	0	]	.	use_only_smooth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_pin_boundary	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	invert_vertex_group	=	self	.	invert_vertex_group	
class	CurveModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
deform_axis	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop	(	self	,	"str"	,	text	=	"str"	)	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
layout	.	label	(	text	=	"str"	)	
layout	.	row	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	pre_execute	(	self	)	:	
if	(	self	.	object	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	object	=	self	.	object	
self	.	mesh	.	modifiers	[	0	]	.	deform_axis	=	self	.	deform_axis	
class	DecimateModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

decimate_type	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	update	=	ScNode	.	update_value	)	
ratio	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
invert_vertex_group	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
vertex_group_factor	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0	,	max	=	1000	,	soft_max	=	10	,	update	=	ScNode	.	update_value	)	
use_collapse_triangulate	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_symmetry	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
symmetry_axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
iterations	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	max	=	32767	,	soft_max	=	100	,	update	=	ScNode	.	update_value	)	
angle_limit	=	FloatProperty	(	name	=	"str"	,	default	=	0.087266	,	min	=	0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
use_dissolve_boundaries	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
delimit	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	,	2	)	,	(	"str"	,	"str"	,	"str"	,	4	)	,	(	"str"	,	"str"	,	"str"	,	8	)	,	(	"str"	,	"str"	,	"str"	,	16	)	,	(	"str"	,	"str"	,	"str"	,	32	)	]	,	default	=	{	"str"	}	,	options	=	{	"str"	}	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
decimate_type	=	self	.	decimate_type	
row	=	layout	.	row	(	)	
row	.	prop	(	self	,	"str"	,	expand	=	True	)	
if	decimate_type	==	"str"	:	
has_vgroup	=	bool	(	self	.	vertex_group	)	
col	=	layout	.	column	(	)	
row	=	col	.	row	(	align	=	True	)	
if	(	not	self	.	mesh	==	None	)	:	
row	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
row	.	prop	(	self	,	"str"	,	text	=	"str"	,	icon	=	"str"	)	
col	=	layout	.	column	(	)	
row	=	col	.	row	(	)	
row	.	active	=	has_vgroup	
row	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	
elif	decimate_type	==	"str"	:	
layout	.	label	(	"str"	)	
row	=	layout	.	row	(	)	
row	.	prop	(	self	,	"str"	,	expand	=	True	)	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	label	(	text	=	"str"	+	str	(	len	(	self	.	mesh	.	data	.	polygons	)	)	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	decimate_type	=	self	.	decimate_type	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	ratio	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	invert_vertex_group	=	self	.	invert_vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group_factor	=	self	.	vertex_group_factor	
self	.	mesh	.	modifiers	[	0	]	.	use_collapse_triangulate	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_symmetry	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	symmetry_axis	=	self	.	symmetry_axis	
self	.	mesh	.	modifiers	[	0	]	.	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	angle_limit	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_dissolve_boundaries	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	delimit	=	self	.	delimit	
class	DisplaceModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

texture	=	PointerProperty	(	type	=	bpy	.	types	.	Texture	)	
direction	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
space	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
texture_coords	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
texture_coords_object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	update	=	ScNode	.	update_value	)	
uv_layer	=	StringProperty	(	update	=	ScNode	.	update_value	)	
mid_level	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	soft_min	=	0.0	,	soft_max	=	1.0	,	update	=	ScNode	.	update_value	)	
strength	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	soft_min	=	-	100.0	,	soft_max	=	100.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
has_texture	=	(	self	.	texture	is	not	None	)	
col	=	layout	.	column	(	align	=	True	)	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	
split	=	layout	.	split	(	)	
col	=	split	.	column	(	align	=	True	)	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	
if	self	.	direction	in	{	"str"	,	"str"	,	"str"	,	"str"	}	:	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	
col	.	label	(	text	=	"str"	)	
if	(	not	self	.	mesh	==	None	)	:	
col	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
col	=	split	.	column	(	align	=	True	)	
col	.	active	=	has_texture	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	
if	self	.	texture_coords	==	"str"	:	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	
elif	self	.	texture_coords	==	"str"	and	(	not	self	.	mesh	==	None	)	:	
col	.	label	(	text	=	"str"	)	
col	.	prop_search	(	self	,	"str"	,	self	.	mesh	.	data	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	texture	=	self	.	texture	
self	.	mesh	.	modifiers	[	0	]	.	direction	=	self	.	direction	
self	.	mesh	.	modifiers	[	0	]	.	space	=	self	.	space	
self	.	mesh	.	modifiers	[	0	]	.	texture_coords	=	self	.	texture_coords	
self	.	mesh	.	modifiers	[	0	]	.	texture_coords_object	=	self	.	texture_coords_object	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	uv_layer	=	self	.	uv_layer	
self	.	mesh	.	modifiers	[	0	]	.	mid_level	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	strength	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	EdgeSplitModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

split_angle	=	FloatProperty	(	name	=	"str"	,	default	=	0.523599	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
use_edge_angle	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
use_edge_sharp	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	split_angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_edge_angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_edge_sharp	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	LaplacianSmoothModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

iterations	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	-	32768	,	max	=	32767	,	soft_min	=	0	,	soft_max	=	200	,	update	=	ScNode	.	update_value	)	
use_x	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_y	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_z	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
lambda_factor	=	FloatProperty	(	default	=	0.01	,	soft_min	=	-	1000.0	,	soft_max	=	1000.0	,	update	=	ScNode	.	update_value	)	
lambda_border	=	FloatProperty	(	default	=	0.01	,	soft_min	=	-	1000.0	,	soft_max	=	1000.0	,	update	=	ScNode	.	update_value	)	
use_volume_preserve	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_normalized	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_y	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_z	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	lambda_factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	lambda_border	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_volume_preserve	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_normalized	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
class	MirrorModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

use_x	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_y	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_z	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_mirror_merge	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
use_clip	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
use_mirror_vertex_groups	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
use_mirror_u	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
use_mirror_v	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
mirror_offset_u	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
mirror_offset_v	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
merge_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.001	,	min	=	0	,	soft_max	=	1	,	update	=	ScNode	.	update_value	)	
mirror_object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
col	=	layout	.	column	(	)	
col	.	label	(	text	=	"str"	)	
col	.	prop	(	self	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	use_x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_y	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_z	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_mirror_merge	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_clip	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_mirror_vertex_groups	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_mirror_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_mirror_v	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	mirror_offset_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	mirror_offset_v	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	merge_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	mirror_object	=	self	.	mirror_object	
class	RemeshModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

mode	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
octree_depth	=	IntProperty	(	name	=	"str"	,	default	=	4	,	min	=	1	,	max	=	12	,	update	=	ScNode	.	update_value	)	
scale	=	FloatProperty	(	name	=	"str"	,	default	=	0.9	,	min	=	0.0	,	max	=	0.99	,	update	=	ScNode	.	update_value	)	
sharpness	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	update	=	ScNode	.	update_value	)	
use_smooth_shade	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_remove_disconnected	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
threshold	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	mode	=	self	.	mode	
self	.	mesh	.	modifiers	[	0	]	.	octree_depth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	scale	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	sharpness	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_smooth_shade	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_remove_disconnected	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	ScrewModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
angle	=	FloatProperty	(	name	=	"str"	,	default	=	6.283185	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
steps	=	IntProperty	(	name	=	"str"	,	default	=	16	,	min	=	2	,	max	=	10000	,	soft_max	=	512	,	update	=	ScNode	.	update_value	)	
render_steps	=	IntProperty	(	name	=	"str"	,	default	=	16	,	min	=	2	,	max	=	10000	,	soft_max	=	512	,	update	=	ScNode	.	update_value	)	
use_smooth_shade	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_merge_vertices	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
merge_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.01	,	min	=	0	,	update	=	ScNode	.	update_value	)	
screw_offset	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_object_screw_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_normal_calculate	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_normal_flip	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
iterations	=	IntProperty	(	default	=	1	,	min	=	1	,	max	=	10000	,	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_stretch_u	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_stretch_v	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	axis	=	self	.	axis	
self	.	mesh	.	modifiers	[	0	]	.	object	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	steps	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	render_steps	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_smooth_shade	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_merge_vertices	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	merge_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	screw_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_object_screw_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_normal_calculate	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_normal_flip	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_stretch_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_stretch_v	=	self	.	inputs	[	"str"	]	.	execute	(	)	

def	post_execute	(	self	)	:	
focusMesh	(	self	.	mesh	)	
return	super	(	)	.	post_execute	(	)	
class	SimpleDeformModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
deform_method	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
invert_vertex_group	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
origin	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
lock_x	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
lock_y	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.785398	,	update	=	ScNode	.	update_value	)	
angle	=	FloatProperty	(	name	=	"str"	,	default	=	0.785398	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
limits	=	FloatVectorProperty	(	size	=	2	,	default	=	(	0.0	,	1.0	)	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	row	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	
if	(	not	self	.	mesh	==	None	)	:	
split	=	layout	.	split	(	)	
col	=	split	.	column	(	)	
col	.	label	(	text	=	"str"	)	
row	=	col	.	row	(	align	=	True	)	
row	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
row	.	prop	(	self	,	"str"	,	text	=	"str"	,	icon	=	"str"	)	
split	=	layout	.	split	(	)	
col	=	split	.	column	(	)	
col	.	prop	(	self	,	"str"	,	slider	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	deform_method	=	self	.	deform_method	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	invert_vertex_group	=	self	.	invert_vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	origin	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	lock_x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	lock_y	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	self	.	deform_method	in	{	"str"	,	"str"	}	:	
self	.	mesh	.	modifiers	[	0	]	.	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	
else	:	
self	.	mesh	.	modifiers	[	0	]	.	angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	limits	=	self	.	limits	

def	post_execute	(	self	)	:	
focusMesh	(	self	.	mesh	)	
return	super	(	)	.	post_execute	(	)	
class	SkinModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

branch_smoothing	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
use_smooth_shade	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_x_symmetry	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_y_symmetry	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_z_symmetry	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
row	=	layout	.	row	(	)	
row	.	operator	(	"str"	,	text	=	"str"	)	
row	.	operator	(	"str"	)	
layout	.	label	(	text	=	"str"	)	
sub	=	layout	.	split	(	)	


sub	.	operator	(	"str"	,	text	=	"str"	)	.	action	=	"str"	
sub	.	operator	(	"str"	,	text	=	"str"	)	.	action	=	"str"	
sub	=	layout	.	split	(	)	
sub	.	operator	(	"str"	,	text	=	"str"	)	
sub	.	operator	(	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	branch_smoothing	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_smooth_shade	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_x_symmetry	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_y_symmetry	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_z_symmetry	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	SmoothModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

use_x	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_y	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_z	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	update	=	ScNode	.	update_value	)	
iterations	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	0	,	max	=	32767	,	soft_max	=	30	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	use_x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_y	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_z	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
class	SolidifyModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

thickness	=	FloatProperty	(	name	=	"str"	,	default	=	0.01	,	update	=	ScNode	.	update_value	)	
thickness_clamp	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	100.0	,	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
invert_vertex_group	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
thickness_vertex_group	=	FloatProperty	(	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
edge_crease_inner	=	FloatProperty	(	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
edge_crease_outer	=	FloatProperty	(	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
edge_crease_rim	=	FloatProperty	(	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
offset	=	FloatProperty	(	name	=	"str"	,	default	=	-	1.0	,	update	=	ScNode	.	update_value	)	
use_flip_normals	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_even_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_quality_normals	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_rim	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
use_rim_only	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
material_offset	=	IntProperty	(	default	=	0	,	min	=	-	32768	,	max	=	32767	,	update	=	ScNode	.	update_value	)	
material_offset_rim	=	IntProperty	(	default	=	0	,	min	=	-	32768	,	max	=	32767	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
split	=	layout	.	split	(	)	
col	=	split	.	column	(	)	
row	=	col	.	row	(	align	=	True	)	
if	(	not	self	.	mesh	==	None	)	:	
row	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
sub	=	row	.	row	(	align	=	True	)	
sub	.	active	=	bool	(	self	.	vertex_group	)	
sub	.	prop	(	self	,	"str"	,	text	=	"str"	,	icon	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	thickness	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	thickness_clamp	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	invert_vertex_group	=	self	.	invert_vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	thickness_vertex_group	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	edge_crease_inner	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	edge_crease_outer	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	edge_crease_rim	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_flip_normals	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_even_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_quality_normals	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_rim	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_rim_only	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	material_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	material_offset_rim	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	SubdivideModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

subdivision_type	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
levels	=	IntProperty	(	default	=	1	,	min	=	0	,	max	=	11	,	soft_max	=	6	,	update	=	ScNode	.	update_value	)	
render_levels	=	IntProperty	(	default	=	2	,	min	=	0	,	max	=	11	,	soft_max	=	6	,	update	=	ScNode	.	update_value	)	
use_subsurf_uv	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
show_only_control_edges	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_levels	=	IntProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	row	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	pre_execute	(	self	)	:	
self	.	prop_levels	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	prop_levels	==	0	)	:	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	subdivision_type	=	self	.	subdivision_type	
self	.	mesh	.	modifiers	[	0	]	.	levels	=	self	.	prop_levels	
self	.	mesh	.	modifiers	[	0	]	.	render_levels	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_subsurf_uv	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	show_only_control_edges	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	TriangulateModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

quad_method	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
ngon_method	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	label	(	text	=	"str"	)	
layout	.	prop	(	self	,	"str"	,	text	=	"str"	)	
layout	.	label	(	text	=	"str"	)	
layout	.	prop	(	self	,	"str"	,	text	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	quad_method	=	self	.	quad_method	
self	.	mesh	.	modifiers	[	0	]	.	ngon_method	=	self	.	ngon_method	
class	WireframeModNode	(	Node	,	ScModifierNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

thickness	=	FloatProperty	(	update	=	ScNode	.	update_value	)	
vertex_group	=	StringProperty	(	update	=	ScNode	.	update_value	)	
invert_vertex_group	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
thickness_vertex_group	=	FloatProperty	(	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
use_crease	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
crease_weight	=	FloatProperty	(	update	=	ScNode	.	update_value	)	
offset	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
use_even_offset	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
use_relative_offset	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
use_boundary	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
use_replace	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
material_offset	=	IntProperty	(	default	=	0	,	min	=	-	32768	,	max	=	32767	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	not	self	.	mesh	==	None	)	:	
row	=	layout	.	row	(	align	=	True	)	
row	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	,	text	=	"str"	)	
row	.	prop	(	self	,	"str"	,	text	=	"str"	,	icon	=	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	modifier_add	(	type	=	"str"	)	
self	.	mesh	.	modifiers	[	0	]	.	thickness	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	vertex_group	=	self	.	vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	invert_vertex_group	=	self	.	invert_vertex_group	
self	.	mesh	.	modifiers	[	0	]	.	thickness_vertex_group	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_crease	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	crease_weight	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_even_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_relative_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_boundary	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	use_replace	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	modifiers	[	0	]	.	material_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	

class	ToComponentNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_selection_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_deselect	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
bpy	.	ops	.	mesh	.	select_mode	(	type	=	self	.	prop_selection_type	)	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
class	ToMeshNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
class	ChangeModeNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_selection_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_mode	(	type	=	self	.	prop_selection_type	)	
class	ToStringNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_in	=	StringProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
data	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	not	data	==	None	)	:	
return	str	(	data	)	
return	"str"	
class	ToFloatNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_in	=	FloatProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
data	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	not	data	==	None	)	:	
return	float	(	data	)	
return	0.0	
class	ToIntNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_in	=	IntProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
data	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	not	data	==	None	)	:	
return	int	(	data	)	
return	0	
class	ToBoolNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_in	=	BoolProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
data	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	not	data	==	None	)	:	
return	bool	(	data	)	
return	False	
class	CurveToMeshNode	(	Node	,	ScConversionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	convert	(	target	=	"str"	)	

class	SelectComponentsManuallyNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

selection_face	=	StringProperty	(	)	
selection_vert	=	StringProperty	(	)	
selection_edge	=	StringProperty	(	)	

def	save_selection	(	self	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
self	.	selection_face	=	str	(	[	i	.	index	for	i	in	self	.	mesh	.	data	.	polygons	if	i	.	select	]	)	
self	.	selection_vert	=	str	(	[	i	.	index	for	i	in	self	.	mesh	.	data	.	vertices	if	i	.	select	]	)	
self	.	selection_edge	=	str	(	[	i	.	index	for	i	in	self	.	mesh	.	data	.	edges	if	i	.	select	]	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
print	(	"str"	+	self	.	name	+	"str"	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	self	.	mesh	)	:	
if	(	self	==	self	.	id_data	.	nodes	.	active	)	:	
layout	.	operator	(	"str"	,	"str"	)	
layout	.	label	(	text	=	"str"	+	str	(	len	(	[	i	for	i	in	self	.	mesh	.	data	.	polygons	if	i	.	select	]	)	)	+	"str"	+	str	(	len	(	self	.	mesh	.	data	.	polygons	)	)	)	
layout	.	label	(	text	=	"str"	+	str	(	len	(	[	i	for	i	in	self	.	mesh	.	data	.	vertices	if	i	.	select	]	)	)	+	"str"	+	str	(	len	(	self	.	mesh	.	data	.	vertices	)	)	)	
layout	.	label	(	text	=	"str"	+	str	(	len	(	[	i	for	i	in	self	.	mesh	.	data	.	edges	if	i	.	select	]	)	)	+	"str"	+	str	(	len	(	self	.	mesh	.	data	.	edges	)	)	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
list_face	=	toList	(	self	.	selection_face	)	
list_vert	=	toList	(	self	.	selection_vert	)	
list_edge	=	toList	(	self	.	selection_edge	)	
for	i	in	list_face	:	
if	i	>	=	len	(	self	.	mesh	.	data	.	polygons	)	:	
break	
self	.	mesh	.	data	.	polygons	[	i	]	.	select	=	True	
for	i	in	list_vert	:	
if	i	>	=	len	(	self	.	mesh	.	data	.	vertices	)	:	
break	
self	.	mesh	.	data	.	vertices	[	i	]	.	select	=	True	
for	i	in	list_edge	:	
if	i	>	=	len	(	self	.	mesh	.	data	.	edges	)	:	
break	
self	.	mesh	.	data	.	edges	[	i	]	.	select	=	True	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
class	SelectComponentByIndexNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_index	=	IntProperty	(	name	=	"str"	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_deselect	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_selection_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
if	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
if	(	self	.	prop_selection_type	==	"str"	)	:	
self	.	mesh	.	data	.	polygons	[	min	(	max	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	0	)	,	len	(	self	.	mesh	.	data	.	polygons	)	-	1	)	]	.	select	=	not	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_selection_type	==	"str"	)	:	
self	.	mesh	.	data	.	vertices	[	min	(	max	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	0	)	,	len	(	self	.	mesh	.	data	.	vertices	)	-	1	)	]	.	select	=	not	self	.	inputs	[	"str"	]	.	execute	(	)	
else	:	
self	.	mesh	.	data	.	edges	[	min	(	max	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	0	)	,	len	(	self	.	mesh	.	data	.	edges	)	-	1	)	]	.	select	=	not	self	.	inputs	[	"str"	]	.	execute	(	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
class	SelectFacesByMaterialNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_mat	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Material	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_deselect	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	pre_execute	(	self	)	:	
if	(	self	.	prop_mat	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
if	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
slot	=	self	.	mesh	.	material_slots	.	find	(	self	.	prop_mat	.	name	)	
if	(	slot	==	-	1	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
else	:	
self	.	mesh	.	active_material_index	=	slot	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	object	.	material_slot_deselect	(	)	
else	:	
bpy	.	ops	.	object	.	material_slot_select	(	)	
class	SelectFacesByNormalNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_min	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	-	1.0	,	-	1.0	,	-	1.0	)	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_max	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	1.0	,	1.0	,	1.0	)	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
prop_min	=	self	.	inputs	[	"str"	]	.	execute	(	)	
prop_max	=	self	.	inputs	[	"str"	]	.	execute	(	)	
for	face	in	self	.	mesh	.	data	.	polygons	:	
if	(	(	face	.	normal	[	0	]	>	=	prop_min	[	0	]	and	face	.	normal	[	1	]	>	=	prop_min	[	1	]	and	face	.	normal	[	2	]	>	=	prop_min	[	2	]	)	and	(	face	.	normal	[	0	]	<	=	prop_max	[	0	]	and	face	.	normal	[	1	]	<	=	prop_max	[	1	]	and	face	.	normal	[	2	]	<	=	prop_max	[	2	]	)	)	:	
face	.	select	=	True	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
class	SelectVerticesByVertexGroupNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_vg	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_deselect	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	not	self	.	mesh	==	None	)	:	
layout	.	prop_search	(	self	,	"str"	,	self	.	mesh	,	"str"	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
if	(	self	.	prop_vg	==	"str"	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	functionality	(	self	)	:	
if	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
self	.	mesh	.	vertex_groups	.	active	=	self	.	mesh	.	vertex_groups	[	self	.	prop_vg	]	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	object	.	vertex_group_deselect	(	)	
else	:	
bpy	.	ops	.	object	.	vertex_group_select	(	)	
class	SelectAllNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_action	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	self	.	prop_action	)	
class	SelectAxisNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_mode	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.0001	,	min	=	0.000001	,	max	=	50	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_axis	(	mode	=	self	.	prop_mode	,	axis	=	self	.	prop_axis	,	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectFaceBySidesNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_number	=	IntProperty	(	name	=	"str"	,	default	=	3	,	min	=	3	,	update	=	ScNode	.	update_value	)	
prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_face_by_sides	(	number	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	type	=	self	.	prop_type	,	extend	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectInteriorFaces	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_interior_faces	(	)	
class	SelectLessNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_face_step	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_less	(	use_face_step	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectMoreNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_face_step	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_more	(	use_face_step	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectLinkedNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_delimit	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_linked	(	delimit	=	{	self	.	prop_delimit	}	)	
class	SelectLoopNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_ring	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	loop_multi_select	(	ring	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectLoopRegionNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_bigger	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	loop_to_region	(	select_bigger	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectLooseNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_loose	(	extend	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectMirrorNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_mirror	(	axis	=	{	self	.	prop_axis	}	,	extend	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectNextItemNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_next_item	(	)	
class	SelectPrevItemNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_prev_item	(	)	
class	SelectNonManifoldNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_extend	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_wire	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_boundary	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_multi_face	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_non_contiguous	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_verts	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_non_manifold	(	extend	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_wire	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_boundary	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_multi_face	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_non_contiguous	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_verts	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectNthNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_nth	=	IntProperty	(	name	=	"str"	,	default	=	2	,	min	=	2	,	update	=	ScNode	.	update_value	)	
prop_skip	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	update	=	ScNode	.	update_value	)	
prop_offset	=	IntProperty	(	name	=	"str"	,	default	=	0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_nth	(	nth	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	skip	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectAlternateFacesNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_nth	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	update	=	ScNode	.	update_value	)	
prop_offset	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
i	=	self	.	inputs	[	"str"	]	.	execute	(	)	
prop_nth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
while	(	i	<	len	(	self	.	mesh	.	data	.	polygons	)	)	:	
self	.	mesh	.	data	.	polygons	[	i	]	.	select	=	True	
i	+	=	prop_nth	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
class	SelectRandomNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_percent	=	FloatProperty	(	name	=	"str"	,	default	=	50.0	,	min	=	0.0	,	max	=	100.0	,	update	=	ScNode	.	update_value	)	
prop_seed	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_action	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_random	(	percent	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	seed	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	action	=	self	.	prop_action	)	
class	SelectRegionBoundaryNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	region_to_loop	(	)	
class	SelectSharpEdgesNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_sharpness	=	FloatProperty	(	name	=	"str"	,	default	=	0.523599	,	min	=	0.000174533	,	max	=	3.14159	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	edges_select_sharp	(	sharpness	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	

















class	SelectSimilarNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_compare	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_similar	(	type	=	self	.	prop_type	,	compare	=	self	.	prop_compare	,	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectSimilarRegionNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_similar_region	(	)	
class	SelectShortestPathNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_step	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_distance	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_fill	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_nth	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	update	=	ScNode	.	update_value	)	
prop_skip	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	update	=	ScNode	.	update_value	)	
prop_offset	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	shortest_path_select	(	use_face_step	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_topology_distance	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_fill	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	nth	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	skip	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectUngroupedNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_extend	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_ungrouped	(	extend	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SelectFacesLinkedFlatNode	(	Node	,	ScSelectionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_sharpness	=	FloatProperty	(	name	=	"str"	,	default	=	0.523599	,	min	=	0.000174533	,	max	=	3.14159	,	precision	=	6	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	faces_select_linked_flat	(	sharpness	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	

class	DeleteNode	(	Node	,	ScDeletionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	delete	(	type	=	self	.	prop_type	)	
class	DeleteEdgeLoopNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_split	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	delete_edgeloop	(	use_face_split	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	DissolveFacesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_verts	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	dissolve_faces	(	use_verts	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	DissolveEdgesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_verts	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_face_split	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	dissolve_edges	(	use_verts	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_face_split	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	DissolveVerticesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_face_split	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_boundary_tear	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	dissolve_verts	(	use_face_split	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_boundary_tear	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	DissolveDegenerateNode	(	Node	,	ScDeletionNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.0001	,	min	=	0.000001	,	max	=	50.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	dissolve_degenerate	(	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	EdgeCollapseNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	edge_collapse	(	)	

class	AddEdgeFaceNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	edge_face_add	(	)	
class	BeautifyFillNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_angle_limit	=	FloatProperty	(	name	=	"str"	,	default	=	3.14159	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	beautify_fill	(	angle_limit	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	BevelNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_offset_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_offset	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1000000.0	,	max	=	1000000.0	,	update	=	ScNode	.	update_value	)	
prop_segments	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_profile	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	min	=	0.15	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_vertex_only	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_clamp_overlap	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_loop_slide	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_material	=	IntProperty	(	name	=	"str"	,	default	=	-	1	,	min	=	-	1	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	bevel	(	offset_type	=	self	.	prop_offset_type	,	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	segments	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	profile	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	vertex_only	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	clamp_overlap	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	loop_slide	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	material	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	BridgeEdgeLoopsNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_use_merge	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_merge_factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	min	=	0.0	,	max	=	0.1	,	update	=	ScNode	.	update_value	)	
prop_twist_offset	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	-	1000	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_number_cuts	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_interpolation	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_smoothness	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	max	=	1000.0	,	update	=	ScNode	.	update_value	)	
prop_profile_shape_factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1000.0	,	max	=	1000.0	,	update	=	ScNode	.	update_value	)	
prop_profile_shape	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	bridge_edge_loops	(	type	=	self	.	prop_type	,	use_merge	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	merge_factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	twist_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	number_cuts	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	interpolation	=	self	.	prop_interpolation	,	smoothness	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	profile_shape_factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	profile_shape	=	self	.	prop_profile_shape	)	
class	ConvexHullNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_delete_unused	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_use_existing_faces	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_make_holes	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_join_triangles	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_face_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.698132	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_shape_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.698132	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_uvs	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_vcols	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_seam	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_sharp	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_materials	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	convex_hull	(	delete_unused	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_existing_faces	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	make_holes	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	join_triangles	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	face_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	shape_threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	uvs	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	vcols	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	seam	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	sharp	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	materials	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	DecimateNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_ratio	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_use_vertex_group	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_vertex_group_factor	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	min	=	0.0	,	max	=	1000.0	,	update	=	ScNode	.	update_value	)	
prop_invert_vertex_group	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_use_symmetry	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_symmetry_axis	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	decimate	(	ratio	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_vertex_group	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	vertex_group_factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	invert_vertex_group	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_symmetry	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	symmetry_axis	=	self	.	prop_symmetry_axis	)	
class	ExtrudeFacesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	extrude_faces_move	(	self	.	override	(	)	,	TRANSFORM_OT_shrink_fatten	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	
class	ExtrudeEdgesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	extrude_edges_move	(	self	.	override	(	)	,	TRANSFORM_OT_translate	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	
class	ExtrudeVerticesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	extrude_vertices_move	(	self	.	override	(	)	,	TRANSFORM_OT_translate	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	
class	ExtrudeRegionNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_amount	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	extrude_region_shrink_fatten	(	self	.	override	(	)	,	TRANSFORM_OT_shrink_fatten	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	














class	FlipNormalsNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	flip_normals	(	)	
class	MakeNormalsConsistentNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_inside	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	normals_make_consistent	(	inside	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	FlattenNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_mode	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.5	,	min	=	-	10.0	,	max	=	10.0	,	update	=	ScNode	.	update_value	)	
prop_repeat	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	0	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_x	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_y	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_z	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
if	(	self	.	prop_mode	==	"str"	)	:	
bpy	.	ops	.	mesh	.	vertices_smooth	(	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	repeat	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	xaxis	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	yaxis	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	zaxis	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
else	:	
bpy	.	ops	.	mesh	.	face_make_planar	(	factor	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	repeat	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	FillEdgeLoopNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_beauty	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	fill	(	use_beauty	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	FillGridNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_span	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_offset	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	-	1000	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_interp	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	fill_grid	(	span	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_interp_simple	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	FillHolesBySidesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_sides	=	IntProperty	(	name	=	"str"	,	default	=	4	,	min	=	0	,	max	=	1000	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	fill_holes	(	sides	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	InsetNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_thickness	=	FloatProperty	(	name	=	"str"	,	default	=	0.01	,	min	=	0.0	,	update	=	ScNode	.	update_value	)	
prop_depth	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_boundary	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_even_offset	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_relative_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_edge_rail	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_outset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_select_inset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_individual	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_interpolate	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	inset	(	use_boundary	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_even_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_relative_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_edge_rail	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	thickness	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	depth	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_outset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_select_inset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_individual	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_interpolate	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	LoopCutNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_number	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	soft_max	=	100	,	update	=	ScNode	.	update_value	)	
prop_smoothness	=	FloatProperty	(	name	=	"str"	,	soft_min	=	-	4.0	,	soft_max	=	4.0	,	update	=	ScNode	.	update_value	)	
prop_use_selected_edge	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_index	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	update	=	ScNode	.	update_value	)	
prop_factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_single	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_even	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_flipped	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_clamp	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	
index	=	IntProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
try	:	
self	.	index	=	[	i	.	index	for	i	in	self	.	mesh	.	data	.	edges	if	i	.	select	]	[	0	]	
except	:	
print	(	"str"	+	self	.	name	+	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
return	False	
else	:	
self	.	index	=	max	(	min	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	len	(	self	.	mesh	.	data	.	edges	)	-	1	)	,	0	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
return	True	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	loopcut_slide	(	self	.	override	(	)	,	MESH_OT_loopcut	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	"str"	,	"str"	:	self	.	index	}	,	TRANSFORM_OT_edge_slide	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	
class	MaterialNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_mat	=	PointerProperty	(	name	=	"str"	,	type	=	bpy	.	types	.	Material	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	pre_execute	(	self	)	:	
if	(	self	.	prop_mat	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
slot	=	self	.	mesh	.	material_slots	.	find	(	self	.	prop_mat	.	name	)	
if	(	slot	==	-	1	)	:	
bpy	.	ops	.	object	.	material_slot_add	(	)	
self	.	mesh	.	active_material	=	self	.	prop_mat	
else	:	
self	.	mesh	.	active_material_index	=	slot	
bpy	.	ops	.	object	.	material_slot_assign	(	)	
class	MergeComponentsNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_uv	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	merge	(	type	=	self	.	prop_type	,	uvs	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	OffsetEdgeLoopNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_cap	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_factor	=	FloatProperty	(	name	=	"str"	,	default	=	0.523187	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_single	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_even	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_flipped	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_clamp	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	offset_edge_loops_slide	(	self	.	override	(	)	,	MESH_OT_offset_edge_loops	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	,	TRANSFORM_OT_edge_slide	=	{	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	,	"str"	:	self	.	inputs	[	"str"	]	.	execute	(	)	}	)	
class	PokeNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_offset	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	-	1000.0	,	max	=	1000.0	,	update	=	ScNode	.	update_value	)	
prop_use_relative_offset	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_center_mode	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	poke	(	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_relative_offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	center_mode	=	self	.	prop_center_mode	)	
class	RemoveDoublesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.0001	,	min	=	0.000001	,	max	=	50.0	,	update	=	ScNode	.	update_value	)	
prop_unselected	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	remove_doubles	(	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	use_unselected	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	RotateEdgeNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_ccw	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	edge_rotate	(	use_ccw	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	ScrewNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_steps	=	IntProperty	(	name	=	"str"	,	default	=	9	,	min	=	1	,	max	=	100000	,	update	=	ScNode	.	update_value	)	
prop_turns	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	max	=	100000	,	update	=	ScNode	.	update_value	)	
prop_center	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_axis	=	FloatVectorProperty	(	name	=	"str"	,	default	=	(	1.0	,	0.0	,	0.0	)	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	screw	(	steps	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	turns	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	center	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	axis	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SolidifyNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_thickness	=	FloatProperty	(	name	=	"str"	,	default	=	0.01	,	min	=	-	10000.0	,	max	=	10000.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	solidify	(	thickness	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SpinNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_steps	=	IntProperty	(	name	=	"str"	,	default	=	9	,	min	=	0	,	max	=	1000000	,	update	=	ScNode	.	update_value	)	
prop_dupli	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_angle	=	FloatProperty	(	name	=	"str"	,	default	=	1.5708	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_center	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_axis	=	FloatVectorProperty	(	name	=	"str"	,	min	=	-	1.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	spin	(	steps	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	dupli	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	center	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	axis	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SplitNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_individual	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	mesh	.	edge_split	(	)	
else	:	
bpy	.	ops	.	mesh	.	split	(	)	
class	SubdivideNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_number_cuts	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	max	=	100	,	update	=	ScNode	.	update_value	)	
prop_smoothness	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	1000.0	,	update	=	ScNode	.	update_value	)	
prop_quadtri	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_quadcorner	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_fractal	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	1000000	,	update	=	ScNode	.	update_value	)	
prop_fractal_along_normal	=	FloatProperty	(	name	=	"str"	,	default	=	0.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_seed	=	IntProperty	(	name	=	"str"	,	default	=	0	,	min	=	0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	subdivide	(	number_cuts	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	smoothness	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	quadtri	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	quadcorner	=	self	.	prop_quadcorner	,	fractal	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	fractal_along_normal	=	self	.	inputs	[	"str"	]	.	execute	(	)	,	seed	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	SymmetrizeNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_direction	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_threshold	=	FloatProperty	(	name	=	"str"	,	default	=	0.0001	,	min	=	0.0	,	max	=	10.0	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	symmetrize	(	direction	=	self	.	prop_direction	,	threshold	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	TriangulateFacesNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_quad	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_ngon	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	quads_convert_to_tris	(	quad_method	=	self	.	prop_quad	,	ngon_method	=	self	.	prop_ngon	)	
class	UnSubdivideNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_iterations	=	IntProperty	(	name	=	"str"	,	default	=	2	,	min	=	1	,	max	=	1000	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	unsubdivide	(	iterations	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	VertexGroupNode	(	Node	,	ScEditOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_vg	=	StringProperty	(	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_assign	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
name	=	self	.	inputs	[	"str"	]	.	execute	(	)	
slot	=	self	.	mesh	.	vertex_groups	.	find	(	name	)	
if	(	slot	==	-	1	)	:	
bpy	.	ops	.	object	.	vertex_group_add	(	)	
self	.	mesh	.	vertex_groups	.	active	.	name	=	name	
else	:	
self	.	mesh	.	vertex_groups	.	active_index	=	slot	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
bpy	.	ops	.	object	.	vertex_group_assign	(	)	
else	:	
bpy	.	ops	.	object	.	vertex_group_remove_from	(	)	

class	ApplyTransformNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_transform	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	,	2	)	,	(	"str"	,	"str"	,	"str"	,	4	)	,	(	"str"	,	"str"	,	"str"	,	8	)	]	,	default	=	{	"str"	}	,	options	=	{	"str"	}	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	transform_apply	(	location	=	"str"	in	self	.	prop_transform	,	rotation	=	"str"	in	self	.	prop_transform	,	scale	=	"str"	in	self	.	prop_transform	)	
class	CopyTransformNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_object	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
prop_transform	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	,	2	)	,	(	"str"	,	"str"	,	"str"	,	4	)	,	(	"str"	,	"str"	,	"str"	,	8	)	]	,	default	=	{	"str"	}	,	options	=	{	"str"	}	,	update	=	ScNode	.	update_value	)	
obj	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	pre_execute	(	self	)	:	
self	.	obj	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	obj	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
if	(	"str"	in	self	.	prop_transform	)	:	
self	.	mesh	.	location	=	self	.	obj	.	location	
if	(	"str"	in	self	.	prop_transform	)	:	
self	.	mesh	.	rotation_euler	=	self	.	obj	.	rotation_euler	
if	(	"str"	in	self	.	prop_transform	)	:	
self	.	mesh	.	scale	=	self	.	obj	.	scale	
class	DuplicateMeshNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_linked	=	BoolProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
removeMesh	(	self	.	mesh	)	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	duplicate	(	linked	=	self	.	inputs	[	"str"	]	.	execute	(	)	)	
self	.	mesh	=	bpy	.	context	.	active_object	
class	MakeLinksNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	make_links_data	(	type	=	self	.	prop_type	)	
class	MergeMeshesNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	link_limit	=	100	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	self	.	inputs	[	1	]	.	is_linked	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
meshes	=	[	]	
for	link	in	self	.	inputs	[	1	]	.	links	:	
mesh	=	link	.	from_socket	.	execute	(	)	
if	(	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
meshes	.	append	(	mesh	)	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
focusMesh	(	self	.	mesh	,	True	,	meshes	)	
return	True	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	join	(	)	
class	OriginNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_center	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	object	.	origin_set	(	type	=	self	.	prop_type	,	center	=	self	.	prop_center	)	
class	ScatterNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_component	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_location	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	,	2	)	,	(	"str"	,	"str"	,	"str"	,	4	)	,	(	"str"	,	"str"	,	"str"	,	8	)	]	,	default	=	{	"str"	,	"str"	,	"str"	}	,	options	=	{	"str"	}	,	update	=	ScNode	.	update_value	)	
prop_rotation	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	,	2	)	,	(	"str"	,	"str"	,	"str"	,	4	)	,	(	"str"	,	"str"	,	"str"	,	8	)	]	,	default	=	{	"str"	,	"str"	,	"str"	}	,	options	=	{	"str"	}	,	update	=	ScNode	.	update_value	)	
prop_random	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
prop_obj	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
obj	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	
scatter	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	
layout	.	label	(	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	
layout	.	label	(	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	pre_execute	(	self	)	:	
self	.	obj	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	obj	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	super	(	)	.	pre_execute	(	)	

def	functionality	(	self	)	:	
removeMesh	(	self	.	scatter	)	
if	(	self	.	prop_component	==	"str"	)	:	
selected_components	=	[	i	for	i	in	self	.	obj	.	data	.	polygons	if	i	.	select	]	
elif	(	self	.	prop_component	==	"str"	)	:	
selected_components	=	[	i	for	i	in	self	.	obj	.	data	.	vertices	if	i	.	select	]	
else	:	
selected_components	=	[	i	for	i	in	self	.	obj	.	data	.	edges	if	i	.	select	]	
if	(	len	(	selected_components	)	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	
re_evaluate	=	self	.	inputs	[	"str"	]	.	execute	(	)	
meshes	=	[	]	
for	i	in	selected_components	:	
focusMesh	(	self	.	mesh	)	
bpy	.	ops	.	object	.	duplicate	(	)	
mesh	=	bpy	.	context	.	active_object	
if	(	self	.	prop_component	==	"str"	)	:	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	0	]	=	i	.	center	[	0	]	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	1	]	=	i	.	center	[	1	]	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	2	]	=	i	.	center	[	2	]	
mesh	.	rotation_mode	=	"str"	
mesh	.	rotation_axis_angle	[	0	]	=	3.14159	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	1	]	=	i	.	normal	[	0	]	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	2	]	=	i	.	normal	[	1	]	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	3	]	=	i	.	normal	[	2	]	+	1	
mesh	.	rotation_mode	=	"str"	
elif	(	self	.	prop_component	==	"str"	)	:	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	0	]	=	i	.	co	[	0	]	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	1	]	=	i	.	co	[	1	]	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	2	]	=	i	.	co	[	2	]	
mesh	.	rotation_mode	=	"str"	
mesh	.	rotation_axis_angle	[	0	]	=	3.14159	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	1	]	=	i	.	normal	[	0	]	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	2	]	=	i	.	normal	[	1	]	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	3	]	=	i	.	normal	[	2	]	+	1	
mesh	.	rotation_mode	=	"str"	
else	:	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	0	]	=	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	co	[	0	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	co	[	0	]	)	/	2	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	1	]	=	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	co	[	1	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	co	[	1	]	)	/	2	
if	(	"str"	in	self	.	prop_location	)	:	
mesh	.	location	[	2	]	=	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	co	[	2	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	co	[	2	]	)	/	2	
mesh	.	rotation_mode	=	"str"	
mesh	.	rotation_axis_angle	[	0	]	=	3.14159	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	1	]	=	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	normal	[	0	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	normal	[	0	]	)	/	2	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	2	]	=	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	normal	[	1	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	normal	[	1	]	)	/	2	
if	(	"str"	in	self	.	prop_rotation	)	:	
mesh	.	rotation_axis_angle	[	3	]	=	(	(	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	normal	[	2	]	+	self	.	obj	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	normal	[	2	]	)	/	2	)	+	1	
mesh	.	rotation_mode	=	"str"	
mesh	.	rotation_mode	=	"str"	
mesh	.	rotation_axis_angle	[	0	]	=	3.14159	
mesh	.	rotation_mode	=	"str"	
meshes	.	append	(	mesh	)	
if	(	re_evaluate	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
focusMesh	(	mesh	,	True	,	meshes	)	
bpy	.	ops	.	object	.	join	(	)	
meshes	.	remove	(	mesh	)	
for	i	in	meshes	:	
removeMesh	(	i	,	False	)	
self	.	scatter	=	bpy	.	context	.	active_object	

def	post_execute	(	self	)	:	
return	self	.	scatter	
class	ShadingNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_shading	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_auto	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_angle	=	FloatProperty	(	name	=	"str"	,	default	=	0.523599	,	min	=	0.0	,	max	=	3.14159	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
if	(	self	.	prop_shading	==	"str"	)	:	
bpy	.	ops	.	object	.	shade_flat	(	)	
else	:	
bpy	.	ops	.	object	.	shade_smooth	(	)	
self	.	mesh	.	data	.	use_auto_smooth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	auto_smooth_angle	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	ViewportDrawModeNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_name	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_wire	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_xray	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_transparency	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_max_draw_type	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	label	(	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
self	.	mesh	.	show_name	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	show_wire	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	show_x_ray	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	show_transparent	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	draw_type	=	self	.	prop_max_draw_type	
class	CyclesDrawModeNode	(	Node	,	ScObjectOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_camera	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_diffuse	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_glossy	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_transmission	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_scatter	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_shadow	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
self	.	mesh	.	cycles_visibility	.	camera	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	cycles_visibility	.	diffuse	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	cycles_visibility	.	glossy	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	cycles_visibility	.	transmission	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	cycles_visibility	.	scatter	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	cycles_visibility	.	shadow	=	self	.	inputs	[	"str"	]	.	execute	(	)	

class	CurveShapeNode	(	Node	,	ScCurveOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_dimensions	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_fill_mode	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_fill_mode_2d	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_resolution	=	IntProperty	(	default	=	12	,	min	=	1	,	max	=	1024	,	soft_max	=	64	,	update	=	ScNode	.	update_value	)	
prop_render_resolution	=	IntProperty	(	min	=	0	,	max	=	1024	,	soft_max	=	64	,	update	=	ScNode	.	update_value	)	
prop_fill	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_twisting	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_smooth	=	FloatProperty	(	update	=	ScNode	.	update_value	)	
prop_radius	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	
prop_stretch	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
prop_clamp	=	BoolProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	
if	(	self	.	prop_dimensions	==	"str"	)	:	
layout	.	prop	(	self	,	"str"	)	
else	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
self	.	mesh	.	data	.	dimensions	=	self	.	prop_dimensions	
if	(	self	.	prop_dimensions	==	"str"	)	:	
self	.	mesh	.	data	.	fill_mode	=	self	.	prop_fill_mode_2d	
else	:	
self	.	mesh	.	data	.	fill_mode	=	self	.	prop_fill_mode	
self	.	mesh	.	data	.	resolution_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	render_resolution_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_fill_deform	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	twist_mode	=	self	.	prop_twisting	
self	.	mesh	.	data	.	twist_smooth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_radius	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_stretch	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_deform_bounds	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	CurveGeometryNode	(	Node	,	ScCurveOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_depth	=	FloatProperty	(	soft_min	=	0.0	,	update	=	ScNode	.	update_value	)	
prop_offset	=	FloatProperty	(	update	=	ScNode	.	update_value	)	
prop_extrude	=	FloatProperty	(	min	=	0.0	,	update	=	ScNode	.	update_value	)	
prop_resolution	=	IntProperty	(	min	=	0	,	max	=	32	,	update	=	ScNode	.	update_value	)	
prop_bevel_obj	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
prop_taper_obj	=	PointerProperty	(	type	=	bpy	.	types	.	Object	,	update	=	ScNode	.	update_value	)	
prop_bevel_mapping_start	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_bevel_mapping_end	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_bevel_start	=	FloatProperty	(	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_bevel_end	=	FloatProperty	(	default	=	1.0	,	min	=	0.0	,	max	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_taper	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
prop_fill	=	BoolProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
self	.	mesh	.	data	.	bevel_depth	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	offset	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	extrude	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	bevel_resolution	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	bevel_object	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	taper_object	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	bevel_factor_mapping_start	=	self	.	prop_bevel_mapping_start	
self	.	mesh	.	data	.	bevel_factor_mapping_end	=	self	.	prop_bevel_mapping_end	
self	.	mesh	.	data	.	bevel_factor_start	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	bevel_factor_end	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_map_taper	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	use_fill_caps	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	CurveSplineNode	(	Node	,	ScCurveOperatorNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_tilt	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_radius	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_resolution	=	IntProperty	(	default	=	12	,	min	=	1	,	max	=	1024	,	soft_max	=	64	,	update	=	ScNode	.	update_value	)	
prop_cyclic	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
prop_smooth	=	BoolProperty	(	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
self	.	mesh	.	data	.	splines	[	0	]	.	tilt_interpolation	=	self	.	prop_tilt	
self	.	mesh	.	data	.	splines	[	0	]	.	radius_interpolation	=	self	.	prop_radius	
self	.	mesh	.	data	.	splines	[	0	]	.	resolution_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	splines	[	0	]	.	use_cyclic_u	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	mesh	.	data	.	splines	[	0	]	.	use_smooth	=	self	.	inputs	[	"str"	]	.	execute	(	)	

class	FloatNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_float	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	post_execute	(	self	)	:	
return	self	.	prop_float	
class	IntNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_int	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	post_execute	(	self	)	:	
return	self	.	prop_int	
class	BoolNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_bool	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	post_execute	(	self	)	:	
return	self	.	prop_bool	
class	AngleNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_angle	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	post_execute	(	self	)	:	
return	self	.	prop_angle	
class	FloatVectorNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_x	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_z	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_uniform	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_vector	=	FloatVectorProperty	(	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	=	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	prop_vector	[	0	]	
self	.	prop_vector	[	2	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	1	]	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	0	]	
else	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	prop_vector	[	0	]	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	0	]	

def	post_execute	(	self	)	:	
return	self	.	prop_vector	
class	AngleVectorNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_x	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_z	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_uniform	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_vector	=	FloatVectorProperty	(	unit	=	"str"	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	=	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	prop_vector	[	0	]	
self	.	prop_vector	[	2	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	1	]	
elif	(	self	.	prop_uniform	==	"str"	)	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	0	]	
else	:	
self	.	prop_vector	[	0	]	=	self	.	inputs	[	"str"	]	.	execute	(	)	
self	.	prop_vector	[	1	]	=	self	.	prop_vector	[	0	]	
self	.	prop_vector	[	2	]	=	self	.	prop_vector	[	0	]	

def	post_execute	(	self	)	:	
return	self	.	prop_vector	
class	RandomFloatNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_min	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_max	=	FloatProperty	(	name	=	"str"	,	default	=	1.0	,	update	=	ScNode	.	update_value	)	
prop_seed	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_once	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
val	=	FloatProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	first_time	)	:	
random	.	seed	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
self	.	val	=	random	.	uniform	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
self	.	val	=	random	.	uniform	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	

def	post_execute	(	self	)	:	
return	self	.	val	
class	RandomIntNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_min	=	IntProperty	(	name	=	"str"	,	default	=	1	,	update	=	ScNode	.	update_value	)	
prop_max	=	IntProperty	(	name	=	"str"	,	default	=	5	,	update	=	ScNode	.	update_value	)	
prop_seed	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_once	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
val	=	IntProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	first_time	)	:	
random	.	seed	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
self	.	val	=	random	.	randint	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
self	.	val	=	random	.	randint	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
def	post_execute	(	self	)	:	
return	self	.	val	
class	RandomBoolNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_seed	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_once	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
val	=	BoolProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	first_time	)	:	
random	.	seed	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
self	.	val	=	bool	(	random	.	getrandbits	(	1	)	)	
elif	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
self	.	val	=	bool	(	random	.	getrandbits	(	1	)	)	

def	post_execute	(	self	)	:	
return	self	.	val	
class	RandomAngleNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_min	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_max	=	FloatProperty	(	name	=	"str"	,	subtype	=	"str"	,	unit	=	"str"	,	default	=	3.14159	,	update	=	ScNode	.	update_value	)	
prop_seed	=	IntProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_once	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
val	=	FloatProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
if	(	self	.	first_time	)	:	
random	.	seed	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
self	.	val	=	random	.	uniform	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	not	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
self	.	val	=	random	.	uniform	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	

def	post_execute	(	self	)	:	
return	self	.	val	
class	StringNode	(	Node	,	ScConstantNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_string	=	StringProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	post_execute	(	self	)	:	
return	self	.	prop_string	

class	AppendStringNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_x	=	StringProperty	(	update	=	ScNode	.	update_value	)	
prop_y	=	StringProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	+	self	.	inputs	[	"str"	]	.	execute	(	)	
class	BooleanOpNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_x	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	execute	(	self	)	:	
if	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	and	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	or	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	==	self	.	inputs	[	"str"	]	.	execute	(	)	
class	ComparisonOpNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_x	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	execute	(	self	)	:	
if	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	<	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	>	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	<	=	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	>	=	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	==	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	!=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	MathsOpNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_x	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	execute	(	self	)	:	
if	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	+	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	-	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	*	self	.	inputs	[	"str"	]	.	execute	(	)	
elif	(	self	.	prop_op	==	"str"	)	:	
temp	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	temp	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	0	
return	self	.	inputs	[	"str"	]	.	execute	(	)	/	temp	
elif	(	self	.	prop_op	==	"str"	)	:	
temp	=	int	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
if	(	temp	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	0	
return	int	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	%	temp	
elif	(	self	.	prop_op	==	"str"	)	:	
return	pow	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	math	.	log	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	TrigonometricOpNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_op2	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_x	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	execute	(	self	)	:	
if	(	self	.	prop_op	==	"str"	)	:	
if	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	sin	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	sinh	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
else	:	
return	math	.	asin	(	max	(	min	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	1	)	,	-	1	)	)	
elif	(	self	.	prop_op	==	"str"	)	:	
if	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	cos	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	cosh	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
else	:	
return	math	.	acos	(	max	(	min	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	1	)	,	-	1	)	)	
else	:	
if	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	tan	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_op2	==	"str"	)	:	
return	math	.	tanh	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
else	:	
return	math	.	atan	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	VectorOpNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_op	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_x	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_y	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	execute	(	self	)	:	
if	(	self	.	prop_op	==	"str"	)	:	
return	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	+	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
elif	(	self	.	prop_op	==	"str"	)	:	
return	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	-	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	
else	:	
return	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	.	cross	(	Vector	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	)	
class	GetComponentInfoNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_component	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_data	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_average	=	BoolProperty	(	update	=	ScNode	.	update_value	)	
mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	
data	=	FloatVectorProperty	(	)	
faces	=	[	]	
vertices	=	[	]	
edges	=	[	]	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	execute	(	self	)	:	
if	not	self	.	pre_execute	(	)	:	
return	(	0	,	0	,	0	)	
self	.	functionality	(	)	
ret_data	=	self	.	post_execute	(	)	
if	(	self	.	first_time	)	:	
self	.	first_time	=	False	
return	ret_data	

def	pre_execute	(	self	)	:	
node	=	self	.	inputs	[	"str"	]	.	links	[	0	]	.	from_node	
if	(	node	.	first_time	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
else	:	
self	.	mesh	=	node	.	mesh	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
self	.	faces	=	[	i	for	i	in	self	.	mesh	.	data	.	polygons	if	i	.	select	]	
self	.	vertices	=	[	i	for	i	in	self	.	mesh	.	data	.	vertices	if	i	.	select	]	
self	.	edges	=	[	i	for	i	in	self	.	mesh	.	data	.	edges	if	i	.	select	]	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
if	(	self	.	prop_component	==	"str"	)	:	
if	(	len	(	self	.	faces	)	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
elif	(	self	.	prop_component	==	"str"	)	:	
if	(	len	(	self	.	vertices	)	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
else	:	
if	(	len	(	self	.	edges	)	==	0	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	functionality	(	self	)	:	
data	=	Vector	(	(	0	,	0	,	0	)	)	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
if	(	self	.	prop_data	==	"str"	)	:	
if	(	self	.	prop_component	==	"str"	)	:	
for	i	in	self	.	faces	:	
data	+	=	i	.	center	
data	/	=	len	(	self	.	faces	)	
elif	(	self	.	prop_component	==	"str"	)	:	
for	i	in	self	.	vertices	:	
data	+	=	i	.	co	
data	/	=	len	(	self	.	vertices	)	
else	:	
for	i	in	self	.	edges	:	
data	+	=	(	Vector	(	self	.	mesh	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	co	)	+	Vector	(	self	.	mesh	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	co	)	)	/	2	
data	/	=	len	(	self	.	edges	)	
else	:	
if	(	self	.	prop_component	==	"str"	)	:	
for	i	in	self	.	faces	:	
data	+	=	i	.	normal	
data	/	=	len	(	self	.	faces	)	
elif	(	self	.	prop_component	==	"str"	)	:	
for	i	in	self	.	vertices	:	
data	+	=	i	.	normal	
data	/	=	len	(	self	.	vertices	)	
else	:	
for	i	in	self	.	edges	:	
data	+	=	(	Vector	(	self	.	mesh	.	data	.	vertices	[	i	.	vertices	[	0	]	]	.	normal	)	+	Vector	(	self	.	mesh	.	data	.	vertices	[	i	.	vertices	[	1	]	]	.	normal	)	)	/	2	
data	/	=	len	(	self	.	edges	)	
else	:	
if	(	self	.	prop_data	==	"str"	)	:	
if	(	self	.	prop_component	==	"str"	)	:	
data	=	self	.	faces	[	0	]	.	center	
elif	(	self	.	prop_component	==	"str"	)	:	
data	=	self	.	vertices	[	0	]	.	co	
else	:	
data	=	(	Vector	(	self	.	mesh	.	data	.	vertices	[	self	.	edges	[	0	]	.	vertices	[	0	]	]	.	co	)	+	Vector	(	self	.	mesh	.	data	.	vertices	[	self	.	edges	[	0	]	.	vertices	[	1	]	]	.	co	)	)	/	2	
else	:	
if	(	self	.	prop_component	==	"str"	)	:	
data	=	self	.	faces	[	0	]	.	normal	
elif	(	self	.	prop_component	==	"str"	)	:	
data	=	self	.	vertices	[	0	]	.	normal	
else	:	
data	=	(	Vector	(	self	.	mesh	.	data	.	vertices	[	self	.	edges	[	0	]	.	vertices	[	0	]	]	.	normal	)	+	Vector	(	self	.	mesh	.	data	.	vertices	[	self	.	edges	[	0	]	.	vertices	[	1	]	]	.	normal	)	)	/	2	
self	.	data	=	data	

def	post_execute	(	self	)	:	
return	self	.	data	
class	ClampNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_val	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_min	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_max	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
return	max	(	min	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	
class	MapRangeNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_val	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_in_min	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_in_max	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_out_min	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_out_max	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_clamp	=	BoolProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	execute	(	self	)	:	
x	=	self	.	inputs	[	"str"	]	.	execute	(	)	
x_min	=	self	.	inputs	[	"str"	]	.	execute	(	)	
x_max	=	self	.	inputs	[	"str"	]	.	execute	(	)	
y_min	=	self	.	inputs	[	"str"	]	.	execute	(	)	
y_max	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	y_max	==	y_min	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	0	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
x	=	max	(	min	(	x	,	x_max	)	,	x_min	)	
return	(	(	(	x	-	x_min	)	*	(	y_max	-	y_min	)	)	/	(	x_max	-	x_min	)	)	+	(	y_min	)	
class	BreakVectorNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_element	=	EnumProperty	(	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_vector	=	FloatVectorProperty	(	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	execute	(	self	)	:	
if	(	self	.	prop_element	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	[	0	]	
if	(	self	.	prop_element	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	[	1	]	
if	(	self	.	prop_element	==	"str"	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	[	2	]	
class	PrintDataNode	(	Node	,	ScUtilityNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_value	=	FloatProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_list	=	BoolProperty	(	name	=	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	self	==	self	.	id_data	.	nodes	.	active	)	:	
layout	.	operator	(	"str"	,	"str"	)	

def	execute	(	self	)	:	
temp	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
print	(	list	(	temp	)	)	
else	:	
print	(	temp	)	
return	temp	

class	BeginForLoopNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	
unlocked	=	BoolProperty	(	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	self	.	outputs	[	0	]	.	is_linked	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
if	(	self	.	first_time	or	self	.	unlocked	)	:	
self	.	unlocked	=	False	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	EndForLoopNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	

prop_start	=	IntProperty	(	name	=	"str"	,	default	=	1	,	update	=	ScNode	.	update_value	)	
prop_end	=	IntProperty	(	name	=	"str"	,	default	=	3	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	self	.	inputs	[	0	]	.	is_linked	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
self	.	mesh	=	self	.	inputs	[	0	]	.	links	[	0	]	.	from_node	.	outputs	[	"str"	]	.	execute	(	)	
return	True	

def	functionality	(	self	)	:	
for	i	in	range	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	self	.	inputs	[	"str"	]	.	execute	(	)	+	1	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	
self	.	inputs	[	0	]	.	links	[	0	]	.	from_node	.	unlocked	=	True	

def	post_execute	(	self	)	:	
return	self	.	mesh	
class	BeginForEachLoopNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	
prop_selection	=	StringProperty	(	default	=	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	self	.	outputs	[	0	]	.	is_linked	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
if	(	self	.	first_time	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
self	.	prop_selection	=	str	(	[	i	.	index	for	i	in	self	.	mesh	.	data	.	polygons	if	i	.	select	]	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
if	(	self	.	prop_selection	==	"str"	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
return	True	

def	functionality	(	self	)	:	
bpy	.	ops	.	mesh	.	select_all	(	action	=	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
temp_list	=	toList	(	self	.	prop_selection	)	
self	.	mesh	.	data	.	polygons	[	temp_list	.	pop	(	)	]	.	select	=	True	
self	.	prop_selection	=	str	(	temp_list	)	

def	post_execute	(	self	)	:	
if	(	self	.	prop_selection	==	"str"	)	:	
self	.	outputs	[	0	]	.	links	[	0	]	.	to_node	.	last_time	=	True	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
return	self	.	mesh	
class	EndForEachLoopNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

mesh	=	PointerProperty	(	type	=	bpy	.	types	.	Object	)	
last_time	=	BoolProperty	(	)	
prop_selection	=	StringProperty	(	default	=	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	pre_execute	(	self	)	:	
if	(	not	self	.	inputs	[	0	]	.	is_linked	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	False	
self	.	prop_selection	=	"str"	
return	True	

def	functionality	(	self	)	:	
while	(	not	self	.	last_time	)	:	
self	.	mesh	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	mesh	==	None	)	:	
print	(	"str"	+	self	.	name	+	"str"	)	
return	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
try	:	
temp_index	=	[	i	.	index	for	i	in	self	.	mesh	.	data	.	polygons	if	i	.	select	]	[	0	]	
temp_list	=	toList	(	self	.	prop_selection	)	
temp_list	.	append	(	temp_index	)	
self	.	prop_selection	=	str	(	temp_list	)	
except	:	
print	(	"str"	+	self	.	name	+	"str"	)	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	

def	post_execute	(	self	)	:	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
for	i	in	toList	(	self	.	prop_selection	)	:	
self	.	mesh	.	data	.	polygons	[	i	]	.	select	=	True	
bpy	.	ops	.	object	.	mode_set	(	mode	=	"str"	)	
return	self	.	mesh	
class	IfElseNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_bool	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	post_execute	(	self	)	:	
if	(	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	
else	:	
return	self	.	inputs	[	"str"	]	.	execute	(	)	
class	SwitchNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_int	=	IntProperty	(	default	=	0	,	min	=	0	,	max	=	10	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	post_execute	(	self	)	:	
return	self	.	inputs	[	max	(	min	(	self	.	inputs	[	"str"	]	.	execute	(	)	,	10	)	,	0	)	+	1	]	.	execute	(	)	
class	SequenceNode	(	Node	,	ScControlNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

data	=	None	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	inputs	.	new	(	"str"	,	"str"	)	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
for	i	in	self	.	inputs	:	
data	=	i	.	execute	(	)	
if	(	not	data	==	None	)	:	
self	.	data	=	data	

def	post_execute	(	self	)	:	
return	self	.	data	

class	CursorLocationNode	(	Node	,	ScSettingNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_location	=	FloatVectorProperty	(	name	=	"str"	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	functionality	(	self	)	:	
self	.	override	(	)	[	"str"	]	.	cursor_location	=	self	.	inputs	[	"str"	]	.	execute	(	)	
class	OrientationNode	(	Node	,	ScSettingNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_orientation	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
self	.	override	(	)	[	"str"	]	.	transform_orientation	=	self	.	prop_orientation	
class	PivotNode	(	Node	,	ScSettingNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_pivot	=	EnumProperty	(	name	=	"str"	,	items	=	[	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	,	(	"str"	,	"str"	,	"str"	)	]	,	default	=	"str"	,	update	=	ScNode	.	update_value	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	column	(	)	.	prop	(	self	,	"str"	,	expand	=	True	)	

def	functionality	(	self	)	:	
self	.	override	(	)	[	"str"	]	.	pivot_point	=	self	.	prop_pivot	
class	CustomPythonNode	(	Node	,	ScSettingNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_script	=	StringProperty	(	name	=	"str"	,	description	=	"str"	,	update	=	ScNode	.	update_value	)	
prop_iterations	=	IntProperty	(	name	=	"str"	,	default	=	1	,	min	=	1	,	max	=	1000	,	update	=	ScNode	.	update_value	)	
prop_print	=	BoolProperty	(	name	=	"str"	,	default	=	True	,	update	=	ScNode	.	update_value	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
layout	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
_OBJ	=	bpy	.	context	.	active_object	
_OVERRIDE	=	self	.	override	(	)	
_M	=	bpy	.	ops	.	mesh	
_O	=	bpy	.	ops	.	object	
_N	=	self	.	id_data	.	nodes	
_L	=	self	.	id_data	.	links	
_SELF	=	self	
script	=	self	.	inputs	[	"str"	]	.	execute	(	)	
if	(	self	.	prop_print	)	:	
print	(	"str"	+	script	)	
for	i	in	range	(	0	,	self	.	inputs	[	"str"	]	.	execute	(	)	)	:	
try	:	
exec	(	script	)	
except	:	
print	(	"str"	+	self	.	name	+	"str"	)	
break	

class	RefreshMeshNode	(	Node	,	ScOutputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

print_output	=	BoolProperty	(	name	=	"str"	,	default	=	False	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	self	==	self	.	id_data	.	nodes	.	active	)	:	
layout	.	operator	(	"str"	,	"str"	)	
layout	.	column	(	)	.	prop	(	self	,	"str"	)	

def	functionality	(	self	)	:	
if	(	self	.	print_output	)	:	
print	(	self	.	name	+	"str"	+	self	.	mesh	.	name	)	
class	ExportMeshFBXNode	(	Node	,	ScOutputNode	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

prop_filepath	=	StringProperty	(	name	=	"str"	,	default	=	"str"	)	
prop_filename	=	StringProperty	(	name	=	"str"	,	default	=	"str"	)	

def	init	(	self	,	context	)	:	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	inputs	.	new	(	"str"	,	"str"	)	.	prop_prop	=	"str"	
self	.	outputs	.	new	(	"str"	,	"str"	)	
super	(	)	.	init	(	context	)	

def	draw_buttons	(	self	,	context	,	layout	)	:	
if	(	self	==	self	.	id_data	.	nodes	.	active	)	:	
layout	.	operator	(	"str"	,	"str"	)	

def	functionality	(	self	)	:	
bpy	.	ops	.	export_scene	.	fbx	(	filepath	=	self	.	inputs	[	"str"	]	.	execute	(	)	+	self	.	inputs	[	"str"	]	.	execute	(	)	+	"str"	,	use_selection	=	True	,	use_tspace	=	True	)	





menu_icons	=	bpy	.	utils	.	previews	.	new	(	)	
icons_dir	=	bpy	.	utils	.	user_resource	(	"str"	,	"str"	)	+	__name__	+	"str"	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	
menu_icons	.	load	(	"str"	,	icons_dir	+	"str"	,	"str"	)	

inputs	=	[	PlaneNode	,	CubeNode	,	CircleNode	,	UVSphereNode	,	IcoSphereNode	,	CylinderNode	,	ConeNode	,	GridNode	,	SuzanneNode	,	CustomMeshNode	,	CustomCurveNode	]	
transform	=	[	LocationNode	,	RotationNode	,	ScaleNode	,	TranslateNode	,	RotateNode	,	ResizeNode	]	
conversion	=	[	ToComponentNode	,	ToMeshNode	,	ChangeModeNode	,	ToStringNode	,	ToFloatNode	,	ToIntNode	,	ToBoolNode	,	CurveToMeshNode	]	
selection	=	[	SelectComponentsManuallyNode	,	SelectComponentByIndexNode	,	SelectFacesByMaterialNode	,	SelectFacesByNormalNode	,	SelectVerticesByVertexGroupNode	,	SelectAllNode	,	SelectAxisNode	,	SelectFaceBySidesNode	,	SelectInteriorFaces	,	SelectLessNode	,	SelectMoreNode	,	SelectLinkedNode	,	SelectLoopNode	,	SelectLoopRegionNode	,	SelectLooseNode	,	SelectMirrorNode	,	SelectNextItemNode	,	SelectPrevItemNode	,	SelectNonManifoldNode	,	SelectNthNode	,	SelectAlternateFacesNode	,	SelectRandomNode	,	SelectRegionBoundaryNode	,	SelectSharpEdgesNode	,	SelectSimilarNode	,	SelectSimilarRegionNode	,	SelectShortestPathNode	,	SelectUngroupedNode	,	SelectFacesLinkedFlatNode	]	
deletion	=	[	DeleteNode	,	DeleteEdgeLoopNode	,	DissolveFacesNode	,	DissolveEdgesNode	,	DissolveVerticesNode	,	DissolveDegenerateNode	,	EdgeCollapseNode	]	
edit_operators	=	[	AddEdgeFaceNode	,	BeautifyFillNode	,	BevelNode	,	BridgeEdgeLoopsNode	,	ConvexHullNode	,	DecimateNode	,	ExtrudeFacesNode	,	ExtrudeEdgesNode	,	ExtrudeVerticesNode	,	ExtrudeRegionNode	,	FlipNormalsNode	,	MakeNormalsConsistentNode	,	FlattenNode	,	FillEdgeLoopNode	,	FillGridNode	,	FillHolesBySidesNode	,	InsetNode	,	LoopCutNode	,	MaterialNode	,	MergeComponentsNode	,	OffsetEdgeLoopNode	,	PokeNode	,	RemoveDoublesNode	,	RotateEdgeNode	,	ScrewNode	,	SolidifyNode	,	SpinNode	,	SplitNode	,	SubdivideNode	,	SymmetrizeNode	,	TriangulateFacesNode	,	UnSubdivideNode	,	VertexGroupNode	]	
object_operators	=	[	ApplyTransformNode	,	CopyTransformNode	,	DuplicateMeshNode	,	MakeLinksNode	,	MergeMeshesNode	,	OriginNode	,	ScatterNode	,	ShadingNode	,	ViewportDrawModeNode	,	CyclesDrawModeNode	]	
curve_operators	=	[	CurveShapeNode	,	CurveGeometryNode	,	CurveSplineNode	]	
modifiers	=	[	ArrayModNode	,	BevelModNode	,	BooleanModNode	,	CastModNode	,	CorrectiveSmoothModNode	,	CurveModNode	,	DecimateModNode	,	DisplaceModNode	,	EdgeSplitModNode	,	LaplacianSmoothModNode	,	MirrorModNode	,	RemeshModNode	,	ScrewModNode	,	SimpleDeformModNode	,	SkinModNode	,	SmoothModNode	,	SolidifyModNode	,	SubdivideModNode	,	TriangulateModNode	,	WireframeModNode	]	
constants	=	[	FloatNode	,	IntNode	,	BoolNode	,	AngleNode	,	FloatVectorNode	,	AngleVectorNode	,	RandomFloatNode	,	RandomIntNode	,	RandomBoolNode	,	RandomAngleNode	,	StringNode	]	
utilities	=	[	AppendStringNode	,	BooleanOpNode	,	ComparisonOpNode	,	MathsOpNode	,	TrigonometricOpNode	,	VectorOpNode	,	GetComponentInfoNode	,	ClampNode	,	MapRangeNode	,	BreakVectorNode	]	
control	=	[	BeginForLoopNode	,	EndForLoopNode	,	BeginForEachLoopNode	,	EndForEachLoopNode	,	IfElseNode	,	SwitchNode	,	SequenceNode	]	
settings	=	[	CursorLocationNode	,	OrientationNode	,	PivotNode	,	CustomPythonNode	]	
outputs	=	[	RefreshMeshNode	,	ExportMeshFBXNode	,	PrintDataNode	]	




class	ScNodeTree	(	NodeTree	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	
bl_icon	=	"str"	

prop_collapse	=	BoolProperty	(	name	=	"str"	)	

def	update	(	self	)	:	
for	link	in	self	.	links	:	
if	not	(	link	.	from_socket	.	rna_type	==	link	.	to_socket	.	rna_type	or	link	.	from_socket	.	rna_type	.	name	in	link	.	to_socket	.	friends	or	link	.	to_socket	.	rna_type	.	name	in	link	.	from_socket	.	friends	)	:	
self	.	links	.	remove	(	link	)	
class	ScNodeCategory	(	NodeCategory	)	:	
@classmethod	
def	poll	(	cls	,	context	)	:	
return	context	.	space_data	.	tree_type	==	"str"	
node_categories	=	[	(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	inputs	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	transform	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	conversion	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	selection	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	deletion	]	)	,	"str"	)	,	
"str"	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	edit_operators	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	object_operators	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	curve_operators	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	modifiers	]	)	,	"str"	)	,	
"str"	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	constants	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	utilities	]	)	,	"str"	)	,	
"str"	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	control	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	settings	]	)	,	"str"	)	,	
(	ScNodeCategory	(	"str"	,	"str"	,	items	=	[	NodeItem	(	i	.	bl_idname	)	for	i	in	outputs	]	)	,	"str"	)	]	
class	NODE_MT_add	(	bpy	.	types	.	Menu	)	:	
bl_space_type	=	"str"	
bl_label	=	"str"	

def	draw	(	self	,	context	)	:	
global	menu_icons	
layout	=	self	.	layout	
layout	.	operator_context	=	"str"	
layout	.	operator	(	"str"	,	text	=	"str"	,	icon_value	=	menu_icons	[	"str"	]	.	icon_id	)	.	use_transform	=	True	
layout	.	separator	(	)	

nodeitems_utils	.	draw_node_categories_menu	(	self	,	context	)	
class	NODE_MT_editor_menus	(	bpy	.	types	.	Menu	)	:	
bl_idname	=	"str"	
bl_label	=	"str"	

def	draw	(	self	,	context	)	:	
self	.	draw_menus	(	self	.	layout	,	context	)	

@staticmethod	
def	draw_menus	(	layout	,	context	)	:	
layout	.	menu	(	"str"	)	
layout	.	menu	(	"str"	)	
layout	.	menu	(	"str"	)	
layout	.	menu	(	"str"	)	
class	NODE_HT_header	(	bpy	.	types	.	Header	)	:	
bl_space_type	=	"str"	

def	draw	(	self	,	context	)	:	
layout	=	self	.	layout	

scene	=	context	.	scene	
snode	=	context	.	space_data	
snode_id	=	snode	.	id	
id_from	=	snode	.	id_from	
toolsettings	=	context	.	tool_settings	

row	=	layout	.	row	(	align	=	True	)	
row	.	template_header	(	)	

NODE_MT_editor_menus	.	draw_collapsible	(	context	,	layout	)	

layout	.	prop	(	snode	,	"str"	,	text	=	"str"	,	expand	=	True	)	

if	snode	.	tree_type	==	"str"	:	
if	scene	.	render	.	use_shading_nodes	:	
layout	.	prop	(	snode	,	"str"	,	text	=	"str"	,	expand	=	True	)	

ob	=	context	.	object	
if	(	not	scene	.	render	.	use_shading_nodes	or	snode	.	shader_type	==	"str"	)	and	ob	:	
row	=	layout	.	row	(	)	

row	.	enabled	=	not	snode	.	pin	

if	not	id_from	and	ob	.	type	in	{	"str"	,	"str"	,	"str"	,	"str"	,	"str"	}	:	
row	.	template_ID	(	ob	,	"str"	,	new	=	"str"	)	

if	id_from	and	ob	.	type	!=	"str"	:	
row	.	template_ID	(	id_from	,	"str"	,	new	=	"str"	)	


if	snode_id	and	not	(	scene	.	render	.	use_shading_nodes	==	0	and	ob	.	type	==	"str"	)	:	
layout	.	prop	(	snode_id	,	"str"	)	

if	scene	.	render	.	use_shading_nodes	and	snode	.	shader_type	==	"str"	:	
row	=	layout	.	row	(	)	
row	.	enabled	=	not	snode	.	pin	
row	.	template_ID	(	scene	,	"str"	,	new	=	"str"	)	
if	snode_id	:	
row	.	prop	(	snode_id	,	"str"	)	

if	scene	.	render	.	use_shading_nodes	and	snode	.	shader_type	==	"str"	:	
rl	=	context	.	scene	.	render	.	layers	.	active	
lineset	=	rl	.	freestyle_settings	.	linesets	.	active	
if	lineset	is	not	None	:	
row	=	layout	.	row	(	)	
row	.	enabled	=	not	snode	.	pin	
row	.	template_ID	(	lineset	,	"str"	,	new	=	"str"	)	
if	snode_id	:	
row	.	prop	(	snode_id	,	"str"	)	

elif	snode	.	tree_type	==	"str"	:	
layout	.	prop	(	snode	,	"str"	,	text	=	"str"	,	expand	=	True	)	

if	id_from	:	
if	snode	.	texture_type	==	"str"	:	
layout	.	template_ID	(	id_from	,	"str"	,	new	=	"str"	)	
else	:	
layout	.	template_ID	(	id_from	,	"str"	,	new	=	"str"	)	
if	snode_id	:	
layout	.	prop	(	snode_id	,	"str"	)	

elif	snode	.	tree_type	==	"str"	:	
if	snode_id	:	
layout	.	prop	(	snode_id	,	"str"	)	
layout	.	prop	(	snode	,	"str"	)	
if	snode	.	show_backdrop	:	
row	=	layout	.	row	(	align	=	True	)	
row	.	prop	(	snode	,	"str"	,	text	=	"str"	,	expand	=	True	)	
layout	.	prop	(	snode	,	"str"	)	

elif	snode	.	tree_type	==	"str"	:	
layout	.	template_ID	(	snode	,	"str"	,	new	=	"str"	)	
if	(	not	snode	.	node_tree	==	None	)	:	
layout	.	prop	(	snode	.	node_tree	,	"str"	)	

else	:	

layout	.	template_ID	(	snode	,	"str"	,	new	=	"str"	)	

layout	.	prop	(	snode	,	"str"	,	text	=	"str"	)	
layout	.	operator	(	"str"	,	text	=	"str"	,	icon	=	"str"	)	

layout	.	separator	(	)	


layout	.	prop	(	snode	,	"str"	,	text	=	"str"	)	


row	=	layout	.	row	(	align	=	True	)	
row	.	prop	(	toolsettings	,	"str"	,	text	=	"str"	)	
row	.	prop	(	toolsettings	,	"str"	,	icon_only	=	True	)	
if	toolsettings	.	snap_node_element	!=	"str"	:	
row	.	prop	(	toolsettings	,	"str"	,	text	=	"str"	)	

row	=	layout	.	row	(	align	=	True	)	
row	.	operator	(	"str"	,	text	=	"str"	,	icon	=	"str"	)	
row	.	operator	(	"str"	,	text	=	"str"	,	icon	=	"str"	)	

layout	.	template_running_jobs	(	)	



def	register_node_categories	(	identifier	,	cat_list_icon	)	:	
if	identifier	in	_node_categories	:	
raise	KeyError	(	"str"	%	identifier	)	
return	


def	draw_node_item	(	self	,	context	)	:	
layout	=	self	.	layout	
col	=	layout	.	column	(	)	
for	item	in	self	.	category	.	items	(	context	)	:	
item	.	draw	(	item	,	col	,	context	)	

menu_types	=	[	]	
panel_types	=	[	]	
for	cat	in	cat_list_icon	:	
if	(	not	cat	==	"str"	)	:	
menu_type	=	type	(	"str"	+	cat	[	0	]	.	identifier	,	(	bpy	.	types	.	Menu	,	)	,	{	
"str"	:	"str"	,	
"str"	:	cat	[	0	]	.	name	,	
"str"	:	cat	[	0	]	,	
"str"	:	cat	[	0	]	.	poll	,	
"str"	:	draw_node_item	,	
}	)	
panel_type	=	type	(	"str"	+	cat	[	0	]	.	identifier	,	(	bpy	.	types	.	Panel	,	)	,	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	cat	[	0	]	.	name	,	
"str"	:	cat	[	0	]	.	name	,	
"str"	:	cat	[	0	]	,	
"str"	:	cat	[	0	]	.	poll	,	
"str"	:	draw_node_item	,	
}	)	
menu_types	.	append	(	menu_type	)	
panel_types	.	append	(	panel_type	)	
bpy	.	utils	.	register_class	(	menu_type	)	
bpy	.	utils	.	register_class	(	panel_type	)	

def	draw_add_menu	(	self	,	context	)	:	
global	menu_icons	
layout	=	self	.	layout	
for	cat	in	cat_list_icon	:	
if	(	not	cat	==	"str"	)	:	
if	cat	[	0	]	.	poll	(	context	)	:	
layout	.	menu	(	"str"	%	cat	[	0	]	.	identifier	,	icon_value	=	menu_icons	[	cat	[	1	]	]	.	icon_id	)	
else	:	
layout	.	separator	(	)	


_node_categories	[	identifier	]	=	(	[	i	[	0	]	for	i	in	cat_list_icon	if	not	i	==	"str"	]	,	draw_add_menu	,	menu_types	,	panel_types	)	
def	register	(	)	:	
register_node_categories	(	"str"	,	node_categories	)	
bpy	.	utils	.	register_module	(	__name__	)	
def	unregister	(	)	:	
global	menu_icons	
bpy	.	utils	.	previews	.	remove	(	menu_icons	)	
nodeitems_utils	.	unregister_node_categories	(	"str"	)	
bpy	.	utils	.	unregister_module	(	__name__	)	
	