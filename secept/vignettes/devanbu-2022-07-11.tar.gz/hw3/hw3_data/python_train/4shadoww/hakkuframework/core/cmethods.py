



import	sys	
import	os	
import	imp	
import	traceback	
import	curses	
import	time	
import	importlib	
import	glob	


from	core	import	getpath	


sys	.	path	.	append	(	getpath	.	lib	(	)	)	



from	core	import	helptable	
from	core	import	helpin	
from	core	import	info	
from	core	import	colors	
from	core	import	moduleop	
from	prettytable	import	PrettyTable	
import	core	.	cowsay	
from	core	import	dsag	
import	core	.	matrix	
import	core	.	touchingsky	
from	core	.	hftest	import	check_module	
from	core	import	update	
from	core	import	mscop	
from	core	import	value_holder	
from	core	import	moddbparser	
from	core	.	messages	import	*	
from	core	.	apistatus	import	*	


from	core	.	exceptions	import	UnknownCommand	
from	core	.	exceptions	import	ModuleNotFound	
from	core	.	exceptions	import	VariableError	

class	Cmethods	:	



mm	=	None	
modadd	=	None	



def	__init__	(	self	,	mmi	)	:	
self	.	mm	=	mmi	



def	mcu	(	self	,	command	)	:	
try	:	
if	command	[	0	]	in	self	.	modadd	.	customcommands	.	keys	(	)	:	
call	=	getattr	(	self	.	modadd	,	command	[	0	]	)	
try	:	
return	call	(	command	[	1	:	]	)	
except	Exception	as	e	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
raise	UnknownCommand	(	"str"	)	
except	AttributeError	:	
raise	UnknownCommand	(	"str"	)	



def	exit	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
self	.	mm	.	moduleLoaded	=	0	
self	.	mm	.	moduleName	=	"str"	
else	:	
sys	.	exit	(	)	

def	clear	(	self	,	args	)	:	
if	len	(	args	)	!=	0	and	args	[	0	]	==	"str"	:	
mscop	.	clear_tmp	(	)	
else	:	
sys	.	stderr	.	write	(	"str"	)	

def	cl	(	self	,	args	)	:	
os	.	system	(	"str"	.	join	(	args	)	)	

def	help	(	self	,	args	)	:	

if	self	.	mm	.	moduleLoaded	==	0	:	
print	(	helptable	.	generateTable	(	helpin	.	commands	)	)	
else	:	
try	:	
print	(	helptable	.	generatemTable	(	helpin	.	mcommands	,	self	.	modadd	.	customcommands	)	)	
except	AttributeError	:	
print	(	helptable	.	generateTable	(	helpin	.	mcommands	)	)	
try	:	
print	(	"str"	,	self	.	modadd	.	help_notes	,	"str"	)	
except	AttributeError	:	
pass	

def	version	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
print	(	self	.	modadd	.	conf	[	"str"	]	+	"str"	+	self	.	modadd	.	conf	[	"str"	]	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
print	(	"str"	+	info	.	version	+	"str"	+	info	.	codename	)	

def	ifconfig	(	self	,	args	)	:	
os	.	system	(	"str"	+	"str"	+	"str"	.	join	(	args	)	)	

def	scan	(	self	,	args	)	:	
network_scanner	=	importlib	.	import_module	(	"str"	)	
network_scanner	.	scan	(	)	
del	network_scanner	

def	about	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
t	=	PrettyTable	(	[	self	.	modadd	.	conf	[	"str"	]	+	"str"	+	self	.	modadd	.	conf	[	"str"	]	,	"str"	]	)	
t	.	add_row	(	[	"str"	,	"str"	]	)	
t	.	align	=	"str"	
t	.	valing	=	"str"	
t	.	border	=	False	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	
t	.	add_row	(	[	"str"	,	self	.	modadd	.	conf	[	"str"	]	]	)	

if	self	.	modadd	.	conf	[	"str"	]	==	True	:	
support	=	"str"	
else	:	
support	=	"str"	
t	.	add_row	(	[	"str"	,	support	]	)	
try	:	
self	.	modadd	.	conf	[	"str"	]	
deps	=	"str"	
i	=	0	
for	dep	in	self	.	modadd	.	conf	[	"str"	]	:	
i	+	=	1	
if	i	==	len	(	self	.	modadd	.	conf	[	"str"	]	)	:	
deps	+	=	dep	
else	:	
deps	+	=	dep	+	"str"	
t	.	add_row	(	[	"str"	,	deps	]	)	
except	KeyError	:	
pass	
print	(	t	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
print	(	info	.	about	)	

def	changelog	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
print	(	self	.	modadd	.	changelog	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
try	:	
f	=	open	(	"str"	,	"str"	)	
file_contents	=	f	.	read	(	)	
print	(	file_contents	)	
f	.	close	(	)	
except	IOError	:	
printError	(	"str"	)	

def	use	(	self	,	args	)	:	
init	=	False	
if	"str"	+	args	[	0	]	not	in	sys	.	modules	:	
init	=	True	

if	self	.	mm	.	moduleLoaded	==	0	:	
try	:	
self	.	modadd	=	importlib	.	import_module	(	"str"	+	args	[	0	]	)	
self	.	mm	.	moduleLoaded	=	1	
self	.	mm	.	setName	(	self	.	modadd	.	conf	[	"str"	]	)	
try	:	
print	(	self	.	modadd	.	conf	[	"str"	]	)	
except	KeyError	:	
pass	
try	:	
if	self	.	modadd	.	conf	[	"str"	]	==	1	:	
printWarning	(	"str"	)	
except	KeyError	:	
pass	
try	:	
if	self	.	modadd	.	conf	[	"str"	]	==	1	:	
if	not	os	.	geteuid	(	)	==	0	:	
printWarning	(	"str"	)	
except	KeyError	:	
pass	
if	init	==	True	:	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
except	ImportError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
raise	ModuleNotFound	(	"str"	)	
except	IndexError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
raise	ModuleNotFound	(	"str"	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
raise	UnknownCommand	(	"str"	)	

def	show	(	self	,	args	)	:	
try	:	
if	args	[	0	]	==	"str"	:	
t	=	PrettyTable	(	[	colors	.	bold	+	"str"	,	"str"	+	colors	.	end	]	)	
t	.	align	=	"str"	
t	.	valing	=	"str"	
t	.	border	=	False	
xml	=	moddbparser	.	parsemoddb	(	)	
root	=	xml	[	0	]	
for	category	in	root	:	
if	category	.	tag	==	"str"	:	
t	.	add_row	(	[	"str"	,	"str"	]	)	
t	.	add_row	(	[	colors	.	red	+	colors	.	uline	+	category	.	attrib	[	"str"	]	+	colors	.	end	,	colors	.	red	+	colors	.	uline	+	"str"	+	colors	.	end	]	)	

for	item	in	category	:	
if	item	.	tag	==	"str"	:	
for	child	in	item	:	
if	child	.	tag	==	"str"	:	
t	.	add_row	(	[	item	.	attrib	[	"str"	]	,	child	.	text	]	)	
break	

print	(	t	)	

elif	args	[	0	]	==	"str"	and	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
moduleop	.	printoptions	(	self	.	modadd	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
raise	UnknownCommand	(	"str"	)	
except	IndexError	:	
raise	UnknownCommand	(	"str"	)	

def	back	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
self	.	mm	.	moduleLoaded	=	0	
self	.	mm	.	moduleName	=	"str"	
else	:	
raise	UnknownCommand	(	"str"	)	

def	reload	(	self	,	args	)	:	
try	:	
if	self	.	mm	.	moduleLoaded	==	0	:	
try	:	
mod	=	"str"	+	args	[	0	]	
if	mod	in	sys	.	modules	:	
value_holder	.	save_values	(	sys	.	modules	[	mod	]	.	variables	)	
importlib	.	reload	(	sys	.	modules	[	mod	]	)	
value_holder	.	set_values	(	sys	.	modules	[	mod	]	.	variables	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	args	[	0	]	+	"str"	+	colors	.	end	)	
else	:	
importlib	.	import_module	(	mod	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	args	[	0	]	+	"str"	+	colors	.	end	)	

except	IndexError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
else	:	
try	:	
mod	=	"str"	+	args	[	0	]	
if	mod	in	sys	.	modules	:	
value_holder	.	save_values	(	sys	.	modules	[	mod	]	.	variables	)	
importlib	.	reload	(	sys	.	modules	[	mod	]	)	
value_holder	.	set_values	(	sys	.	modules	[	mod	]	.	variables	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	args	[	0	]	+	"str"	+	colors	.	end	)	
else	:	
importlib	.	import_module	(	mod	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	self	.	mm	.	moduleName	+	"str"	+	colors	.	end	)	
except	IndexError	:	
mod	=	"str"	+	self	.	mm	.	moduleName	
if	mod	in	sys	.	modules	:	
value_holder	.	save_values	(	sys	.	modules	[	mod	]	.	variables	)	
importlib	.	reload	(	sys	.	modules	[	mod	]	)	
value_holder	.	set_values	(	sys	.	modules	[	mod	]	.	variables	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	self	.	mm	.	moduleName	+	"str"	+	colors	.	end	)	

else	:	
modadd	=	importlib	.	import_module	(	mod	)	
try	:	
self	.	modadd	.	init	(	)	
except	AttributeError	:	
pass	
print	(	colors	.	bold	+	"str"	+	self	.	mm	.	moduleName	+	"str"	+	colors	.	end	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	

def	run	(	self	,	args	)	:	

if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
return	self	.	modadd	.	run	(	)	

except	KeyboardInterrupt	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
except	PermissionError	:	
printError	(	"str"	)	
return	"str"	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
else	:	
raise	UnknownCommand	(	"str"	)	

def	set	(	self	,	args	)	:	
try	:	
self	.	modadd	.	variables	[	args	[	0	]	]	[	0	]	=	args	[	1	]	
print	(	colors	.	bold	+	args	[	0	]	+	"str"	+	str	(	args	[	1	]	)	+	colors	.	end	)	

except	(	NameError	,	KeyError	)	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
raise	VariableError	(	"str"	)	
except	IndexError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
raise	VariableError	(	"str"	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	

def	new	(	self	,	args	)	:	
try	:	
if	args	[	0	]	==	"str"	:	
try	:	
completeName	=	os	.	path	.	join	(	getpath	.	modules	(	)	,	args	[	1	]	+	"str"	)	
if	os	.	path	.	exists	(	completeName	)	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

else	:	
mfile	=	open	(	completeName	,	"str"	)	
template	=	os	.	path	.	join	(	"str"	,	"str"	)	
f	=	open	(	template	,	"str"	)	
template_contents	=	f	.	readlines	(	)	
template_contents	[	5	]	=	"str"	+	args	[	1	]	+	"str"	
template_contents	[	11	]	=	"str"	+	(	time	.	strftime	(	"str"	)	)	+	"str"	
template_contents	[	12	]	=	"str"	+	(	time	.	strftime	(	"str"	)	)	+	"str"	
mfile	.	writelines	(	template_contents	)	
mfile	.	close	(	)	
print	(	colors	.	bold	+	"str"	+	args	[	1	]	+	"str"	+	"str"	+	colors	.	end	)	
print	(	colors	.	bold	+	"str"	+	colors	.	end	)	

except	IndexError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

except	PermissionError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

except	IOError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

else	:	
raise	UnknownCommand	(	"str"	)	
except	IndexError	:	
raise	UnknownCommand	(	"str"	)	

def	check	(	self	,	args	)	:	
try	:	
if	args	[	0	]	==	"str"	:	
try	:	
self	.	modadd	=	importlib	.	import_module	(	"str"	+	args	[	1	]	)	
print	(	colors	.	green	+	"str"	+	colors	.	end	)	
check_module	(	self	.	modadd	)	
print	(	colors	.	green	+	"str"	+	colors	.	end	)	

except	IndexError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

except	ImportError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
else	:	
raise	UnknownCommand	(	"str"	)	
except	IndexError	:	
raise	UnknownCommand	(	"str"	)	

def	matrix	(	self	,	args	)	:	
try	:	
core	.	matrix	.	main	(	)	
except	KeyboardInterrupt	:	
curses	.	endwin	(	)	
curses	.	curs_set	(	1	)	
curses	.	reset_shell_mode	(	)	
curses	.	echo	(	)	

def	cowsay	(	self	,	args	)	:	
try	:	
message	=	"str"	.	join	(	args	)	
print	(	core	.	cowsay	.	cowsay	(	message	)	)	
return	
except	ValueError	:	
print	(	core	.	cowsay	.	cowsay	(	"str"	)	)	

def	ds	(	self	,	args	)	:	
print	(	dsag	.	darkside	)	

def	make	(	self	,	args	)	:	
try	:	
if	args	[	0	]	==	"str"	:	
sys	.	exit	(	0	)	
else	:	
raise	UnknownCommand	(	"str"	)	
except	IndexError	:	
raise	UnknownCommand	(	"str"	)	

def	touchingsky	(	self	,	args	)	:	
core	.	touchingsky	.	main	(	)	

def	update	(	self	,	args	)	:	
if	update	.	check_for_updates	(	)	==	True	:	
try	:	
update	.	update	(	)	
except	PermissionError	:	
printError	(	"str"	)	

except	Exception	as	error	:	
printError	(	str	(	error	)	)	

def	loaded	(	self	,	args	)	:	
print	(	sys	.	modules	.	keys	(	)	)	

def	list	(	self	,	args	)	:	
if	args	[	0	]	==	"str"	:	
if	self	.	mm	.	moduleLoaded	==	0	:	
modules	=	glob	.	glob	(	getpath	.	modules	(	)	+	"str"	)	
dependencies	=	[	]	
for	module	in	modules	:	
try	:	
modadd	=	importlib	.	import_module	(	"str"	+	os	.	path	.	basename	(	module	)	.	replace	(	"str"	,	"str"	)	)	
for	dep	in	modadd	.	conf	[	"str"	]	:	
if	dep	not	in	dependencies	:	
dependencies	.	append	(	dep	)	
except	ImportError	:	
print	(	colors	.	red	+	"str"	+	os	.	path	.	basename	(	module	)	.	replace	(	"str"	,	"str"	)	+	colors	.	end	)	
break	
except	KeyError	:	
pass	
for	dep	in	dependencies	:	
print	(	dep	)	
else	:	
try	:	
for	dep	in	self	.	modadd	.	conf	[	"str"	]	:	
print	(	dep	)	
except	KeyError	:	
printInfo	(	"str"	)	
else	:	
raise	UnknownCommand	(	"str"	)	

def	init	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
self	.	modadd	.	init	(	)	
print	(	"str"	)	
except	AttributeError	:	
print	(	"str"	)	
else	:	
raise	UnknownCommand	(	"str"	)	

def	redb	(	self	,	args	)	:	
if	self	.	mm	.	moduleLoaded	==	1	:	
try	:	
moduleop	.	addtodb	(	self	.	modadd	)	
except	PermissionError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
except	KeyboardInterrupt	:	
print	(	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	

else	:	
answer	=	input	(	"str"	)	
if	answer	==	"str"	or	answer	==	"str"	:	
try	:	
modules	=	glob	.	glob	(	getpath	.	modules	(	)	+	"str"	)	
for	module	in	modules	:	
module	=	module	.	replace	(	getpath	.	modules	(	)	,	"str"	)	.	replace	(	"str"	,	"str"	)	
if	module	!=	"str"	and	module	!=	"str"	:	
modadd	=	importlib	.	import_module	(	"str"	+	module	)	
moduleop	.	addtodb	(	modadd	)	
except	PermissionError	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
except	KeyboardInterrupt	:	
print	(	)	
except	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	file	=	sys	.	stdout	)	
print	(	colors	.	end	)	
if	api	.	enabled	==	True	:	
raise	
	