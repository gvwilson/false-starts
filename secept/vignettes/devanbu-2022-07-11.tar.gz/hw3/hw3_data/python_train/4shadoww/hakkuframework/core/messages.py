import	sys	
from	core	import	colors	

errorstr	=	"str"	+	colors	.	bold	+	colors	.	red	+	"str"	+	colors	.	end	+	"str"	
infostr	=	"str"	+	colors	.	bold	+	colors	.	blue	+	"str"	+	colors	.	end	+	"str"	
warningstr	=	"str"	+	colors	.	bold	+	colors	.	yellow	+	"str"	+	colors	.	end	+	"str"	
successstr	=	"str"	+	colors	.	bold	+	colors	.	green	+	"str"	+	colors	.	end	+	"str"	

def	printError	(	message	,	start	=	"str"	,	end	=	"str"	)	:	
sys	.	stdout	.	write	(	errorstr	+	message	+	end	)	

def	printWarning	(	message	,	start	=	"str"	,	end	=	"str"	)	:	
sys	.	stdout	.	write	(	start	+	warningstr	+	message	+	end	)	

def	printInfo	(	message	,	start	=	"str"	,	end	=	"str"	)	:	
sys	.	stdout	.	write	(	start	+	infostr	+	message	+	end	)	

def	printSuccess	(	message	,	start	=	"str"	,	end	=	"str"	)	:	
sys	.	stdout	.	write	(	start	+	successstr	+	message	+	end	)	
	