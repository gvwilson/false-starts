



import	sys	
import	textwrap	

def	cowsay	(	str	,	length	=	40	)	:	
return	build_bubble	(	str	,	length	)	+	build_cow	(	)	

def	build_cow	(	)	:	
return	"str"	

def	build_bubble	(	str	,	length	=	40	)	:	
bubble	=	[	]	

lines	=	normalize_text	(	str	,	length	)	

bordersize	=	len	(	lines	[	0	]	)	

bubble	.	append	(	"str"	+	"str"	*	bordersize	)	

for	index	,	line	in	enumerate	(	lines	)	:	
border	=	get_border	(	lines	,	index	)	

bubble	.	append	(	"str"	%	(	border	[	0	]	,	line	,	border	[	1	]	)	)	

bubble	.	append	(	"str"	+	"str"	*	bordersize	)	

return	"str"	.	join	(	bubble	)	

def	normalize_text	(	str	,	length	)	:	
lines	=	textwrap	.	wrap	(	str	,	length	)	
maxlen	=	len	(	max	(	lines	,	key	=	len	)	)	
return	[	line	.	ljust	(	maxlen	)	for	line	in	lines	]	

def	get_border	(	lines	,	index	)	:	
if	len	(	lines	)	<	2	:	
return	[	"str"	,	"str"	]	

elif	index	==	0	:	
return	[	"str"	,	"str"	]	

elif	index	==	len	(	lines	)	-	1	:	
return	[	"str"	,	"str"	]	

else	:	
return	[	"str"	,	"str"	]	


print	(	cowsay	(	sys	.	argv	[	1	]	)	)	
	