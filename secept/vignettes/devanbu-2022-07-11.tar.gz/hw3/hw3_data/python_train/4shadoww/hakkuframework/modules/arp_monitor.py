

from	core	.	hakkuframework	import	*	
from	scapy	.	all	import	*	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	1	,	
}	


variables	=	OrderedDict	(	(	

)	)	


option_notes	=	"str"	


changelog	=	"str"	

def	arp_display	(	pkt	)	:	
if	pkt	[	ARP	]	.	op	==	1	:	
return	"str"	+	pkt	[	ARP	]	.	psrc	+	"str"	+	pkt	[	ARP	]	.	pdst	
if	pkt	[	ARP	]	.	op	==	2	:	
return	"str"	+	pkt	[	ARP	]	.	hwsrc	+	"str"	+	pkt	[	ARP	]	.	psrc	


def	run	(	)	:	
printInfo	(	"str"	)	
printInfo	(	"str"	)	
print	(	sniff	(	prn	=	arp_display	,	filter	=	"str"	,	store	=	0	)	)	
printInfo	(	"str"	)	
	