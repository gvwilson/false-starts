
from	__future__	import	unicode_literals	
from	__future__	import	division	
from	__future__	import	absolute_import	
from	future	.	builtins	import	super	

from	future	.	standard_library	.	email	.	_policybase	import	(	Policy	,	Compat32	,	
compat32	,	_extend_docstrings	)	
from	future	.	standard_library	.	email	.	utils	import	_has_surrogates	
from	future	.	standard_library	.	email	.	headerregistry	import	HeaderRegistry	as	HeaderRegistry	

__all__	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	

@_extend_docstrings	
class	EmailPolicy	(	Policy	)	:	



refold_source	=	"str"	
header_factory	=	HeaderRegistry	(	)	

def	__init__	(	self	,	*	*	kw	)	:	


if	"str"	not	in	kw	:	
object	.	__setattr__	(	self	,	"str"	,	HeaderRegistry	(	)	)	
super	(	)	.	__init__	(	*	*	kw	)	

def	header_max_count	(	self	,	name	)	:	

return	self	.	header_factory	[	name	]	.	max_count	











def	header_source_parse	(	self	,	sourcelines	)	:	

name	,	value	=	sourcelines	[	0	]	.	split	(	"str"	,	1	)	
value	=	value	.	lstrip	(	"str"	)	+	"str"	.	join	(	sourcelines	[	1	:	]	)	
return	(	name	,	value	.	rstrip	(	"str"	)	)	

def	header_store_parse	(	self	,	name	,	value	)	:	

if	hasattr	(	value	,	"str"	)	and	value	.	name	.	lower	(	)	==	name	.	lower	(	)	:	
return	(	name	,	value	)	
if	isinstance	(	value	,	str	)	and	len	(	value	.	splitlines	(	)	)	>	1	:	
raise	ValueError	(	"str"	
"str"	)	
return	(	name	,	self	.	header_factory	(	name	,	value	)	)	

def	header_fetch_parse	(	self	,	name	,	value	)	:	

if	hasattr	(	value	,	"str"	)	:	
return	value	
return	self	.	header_factory	(	name	,	"str"	.	join	(	value	.	splitlines	(	)	)	)	

def	fold	(	self	,	name	,	value	)	:	

return	self	.	_fold	(	name	,	value	,	refold_binary	=	True	)	

def	fold_binary	(	self	,	name	,	value	)	:	

folded	=	self	.	_fold	(	name	,	value	,	refold_binary	=	self	.	cte_type	==	"str"	)	
return	folded	.	encode	(	"str"	,	"str"	)	

def	_fold	(	self	,	name	,	value	,	refold_binary	=	False	)	:	
if	hasattr	(	value	,	"str"	)	:	
return	value	.	fold	(	policy	=	self	)	
maxlen	=	self	.	max_line_length	if	self	.	max_line_length	else	float	(	"str"	)	
lines	=	value	.	splitlines	(	)	
refold	=	(	self	.	refold_source	==	"str"	or	
self	.	refold_source	==	"str"	and	
(	lines	and	len	(	lines	[	0	]	)	+	len	(	name	)	+	2	>	maxlen	or	
any	(	len	(	x	)	>	maxlen	for	x	in	lines	[	1	:	]	)	)	)	
if	refold	or	refold_binary	and	_has_surrogates	(	value	)	:	
return	self	.	header_factory	(	name	,	"str"	.	join	(	lines	)	)	.	fold	(	policy	=	self	)	
return	name	+	"str"	+	self	.	linesep	.	join	(	lines	)	+	self	.	linesep	


default	=	EmailPolicy	(	)	

del	default	.	header_factory	
strict	=	default	.	clone	(	raise_on_defect	=	True	)	
SMTP	=	default	.	clone	(	linesep	=	"str"	)	
HTTP	=	default	.	clone	(	linesep	=	"str"	,	max_line_length	=	None	)	
	