
import	os	
import	sys	

def	rchop	(	thestring	,	ending	)	:	
if	thestring	.	endswith	(	ending	)	:	
return	thestring	[	:	-	len	(	ending	)	]	
return	thestring	

def	main	(	)	:	
path	=	rchop	(	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	,	"str"	)	
return	path	

def	main_module	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	sys	.	modules	[	"str"	]	.	__file__	)	)	+	"str"	
return	path	

def	modules	(	)	:	
path	=	rchop	(	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	,	"str"	)	+	"str"	
return	path	

def	core	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	lib	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	tools	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	conf	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	tmp	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	scripts	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	

def	db	(	)	:	
path	=	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	+	"str"	
return	path	
	