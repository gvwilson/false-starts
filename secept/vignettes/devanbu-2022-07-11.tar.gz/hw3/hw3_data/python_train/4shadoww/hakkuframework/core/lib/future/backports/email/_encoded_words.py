
from	__future__	import	unicode_literals	
from	__future__	import	division	
from	__future__	import	absolute_import	
from	future	.	builtins	import	bytes	
from	future	.	builtins	import	chr	
from	future	.	builtins	import	int	
from	future	.	builtins	import	str	



































import	re	
import	base64	
import	binascii	
import	functools	
from	string	import	ascii_letters	,	digits	
from	future	.	backports	.	email	import	errors	

__all__	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	






_q_byte_subber	=	functools	.	partial	(	re	.	compile	(	br	"str"	)	.	sub	,	
lambda	m	:	bytes	(	[	int	(	m	.	group	(	1	)	,	16	)	]	)	)	

def	decode_q	(	encoded	)	:	
encoded	=	bytes	(	encoded	.	replace	(	b	"str"	,	b	"str"	)	)	
return	_q_byte_subber	(	encoded	)	,	[	]	



class	_QByteMap	(	dict	)	:	

safe	=	bytes	(	b	"str"	+	ascii_letters	.	encode	(	"str"	)	+	digits	.	encode	(	"str"	)	)	

def	__missing__	(	self	,	key	)	:	
if	key	in	self	.	safe	:	
self	[	key	]	=	chr	(	key	)	
else	:	
self	[	key	]	=	"str"	.	format	(	key	)	
return	self	[	key	]	

_q_byte_map	=	_QByteMap	(	)	


_q_byte_map	[	ord	(	"str"	)	]	=	"str"	

def	encode_q	(	bstring	)	:	
return	str	(	"str"	.	join	(	_q_byte_map	[	x	]	for	x	in	bytes	(	bstring	)	)	)	

def	len_q	(	bstring	)	:	
return	sum	(	len	(	_q_byte_map	[	x	]	)	for	x	in	bytes	(	bstring	)	)	






def	decode_b	(	encoded	)	:	
defects	=	[	]	
pad_err	=	len	(	encoded	)	%	4	
if	pad_err	:	
defects	.	append	(	errors	.	InvalidBase64PaddingDefect	(	)	)	
padded_encoded	=	encoded	+	b	"str"	[	:	4	-	pad_err	]	
else	:	
padded_encoded	=	encoded	
try	:	

if	not	re	.	match	(	b	"str"	,	padded_encoded	)	:	
raise	binascii	.	Error	(	"str"	)	
return	base64	.	b64decode	(	padded_encoded	)	,	defects	
except	binascii	.	Error	:	

defects	=	[	errors	.	InvalidBase64CharactersDefect	(	)	]	



for	i	in	0	,	1	,	2	,	3	:	
try	:	
return	base64	.	b64decode	(	encoded	+	b	"str"	*	i	)	,	defects	
except	(	binascii	.	Error	,	TypeError	)	:	
if	i	==	0	:	
defects	.	append	(	errors	.	InvalidBase64PaddingDefect	(	)	)	
else	:	

raise	AssertionError	(	"str"	)	

def	encode_b	(	bstring	)	:	
return	base64	.	b64encode	(	bstring	)	.	decode	(	"str"	)	

def	len_b	(	bstring	)	:	
groups_of_3	,	leftover	=	divmod	(	len	(	bstring	)	,	3	)	

return	groups_of_3	*	4	+	(	4	if	leftover	else	0	)	


_cte_decoders	=	{	
"str"	:	decode_q	,	
"str"	:	decode_b	,	
}	

def	decode	(	ew	)	:	

_	,	charset	,	cte	,	cte_string	,	_	=	str	(	ew	)	.	split	(	"str"	)	
charset	,	_	,	lang	=	charset	.	partition	(	"str"	)	
cte	=	cte	.	lower	(	)	

bstring	=	cte_string	.	encode	(	"str"	,	"str"	)	
bstring	,	defects	=	_cte_decoders	[	cte	]	(	bstring	)	

try	:	
string	=	bstring	.	decode	(	charset	)	
except	UnicodeError	:	
defects	.	append	(	errors	.	UndecodableBytesDefect	(	"str"	
"str"	.	format	(	charset	)	)	)	
string	=	bstring	.	decode	(	charset	,	"str"	)	
except	LookupError	:	
string	=	bstring	.	decode	(	"str"	,	"str"	)	
if	charset	.	lower	(	)	!=	"str"	:	
defects	.	append	(	errors	.	CharsetError	(	"str"	
"str"	.	format	(	charset	)	)	)	
return	string	,	charset	,	lang	,	defects	


_cte_encoders	=	{	
"str"	:	encode_q	,	
"str"	:	encode_b	,	
}	

_cte_encode_length	=	{	
"str"	:	len_q	,	
"str"	:	len_b	,	
}	

def	encode	(	string	,	charset	=	"str"	,	encoding	=	None	,	lang	=	"str"	)	:	

string	=	str	(	string	)	
if	charset	==	"str"	:	
bstring	=	string	.	encode	(	"str"	,	"str"	)	
else	:	
bstring	=	string	.	encode	(	charset	)	
if	encoding	is	None	:	
qlen	=	_cte_encode_length	[	"str"	]	(	bstring	)	
blen	=	_cte_encode_length	[	"str"	]	(	bstring	)	

encoding	=	"str"	if	qlen	-	blen	<	5	else	"str"	
encoded	=	_cte_encoders	[	encoding	]	(	bstring	)	
if	lang	:	
lang	=	"str"	+	lang	
return	"str"	.	format	(	charset	,	lang	,	encoding	,	encoded	)	
	