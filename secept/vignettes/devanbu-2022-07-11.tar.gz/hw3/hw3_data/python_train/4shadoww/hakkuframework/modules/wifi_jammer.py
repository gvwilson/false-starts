

from	core	.	hakkuframework	import	*	
import	subprocess	
import	os	
from	core	import	colors	
from	core	import	getpath	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	1	,	
"str"	:	[	"str"	,	"str"	]	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


help_notes	=	colors	.	red	+	"str"	+	colors	.	end	


customcommands	=	{	
"str"	:	"str"	,	
"str"	:	"str"	
}	


changelog	=	"str"	


def	run	(	)	:	
printInfo	(	"str"	+	variables	[	"str"	]	[	0	]	)	
printInfo	(	"str"	+	colors	.	end	)	
xterm_3	=	"str"	+	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	
os	.	system	(	xterm_3	)	
xterm_4	=	"str"	+	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	
os	.	system	(	xterm_4	)	
os	.	system	(	xterm_4	)	
printInfo	(	"str"	)	

def	stop	(	args	)	:	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	.	wait	(	)	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	.	wait	(	)	
xterm_5	=	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	
os	.	system	(	xterm_5	)	
printSuccess	(	"str"	)	

def	scan	(	args	)	:	
xterm_1	=	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	
xterm_2	=	"str"	+	"str"	+	+	variables	[	"str"	]	[	0	]	+	"str"	
subprocess	.	Popen	(	xterm_1	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	.	wait	(	)	
os	.	system	(	xterm_2	)	
printSuccess	(	"str"	)	
	