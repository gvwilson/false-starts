from	core	import	colors	

version	=	"str"	
apiversion	=	"str"	
update_date	=	"str"	
codename	=	"str"	

about	=	(	"str"	+	version	+	"str"	+	codename	+	
"str"	
"str"	
"str"	)	
	