

__title__	=	"str"	
__author__	=	"str"	
__license__	=	"str"	
__copyright__	=	"str"	
__ver_major__	=	0	
__ver_minor__	=	16	
__ver_patch__	=	0	
__ver_sub__	=	"str"	
__version__	=	"str"	%	(	__ver_major__	,	__ver_minor__	,	
__ver_patch__	,	__ver_sub__	)	
	