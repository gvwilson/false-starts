
from	__future__	import	print_function	
from	__future__	import	unicode_literals	
from	__future__	import	division	
from	__future__	import	absolute_import	
from	future	.	builtins	import	int	,	range	,	str	,	super	,	list	

import	re	
from	collections	import	namedtuple	,	OrderedDict	

from	future	.	backports	.	urllib	.	parse	import	(	unquote	,	unquote_to_bytes	)	
from	future	.	backports	.	email	import	_encoded_words	as	_ew	
from	future	.	backports	.	email	import	errors	
from	future	.	backports	.	email	import	utils	





WSP	=	set	(	"str"	)	
CFWS_LEADER	=	WSP	|	set	(	"str"	)	
SPECIALS	=	set	(	"str"	)	
ATOM_ENDS	=	SPECIALS	|	WSP	
DOT_ATOM_ENDS	=	ATOM_ENDS	-	set	(	"str"	)	

PHRASE_ENDS	=	SPECIALS	-	set	(	"str"	)	
TSPECIALS	=	(	SPECIALS	|	set	(	"str"	)	)	-	set	(	"str"	)	
TOKEN_ENDS	=	TSPECIALS	|	WSP	
ASPECIALS	=	TSPECIALS	|	set	(	"str"	)	
ATTRIBUTE_ENDS	=	ASPECIALS	|	WSP	
EXTENDED_ATTRIBUTE_ENDS	=	ATTRIBUTE_ENDS	-	set	(	"str"	)	

def	quote_string	(	value	)	:	
return	"str"	+	str	(	value	)	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	+	"str"	





class	_Folded	(	object	)	:	

def	__init__	(	self	,	maxlen	,	policy	)	:	
self	.	maxlen	=	maxlen	
self	.	policy	=	policy	
self	.	lastlen	=	0	
self	.	stickyspace	=	None	
self	.	firstline	=	True	
self	.	done	=	[	]	
self	.	current	=	list	(	)	

def	newline	(	self	)	:	
self	.	done	.	extend	(	self	.	current	)	
self	.	done	.	append	(	self	.	policy	.	linesep	)	
self	.	current	.	clear	(	)	
self	.	lastlen	=	0	

def	finalize	(	self	)	:	
if	self	.	current	:	
self	.	newline	(	)	

def	__str__	(	self	)	:	
return	"str"	.	join	(	self	.	done	)	

def	append	(	self	,	stoken	)	:	
self	.	current	.	append	(	stoken	)	

def	append_if_fits	(	self	,	token	,	stoken	=	None	)	:	
if	stoken	is	None	:	
stoken	=	str	(	token	)	
l	=	len	(	stoken	)	
if	self	.	stickyspace	is	not	None	:	
stickyspace_len	=	len	(	self	.	stickyspace	)	
if	self	.	lastlen	+	stickyspace_len	+	l	<	=	self	.	maxlen	:	
self	.	current	.	append	(	self	.	stickyspace	)	
self	.	lastlen	+	=	stickyspace_len	
self	.	current	.	append	(	stoken	)	
self	.	lastlen	+	=	l	
self	.	stickyspace	=	None	
self	.	firstline	=	False	
return	True	
if	token	.	has_fws	:	
ws	=	token	.	pop_leading_fws	(	)	
if	ws	is	not	None	:	
self	.	stickyspace	+	=	str	(	ws	)	
stickyspace_len	+	=	len	(	ws	)	
token	.	_fold	(	self	)	
return	True	
if	stickyspace_len	and	l	+	1	<	=	self	.	maxlen	:	
margin	=	self	.	maxlen	-	l	
if	0	<	margin	<	stickyspace_len	:	
trim	=	stickyspace_len	-	margin	
self	.	current	.	append	(	self	.	stickyspace	[	:	trim	]	)	
self	.	stickyspace	=	self	.	stickyspace	[	trim	:	]	
stickyspace_len	=	trim	
self	.	newline	(	)	
self	.	current	.	append	(	self	.	stickyspace	)	
self	.	current	.	append	(	stoken	)	
self	.	lastlen	=	l	+	stickyspace_len	
self	.	stickyspace	=	None	
self	.	firstline	=	False	
return	True	
if	not	self	.	firstline	:	
self	.	newline	(	)	
self	.	current	.	append	(	self	.	stickyspace	)	
self	.	current	.	append	(	stoken	)	
self	.	stickyspace	=	None	
self	.	firstline	=	False	
return	True	
if	self	.	lastlen	+	l	<	=	self	.	maxlen	:	
self	.	current	.	append	(	stoken	)	
self	.	lastlen	+	=	l	
return	True	
if	l	<	self	.	maxlen	:	
self	.	newline	(	)	
self	.	current	.	append	(	stoken	)	
self	.	lastlen	=	l	
return	True	
return	False	





class	TokenList	(	list	)	:	

token_type	=	None	

def	__init__	(	self	,	*	args	,	*	*	kw	)	:	
super	(	TokenList	,	self	)	.	__init__	(	*	args	,	*	*	kw	)	
self	.	defects	=	[	]	

def	__str__	(	self	)	:	
return	"str"	.	join	(	str	(	x	)	for	x	in	self	)	

def	__repr__	(	self	)	:	
return	"str"	.	format	(	self	.	__class__	.	__name__	,	
super	(	TokenList	,	self	)	.	__repr__	(	)	)	

@property	
def	value	(	self	)	:	
return	"str"	.	join	(	x	.	value	for	x	in	self	if	x	.	value	)	

@property	
def	all_defects	(	self	)	:	
return	sum	(	(	x	.	all_defects	for	x	in	self	)	,	self	.	defects	)	








































@property	
def	parts	(	self	)	:	
klass	=	self	.	__class__	
this	=	list	(	)	
for	token	in	self	:	
if	token	.	startswith_fws	(	)	:	
if	this	:	
yield	this	[	0	]	if	len	(	this	)	==	1	else	klass	(	this	)	
this	.	clear	(	)	
end_ws	=	token	.	pop_trailing_ws	(	)	
this	.	append	(	token	)	
if	end_ws	:	
yield	klass	(	this	)	
this	=	[	end_ws	]	
if	this	:	
yield	this	[	0	]	if	len	(	this	)	==	1	else	klass	(	this	)	

def	startswith_fws	(	self	)	:	
return	self	[	0	]	.	startswith_fws	(	)	

def	pop_leading_fws	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	self	.	pop	(	0	)	
return	self	[	0	]	.	pop_leading_fws	(	)	

def	pop_trailing_ws	(	self	)	:	
if	self	[	-	1	]	.	token_type	==	"str"	:	
return	self	.	pop	(	-	1	)	
return	self	[	-	1	]	.	pop_trailing_ws	(	)	

@property	
def	has_fws	(	self	)	:	
for	part	in	self	:	
if	part	.	has_fws	:	
return	True	
return	False	

def	has_leading_comment	(	self	)	:	
return	self	[	0	]	.	has_leading_comment	(	)	

@property	
def	comments	(	self	)	:	
comments	=	[	]	
for	token	in	self	:	
comments	.	extend	(	token	.	comments	)	
return	comments	

def	fold	(	self	,	*	*	_3to2kwargs	)	:	

policy	=	_3to2kwargs	[	"str"	]	;	del	_3to2kwargs	[	"str"	]	
maxlen	=	policy	.	max_line_length	or	float	(	"str"	)	
folded	=	_Folded	(	maxlen	,	policy	)	
self	.	_fold	(	folded	)	
folded	.	finalize	(	)	
return	str	(	folded	)	

def	as_encoded_word	(	self	,	charset	)	:	


res	=	[	]	
ws	=	self	.	pop_leading_fws	(	)	
if	ws	:	
res	.	append	(	ws	)	
trailer	=	self	.	pop	(	-	1	)	if	self	[	-	1	]	.	token_type	==	"str"	else	"str"	
res	.	append	(	_ew	.	encode	(	str	(	self	)	,	charset	)	)	
res	.	append	(	trailer	)	
return	"str"	.	join	(	res	)	

def	cte_encode	(	self	,	charset	,	policy	)	:	
res	=	[	]	
for	part	in	self	:	
res	.	append	(	part	.	cte_encode	(	charset	,	policy	)	)	
return	"str"	.	join	(	res	)	

def	_fold	(	self	,	folded	)	:	
for	part	in	self	.	parts	:	
tstr	=	str	(	part	)	
tlen	=	len	(	tstr	)	
try	:	
str	(	part	)	.	encode	(	"str"	)	
except	UnicodeEncodeError	:	
if	any	(	isinstance	(	x	,	errors	.	UndecodableBytesDefect	)	
for	x	in	part	.	all_defects	)	:	
charset	=	"str"	
else	:	

charset	=	"str"	
tstr	=	part	.	cte_encode	(	charset	,	folded	.	policy	)	
tlen	=	len	(	tstr	)	
if	folded	.	append_if_fits	(	part	,	tstr	)	:	
continue	


ws	=	part	.	pop_leading_fws	(	)	
if	ws	is	not	None	:	


folded	.	stickyspace	=	str	(	part	.	pop	(	0	)	)	
if	folded	.	append_if_fits	(	part	)	:	
continue	
if	part	.	has_fws	:	
part	.	_fold	(	folded	)	
continue	


folded	.	append	(	tstr	)	
folded	.	newline	(	)	

def	pprint	(	self	,	indent	=	"str"	)	:	
print	(	"str"	.	join	(	self	.	_pp	(	indent	=	"str"	)	)	)	

def	ppstr	(	self	,	indent	=	"str"	)	:	
return	"str"	.	join	(	self	.	_pp	(	indent	=	"str"	)	)	

def	_pp	(	self	,	indent	=	"str"	)	:	
yield	"str"	.	format	(	
indent	,	
self	.	__class__	.	__name__	,	
self	.	token_type	)	
for	token	in	self	:	
if	not	hasattr	(	token	,	"str"	)	:	
yield	(	indent	+	"str"	
"str"	.	format	(	token	)	)	
else	:	
for	line	in	token	.	_pp	(	indent	+	"str"	)	:	
yield	line	
if	self	.	defects	:	
extra	=	"str"	.	format	(	self	.	defects	)	
else	:	
extra	=	"str"	
yield	"str"	.	format	(	indent	,	extra	)	


class	WhiteSpaceTokenList	(	TokenList	)	:	

@property	
def	value	(	self	)	:	
return	"str"	

@property	
def	comments	(	self	)	:	
return	[	x	.	content	for	x	in	self	if	x	.	token_type	==	"str"	]	


class	UnstructuredTokenList	(	TokenList	)	:	

token_type	=	"str"	

def	_fold	(	self	,	folded	)	:	
if	any	(	x	.	token_type	==	"str"	for	x	in	self	)	:	
return	self	.	_fold_encoded	(	folded	)	


last_ew	=	None	
for	part	in	self	.	parts	:	
tstr	=	str	(	part	)	
is_ew	=	False	
try	:	
str	(	part	)	.	encode	(	"str"	)	
except	UnicodeEncodeError	:	
if	any	(	isinstance	(	x	,	errors	.	UndecodableBytesDefect	)	
for	x	in	part	.	all_defects	)	:	
charset	=	"str"	
else	:	
charset	=	"str"	
if	last_ew	is	not	None	:	


chunk	=	get_unstructured	(	
"str"	.	join	(	folded	.	current	[	last_ew	:	]	+	[	tstr	]	)	)	.	as_encoded_word	(	charset	)	
oldlastlen	=	sum	(	len	(	x	)	for	x	in	folded	.	current	[	:	last_ew	]	)	
schunk	=	str	(	chunk	)	
lchunk	=	len	(	schunk	)	
if	oldlastlen	+	lchunk	<	=	folded	.	maxlen	:	
del	folded	.	current	[	last_ew	:	]	
folded	.	append	(	schunk	)	
folded	.	lastlen	=	oldlastlen	+	lchunk	
continue	
tstr	=	part	.	as_encoded_word	(	charset	)	
is_ew	=	True	
if	folded	.	append_if_fits	(	part	,	tstr	)	:	
if	is_ew	:	
last_ew	=	len	(	folded	.	current	)	-	1	
continue	
if	is_ew	or	last_ew	:	


part	.	_fold_as_ew	(	folded	)	
continue	


ws	=	part	.	pop_leading_fws	(	)	
if	ws	is	not	None	:	
folded	.	stickyspace	=	str	(	ws	)	
if	folded	.	append_if_fits	(	part	)	:	
continue	
if	part	.	has_fws	:	
part	.	fold	(	folded	)	
continue	

folded	.	append	(	tstr	)	
folded	.	newline	(	)	
last_ew	=	None	

def	cte_encode	(	self	,	charset	,	policy	)	:	
res	=	[	]	
last_ew	=	None	
for	part	in	self	:	
spart	=	str	(	part	)	
try	:	
spart	.	encode	(	"str"	)	
res	.	append	(	spart	)	
except	UnicodeEncodeError	:	
if	last_ew	is	None	:	
res	.	append	(	part	.	cte_encode	(	charset	,	policy	)	)	
last_ew	=	len	(	res	)	
else	:	
tl	=	get_unstructured	(	"str"	.	join	(	res	[	last_ew	:	]	+	[	spart	]	)	)	
res	.	append	(	tl	.	as_encoded_word	(	)	)	
return	"str"	.	join	(	res	)	


class	Phrase	(	TokenList	)	:	

token_type	=	"str"	

def	_fold	(	self	,	folded	)	:	







last_ew	=	None	
for	part	in	self	.	parts	:	
tstr	=	str	(	part	)	
tlen	=	len	(	tstr	)	
has_ew	=	False	
try	:	
str	(	part	)	.	encode	(	"str"	)	
except	UnicodeEncodeError	:	
if	any	(	isinstance	(	x	,	errors	.	UndecodableBytesDefect	)	
for	x	in	part	.	all_defects	)	:	
charset	=	"str"	
else	:	
charset	=	"str"	
if	last_ew	is	not	None	and	not	part	.	has_leading_comment	(	)	:	










if	part	[	-	1	]	.	token_type	==	"str"	and	part	.	comments	:	
remainder	=	part	.	pop	(	-	1	)	
else	:	
remainder	=	"str"	
for	i	,	token	in	enumerate	(	part	)	:	
if	token	.	token_type	==	"str"	:	
part	[	i	]	=	UnstructuredTokenList	(	token	[	:	]	)	
chunk	=	get_unstructured	(	
"str"	.	join	(	folded	.	current	[	last_ew	:	]	+	[	tstr	]	)	)	.	as_encoded_word	(	charset	)	
schunk	=	str	(	chunk	)	
lchunk	=	len	(	schunk	)	
if	last_ew	+	lchunk	<	=	folded	.	maxlen	:	
del	folded	.	current	[	last_ew	:	]	
folded	.	append	(	schunk	)	
folded	.	lastlen	=	sum	(	len	(	x	)	for	x	in	folded	.	current	)	
continue	
tstr	=	part	.	as_encoded_word	(	charset	)	
tlen	=	len	(	tstr	)	
has_ew	=	True	
if	folded	.	append_if_fits	(	part	,	tstr	)	:	
if	has_ew	and	not	part	.	comments	:	
last_ew	=	len	(	folded	.	current	)	-	1	
elif	part	.	comments	or	part	.	token_type	==	"str"	:	



last_ew	=	None	
continue	
part	.	_fold	(	folded	)	

def	cte_encode	(	self	,	charset	,	policy	)	:	
res	=	[	]	
last_ew	=	None	
is_ew	=	False	
for	part	in	self	:	
spart	=	str	(	part	)	
try	:	
spart	.	encode	(	"str"	)	
res	.	append	(	spart	)	
except	UnicodeEncodeError	:	
is_ew	=	True	
if	last_ew	is	None	:	
if	not	part	.	comments	:	
last_ew	=	len	(	res	)	
res	.	append	(	part	.	cte_encode	(	charset	,	policy	)	)	
elif	not	part	.	has_leading_comment	(	)	:	
if	part	[	-	1	]	.	token_type	==	"str"	and	part	.	comments	:	
remainder	=	part	.	pop	(	-	1	)	
else	:	
remainder	=	"str"	
for	i	,	token	in	enumerate	(	part	)	:	
if	token	.	token_type	==	"str"	:	
part	[	i	]	=	UnstructuredTokenList	(	token	[	:	]	)	
tl	=	get_unstructured	(	"str"	.	join	(	res	[	last_ew	:	]	+	[	spart	]	)	)	
res	[	last_ew	:	]	=	[	tl	.	as_encoded_word	(	charset	)	]	
if	part	.	comments	or	(	not	is_ew	and	part	.	token_type	==	"str"	)	:	
last_ew	=	None	
return	"str"	.	join	(	res	)	

class	Word	(	TokenList	)	:	

token_type	=	"str"	


class	CFWSList	(	WhiteSpaceTokenList	)	:	

token_type	=	"str"	

def	has_leading_comment	(	self	)	:	
return	bool	(	self	.	comments	)	


class	Atom	(	TokenList	)	:	

token_type	=	"str"	


class	Token	(	TokenList	)	:	

token_type	=	"str"	


class	EncodedWord	(	TokenList	)	:	

token_type	=	"str"	
cte	=	None	
charset	=	None	
lang	=	None	

@property	
def	encoded	(	self	)	:	
if	self	.	cte	is	not	None	:	
return	self	.	cte	
_ew	.	encode	(	str	(	self	)	,	self	.	charset	)	



class	QuotedString	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	content	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	value	

@property	
def	quoted_value	(	self	)	:	
res	=	[	]	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
res	.	append	(	str	(	x	)	)	
else	:	
res	.	append	(	x	.	value	)	
return	"str"	.	join	(	res	)	

@property	
def	stripped_value	(	self	)	:	
for	token	in	self	:	
if	token	.	token_type	==	"str"	:	
return	token	.	value	


class	BareQuotedString	(	QuotedString	)	:	

token_type	=	"str"	

def	__str__	(	self	)	:	
return	quote_string	(	"str"	.	join	(	str	(	x	)	for	x	in	self	)	)	

@property	
def	value	(	self	)	:	
return	"str"	.	join	(	str	(	x	)	for	x	in	self	)	


class	Comment	(	WhiteSpaceTokenList	)	:	

token_type	=	"str"	

def	__str__	(	self	)	:	
return	"str"	.	join	(	sum	(	[	
[	"str"	]	,	
[	self	.	quote	(	x	)	for	x	in	self	]	,	
[	"str"	]	,	
]	,	[	]	)	)	

def	quote	(	self	,	value	)	:	
if	value	.	token_type	==	"str"	:	
return	str	(	value	)	
return	str	(	value	)	.	replace	(	"str"	,	"str"	)	.	replace	(	
"str"	,	"str"	)	.	replace	(	
"str"	,	"str"	)	

@property	
def	content	(	self	)	:	
return	"str"	.	join	(	str	(	x	)	for	x	in	self	)	

@property	
def	comments	(	self	)	:	
return	[	self	.	content	]	

class	AddressList	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	addresses	(	self	)	:	
return	[	x	for	x	in	self	if	x	.	token_type	==	"str"	]	

@property	
def	mailboxes	(	self	)	:	
return	sum	(	(	x	.	mailboxes	
for	x	in	self	if	x	.	token_type	==	"str"	)	,	[	]	)	

@property	
def	all_mailboxes	(	self	)	:	
return	sum	(	(	x	.	all_mailboxes	
for	x	in	self	if	x	.	token_type	==	"str"	)	,	[	]	)	


class	Address	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	display_name	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	self	[	0	]	.	display_name	

@property	
def	mailboxes	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	[	self	[	0	]	]	
elif	self	[	0	]	.	token_type	==	"str"	:	
return	[	]	
return	self	[	0	]	.	mailboxes	

@property	
def	all_mailboxes	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	[	self	[	0	]	]	
elif	self	[	0	]	.	token_type	==	"str"	:	
return	[	self	[	0	]	]	
return	self	[	0	]	.	all_mailboxes	

class	MailboxList	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	mailboxes	(	self	)	:	
return	[	x	for	x	in	self	if	x	.	token_type	==	"str"	]	

@property	
def	all_mailboxes	(	self	)	:	
return	[	x	for	x	in	self	
if	x	.	token_type	in	(	"str"	,	"str"	)	]	


class	GroupList	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	mailboxes	(	self	)	:	
if	not	self	or	self	[	0	]	.	token_type	!=	"str"	:	
return	[	]	
return	self	[	0	]	.	mailboxes	

@property	
def	all_mailboxes	(	self	)	:	
if	not	self	or	self	[	0	]	.	token_type	!=	"str"	:	
return	[	]	
return	self	[	0	]	.	all_mailboxes	


class	Group	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	mailboxes	(	self	)	:	
if	self	[	2	]	.	token_type	!=	"str"	:	
return	[	]	
return	self	[	2	]	.	mailboxes	

@property	
def	all_mailboxes	(	self	)	:	
if	self	[	2	]	.	token_type	!=	"str"	:	
return	[	]	
return	self	[	2	]	.	all_mailboxes	

@property	
def	display_name	(	self	)	:	
return	self	[	0	]	.	display_name	


class	NameAddr	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	display_name	(	self	)	:	
if	len	(	self	)	==	1	:	
return	None	
return	self	[	0	]	.	display_name	

@property	
def	local_part	(	self	)	:	
return	self	[	-	1	]	.	local_part	

@property	
def	domain	(	self	)	:	
return	self	[	-	1	]	.	domain	

@property	
def	route	(	self	)	:	
return	self	[	-	1	]	.	route	

@property	
def	addr_spec	(	self	)	:	
return	self	[	-	1	]	.	addr_spec	


class	AngleAddr	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	local_part	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	local_part	

@property	
def	domain	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	domain	

@property	
def	route	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	domains	

@property	
def	addr_spec	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	addr_spec	
else	:	
return	"str"	


class	ObsRoute	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	domains	(	self	)	:	
return	[	x	.	domain	for	x	in	self	if	x	.	token_type	==	"str"	]	


class	Mailbox	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	display_name	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	self	[	0	]	.	display_name	

@property	
def	local_part	(	self	)	:	
return	self	[	0	]	.	local_part	

@property	
def	domain	(	self	)	:	
return	self	[	0	]	.	domain	

@property	
def	route	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	self	[	0	]	.	route	

@property	
def	addr_spec	(	self	)	:	
return	self	[	0	]	.	addr_spec	


class	InvalidMailbox	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	display_name	(	self	)	:	
return	None	

local_part	=	domain	=	route	=	addr_spec	=	display_name	


class	Domain	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	domain	(	self	)	:	
return	"str"	.	join	(	super	(	Domain	,	self	)	.	value	.	split	(	)	)	


class	DotAtom	(	TokenList	)	:	

token_type	=	"str"	


class	DotAtomText	(	TokenList	)	:	

token_type	=	"str"	


class	AddrSpec	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	local_part	(	self	)	:	
return	self	[	0	]	.	local_part	

@property	
def	domain	(	self	)	:	
if	len	(	self	)	<	3	:	
return	None	
return	self	[	-	1	]	.	domain	

@property	
def	value	(	self	)	:	
if	len	(	self	)	<	3	:	
return	self	[	0	]	.	value	
return	self	[	0	]	.	value	.	rstrip	(	)	+	self	[	1	]	.	value	+	self	[	2	]	.	value	.	lstrip	(	)	

@property	
def	addr_spec	(	self	)	:	
nameset	=	set	(	self	.	local_part	)	
if	len	(	nameset	)	>	len	(	nameset	-	DOT_ATOM_ENDS	)	:	
lp	=	quote_string	(	self	.	local_part	)	
else	:	
lp	=	self	.	local_part	
if	self	.	domain	is	not	None	:	
return	lp	+	"str"	+	self	.	domain	
return	lp	


class	ObsLocalPart	(	TokenList	)	:	

token_type	=	"str"	


class	DisplayName	(	Phrase	)	:	

token_type	=	"str"	

@property	
def	display_name	(	self	)	:	
res	=	TokenList	(	self	)	
if	res	[	0	]	.	token_type	==	"str"	:	
res	.	pop	(	0	)	
else	:	
if	res	[	0	]	[	0	]	.	token_type	==	"str"	:	
res	[	0	]	=	TokenList	(	res	[	0	]	[	1	:	]	)	
if	res	[	-	1	]	.	token_type	==	"str"	:	
res	.	pop	(	)	
else	:	
if	res	[	-	1	]	[	-	1	]	.	token_type	==	"str"	:	
res	[	-	1	]	=	TokenList	(	res	[	-	1	]	[	:	-	1	]	)	
return	res	.	value	

@property	
def	value	(	self	)	:	
quote	=	False	
if	self	.	defects	:	
quote	=	True	
else	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
quote	=	True	
if	quote	:	
pre	=	post	=	"str"	
if	self	[	0	]	.	token_type	==	"str"	or	self	[	0	]	[	0	]	.	token_type	==	"str"	:	
pre	=	"str"	
if	self	[	-	1	]	.	token_type	==	"str"	or	self	[	-	1	]	[	-	1	]	.	token_type	==	"str"	:	
post	=	"str"	
return	pre	+	quote_string	(	self	.	display_name	)	+	post	
else	:	
return	super	(	DisplayName	,	self	)	.	value	


class	LocalPart	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	value	(	self	)	:	
if	self	[	0	]	.	token_type	==	"str"	:	
return	self	[	0	]	.	quoted_value	
else	:	
return	self	[	0	]	.	value	

@property	
def	local_part	(	self	)	:	

res	=	[	DOT	]	
last	=	DOT	
last_is_tl	=	False	
for	tok	in	self	[	0	]	+	[	DOT	]	:	
if	tok	.	token_type	==	"str"	:	
continue	
if	(	last_is_tl	and	tok	.	token_type	==	"str"	and	
last	[	-	1	]	.	token_type	==	"str"	)	:	
res	[	-	1	]	=	TokenList	(	last	[	:	-	1	]	)	
is_tl	=	isinstance	(	tok	,	TokenList	)	
if	(	is_tl	and	last	.	token_type	==	"str"	and	
tok	[	0	]	.	token_type	==	"str"	)	:	
res	.	append	(	TokenList	(	tok	[	1	:	]	)	)	
else	:	
res	.	append	(	tok	)	
last	=	res	[	-	1	]	
last_is_tl	=	is_tl	
res	=	TokenList	(	res	[	1	:	-	1	]	)	
return	res	.	value	


class	DomainLiteral	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	domain	(	self	)	:	
return	"str"	.	join	(	super	(	DomainLiteral	,	self	)	.	value	.	split	(	)	)	

@property	
def	ip	(	self	)	:	
for	x	in	self	:	
if	x	.	token_type	==	"str"	:	
return	x	.	value	


class	MIMEVersion	(	TokenList	)	:	

token_type	=	"str"	
major	=	None	
minor	=	None	


class	Parameter	(	TokenList	)	:	

token_type	=	"str"	
sectioned	=	False	
extended	=	False	
charset	=	"str"	

@property	
def	section_number	(	self	)	:	


return	self	[	1	]	.	number	if	self	.	sectioned	else	0	

@property	
def	param_value	(	self	)	:	

for	token	in	self	:	
if	token	.	token_type	==	"str"	:	
return	token	.	stripped_value	
if	token	.	token_type	==	"str"	:	
for	token	in	token	:	
if	token	.	token_type	==	"str"	:	
for	token	in	token	:	
if	token	.	token_type	==	"str"	:	
return	token	.	stripped_value	
return	"str"	


class	InvalidParameter	(	Parameter	)	:	

token_type	=	"str"	


class	Attribute	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	stripped_value	(	self	)	:	
for	token	in	self	:	
if	token	.	token_type	.	endswith	(	"str"	)	:	
return	token	.	value	

class	Section	(	TokenList	)	:	

token_type	=	"str"	
number	=	None	


class	Value	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	stripped_value	(	self	)	:	
token	=	self	[	0	]	
if	token	.	token_type	==	"str"	:	
token	=	self	[	1	]	
if	token	.	token_type	.	endswith	(	
(	"str"	,	"str"	,	"str"	)	)	:	
return	token	.	stripped_value	
return	self	.	value	


class	MimeParameters	(	TokenList	)	:	

token_type	=	"str"	

@property	
def	params	(	self	)	:	





params	=	OrderedDict	(	)	
for	token	in	self	:	
if	not	token	.	token_type	.	endswith	(	"str"	)	:	
continue	
if	token	[	0	]	.	token_type	!=	"str"	:	
continue	
name	=	token	[	0	]	.	value	.	strip	(	)	
if	name	not	in	params	:	
params	[	name	]	=	[	]	
params	[	name	]	.	append	(	(	token	.	section_number	,	token	)	)	
for	name	,	parts	in	params	.	items	(	)	:	
parts	=	sorted	(	parts	)	


value_parts	=	[	]	
charset	=	parts	[	0	]	[	1	]	.	charset	
for	i	,	(	section_number	,	param	)	in	enumerate	(	parts	)	:	
if	section_number	!=	i	:	
param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
value	=	param	.	param_value	
if	param	.	extended	:	
try	:	
value	=	unquote_to_bytes	(	value	)	
except	UnicodeEncodeError	:	



value	=	unquote	(	value	,	encoding	=	"str"	)	
else	:	
try	:	
value	=	value	.	decode	(	charset	,	"str"	)	
except	LookupError	:	




value	=	value	.	decode	(	"str"	,	"str"	)	
if	utils	.	_has_surrogates	(	value	)	:	
param	.	defects	.	append	(	errors	.	UndecodableBytesDefect	(	)	)	
value_parts	.	append	(	value	)	
value	=	"str"	.	join	(	value_parts	)	
yield	name	,	value	

def	__str__	(	self	)	:	
params	=	[	]	
for	name	,	value	in	self	.	params	:	
if	value	:	
params	.	append	(	"str"	.	format	(	name	,	quote_string	(	value	)	)	)	
else	:	
params	.	append	(	name	)	
params	=	"str"	.	join	(	params	)	
return	"str"	+	params	if	params	else	"str"	


class	ParameterizedHeaderValue	(	TokenList	)	:	

@property	
def	params	(	self	)	:	
for	token	in	reversed	(	self	)	:	
if	token	.	token_type	==	"str"	:	
return	token	.	params	
return	{	}	

@property	
def	parts	(	self	)	:	
if	self	and	self	[	-	1	]	.	token_type	==	"str"	:	


return	TokenList	(	self	[	:	-	1	]	+	self	[	-	1	]	)	
return	TokenList	(	self	)	.	parts	


class	ContentType	(	ParameterizedHeaderValue	)	:	

token_type	=	"str"	
maintype	=	"str"	
subtype	=	"str"	


class	ContentDisposition	(	ParameterizedHeaderValue	)	:	

token_type	=	"str"	
content_disposition	=	None	


class	ContentTransferEncoding	(	TokenList	)	:	

token_type	=	"str"	
cte	=	"str"	


class	HeaderLabel	(	TokenList	)	:	

token_type	=	"str"	


class	Header	(	TokenList	)	:	

token_type	=	"str"	

def	_fold	(	self	,	folded	)	:	
folded	.	append	(	str	(	self	.	pop	(	0	)	)	)	
folded	.	lastlen	=	len	(	folded	.	current	[	0	]	)	







folded	.	stickyspace	=	str	(	self	.	pop	(	0	)	)	if	self	[	0	]	.	token_type	==	"str"	else	"str"	
rest	=	self	.	pop	(	0	)	
if	self	:	
raise	ValueError	(	"str"	)	
rest	.	_fold	(	folded	)	






class	Terminal	(	str	)	:	

def	__new__	(	cls	,	value	,	token_type	)	:	
self	=	super	(	Terminal	,	cls	)	.	__new__	(	cls	,	value	)	
self	.	token_type	=	token_type	
self	.	defects	=	[	]	
return	self	

def	__repr__	(	self	)	:	
return	"str"	.	format	(	self	.	__class__	.	__name__	,	super	(	Terminal	,	self	)	.	__repr__	(	)	)	

@property	
def	all_defects	(	self	)	:	
return	list	(	self	.	defects	)	

def	_pp	(	self	,	indent	=	"str"	)	:	
return	[	"str"	.	format	(	
indent	,	
self	.	__class__	.	__name__	,	
self	.	token_type	,	
super	(	Terminal	,	self	)	.	__repr__	(	)	,	
"str"	if	not	self	.	defects	else	"str"	.	format	(	self	.	defects	)	,	
)	]	

def	cte_encode	(	self	,	charset	,	policy	)	:	
value	=	str	(	self	)	
try	:	
value	.	encode	(	"str"	)	
return	value	
except	UnicodeEncodeError	:	
return	_ew	.	encode	(	value	,	charset	)	

def	pop_trailing_ws	(	self	)	:	

return	None	

def	pop_leading_fws	(	self	)	:	

return	None	

@property	
def	comments	(	self	)	:	
return	[	]	

def	has_leading_comment	(	self	)	:	
return	False	

def	__getnewargs__	(	self	)	:	
return	(	str	(	self	)	,	self	.	token_type	)	


class	WhiteSpaceTerminal	(	Terminal	)	:	

@property	
def	value	(	self	)	:	
return	"str"	

def	startswith_fws	(	self	)	:	
return	True	

has_fws	=	True	


class	ValueTerminal	(	Terminal	)	:	

@property	
def	value	(	self	)	:	
return	self	

def	startswith_fws	(	self	)	:	
return	False	

has_fws	=	False	

def	as_encoded_word	(	self	,	charset	)	:	
return	_ew	.	encode	(	str	(	self	)	,	charset	)	


class	EWWhiteSpaceTerminal	(	WhiteSpaceTerminal	)	:	

@property	
def	value	(	self	)	:	
return	"str"	

@property	
def	encoded	(	self	)	:	
return	self	[	:	]	

def	__str__	(	self	)	:	
return	"str"	

has_fws	=	True	





DOT	=	ValueTerminal	(	"str"	,	"str"	)	
ListSeparator	=	ValueTerminal	(	"str"	,	"str"	)	
RouteComponentMarker	=	ValueTerminal	(	"str"	,	"str"	)	







_wsp_splitter	=	re	.	compile	(	"str"	.	format	(	"str"	.	join	(	WSP	)	)	)	.	split	
_non_atom_end_matcher	=	re	.	compile	(	"str"	.	format	(	
"str"	.	join	(	ATOM_ENDS	)	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	)	)	.	match	
_non_printable_finder	=	re	.	compile	(	"str"	)	.	findall	
_non_token_end_matcher	=	re	.	compile	(	"str"	.	format	(	
"str"	.	join	(	TOKEN_ENDS	)	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	)	)	.	match	
_non_attribute_end_matcher	=	re	.	compile	(	"str"	.	format	(	
"str"	.	join	(	ATTRIBUTE_ENDS	)	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	)	)	.	match	
_non_extended_attribute_end_matcher	=	re	.	compile	(	"str"	.	format	(	
"str"	.	join	(	EXTENDED_ATTRIBUTE_ENDS	)	.	replace	(	
"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	)	)	.	match	

def	_validate_xtext	(	xtext	)	:	


non_printables	=	_non_printable_finder	(	xtext	)	
if	non_printables	:	
xtext	.	defects	.	append	(	errors	.	NonPrintableDefect	(	non_printables	)	)	
if	utils	.	_has_surrogates	(	xtext	)	:	
xtext	.	defects	.	append	(	errors	.	UndecodableBytesDefect	(	
"str"	)	)	

def	_get_ptext_to_endchars	(	value	,	endchars	)	:	

_3to2list	=	list	(	_wsp_splitter	(	value	,	1	)	)	
fragment	,	remainder	,	=	_3to2list	[	:	1	]	+	[	_3to2list	[	1	:	]	]	
vchars	=	[	]	
escape	=	False	
had_qp	=	False	
for	pos	in	range	(	len	(	fragment	)	)	:	
if	fragment	[	pos	]	==	"str"	:	
if	escape	:	
escape	=	False	
had_qp	=	True	
else	:	
escape	=	True	
continue	
if	escape	:	
escape	=	False	
elif	fragment	[	pos	]	in	endchars	:	
break	
vchars	.	append	(	fragment	[	pos	]	)	
else	:	
pos	=	pos	+	1	
return	"str"	.	join	(	vchars	)	,	"str"	.	join	(	[	fragment	[	pos	:	]	]	+	remainder	)	,	had_qp	

def	_decode_ew_run	(	value	)	:	

res	=	[	]	
defects	=	[	]	
last_ws	=	"str"	
while	value	:	
try	:	
tok	,	ws	,	value	=	_wsp_splitter	(	value	,	1	)	
except	ValueError	:	
tok	,	ws	,	value	=	value	,	"str"	,	"str"	
if	not	(	tok	.	startswith	(	"str"	)	and	tok	.	endswith	(	"str"	)	)	:	
return	"str"	.	join	(	res	)	,	last_ws	+	tok	+	ws	+	value	,	defects	
text	,	charset	,	lang	,	new_defects	=	_ew	.	decode	(	tok	)	
res	.	append	(	text	)	
defects	.	extend	(	new_defects	)	
last_ws	=	ws	
return	"str"	.	join	(	res	)	,	last_ws	,	defects	

def	get_fws	(	value	)	:	

newvalue	=	value	.	lstrip	(	)	
fws	=	WhiteSpaceTerminal	(	value	[	:	len	(	value	)	-	len	(	newvalue	)	]	,	"str"	)	
return	fws	,	newvalue	

def	get_encoded_word	(	value	)	:	

ew	=	EncodedWord	(	)	
if	not	value	.	startswith	(	"str"	)	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
_3to2list1	=	list	(	value	[	2	:	]	.	split	(	"str"	,	1	)	)	
tok	,	remainder	,	=	_3to2list1	[	:	1	]	+	[	_3to2list1	[	1	:	]	]	
if	tok	==	value	[	2	:	]	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
remstr	=	"str"	.	join	(	remainder	)	
if	remstr	[	:	2	]	.	isdigit	(	)	:	
_3to2list3	=	list	(	remstr	.	split	(	"str"	,	1	)	)	
rest	,	remainder	,	=	_3to2list3	[	:	1	]	+	[	_3to2list3	[	1	:	]	]	
tok	=	tok	+	"str"	+	rest	
if	len	(	tok	.	split	(	)	)	>	1	:	
ew	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
ew	.	cte	=	value	
value	=	"str"	.	join	(	remainder	)	
try	:	
text	,	charset	,	lang	,	defects	=	_ew	.	decode	(	"str"	+	tok	+	"str"	)	
except	ValueError	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	ew	.	cte	)	)	
ew	.	charset	=	charset	
ew	.	lang	=	lang	
ew	.	defects	.	extend	(	defects	)	
while	text	:	
if	text	[	0	]	in	WSP	:	
token	,	text	=	get_fws	(	text	)	
ew	.	append	(	token	)	
continue	
_3to2list5	=	list	(	_wsp_splitter	(	text	,	1	)	)	
chars	,	remainder	,	=	_3to2list5	[	:	1	]	+	[	_3to2list5	[	1	:	]	]	
vtext	=	ValueTerminal	(	chars	,	"str"	)	
_validate_xtext	(	vtext	)	
ew	.	append	(	vtext	)	
text	=	"str"	.	join	(	remainder	)	
return	ew	,	value	

def	get_unstructured	(	value	)	:	





unstructured	=	UnstructuredTokenList	(	)	
while	value	:	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
unstructured	.	append	(	token	)	
continue	
if	value	.	startswith	(	"str"	)	:	
try	:	
token	,	value	=	get_encoded_word	(	value	)	
except	errors	.	HeaderParseError	:	
pass	
else	:	
have_ws	=	True	
if	len	(	unstructured	)	>	0	:	
if	unstructured	[	-	1	]	.	token_type	!=	"str"	:	
unstructured	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
have_ws	=	False	
if	have_ws	and	len	(	unstructured	)	>	1	:	
if	unstructured	[	-	2	]	.	token_type	==	"str"	:	
unstructured	[	-	1	]	=	EWWhiteSpaceTerminal	(	
unstructured	[	-	1	]	,	"str"	)	
unstructured	.	append	(	token	)	
continue	
_3to2list7	=	list	(	_wsp_splitter	(	value	,	1	)	)	
tok	,	remainder	,	=	_3to2list7	[	:	1	]	+	[	_3to2list7	[	1	:	]	]	
vtext	=	ValueTerminal	(	tok	,	"str"	)	
_validate_xtext	(	vtext	)	
unstructured	.	append	(	vtext	)	
value	=	"str"	.	join	(	remainder	)	
return	unstructured	

def	get_qp_ctext	(	value	)	:	

ptext	,	value	,	_	=	_get_ptext_to_endchars	(	value	,	"str"	)	
ptext	=	WhiteSpaceTerminal	(	ptext	,	"str"	)	
_validate_xtext	(	ptext	)	
return	ptext	,	value	

def	get_qcontent	(	value	)	:	

ptext	,	value	,	_	=	_get_ptext_to_endchars	(	value	,	"str"	)	
ptext	=	ValueTerminal	(	ptext	,	"str"	)	
_validate_xtext	(	ptext	)	
return	ptext	,	value	

def	get_atext	(	value	)	:	

m	=	_non_atom_end_matcher	(	value	)	
if	not	m	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
atext	=	m	.	group	(	)	
value	=	value	[	len	(	atext	)	:	]	
atext	=	ValueTerminal	(	atext	,	"str"	)	
_validate_xtext	(	atext	)	
return	atext	,	value	

def	get_bare_quoted_string	(	value	)	:	

if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
bare_quoted_string	=	BareQuotedString	(	)	
value	=	value	[	1	:	]	
while	value	and	value	[	0	]	!=	"str"	:	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
else	:	
token	,	value	=	get_qcontent	(	value	)	
bare_quoted_string	.	append	(	token	)	
if	not	value	:	
bare_quoted_string	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
return	bare_quoted_string	,	value	
return	bare_quoted_string	,	value	[	1	:	]	

def	get_comment	(	value	)	:	

if	value	and	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
comment	=	Comment	(	)	
value	=	value	[	1	:	]	
while	value	and	value	[	0	]	!=	"str"	:	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
elif	value	[	0	]	==	"str"	:	
token	,	value	=	get_comment	(	value	)	
else	:	
token	,	value	=	get_qp_ctext	(	value	)	
comment	.	append	(	token	)	
if	not	value	:	
comment	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
return	comment	,	value	
return	comment	,	value	[	1	:	]	

def	get_cfws	(	value	)	:	

cfws	=	CFWSList	(	)	
while	value	and	value	[	0	]	in	CFWS_LEADER	:	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
else	:	
token	,	value	=	get_comment	(	value	)	
cfws	.	append	(	token	)	
return	cfws	,	value	

def	get_quoted_string	(	value	)	:	

quoted_string	=	QuotedString	(	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
quoted_string	.	append	(	token	)	
token	,	value	=	get_bare_quoted_string	(	value	)	
quoted_string	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
quoted_string	.	append	(	token	)	
return	quoted_string	,	value	

def	get_atom	(	value	)	:	

atom	=	Atom	(	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
atom	.	append	(	token	)	
if	value	and	value	[	0	]	in	ATOM_ENDS	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
token	,	value	=	get_atext	(	value	)	
atom	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
atom	.	append	(	token	)	
return	atom	,	value	

def	get_dot_atom_text	(	value	)	:	

dot_atom_text	=	DotAtomText	(	)	
if	not	value	or	value	[	0	]	in	ATOM_ENDS	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
while	value	and	value	[	0	]	not	in	ATOM_ENDS	:	
token	,	value	=	get_atext	(	value	)	
dot_atom_text	.	append	(	token	)	
if	value	and	value	[	0	]	==	"str"	:	
dot_atom_text	.	append	(	DOT	)	
value	=	value	[	1	:	]	
if	dot_atom_text	[	-	1	]	is	DOT	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	"str"	+	value	)	)	
return	dot_atom_text	,	value	

def	get_dot_atom	(	value	)	:	

dot_atom	=	DotAtom	(	)	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
dot_atom	.	append	(	token	)	
token	,	value	=	get_dot_atom_text	(	value	)	
dot_atom	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
dot_atom	.	append	(	token	)	
return	dot_atom	,	value	

def	get_word	(	value	)	:	

if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
else	:	
leader	=	None	
if	value	[	0	]	==	"str"	:	
token	,	value	=	get_quoted_string	(	value	)	
elif	value	[	0	]	in	SPECIALS	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
else	:	
token	,	value	=	get_atom	(	value	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
return	token	,	value	

def	get_phrase	(	value	)	:	

phrase	=	Phrase	(	)	
try	:	
token	,	value	=	get_word	(	value	)	
phrase	.	append	(	token	)	
except	errors	.	HeaderParseError	:	
phrase	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
while	value	and	value	[	0	]	not	in	PHRASE_ENDS	:	
if	value	[	0	]	==	"str"	:	
phrase	.	append	(	DOT	)	
phrase	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
value	=	value	[	1	:	]	
else	:	
try	:	
token	,	value	=	get_word	(	value	)	
except	errors	.	HeaderParseError	:	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
phrase	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
else	:	
raise	
phrase	.	append	(	token	)	
return	phrase	,	value	

def	get_local_part	(	value	)	:	

local_part	=	LocalPart	(	)	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
try	:	
token	,	value	=	get_dot_atom	(	value	)	
except	errors	.	HeaderParseError	:	
try	:	
token	,	value	=	get_word	(	value	)	
except	errors	.	HeaderParseError	:	
if	value	[	0	]	!=	"str"	and	value	[	0	]	in	PHRASE_ENDS	:	
raise	
token	=	TokenList	(	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
local_part	.	append	(	token	)	
if	value	and	(	value	[	0	]	==	"str"	or	value	[	0	]	not	in	PHRASE_ENDS	)	:	
obs_local_part	,	value	=	get_obs_local_part	(	str	(	local_part	)	+	value	)	
if	obs_local_part	.	token_type	==	"str"	:	
local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
else	:	
local_part	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
local_part	[	0	]	=	obs_local_part	
try	:	
local_part	.	value	.	encode	(	"str"	)	
except	UnicodeEncodeError	:	
local_part	.	defects	.	append	(	errors	.	NonASCIILocalPartDefect	(	
"str"	)	)	
return	local_part	,	value	

def	get_obs_local_part	(	value	)	:	

obs_local_part	=	ObsLocalPart	(	)	
last_non_ws_was_dot	=	False	
while	value	and	(	value	[	0	]	==	"str"	or	value	[	0	]	not	in	PHRASE_ENDS	)	:	
if	value	[	0	]	==	"str"	:	
if	last_non_ws_was_dot	:	
obs_local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
obs_local_part	.	append	(	DOT	)	
last_non_ws_was_dot	=	True	
value	=	value	[	1	:	]	
continue	
elif	value	[	0	]	==	"str"	:	
obs_local_part	.	append	(	ValueTerminal	(	value	[	0	]	,	
"str"	)	)	
value	=	value	[	1	:	]	
obs_local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
last_non_ws_was_dot	=	False	
continue	
if	obs_local_part	and	obs_local_part	[	-	1	]	.	token_type	!=	"str"	:	
obs_local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
try	:	
token	,	value	=	get_word	(	value	)	
last_non_ws_was_dot	=	False	
except	errors	.	HeaderParseError	:	
if	value	[	0	]	not	in	CFWS_LEADER	:	
raise	
token	,	value	=	get_cfws	(	value	)	
obs_local_part	.	append	(	token	)	
if	(	obs_local_part	[	0	]	.	token_type	==	"str"	or	
obs_local_part	[	0	]	.	token_type	==	"str"	and	
obs_local_part	[	1	]	.	token_type	==	"str"	)	:	
obs_local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	(	obs_local_part	[	-	1	]	.	token_type	==	"str"	or	
obs_local_part	[	-	1	]	.	token_type	==	"str"	and	
obs_local_part	[	-	2	]	.	token_type	==	"str"	)	:	
obs_local_part	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	obs_local_part	.	defects	:	
obs_local_part	.	token_type	=	"str"	
return	obs_local_part	,	value	

def	get_dtext	(	value	)	:	

ptext	,	value	,	had_qp	=	_get_ptext_to_endchars	(	value	,	"str"	)	
ptext	=	ValueTerminal	(	ptext	,	"str"	)	
if	had_qp	:	
ptext	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
_validate_xtext	(	ptext	)	
return	ptext	,	value	

def	_check_for_early_dl_end	(	value	,	domain_literal	)	:	
if	value	:	
return	False	
domain_literal	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
domain_literal	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
return	True	

def	get_domain_literal	(	value	)	:	

domain_literal	=	DomainLiteral	(	)	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
domain_literal	.	append	(	token	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	"str"	)	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
value	=	value	[	1	:	]	
if	_check_for_early_dl_end	(	value	,	domain_literal	)	:	
return	domain_literal	,	value	
domain_literal	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
domain_literal	.	append	(	token	)	
token	,	value	=	get_dtext	(	value	)	
domain_literal	.	append	(	token	)	
if	_check_for_early_dl_end	(	value	,	domain_literal	)	:	
return	domain_literal	,	value	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
domain_literal	.	append	(	token	)	
if	_check_for_early_dl_end	(	value	,	domain_literal	)	:	
return	domain_literal	,	value	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
domain_literal	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
domain_literal	.	append	(	token	)	
return	domain_literal	,	value	

def	get_domain	(	value	)	:	

domain	=	Domain	(	)	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
if	value	[	0	]	==	"str"	:	
token	,	value	=	get_domain_literal	(	value	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
domain	.	append	(	token	)	
return	domain	,	value	
try	:	
token	,	value	=	get_dot_atom	(	value	)	
except	errors	.	HeaderParseError	:	
token	,	value	=	get_atom	(	value	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
domain	.	append	(	token	)	
if	value	and	value	[	0	]	==	"str"	:	
domain	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
if	domain	[	0	]	.	token_type	==	"str"	:	
domain	[	:	]	=	domain	[	0	]	
while	value	and	value	[	0	]	==	"str"	:	
domain	.	append	(	DOT	)	
token	,	value	=	get_atom	(	value	[	1	:	]	)	
domain	.	append	(	token	)	
return	domain	,	value	

def	get_addr_spec	(	value	)	:	

addr_spec	=	AddrSpec	(	)	
token	,	value	=	get_local_part	(	value	)	
addr_spec	.	append	(	token	)	
if	not	value	or	value	[	0	]	!=	"str"	:	
addr_spec	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
return	addr_spec	,	value	
addr_spec	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
token	,	value	=	get_domain	(	value	[	1	:	]	)	
addr_spec	.	append	(	token	)	
return	addr_spec	,	value	

def	get_obs_route	(	value	)	:	

obs_route	=	ObsRoute	(	)	
while	value	and	(	value	[	0	]	==	"str"	or	value	[	0	]	in	CFWS_LEADER	)	:	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
obs_route	.	append	(	token	)	
elif	value	[	0	]	==	"str"	:	
obs_route	.	append	(	ListSeparator	)	
value	=	value	[	1	:	]	
if	not	value	or	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
obs_route	.	append	(	RouteComponentMarker	)	
token	,	value	=	get_domain	(	value	[	1	:	]	)	
obs_route	.	append	(	token	)	
while	value	and	value	[	0	]	==	"str"	:	
obs_route	.	append	(	ListSeparator	)	
value	=	value	[	1	:	]	
if	not	value	:	
break	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
obs_route	.	append	(	token	)	
if	value	[	0	]	==	"str"	:	
obs_route	.	append	(	RouteComponentMarker	)	
token	,	value	=	get_domain	(	value	[	1	:	]	)	
obs_route	.	append	(	token	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	"str"	)	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
obs_route	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
return	obs_route	,	value	[	1	:	]	

def	get_angle_addr	(	value	)	:	

angle_addr	=	AngleAddr	(	)	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
angle_addr	.	append	(	token	)	
if	not	value	or	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
angle_addr	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	


if	value	[	0	]	==	"str"	:	
angle_addr	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
angle_addr	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
value	=	value	[	1	:	]	
return	angle_addr	,	value	
try	:	
token	,	value	=	get_addr_spec	(	value	)	
except	errors	.	HeaderParseError	:	
try	:	
token	,	value	=	get_obs_route	(	value	)	
angle_addr	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
except	errors	.	HeaderParseError	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
angle_addr	.	append	(	token	)	
token	,	value	=	get_addr_spec	(	value	)	
angle_addr	.	append	(	token	)	
if	value	and	value	[	0	]	==	"str"	:	
value	=	value	[	1	:	]	
else	:	
angle_addr	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
angle_addr	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
angle_addr	.	append	(	token	)	
return	angle_addr	,	value	

def	get_display_name	(	value	)	:	

display_name	=	DisplayName	(	)	
token	,	value	=	get_phrase	(	value	)	
display_name	.	extend	(	token	[	:	]	)	
display_name	.	defects	=	token	.	defects	[	:	]	
return	display_name	,	value	


def	get_name_addr	(	value	)	:	

name_addr	=	NameAddr	(	)	

leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	leader	)	)	
if	value	[	0	]	!=	"str"	:	
if	value	[	0	]	in	PHRASE_ENDS	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
token	,	value	=	get_display_name	(	value	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	token	)	)	
if	leader	is	not	None	:	
token	[	0	]	[	:	0	]	=	[	leader	]	
leader	=	None	
name_addr	.	append	(	token	)	
token	,	value	=	get_angle_addr	(	value	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
name_addr	.	append	(	token	)	
return	name_addr	,	value	

def	get_mailbox	(	value	)	:	



mailbox	=	Mailbox	(	)	
try	:	
token	,	value	=	get_name_addr	(	value	)	
except	errors	.	HeaderParseError	:	
try	:	
token	,	value	=	get_addr_spec	(	value	)	
except	errors	.	HeaderParseError	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
if	any	(	isinstance	(	x	,	errors	.	InvalidHeaderDefect	)	
for	x	in	token	.	all_defects	)	:	
mailbox	.	token_type	=	"str"	
mailbox	.	append	(	token	)	
return	mailbox	,	value	

def	get_invalid_mailbox	(	value	,	endchars	)	:	

invalid_mailbox	=	InvalidMailbox	(	)	
while	value	and	value	[	0	]	not	in	endchars	:	
if	value	[	0	]	in	PHRASE_ENDS	:	
invalid_mailbox	.	append	(	ValueTerminal	(	value	[	0	]	,	
"str"	)	)	
value	=	value	[	1	:	]	
else	:	
token	,	value	=	get_phrase	(	value	)	
invalid_mailbox	.	append	(	token	)	
return	invalid_mailbox	,	value	

def	get_mailbox_list	(	value	)	:	

mailbox_list	=	MailboxList	(	)	
while	value	and	value	[	0	]	!=	"str"	:	
try	:	
token	,	value	=	get_mailbox	(	value	)	
mailbox_list	.	append	(	token	)	
except	errors	.	HeaderParseError	:	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	or	value	[	0	]	in	"str"	:	
mailbox_list	.	append	(	leader	)	
mailbox_list	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
else	:	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
mailbox_list	.	append	(	token	)	
mailbox_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
elif	value	[	0	]	==	"str"	:	
mailbox_list	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
else	:	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
mailbox_list	.	append	(	token	)	
mailbox_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	and	value	[	0	]	not	in	"str"	:	


mailbox	=	mailbox_list	[	-	1	]	
mailbox	.	token_type	=	"str"	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
mailbox	.	extend	(	token	)	
mailbox_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	and	value	[	0	]	==	"str"	:	
mailbox_list	.	append	(	ListSeparator	)	
value	=	value	[	1	:	]	
return	mailbox_list	,	value	


def	get_group_list	(	value	)	:	

group_list	=	GroupList	(	)	
if	not	value	:	
group_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
return	group_list	,	value	
leader	=	None	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	



group_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
group_list	.	append	(	leader	)	
return	group_list	,	value	
if	value	[	0	]	==	"str"	:	
group_list	.	append	(	leader	)	
return	group_list	,	value	
token	,	value	=	get_mailbox_list	(	value	)	
if	len	(	token	.	all_mailboxes	)	==	0	:	
if	leader	is	not	None	:	
group_list	.	append	(	leader	)	
group_list	.	extend	(	token	)	
group_list	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
return	group_list	,	value	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
group_list	.	append	(	token	)	
return	group_list	,	value	

def	get_group	(	value	)	:	

group	=	Group	(	)	
token	,	value	=	get_display_name	(	value	)	
if	not	value	or	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
group	.	append	(	token	)	
group	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	value	and	value	[	0	]	==	"str"	:	
group	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
return	group	,	value	[	1	:	]	
token	,	value	=	get_group_list	(	value	)	
group	.	append	(	token	)	
if	not	value	:	
group	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
group	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
group	.	append	(	token	)	
return	group	,	value	

def	get_address	(	value	)	:	








address	=	Address	(	)	
try	:	
token	,	value	=	get_group	(	value	)	
except	errors	.	HeaderParseError	:	
try	:	
token	,	value	=	get_mailbox	(	value	)	
except	errors	.	HeaderParseError	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
address	.	append	(	token	)	
return	address	,	value	

def	get_address_list	(	value	)	:	

address_list	=	AddressList	(	)	
while	value	:	
try	:	
token	,	value	=	get_address	(	value	)	
address_list	.	append	(	token	)	
except	errors	.	HeaderParseError	as	err	:	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	or	value	[	0	]	==	"str"	:	
address_list	.	append	(	leader	)	
address_list	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
else	:	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
address_list	.	append	(	Address	(	[	token	]	)	)	
address_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
elif	value	[	0	]	==	"str"	:	
address_list	.	defects	.	append	(	errors	.	ObsoleteHeaderDefect	(	
"str"	)	)	
else	:	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
address_list	.	append	(	Address	(	[	token	]	)	)	
address_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	and	value	[	0	]	!=	"str"	:	


mailbox	=	address_list	[	-	1	]	[	0	]	
mailbox	.	token_type	=	"str"	
token	,	value	=	get_invalid_mailbox	(	value	,	"str"	)	
mailbox	.	extend	(	token	)	
address_list	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	:	
address_list	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
return	address_list	,	value	









def	parse_mime_version	(	value	)	:	



mime_version	=	MIMEVersion	(	)	
if	not	value	:	
mime_version	.	defects	.	append	(	errors	.	HeaderMissingRequiredValue	(	
"str"	)	)	
return	mime_version	
if	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mime_version	.	append	(	token	)	
if	not	value	:	
mime_version	.	defects	.	append	(	errors	.	HeaderMissingRequiredValue	(	
"str"	)	)	
digits	=	"str"	
while	value	and	value	[	0	]	!=	"str"	and	value	[	0	]	not	in	CFWS_LEADER	:	
digits	+	=	value	[	0	]	
value	=	value	[	1	:	]	
if	not	digits	.	isdigit	(	)	:	
mime_version	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	digits	)	)	)	
mime_version	.	append	(	ValueTerminal	(	digits	,	"str"	)	)	
else	:	
mime_version	.	major	=	int	(	digits	)	
mime_version	.	append	(	ValueTerminal	(	digits	,	"str"	)	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mime_version	.	append	(	token	)	
if	not	value	or	value	[	0	]	!=	"str"	:	
if	mime_version	.	major	is	not	None	:	
mime_version	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	:	
mime_version	.	append	(	ValueTerminal	(	value	,	"str"	)	)	
return	mime_version	
mime_version	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mime_version	.	append	(	token	)	
if	not	value	:	
if	mime_version	.	major	is	not	None	:	
mime_version	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
return	mime_version	
digits	=	"str"	
while	value	and	value	[	0	]	not	in	CFWS_LEADER	:	
digits	+	=	value	[	0	]	
value	=	value	[	1	:	]	
if	not	digits	.	isdigit	(	)	:	
mime_version	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	digits	)	)	)	
mime_version	.	append	(	ValueTerminal	(	digits	,	"str"	)	)	
else	:	
mime_version	.	minor	=	int	(	digits	)	
mime_version	.	append	(	ValueTerminal	(	digits	,	"str"	)	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mime_version	.	append	(	token	)	
if	value	:	
mime_version	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
mime_version	.	append	(	ValueTerminal	(	value	,	"str"	)	)	
return	mime_version	

def	get_invalid_parameter	(	value	)	:	

invalid_parameter	=	InvalidParameter	(	)	
while	value	and	value	[	0	]	!=	"str"	:	
if	value	[	0	]	in	PHRASE_ENDS	:	
invalid_parameter	.	append	(	ValueTerminal	(	value	[	0	]	,	
"str"	)	)	
value	=	value	[	1	:	]	
else	:	
token	,	value	=	get_phrase	(	value	)	
invalid_parameter	.	append	(	token	)	
return	invalid_parameter	,	value	

def	get_ttext	(	value	)	:	

m	=	_non_token_end_matcher	(	value	)	
if	not	m	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
ttext	=	m	.	group	(	)	
value	=	value	[	len	(	ttext	)	:	]	
ttext	=	ValueTerminal	(	ttext	,	"str"	)	
_validate_xtext	(	ttext	)	
return	ttext	,	value	

def	get_token	(	value	)	:	

mtoken	=	Token	(	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mtoken	.	append	(	token	)	
if	value	and	value	[	0	]	in	TOKEN_ENDS	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
token	,	value	=	get_ttext	(	value	)	
mtoken	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
mtoken	.	append	(	token	)	
return	mtoken	,	value	

def	get_attrtext	(	value	)	:	

m	=	_non_attribute_end_matcher	(	value	)	
if	not	m	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
attrtext	=	m	.	group	(	)	
value	=	value	[	len	(	attrtext	)	:	]	
attrtext	=	ValueTerminal	(	attrtext	,	"str"	)	
_validate_xtext	(	attrtext	)	
return	attrtext	,	value	

def	get_attribute	(	value	)	:	

attribute	=	Attribute	(	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
attribute	.	append	(	token	)	
if	value	and	value	[	0	]	in	ATTRIBUTE_ENDS	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
token	,	value	=	get_attrtext	(	value	)	
attribute	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
attribute	.	append	(	token	)	
return	attribute	,	value	

def	get_extended_attrtext	(	value	)	:	

m	=	_non_extended_attribute_end_matcher	(	value	)	
if	not	m	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
attrtext	=	m	.	group	(	)	
value	=	value	[	len	(	attrtext	)	:	]	
attrtext	=	ValueTerminal	(	attrtext	,	"str"	)	
_validate_xtext	(	attrtext	)	
return	attrtext	,	value	

def	get_extended_attribute	(	value	)	:	


attribute	=	Attribute	(	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
attribute	.	append	(	token	)	
if	value	and	value	[	0	]	in	EXTENDED_ATTRIBUTE_ENDS	:	
raise	errors	.	HeaderParseError	(	
"str"	.	format	(	value	)	)	
token	,	value	=	get_extended_attrtext	(	value	)	
attribute	.	append	(	token	)	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
attribute	.	append	(	token	)	
return	attribute	,	value	

def	get_section	(	value	)	:	

section	=	Section	(	)	
if	not	value	or	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	.	format	(	
value	)	)	
section	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	not	value	or	not	value	[	0	]	.	isdigit	(	)	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
digits	=	"str"	
while	value	and	value	[	0	]	.	isdigit	(	)	:	
digits	+	=	value	[	0	]	
value	=	value	[	1	:	]	
if	digits	[	0	]	==	"str"	and	digits	!=	"str"	:	
section	.	defects	.	append	(	errors	.	InvalidHeaderError	(	"str"	
"str"	)	)	
section	.	number	=	int	(	digits	)	
section	.	append	(	ValueTerminal	(	digits	,	"str"	)	)	
return	section	,	value	


def	get_value	(	value	)	:	

v	=	Value	(	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	"str"	)	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	leader	)	)	
if	value	[	0	]	==	"str"	:	
token	,	value	=	get_quoted_string	(	value	)	
else	:	
token	,	value	=	get_extended_attribute	(	value	)	
if	leader	is	not	None	:	
token	[	:	0	]	=	[	leader	]	
v	.	append	(	token	)	
return	v	,	value	

def	get_parameter	(	value	)	:	




param	=	Parameter	(	)	
token	,	value	=	get_attribute	(	value	)	
param	.	append	(	token	)	
if	not	value	or	value	[	0	]	==	"str"	:	
param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	"str"	
"str"	.	format	(	token	)	)	)	
return	param	,	value	
if	value	[	0	]	==	"str"	:	
try	:	
token	,	value	=	get_section	(	value	)	
param	.	sectioned	=	True	
param	.	append	(	token	)	
except	errors	.	HeaderParseError	:	
pass	
if	not	value	:	
raise	errors	.	HeaderParseError	(	"str"	)	
if	value	[	0	]	==	"str"	:	
param	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
param	.	extended	=	True	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	)	
param	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
leader	=	None	
if	value	and	value	[	0	]	in	CFWS_LEADER	:	
token	,	value	=	get_cfws	(	value	)	
param	.	append	(	token	)	
remainder	=	None	
appendto	=	param	
if	param	.	extended	and	value	and	value	[	0	]	==	"str"	:	



qstring	,	remainder	=	get_quoted_string	(	value	)	
inner_value	=	qstring	.	stripped_value	
semi_valid	=	False	
if	param	.	section_number	==	0	:	
if	inner_value	and	inner_value	[	0	]	==	"str"	:	
semi_valid	=	True	
else	:	
token	,	rest	=	get_attrtext	(	inner_value	)	
if	rest	and	rest	[	0	]	==	"str"	:	
semi_valid	=	True	
else	:	
try	:	
token	,	rest	=	get_extended_attrtext	(	inner_value	)	
except	:	
pass	
else	:	
if	not	rest	:	
semi_valid	=	True	
if	semi_valid	:	
param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
param	.	append	(	qstring	)	
for	t	in	qstring	:	
if	t	.	token_type	==	"str"	:	
t	[	:	]	=	[	]	
appendto	=	t	
break	
value	=	inner_value	
else	:	
remainder	=	None	
param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	
"str"	)	)	
if	value	and	value	[	0	]	==	"str"	:	
token	=	None	
else	:	
token	,	value	=	get_value	(	value	)	
if	not	param	.	extended	or	param	.	section_number	>	0	:	
if	not	value	or	value	[	0	]	!=	"str"	:	
appendto	.	append	(	token	)	
if	remainder	is	not	None	:	
assert	not	value	,	value	
value	=	remainder	
return	param	,	value	
param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	
"str"	)	)	
if	not	value	:	

param	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
appendto	.	append	(	token	)	
if	remainder	is	None	:	
return	param	,	value	
else	:	
if	token	is	not	None	:	
for	t	in	token	:	
if	t	.	token_type	==	"str"	:	
break	
t	.	token_type	==	"str"	
appendto	.	append	(	t	)	
param	.	charset	=	t	.	value	
if	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
appendto	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	value	and	value	[	0	]	!=	"str"	:	
token	,	value	=	get_attrtext	(	value	)	
appendto	.	append	(	token	)	
param	.	lang	=	token	.	value	
if	not	value	or	value	[	0	]	!=	"str"	:	
raise	errors	.	HeaderParseError	(	"str"	
"str"	.	format	(	value	)	)	
appendto	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
if	remainder	is	not	None	:	

v	=	Value	(	)	
while	value	:	
if	value	[	0	]	in	WSP	:	
token	,	value	=	get_fws	(	value	)	
else	:	
token	,	value	=	get_qcontent	(	value	)	
v	.	append	(	token	)	
token	=	v	
else	:	
token	,	value	=	get_value	(	value	)	
appendto	.	append	(	token	)	
if	remainder	is	not	None	:	
assert	not	value	,	value	
value	=	remainder	
return	param	,	value	

def	parse_mime_parameters	(	value	)	:	

mime_parameters	=	MimeParameters	(	)	
while	value	:	
try	:	
token	,	value	=	get_parameter	(	value	)	
mime_parameters	.	append	(	token	)	
except	errors	.	HeaderParseError	as	err	:	
leader	=	None	
if	value	[	0	]	in	CFWS_LEADER	:	
leader	,	value	=	get_cfws	(	value	)	
if	not	value	:	
mime_parameters	.	append	(	leader	)	
return	mime_parameters	
if	value	[	0	]	==	"str"	:	
if	leader	is	not	None	:	
mime_parameters	.	append	(	leader	)	
mime_parameters	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
else	:	
token	,	value	=	get_invalid_parameter	(	value	)	
if	leader	:	
token	[	:	0	]	=	[	leader	]	
mime_parameters	.	append	(	token	)	
mime_parameters	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	token	)	)	)	
if	value	and	value	[	0	]	!=	"str"	:	


param	=	mime_parameters	[	-	1	]	
param	.	token_type	=	"str"	
token	,	value	=	get_invalid_parameter	(	value	)	
param	.	extend	(	token	)	
mime_parameters	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	token	)	)	)	
if	value	:	

mime_parameters	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
return	mime_parameters	

def	_find_mime_parameters	(	tokenlist	,	value	)	:	

while	value	and	value	[	0	]	!=	"str"	:	
if	value	[	0	]	in	PHRASE_ENDS	:	
tokenlist	.	append	(	ValueTerminal	(	value	[	0	]	,	"str"	)	)	
value	=	value	[	1	:	]	
else	:	
token	,	value	=	get_phrase	(	value	)	
tokenlist	.	append	(	token	)	
if	not	value	:	
return	
tokenlist	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
tokenlist	.	append	(	parse_mime_parameters	(	value	[	1	:	]	)	)	

def	parse_content_type_header	(	value	)	:	

ctype	=	ContentType	(	)	
recover	=	False	
if	not	value	:	
ctype	.	defects	.	append	(	errors	.	HeaderMissingRequiredValue	(	
"str"	)	)	
return	ctype	
try	:	
token	,	value	=	get_token	(	value	)	
except	errors	.	HeaderParseError	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	value	)	)	)	
_find_mime_parameters	(	ctype	,	value	)	
return	ctype	
ctype	.	append	(	token	)	


if	not	value	or	value	[	0	]	!=	"str"	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	:	
_find_mime_parameters	(	ctype	,	value	)	
return	ctype	
ctype	.	maintype	=	token	.	value	.	strip	(	)	.	lower	(	)	
ctype	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
value	=	value	[	1	:	]	
try	:	
token	,	value	=	get_token	(	value	)	
except	errors	.	HeaderParseError	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	value	)	)	)	
_find_mime_parameters	(	ctype	,	value	)	
return	ctype	
ctype	.	append	(	token	)	
ctype	.	subtype	=	token	.	value	.	strip	(	)	.	lower	(	)	
if	not	value	:	
return	ctype	
if	value	[	0	]	!=	"str"	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	
"str"	.	format	(	value	)	)	)	



del	ctype	.	maintype	,	ctype	.	subtype	
_find_mime_parameters	(	ctype	,	value	)	
return	ctype	
ctype	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
ctype	.	append	(	parse_mime_parameters	(	value	[	1	:	]	)	)	
return	ctype	

def	parse_content_disposition_header	(	value	)	:	

disp_header	=	ContentDisposition	(	)	
if	not	value	:	
disp_header	.	defects	.	append	(	errors	.	HeaderMissingRequiredValue	(	
"str"	)	)	
return	disp_header	
try	:	
token	,	value	=	get_token	(	value	)	
except	errors	.	HeaderParseError	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	value	)	)	)	
_find_mime_parameters	(	disp_header	,	value	)	
return	disp_header	
disp_header	.	append	(	token	)	
disp_header	.	content_disposition	=	token	.	value	.	strip	(	)	.	lower	(	)	
if	not	value	:	
return	disp_header	
if	value	[	0	]	!=	"str"	:	
disp_header	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	
"str"	.	format	(	value	)	)	)	
_find_mime_parameters	(	disp_header	,	value	)	
return	disp_header	
disp_header	.	append	(	ValueTerminal	(	"str"	,	"str"	)	)	
disp_header	.	append	(	parse_mime_parameters	(	value	[	1	:	]	)	)	
return	disp_header	

def	parse_content_transfer_encoding_header	(	value	)	:	


cte_header	=	ContentTransferEncoding	(	)	
if	not	value	:	
cte_header	.	defects	.	append	(	errors	.	HeaderMissingRequiredValue	(	
"str"	)	)	
return	cte_header	
try	:	
token	,	value	=	get_token	(	value	)	
except	errors	.	HeaderParseError	:	
ctype	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	.	format	(	value	)	)	)	
else	:	
cte_header	.	append	(	token	)	
cte_header	.	cte	=	token	.	value	.	strip	(	)	.	lower	(	)	
if	not	value	:	
return	cte_header	
while	value	:	
cte_header	.	defects	.	append	(	errors	.	InvalidHeaderDefect	(	
"str"	)	)	
if	value	[	0	]	in	PHRASE_ENDS	:	
cte_header	.	append	(	ValueTerminal	(	value	[	0	]	,	"str"	)	)	
value	=	value	[	1	:	]	
else	:	
token	,	value	=	get_phrase	(	value	)	
cte_header	.	append	(	token	)	
return	cte_header	
	