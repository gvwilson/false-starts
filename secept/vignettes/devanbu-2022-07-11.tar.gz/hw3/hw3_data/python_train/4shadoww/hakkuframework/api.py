



import	sys	
import	os	
import	traceback	


sys	.	path	.	append	(	os	.	path	.	dirname	(	os	.	path	.	realpath	(	__file__	)	)	)	


from	core	import	command_handler	
from	core	.	module_manager	import	ModuleManager	
from	core	.	apistatus	import	*	
api	.	enabled	=	True	


import	core	.	exceptions	

class	Hakkuapi	:	
mm	=	None	
ch	=	None	
allowPrint	=	False	
ModuleError	=	False	

def	disablePrint	(	self	)	:	
if	self	.	allowPrint	==	False	:	
f	=	open	(	os	.	devnull	,	"str"	)	
sys	.	stdout	=	f	

def	enablePrint	(	self	)	:	
if	self	.	allowPrint	==	False	:	
sys	.	stdout	=	sys	.	__stdout__	

def	__init__	(	self	,	allowPrint	)	:	
self	.	allowPrint	=	allowPrint	
self	.	mm	=	ModuleManager	
self	.	ch	=	command_handler	.	Commandhandler	(	self	.	mm	,	True	)	

def	loadModule	(	self	,	module	)	:	
self	.	disablePrint	(	)	
try	:	
self	.	ch	.	handle	(	"str"	+	module	)	
modadd	=	sys	.	modules	[	"str"	+	module	]	
if	modadd	.	conf	[	"str"	]	==	False	:	
raise	ApiNotSupported	(	"str"	)	
except	core	.	exceptions	.	ModuleNotFound	:	
self	.	enablePrint	(	)	
raise	ModuleNotFound	(	"str"	)	
except	:	
self	.	enablePrint	(	)	
raise	

self	.	enablePrint	(	)	

def	unloadModule	(	self	)	:	
self	.	disablePrint	(	)	
try	:	
self	.	ch	.	handle	(	"str"	)	
except	:	
self	.	enablePrint	(	)	
raise	
self	.	enablePrint	(	)	

def	setVariable	(	self	,	target	,	value	)	:	
self	.	disablePrint	(	)	
try	:	
self	.	ch	.	handle	(	"str"	+	target	+	"str"	+	value	)	
except	core	.	exceptions	.	VariableError	:	
self	.	enablePrint	(	)	
raise	VariableError	(	"str"	)	
except	:	
self	.	enablePrint	(	)	
raise	

self	.	enablePrint	(	)	

def	runModule	(	self	)	:	
self	.	ModuleError	=	False	
self	.	disablePrint	(	)	
try	:	
answer	=	self	.	ch	.	handle	(	"str"	)	
except	:	
self	.	enablePrint	(	)	
raise	
self	.	enablePrint	(	)	

if	type	(	answer	)	is	core	.	exceptions	.	ModuleError	:	
self	.	ModuleError	=	True	

return	answer	

def	customCommand	(	self	,	command	)	:	
self	.	disablePrint	(	)	
try	:	
answer	=	self	.	ch	.	handle	(	command	)	
except	:	
self	.	enablePrint	(	)	
raise	

self	.	enablePrint	(	)	
return	answer	

def	runCommand	(	self	,	command	)	:	
self	.	disablePrint	(	)	
try	:	
self	.	ch	.	handle	(	command	)	
except	:	
self	.	enablePrint	(	)	
raise	

self	.	enablePrint	(	)	


class	ModuleNotFound	(	Exception	)	:	
pass	

class	VariableError	(	Exception	)	:	
pass	

class	ApiNotSupported	(	Exception	)	:	
pass	
	