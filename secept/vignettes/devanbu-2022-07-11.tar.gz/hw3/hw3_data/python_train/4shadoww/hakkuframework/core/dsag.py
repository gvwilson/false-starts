darkside	=	"str"	

ag	=	"str"	
	