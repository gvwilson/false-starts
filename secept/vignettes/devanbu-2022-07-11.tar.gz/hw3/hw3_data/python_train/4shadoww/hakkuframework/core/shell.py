


import	sys	


from	core	.	module_manager	import	ModuleManager	
from	core	import	colors	
from	core	import	command_handler	

shellface	=	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	
mm	=	ModuleManager	

def	run	(	)	:	
global	shellface	
global	mm	

ch	=	command_handler	.	Commandhandler	(	mm	,	False	)	

while	True	:	
try	:	
setFace	(	)	
command	=	input	(	shellface	+	"str"	)	

ch	.	handle	(	command	)	
except	KeyboardInterrupt	:	
if	mm	.	moduleLoaded	==	0	:	
print	(	)	
sys	.	exit	(	0	)	
else	:	
print	(	)	
mm	.	moduleLoaded	=	0	
mm	.	moduleName	=	"str"	
print	(	colors	.	bold	+	colors	.	red	+	"str"	+	colors	.	end	)	

def	setFace	(	)	:	
global	shellface	
global	mm	
if	mm	.	moduleLoaded	==	0	:	
shellface	=	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	
else	:	
shellface	=	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	+	"str"	+	colors	.	red	+	mm	.	moduleName	+	colors	.	end	+	"str"	
	