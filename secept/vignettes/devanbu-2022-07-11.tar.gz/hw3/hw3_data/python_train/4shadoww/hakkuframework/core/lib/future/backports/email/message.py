





from	__future__	import	absolute_import	,	division	,	unicode_literals	
from	future	.	builtins	import	list	,	range	,	str	,	zip	

__all__	=	[	"str"	]	

import	re	
import	uu	
import	base64	
import	binascii	
from	io	import	BytesIO	,	StringIO	


from	future	.	utils	import	as_native_str	
from	future	.	backports	.	email	import	utils	
from	future	.	backports	.	email	import	errors	
from	future	.	backports	.	email	.	_policybase	import	compat32	
from	future	.	backports	.	email	import	charset	as	_charset	
from	future	.	backports	.	email	.	_encoded_words	import	decode_b	
Charset	=	_charset	.	Charset	

SEMISPACE	=	"str"	



tspecials	=	re	.	compile	(	"str"	)	


def	_splitparam	(	param	)	:	




a	,	sep	,	b	=	str	(	param	)	.	partition	(	"str"	)	
if	not	sep	:	
return	a	.	strip	(	)	,	None	
return	a	.	strip	(	)	,	b	.	strip	(	)	

def	_formatparam	(	param	,	value	=	None	,	quote	=	True	)	:	

if	value	is	not	None	and	len	(	value	)	>	0	:	



if	isinstance	(	value	,	tuple	)	:	

param	+	=	"str"	
value	=	utils	.	encode_rfc2231	(	value	[	2	]	,	value	[	0	]	,	value	[	1	]	)	
return	"str"	%	(	param	,	value	)	
else	:	
try	:	
value	.	encode	(	"str"	)	
except	UnicodeEncodeError	:	
param	+	=	"str"	
value	=	utils	.	encode_rfc2231	(	value	,	"str"	,	"str"	)	
return	"str"	%	(	param	,	value	)	


if	quote	or	tspecials	.	search	(	value	)	:	
return	"str"	%	(	param	,	utils	.	quote	(	value	)	)	
else	:	
return	"str"	%	(	param	,	value	)	
else	:	
return	param	

def	_parseparam	(	s	)	:	

s	=	"str"	+	str	(	s	)	
plist	=	[	]	
while	s	[	:	1	]	==	"str"	:	
s	=	s	[	1	:	]	
end	=	s	.	find	(	"str"	)	
while	end	>	0	and	(	s	.	count	(	"str"	,	0	,	end	)	-	s	.	count	(	"str"	,	0	,	end	)	)	%	2	:	
end	=	s	.	find	(	"str"	,	end	+	1	)	
if	end	<	0	:	
end	=	len	(	s	)	
f	=	s	[	:	end	]	
if	"str"	in	f	:	
i	=	f	.	index	(	"str"	)	
f	=	f	[	:	i	]	.	strip	(	)	.	lower	(	)	+	"str"	+	f	[	i	+	1	:	]	.	strip	(	)	
plist	.	append	(	f	.	strip	(	)	)	
s	=	s	[	end	:	]	
return	plist	


def	_unquotevalue	(	value	)	:	




if	isinstance	(	value	,	tuple	)	:	
return	value	[	0	]	,	value	[	1	]	,	utils	.	unquote	(	value	[	2	]	)	
else	:	
return	utils	.	unquote	(	value	)	


class	Message	(	object	)	:	

def	__init__	(	self	,	policy	=	compat32	)	:	
self	.	policy	=	policy	
self	.	_headers	=	list	(	)	
self	.	_unixfrom	=	None	
self	.	_payload	=	None	
self	.	_charset	=	None	

self	.	preamble	=	self	.	epilogue	=	None	
self	.	defects	=	[	]	

self	.	_default_type	=	"str"	

@as_native_str	(	encoding	=	"str"	)	
def	__str__	(	self	)	:	

return	self	.	as_string	(	)	

def	as_string	(	self	,	unixfrom	=	False	,	maxheaderlen	=	0	)	:	

from	future	.	backports	.	email	.	generator	import	Generator	
fp	=	StringIO	(	)	
g	=	Generator	(	fp	,	mangle_from_	=	False	,	maxheaderlen	=	maxheaderlen	)	
g	.	flatten	(	self	,	unixfrom	=	unixfrom	)	
return	fp	.	getvalue	(	)	

def	is_multipart	(	self	)	:	

return	isinstance	(	self	.	_payload	,	list	)	




def	set_unixfrom	(	self	,	unixfrom	)	:	
self	.	_unixfrom	=	unixfrom	

def	get_unixfrom	(	self	)	:	
return	self	.	_unixfrom	




def	attach	(	self	,	payload	)	:	

if	self	.	_payload	is	None	:	
self	.	_payload	=	[	payload	]	
else	:	
self	.	_payload	.	append	(	payload	)	

def	get_payload	(	self	,	i	=	None	,	decode	=	False	)	:	















if	self	.	is_multipart	(	)	:	
if	decode	:	
return	None	
if	i	is	None	:	
return	self	.	_payload	
else	:	
return	self	.	_payload	[	i	]	


if	i	is	not	None	and	not	isinstance	(	self	.	_payload	,	list	)	:	
raise	TypeError	(	"str"	%	type	(	self	.	_payload	)	)	
payload	=	self	.	_payload	

cte	=	str	(	self	.	get	(	"str"	,	"str"	)	)	.	lower	(	)	

if	isinstance	(	payload	,	str	)	:	
payload	=	str	(	payload	)	
if	utils	.	_has_surrogates	(	payload	)	:	
bpayload	=	payload	.	encode	(	"str"	,	"str"	)	
if	not	decode	:	
try	:	
payload	=	bpayload	.	decode	(	self	.	get_param	(	"str"	,	"str"	)	,	"str"	)	
except	LookupError	:	
payload	=	bpayload	.	decode	(	"str"	,	"str"	)	
elif	decode	:	
try	:	
bpayload	=	payload	.	encode	(	"str"	)	
except	UnicodeError	:	




bpayload	=	payload	.	encode	(	"str"	)	
if	not	decode	:	
return	payload	
if	cte	==	"str"	:	
return	utils	.	_qdecode	(	bpayload	)	
elif	cte	==	"str"	:	


value	,	defects	=	decode_b	(	b	"str"	.	join	(	bpayload	.	splitlines	(	)	)	)	
for	defect	in	defects	:	
self	.	policy	.	handle_defect	(	self	,	defect	)	
return	value	
elif	cte	in	(	"str"	,	"str"	,	"str"	,	"str"	)	:	
in_file	=	BytesIO	(	bpayload	)	
out_file	=	BytesIO	(	)	
try	:	
uu	.	decode	(	in_file	,	out_file	,	quiet	=	True	)	
return	out_file	.	getvalue	(	)	
except	uu	.	Error	:	

return	bpayload	
if	isinstance	(	payload	,	str	)	:	
return	bpayload	
return	payload	

def	set_payload	(	self	,	payload	,	charset	=	None	)	:	

self	.	_payload	=	payload	
if	charset	is	not	None	:	
self	.	set_charset	(	charset	)	

def	set_charset	(	self	,	charset	)	:	

if	charset	is	None	:	
self	.	del_param	(	"str"	)	
self	.	_charset	=	None	
return	
if	not	isinstance	(	charset	,	Charset	)	:	
charset	=	Charset	(	charset	)	
self	.	_charset	=	charset	
if	"str"	not	in	self	:	
self	.	add_header	(	"str"	,	"str"	)	
if	"str"	not	in	self	:	
self	.	add_header	(	"str"	,	"str"	,	
charset	=	charset	.	get_output_charset	(	)	)	
else	:	
self	.	set_param	(	"str"	,	charset	.	get_output_charset	(	)	)	
if	charset	!=	charset	.	get_output_charset	(	)	:	
self	.	_payload	=	charset	.	body_encode	(	self	.	_payload	)	
if	"str"	not	in	self	:	
cte	=	charset	.	get_body_encoding	(	)	
try	:	
cte	(	self	)	
except	TypeError	:	
self	.	_payload	=	charset	.	body_encode	(	self	.	_payload	)	
self	.	add_header	(	"str"	,	cte	)	

def	get_charset	(	self	)	:	

return	self	.	_charset	




def	__len__	(	self	)	:	

return	len	(	self	.	_headers	)	

def	__getitem__	(	self	,	name	)	:	

return	self	.	get	(	name	)	

def	__setitem__	(	self	,	name	,	val	)	:	

max_count	=	self	.	policy	.	header_max_count	(	name	)	
if	max_count	:	
lname	=	name	.	lower	(	)	
found	=	0	
for	k	,	v	in	self	.	_headers	:	
if	k	.	lower	(	)	==	lname	:	
found	+	=	1	
if	found	>	=	max_count	:	
raise	ValueError	(	"str"	
"str"	.	format	(	max_count	,	name	)	)	
self	.	_headers	.	append	(	self	.	policy	.	header_store_parse	(	name	,	val	)	)	

def	__delitem__	(	self	,	name	)	:	

name	=	name	.	lower	(	)	
newheaders	=	list	(	)	
for	k	,	v	in	self	.	_headers	:	
if	k	.	lower	(	)	!=	name	:	
newheaders	.	append	(	(	k	,	v	)	)	
self	.	_headers	=	newheaders	

def	__contains__	(	self	,	name	)	:	
return	name	.	lower	(	)	in	[	k	.	lower	(	)	for	k	,	v	in	self	.	_headers	]	

def	__iter__	(	self	)	:	
for	field	,	value	in	self	.	_headers	:	
yield	field	

def	keys	(	self	)	:	

return	[	k	for	k	,	v	in	self	.	_headers	]	

def	values	(	self	)	:	

return	[	self	.	policy	.	header_fetch_parse	(	k	,	v	)	
for	k	,	v	in	self	.	_headers	]	

def	items	(	self	)	:	

return	[	(	k	,	self	.	policy	.	header_fetch_parse	(	k	,	v	)	)	
for	k	,	v	in	self	.	_headers	]	

def	get	(	self	,	name	,	failobj	=	None	)	:	

name	=	name	.	lower	(	)	
for	k	,	v	in	self	.	_headers	:	
if	k	.	lower	(	)	==	name	:	
return	self	.	policy	.	header_fetch_parse	(	k	,	v	)	
return	failobj	






def	set_raw	(	self	,	name	,	value	)	:	

self	.	_headers	.	append	(	(	name	,	value	)	)	

def	raw_items	(	self	)	:	

return	iter	(	self	.	_headers	.	copy	(	)	)	





def	get_all	(	self	,	name	,	failobj	=	None	)	:	

values	=	[	]	
name	=	name	.	lower	(	)	
for	k	,	v	in	self	.	_headers	:	
if	k	.	lower	(	)	==	name	:	
values	.	append	(	self	.	policy	.	header_fetch_parse	(	k	,	v	)	)	
if	not	values	:	
return	failobj	
return	values	

def	add_header	(	self	,	_name	,	_value	,	*	*	_params	)	:	

parts	=	[	]	
for	k	,	v	in	_params	.	items	(	)	:	
if	v	is	None	:	
parts	.	append	(	k	.	replace	(	"str"	,	"str"	)	)	
else	:	
parts	.	append	(	_formatparam	(	k	.	replace	(	"str"	,	"str"	)	,	v	)	)	
if	_value	is	not	None	:	
parts	.	insert	(	0	,	_value	)	
self	[	_name	]	=	SEMISPACE	.	join	(	parts	)	

def	replace_header	(	self	,	_name	,	_value	)	:	

_name	=	_name	.	lower	(	)	
for	i	,	(	k	,	v	)	in	zip	(	range	(	len	(	self	.	_headers	)	)	,	self	.	_headers	)	:	
if	k	.	lower	(	)	==	_name	:	
self	.	_headers	[	i	]	=	self	.	policy	.	header_store_parse	(	k	,	_value	)	
break	
else	:	
raise	KeyError	(	_name	)	





def	get_content_type	(	self	)	:	

missing	=	object	(	)	
value	=	self	.	get	(	"str"	,	missing	)	
if	value	is	missing	:	

return	self	.	get_default_type	(	)	
ctype	=	_splitparam	(	value	)	[	0	]	.	lower	(	)	

if	ctype	.	count	(	"str"	)	!=	1	:	
return	"str"	
return	ctype	

def	get_content_maintype	(	self	)	:	

ctype	=	self	.	get_content_type	(	)	
return	ctype	.	split	(	"str"	)	[	0	]	

def	get_content_subtype	(	self	)	:	

ctype	=	self	.	get_content_type	(	)	
return	ctype	.	split	(	"str"	)	[	1	]	

def	get_default_type	(	self	)	:	

return	self	.	_default_type	

def	set_default_type	(	self	,	ctype	)	:	

self	.	_default_type	=	ctype	

def	_get_params_preserve	(	self	,	failobj	,	header	)	:	


missing	=	object	(	)	
value	=	self	.	get	(	header	,	missing	)	
if	value	is	missing	:	
return	failobj	
params	=	[	]	
for	p	in	_parseparam	(	value	)	:	
try	:	
name	,	val	=	p	.	split	(	"str"	,	1	)	
name	=	name	.	strip	(	)	
val	=	val	.	strip	(	)	
except	ValueError	:	

name	=	p	.	strip	(	)	
val	=	"str"	
params	.	append	(	(	name	,	val	)	)	
params	=	utils	.	decode_params	(	params	)	
return	params	

def	get_params	(	self	,	failobj	=	None	,	header	=	"str"	,	unquote	=	True	)	:	

missing	=	object	(	)	
params	=	self	.	_get_params_preserve	(	missing	,	header	)	
if	params	is	missing	:	
return	failobj	
if	unquote	:	
return	[	(	k	,	_unquotevalue	(	v	)	)	for	k	,	v	in	params	]	
else	:	
return	params	

def	get_param	(	self	,	param	,	failobj	=	None	,	header	=	"str"	,	
unquote	=	True	)	:	

if	header	not	in	self	:	
return	failobj	
for	k	,	v	in	self	.	_get_params_preserve	(	failobj	,	header	)	:	
if	k	.	lower	(	)	==	param	.	lower	(	)	:	
if	unquote	:	
return	_unquotevalue	(	v	)	
else	:	
return	v	
return	failobj	

def	set_param	(	self	,	param	,	value	,	header	=	"str"	,	requote	=	True	,	
charset	=	None	,	language	=	"str"	)	:	

if	not	isinstance	(	value	,	tuple	)	and	charset	:	
value	=	(	charset	,	language	,	value	)	

if	header	not	in	self	and	header	.	lower	(	)	==	"str"	:	
ctype	=	"str"	
else	:	
ctype	=	self	.	get	(	header	)	
if	not	self	.	get_param	(	param	,	header	=	header	)	:	
if	not	ctype	:	
ctype	=	_formatparam	(	param	,	value	,	requote	)	
else	:	
ctype	=	SEMISPACE	.	join	(	
[	ctype	,	_formatparam	(	param	,	value	,	requote	)	]	)	
else	:	
ctype	=	"str"	
for	old_param	,	old_value	in	self	.	get_params	(	header	=	header	,	
unquote	=	requote	)	:	
append_param	=	"str"	
if	old_param	.	lower	(	)	==	param	.	lower	(	)	:	
append_param	=	_formatparam	(	param	,	value	,	requote	)	
else	:	
append_param	=	_formatparam	(	old_param	,	old_value	,	requote	)	
if	not	ctype	:	
ctype	=	append_param	
else	:	
ctype	=	SEMISPACE	.	join	(	[	ctype	,	append_param	]	)	
if	ctype	!=	self	.	get	(	header	)	:	
del	self	[	header	]	
self	[	header	]	=	ctype	

def	del_param	(	self	,	param	,	header	=	"str"	,	requote	=	True	)	:	

if	header	not	in	self	:	
return	
new_ctype	=	"str"	
for	p	,	v	in	self	.	get_params	(	header	=	header	,	unquote	=	requote	)	:	
if	p	.	lower	(	)	!=	param	.	lower	(	)	:	
if	not	new_ctype	:	
new_ctype	=	_formatparam	(	p	,	v	,	requote	)	
else	:	
new_ctype	=	SEMISPACE	.	join	(	[	new_ctype	,	
_formatparam	(	p	,	v	,	requote	)	]	)	
if	new_ctype	!=	self	.	get	(	header	)	:	
del	self	[	header	]	
self	[	header	]	=	new_ctype	

def	set_type	(	self	,	type	,	header	=	"str"	,	requote	=	True	)	:	


if	not	type	.	count	(	"str"	)	==	1	:	
raise	ValueError	

if	header	.	lower	(	)	==	"str"	:	
del	self	[	"str"	]	
self	[	"str"	]	=	"str"	
if	header	not	in	self	:	
self	[	header	]	=	type	
return	
params	=	self	.	get_params	(	header	=	header	,	unquote	=	requote	)	
del	self	[	header	]	
self	[	header	]	=	type	

for	p	,	v	in	params	[	1	:	]	:	
self	.	set_param	(	p	,	v	,	header	,	requote	)	

def	get_filename	(	self	,	failobj	=	None	)	:	

missing	=	object	(	)	
filename	=	self	.	get_param	(	"str"	,	missing	,	"str"	)	
if	filename	is	missing	:	
filename	=	self	.	get_param	(	"str"	,	missing	,	"str"	)	
if	filename	is	missing	:	
return	failobj	
return	utils	.	collapse_rfc2231_value	(	filename	)	.	strip	(	)	

def	get_boundary	(	self	,	failobj	=	None	)	:	

missing	=	object	(	)	
boundary	=	self	.	get_param	(	"str"	,	missing	)	
if	boundary	is	missing	:	
return	failobj	

return	utils	.	collapse_rfc2231_value	(	boundary	)	.	rstrip	(	)	

def	set_boundary	(	self	,	boundary	)	:	

missing	=	object	(	)	
params	=	self	.	_get_params_preserve	(	missing	,	"str"	)	
if	params	is	missing	:	


raise	errors	.	HeaderParseError	(	"str"	)	
newparams	=	[	]	
foundp	=	False	
for	pk	,	pv	in	params	:	
if	pk	.	lower	(	)	==	"str"	:	
newparams	.	append	(	(	"str"	,	"str"	%	boundary	)	)	
foundp	=	True	
else	:	
newparams	.	append	(	(	pk	,	pv	)	)	
if	not	foundp	:	



newparams	.	append	(	(	"str"	,	"str"	%	boundary	)	)	

newheaders	=	[	]	
for	h	,	v	in	self	.	_headers	:	
if	h	.	lower	(	)	==	"str"	:	
parts	=	[	]	
for	k	,	v	in	newparams	:	
if	v	==	"str"	:	
parts	.	append	(	k	)	
else	:	
parts	.	append	(	"str"	%	(	k	,	v	)	)	
val	=	SEMISPACE	.	join	(	parts	)	
newheaders	.	append	(	self	.	policy	.	header_store_parse	(	h	,	val	)	)	

else	:	
newheaders	.	append	(	(	h	,	v	)	)	
self	.	_headers	=	newheaders	

def	get_content_charset	(	self	,	failobj	=	None	)	:	

missing	=	object	(	)	
charset	=	self	.	get_param	(	"str"	,	missing	)	
if	charset	is	missing	:	
return	failobj	
if	isinstance	(	charset	,	tuple	)	:	

pcharset	=	charset	[	0	]	or	"str"	
try	:	



as_bytes	=	charset	[	2	]	.	encode	(	"str"	)	
charset	=	str	(	as_bytes	,	pcharset	)	
except	(	LookupError	,	UnicodeError	)	:	
charset	=	charset	[	2	]	

try	:	
charset	.	encode	(	"str"	)	
except	UnicodeError	:	
return	failobj	

return	charset	.	lower	(	)	

def	get_charsets	(	self	,	failobj	=	None	)	:	

return	[	part	.	get_content_charset	(	failobj	)	for	part	in	self	.	walk	(	)	]	


from	future	.	backports	.	email	.	iterators	import	walk	
	