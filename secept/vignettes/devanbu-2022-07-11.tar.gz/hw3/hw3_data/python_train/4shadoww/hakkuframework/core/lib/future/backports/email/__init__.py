




from	__future__	import	unicode_literals	
from	__future__	import	division	
from	__future__	import	absolute_import	



from	future	.	utils	import	surrogateescape	
surrogateescape	.	register_surrogateescape	(	)	



__version__	=	"str"	

__all__	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	






def	message_from_string	(	s	,	*	args	,	*	*	kws	)	:	

from	future	.	backports	.	email	.	parser	import	Parser	
return	Parser	(	*	args	,	*	*	kws	)	.	parsestr	(	s	)	

def	message_from_bytes	(	s	,	*	args	,	*	*	kws	)	:	

from	future	.	backports	.	email	.	parser	import	BytesParser	
return	BytesParser	(	*	args	,	*	*	kws	)	.	parsebytes	(	s	)	

def	message_from_file	(	fp	,	*	args	,	*	*	kws	)	:	

from	future	.	backports	.	email	.	parser	import	Parser	
return	Parser	(	*	args	,	*	*	kws	)	.	parse	(	fp	)	

def	message_from_binary_file	(	fp	,	*	args	,	*	*	kws	)	:	

from	future	.	backports	.	email	.	parser	import	BytesParser	
return	BytesParser	(	*	args	,	*	*	kws	)	.	parse	(	fp	)	
	