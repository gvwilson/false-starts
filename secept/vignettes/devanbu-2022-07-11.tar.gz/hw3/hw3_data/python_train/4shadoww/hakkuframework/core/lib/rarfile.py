

















__version__	=	"str"	


__all__	=	[	"str"	,	"str"	,	"str"	,	"str"	]	





import	sys	,	os	,	struct	,	errno	
from	struct	import	pack	,	unpack	,	Struct	
from	binascii	import	crc32	
from	tempfile	import	mkstemp	
from	subprocess	import	Popen	,	PIPE	,	STDOUT	
from	datetime	import	datetime	
from	io	import	RawIOBase	
from	hashlib	import	sha1	


try	:	
try	:	
from	cryptography	.	hazmat	.	primitives	.	ciphers	import	algorithms	,	modes	,	Cipher	
from	cryptography	.	hazmat	.	backends	import	default_backend	
class	AES_CBC_Decrypt	(	object	)	:	
block_size	=	16	
def	__init__	(	self	,	key	,	iv	)	:	
ciph	=	Cipher	(	algorithms	.	AES	(	key	)	,	modes	.	CBC	(	iv	)	,	default_backend	(	)	)	
self	.	dec	=	ciph	.	decryptor	(	)	
def	decrypt	(	self	,	data	)	:	
return	self	.	dec	.	update	(	data	)	
except	ImportError	:	
from	Crypto	.	Cipher	import	AES	
class	AES_CBC_Decrypt	(	object	)	:	
block_size	=	16	
def	__init__	(	self	,	key	,	iv	)	:	
self	.	dec	=	AES	.	new	(	key	,	AES	.	MODE_CBC	,	iv	)	
def	decrypt	(	self	,	data	)	:	
return	self	.	dec	.	decrypt	(	data	)	
_have_crypto	=	1	
except	ImportError	:	
_have_crypto	=	0	


if	sys	.	hexversion	<	0x3000000	:	

range	=	xrange	
else	:	
unicode	=	str	






DEFAULT_CHARSET	=	"str"	


TRY_ENCODINGS	=	(	"str"	,	"str"	)	


UNRAR_TOOL	=	"str"	


OPEN_ARGS	=	(	"str"	,	"str"	)	


EXTRACT_ARGS	=	(	"str"	,	"str"	,	"str"	)	


TEST_ARGS	=	(	"str"	,	"str"	)	












ALT_TOOL	=	"str"	
ALT_OPEN_ARGS	=	(	"str"	,	"str"	,	"str"	)	
ALT_EXTRACT_ARGS	=	(	"str"	,	"str"	)	
ALT_TEST_ARGS	=	(	"str"	,	"str"	)	
ALT_CHECK_ARGS	=	(	"str"	,	)	


USE_EXTRACT_HACK	=	1	


HACK_SIZE_LIMIT	=	20	*	1024	*	1024	


NEED_COMMENTS	=	1	


UNICODE_COMMENTS	=	0	


USE_DATETIME	=	0	



PATH_SEP	=	"str"	






RAR_BLOCK_MARK	=	0x72	
RAR_BLOCK_MAIN	=	0x73	
RAR_BLOCK_FILE	=	0x74	
RAR_BLOCK_OLD_COMMENT	=	0x75	
RAR_BLOCK_OLD_EXTRA	=	0x76	
RAR_BLOCK_OLD_SUB	=	0x77	
RAR_BLOCK_OLD_RECOVERY	=	0x78	
RAR_BLOCK_OLD_AUTH	=	0x79	
RAR_BLOCK_SUB	=	0x7a	
RAR_BLOCK_ENDARC	=	0x7b	


RAR_MAIN_VOLUME	=	0x0001	
RAR_MAIN_COMMENT	=	0x0002	
RAR_MAIN_LOCK	=	0x0004	
RAR_MAIN_SOLID	=	0x0008	
RAR_MAIN_NEWNUMBERING	=	0x0010	
RAR_MAIN_AUTH	=	0x0020	
RAR_MAIN_RECOVERY	=	0x0040	
RAR_MAIN_PASSWORD	=	0x0080	
RAR_MAIN_FIRSTVOLUME	=	0x0100	
RAR_MAIN_ENCRYPTVER	=	0x0200	


RAR_FILE_SPLIT_BEFORE	=	0x0001	
RAR_FILE_SPLIT_AFTER	=	0x0002	
RAR_FILE_PASSWORD	=	0x0004	
RAR_FILE_COMMENT	=	0x0008	
RAR_FILE_SOLID	=	0x0010	
RAR_FILE_DICTMASK	=	0x00e0	
RAR_FILE_DICT64	=	0x0000	
RAR_FILE_DICT128	=	0x0020	
RAR_FILE_DICT256	=	0x0040	
RAR_FILE_DICT512	=	0x0060	
RAR_FILE_DICT1024	=	0x0080	
RAR_FILE_DICT2048	=	0x00a0	
RAR_FILE_DICT4096	=	0x00c0	
RAR_FILE_DIRECTORY	=	0x00e0	
RAR_FILE_LARGE	=	0x0100	
RAR_FILE_UNICODE	=	0x0200	
RAR_FILE_SALT	=	0x0400	
RAR_FILE_VERSION	=	0x0800	
RAR_FILE_EXTTIME	=	0x1000	
RAR_FILE_EXTFLAGS	=	0x2000	


RAR_ENDARC_NEXT_VOLUME	=	0x0001	
RAR_ENDARC_DATACRC	=	0x0002	
RAR_ENDARC_REVSPACE	=	0x0004	
RAR_ENDARC_VOLNR	=	0x0008	


RAR_SKIP_IF_UNKNOWN	=	0x4000	
RAR_LONG_BLOCK	=	0x8000	


RAR_OS_MSDOS	=	0	
RAR_OS_OS2	=	1	
RAR_OS_WIN32	=	2	
RAR_OS_UNIX	=	3	
RAR_OS_MACOS	=	4	
RAR_OS_BEOS	=	5	


RAR_M0	=	0x30	
RAR_M1	=	0x31	
RAR_M2	=	0x32	
RAR_M3	=	0x33	
RAR_M4	=	0x34	
RAR_M5	=	0x35	





RAR_ID	=	b	"str"	
ZERO	=	b	"str"	
EMPTY	=	b	"str"	

S_BLK_HDR	=	Struct	(	"str"	)	
S_FILE_HDR	=	Struct	(	"str"	)	
S_LONG	=	Struct	(	"str"	)	
S_SHORT	=	Struct	(	"str"	)	
S_BYTE	=	Struct	(	"str"	)	
S_COMMENT_HDR	=	Struct	(	"str"	)	





class	Error	(	Exception	)	:	

class	BadRarFile	(	Error	)	:	

class	NotRarFile	(	Error	)	:	

class	BadRarName	(	Error	)	:	

class	NoRarEntry	(	Error	)	:	

class	PasswordRequired	(	Error	)	:	

class	NeedFirstVolume	(	Error	)	:	

class	NoCrypto	(	Error	)	:	

class	RarExecError	(	Error	)	:	

class	RarWarning	(	RarExecError	)	:	

class	RarFatalError	(	RarExecError	)	:	

class	RarCRCError	(	RarExecError	)	:	

class	RarLockedArchiveError	(	RarExecError	)	:	

class	RarWriteError	(	RarExecError	)	:	

class	RarOpenError	(	RarExecError	)	:	

class	RarUserError	(	RarExecError	)	:	

class	RarMemoryError	(	RarExecError	)	:	

class	RarCreateError	(	RarExecError	)	:	

class	RarNoFilesError	(	RarExecError	)	:	

class	RarUserBreak	(	RarExecError	)	:	

class	RarUnknownError	(	RarExecError	)	:	

class	RarSignalExit	(	RarExecError	)	:	

class	RarCannotExec	(	RarExecError	)	:	



def	is_rarfile	(	xfile	)	:	

fd	=	XFile	(	xfile	)	
buf	=	fd	.	read	(	len	(	RAR_ID	)	)	
fd	.	close	(	)	
return	buf	==	RAR_ID	


class	RarInfo	(	object	)	:	


__slots__	=	(	

"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	


"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	



"str"	,	
"str"	,	
"str"	,	
"str"	,	


"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	

def	isdir	(	self	)	:	

if	self	.	type	==	RAR_BLOCK_FILE	:	
return	(	self	.	flags	&	RAR_FILE_DIRECTORY	)	==	RAR_FILE_DIRECTORY	
return	False	

def	needs_password	(	self	)	:	
return	(	self	.	flags	&	RAR_FILE_PASSWORD	)	>	0	


class	RarFile	(	object	)	:	




comment	=	None	

def	__init__	(	self	,	rarfile	,	mode	=	"str"	,	charset	=	None	,	info_callback	=	None	,	
crc_check	=	True	,	errors	=	"str"	)	:	

self	.	rarfile	=	rarfile	
self	.	comment	=	None	
self	.	_charset	=	charset	or	DEFAULT_CHARSET	
self	.	_info_callback	=	info_callback	

self	.	_info_list	=	[	]	
self	.	_info_map	=	{	}	
self	.	_parse_error	=	None	
self	.	_needs_password	=	False	
self	.	_password	=	None	
self	.	_crc_check	=	crc_check	
self	.	_vol_list	=	[	]	

if	errors	==	"str"	:	
self	.	_strict	=	False	
elif	errors	==	"str"	:	
self	.	_strict	=	True	
else	:	
raise	ValueError	(	"str"	)	

self	.	_main	=	None	

if	mode	!=	"str"	:	
raise	NotImplementedError	(	"str"	)	

self	.	_parse	(	)	

def	__enter__	(	self	)	:	
return	self	

def	__exit__	(	self	,	type	,	value	,	traceback	)	:	
self	.	close	(	)	

def	setpassword	(	self	,	password	)	:	

self	.	_password	=	password	
if	not	self	.	_main	:	
self	.	_parse	(	)	

def	needs_password	(	self	)	:	

return	self	.	_needs_password	

def	namelist	(	self	)	:	

return	[	f	.	filename	for	f	in	self	.	infolist	(	)	]	

def	infolist	(	self	)	:	

return	self	.	_info_list	

def	volumelist	(	self	)	:	

return	self	.	_vol_list	

def	getinfo	(	self	,	fname	)	:	


if	isinstance	(	fname	,	RarInfo	)	:	
return	fname	


if	PATH_SEP	==	"str"	:	
fname2	=	fname	.	replace	(	"str"	,	"str"	)	
else	:	
fname2	=	fname	.	replace	(	"str"	,	"str"	)	

try	:	
return	self	.	_info_map	[	fname	]	
except	KeyError	:	
try	:	
return	self	.	_info_map	[	fname2	]	
except	KeyError	:	
raise	NoRarEntry	(	"str"	+	fname	)	

def	open	(	self	,	fname	,	mode	=	"str"	,	psw	=	None	)	:	


if	mode	!=	"str"	:	
raise	NotImplementedError	(	"str"	)	


inf	=	self	.	getinfo	(	fname	)	
if	inf	.	isdir	(	)	:	
raise	TypeError	(	"str"	+	inf	.	filename	)	

if	inf	.	flags	&	RAR_FILE_SPLIT_BEFORE	:	
raise	NeedFirstVolume	(	"str"	+	inf	.	filename	)	


if	inf	.	needs_password	(	)	:	
psw	=	psw	or	self	.	_password	
if	psw	is	None	:	
raise	PasswordRequired	(	"str"	%	inf	.	filename	)	
else	:	
psw	=	None	


use_hack	=	1	
if	not	self	.	_main	:	
use_hack	=	0	
elif	self	.	_main	.	flags	&	(	RAR_MAIN_SOLID	|	RAR_MAIN_PASSWORD	)	:	
use_hack	=	0	
elif	inf	.	flags	&	(	RAR_FILE_SPLIT_BEFORE	|	RAR_FILE_SPLIT_AFTER	)	:	
use_hack	=	0	
elif	is_filelike	(	self	.	rarfile	)	:	
pass	
elif	inf	.	file_size	>	HACK_SIZE_LIMIT	:	
use_hack	=	0	
elif	not	USE_EXTRACT_HACK	:	
use_hack	=	0	


if	inf	.	compress_type	==	RAR_M0	and	(	inf	.	flags	&	RAR_FILE_PASSWORD	)	==	0	:	
return	self	.	_open_clear	(	inf	)	
elif	use_hack	:	
return	self	.	_open_hack	(	inf	,	psw	)	
elif	is_filelike	(	self	.	rarfile	)	:	
return	self	.	_open_unrar_membuf	(	self	.	rarfile	,	inf	,	psw	)	
else	:	
return	self	.	_open_unrar	(	self	.	rarfile	,	inf	,	psw	)	

def	read	(	self	,	fname	,	psw	=	None	)	:	


f	=	self	.	open	(	fname	,	"str"	,	psw	)	
try	:	
return	f	.	read	(	)	
finally	:	
f	.	close	(	)	

def	close	(	self	)	:	

pass	

def	printdir	(	self	)	:	

for	f	in	self	.	infolist	(	)	:	
print	(	f	.	filename	)	

def	extract	(	self	,	member	,	path	=	None	,	pwd	=	None	)	:	

if	isinstance	(	member	,	RarInfo	)	:	
fname	=	member	.	filename	
else	:	
fname	=	member	
self	.	_extract	(	[	fname	]	,	path	,	pwd	)	

def	extractall	(	self	,	path	=	None	,	members	=	None	,	pwd	=	None	)	:	

fnlist	=	[	]	
if	members	is	not	None	:	
for	m	in	members	:	
if	isinstance	(	m	,	RarInfo	)	:	
fnlist	.	append	(	m	.	filename	)	
else	:	
fnlist	.	append	(	m	)	
self	.	_extract	(	fnlist	,	path	,	pwd	)	

def	testrar	(	self	)	:	

cmd	=	[	UNRAR_TOOL	]	+	list	(	TEST_ARGS	)	
add_password_arg	(	cmd	,	self	.	_password	)	
cmd	.	append	(	"str"	)	

if	is_filelike	(	self	.	rarfile	)	:	
tmpname	=	membuf_tempfile	(	self	.	rarfile	)	
cmd	.	append	(	tmpname	)	
else	:	
tmpname	=	None	
cmd	.	append	(	self	.	rarfile	)	

try	:	
p	=	custom_popen	(	cmd	)	
output	=	p	.	communicate	(	)	[	0	]	
check_returncode	(	p	,	output	)	
finally	:	
if	tmpname	:	
os	.	unlink	(	tmpname	)	

def	strerror	(	self	)	:	

return	self	.	_parse_error	





def	_set_error	(	self	,	msg	,	*	args	)	:	
if	args	:	
msg	=	msg	%	args	
self	.	_parse_error	=	msg	
if	self	.	_strict	:	
raise	BadRarFile	(	msg	)	


def	_process_entry	(	self	,	item	)	:	
if	item	.	type	==	RAR_BLOCK_FILE	:	

if	(	item	.	flags	&	RAR_FILE_SPLIT_BEFORE	)	==	0	:	
self	.	_info_map	[	item	.	filename	]	=	item	
self	.	_info_list	.	append	(	item	)	

if	item	.	needs_password	(	)	:	
self	.	_needs_password	=	True	
elif	len	(	self	.	_info_list	)	>	0	:	

old	=	self	.	_info_list	[	-	1	]	
old	.	CRC	=	item	.	CRC	
old	.	compress_size	+	=	item	.	compress_size	


if	item	.	type	==	RAR_BLOCK_SUB	and	item	.	filename	==	"str"	:	
if	not	NEED_COMMENTS	:	
pass	
elif	item	.	flags	&	(	RAR_FILE_SPLIT_BEFORE	|	RAR_FILE_SPLIT_AFTER	)	:	
pass	
elif	item	.	flags	&	RAR_FILE_SOLID	:	

cmt	=	self	.	_read_comment_v3	(	item	,	self	.	_password	)	
if	len	(	self	.	_info_list	)	>	0	:	
old	=	self	.	_info_list	[	-	1	]	
old	.	comment	=	cmt	
else	:	

cmt	=	self	.	_read_comment_v3	(	item	,	self	.	_password	)	
self	.	comment	=	cmt	

if	self	.	_info_callback	:	
self	.	_info_callback	(	item	)	


def	_parse	(	self	)	:	
self	.	_fd	=	None	
try	:	
self	.	_parse_real	(	)	
finally	:	
if	self	.	_fd	:	
self	.	_fd	.	close	(	)	
self	.	_fd	=	None	

def	_parse_real	(	self	)	:	
fd	=	XFile	(	self	.	rarfile	)	
self	.	_fd	=	fd	
id	=	fd	.	read	(	len	(	RAR_ID	)	)	
if	id	!=	RAR_ID	:	
if	isinstance	(	self	.	rarfile	,	(	str	,	unicode	)	)	:	
raise	NotRarFile	(	"str"	.	format	(	self	.	rarfile	)	)	
raise	NotRarFile	(	"str"	)	

volume	=	0	
more_vols	=	0	
endarc	=	0	
volfile	=	self	.	rarfile	
self	.	_vol_list	=	[	self	.	rarfile	]	
while	1	:	
if	endarc	:	
h	=	None	
else	:	
h	=	self	.	_parse_header	(	fd	)	
if	not	h	:	
if	more_vols	:	
volume	+	=	1	
fd	.	close	(	)	
try	:	
volfile	=	self	.	_next_volname	(	volfile	)	
fd	=	XFile	(	volfile	)	
except	IOError	:	
self	.	_set_error	(	"str"	,	volfile	)	
break	
self	.	_fd	=	fd	
more_vols	=	0	
endarc	=	0	
self	.	_vol_list	.	append	(	volfile	)	
continue	
break	
h	.	volume	=	volume	
h	.	volume_file	=	volfile	

if	h	.	type	==	RAR_BLOCK_MAIN	and	not	self	.	_main	:	
self	.	_main	=	h	
if	h	.	flags	&	RAR_MAIN_NEWNUMBERING	:	


if	(	h	.	flags	&	RAR_MAIN_FIRSTVOLUME	)	==	0	:	
raise	NeedFirstVolume	(	"str"	)	
if	h	.	flags	&	RAR_MAIN_PASSWORD	:	
self	.	_needs_password	=	True	
if	not	self	.	_password	:	
self	.	_main	=	None	
break	
elif	h	.	type	==	RAR_BLOCK_ENDARC	:	
more_vols	=	h	.	flags	&	RAR_ENDARC_NEXT_VOLUME	
endarc	=	1	
elif	h	.	type	==	RAR_BLOCK_FILE	:	

if	h	.	flags	&	RAR_FILE_SPLIT_AFTER	:	
more_vols	=	1	

if	volume	==	0	and	h	.	flags	&	RAR_FILE_SPLIT_BEFORE	:	
raise	NeedFirstVolume	(	"str"	)	


self	.	_process_entry	(	h	)	


if	h	.	add_size	>	0	:	
fd	.	seek	(	h	.	file_offset	+	h	.	add_size	,	0	)	


_last_aes_key	=	(	None	,	None	,	None	)	
def	_decrypt_header	(	self	,	fd	)	:	
if	not	_have_crypto	:	
raise	NoCrypto	(	"str"	)	
salt	=	fd	.	read	(	8	)	
if	self	.	_last_aes_key	[	0	]	==	salt	:	
key	,	iv	=	self	.	_last_aes_key	[	1	:	]	
else	:	
key	,	iv	=	rar3_s2k	(	self	.	_password	,	salt	)	
self	.	_last_aes_key	=	(	salt	,	key	,	iv	)	
return	HeaderDecrypt	(	fd	,	key	,	iv	)	


def	_parse_header	(	self	,	fd	)	:	
try	:	

if	self	.	_main	and	self	.	_main	.	flags	&	RAR_MAIN_PASSWORD	:	
if	not	self	.	_password	:	
return	
fd	=	self	.	_decrypt_header	(	fd	)	


return	self	.	_parse_block_header	(	fd	)	
except	struct	.	error	:	
self	.	_set_error	(	"str"	)	
return	None	


def	_parse_block_header	(	self	,	fd	)	:	
h	=	RarInfo	(	)	
h	.	header_offset	=	fd	.	tell	(	)	
h	.	comment	=	None	


buf	=	fd	.	read	(	S_BLK_HDR	.	size	)	
if	not	buf	:	
return	None	
t	=	S_BLK_HDR	.	unpack_from	(	buf	)	
h	.	header_crc	,	h	.	type	,	h	.	flags	,	h	.	header_size	=	t	
h	.	header_base	=	S_BLK_HDR	.	size	
pos	=	S_BLK_HDR	.	size	


if	h	.	header_size	>	S_BLK_HDR	.	size	:	
h	.	header_data	=	buf	+	fd	.	read	(	h	.	header_size	-	S_BLK_HDR	.	size	)	
else	:	
h	.	header_data	=	buf	
h	.	file_offset	=	fd	.	tell	(	)	


if	len	(	h	.	header_data	)	!=	h	.	header_size	:	
self	.	_set_error	(	"str"	)	
return	None	


if	h	.	flags	&	RAR_LONG_BLOCK	:	
h	.	add_size	=	S_LONG	.	unpack_from	(	h	.	header_data	,	pos	)	[	0	]	
else	:	
h	.	add_size	=	0	


if	h	.	type	==	RAR_BLOCK_MARK	:	
return	h	
elif	h	.	type	==	RAR_BLOCK_MAIN	:	
h	.	header_base	+	=	6	
if	h	.	flags	&	RAR_MAIN_ENCRYPTVER	:	
h	.	header_base	+	=	1	
if	h	.	flags	&	RAR_MAIN_COMMENT	:	
self	.	_parse_subblocks	(	h	,	h	.	header_base	)	
self	.	comment	=	h	.	comment	
elif	h	.	type	==	RAR_BLOCK_FILE	:	
self	.	_parse_file_header	(	h	,	pos	)	
elif	h	.	type	==	RAR_BLOCK_SUB	:	
self	.	_parse_file_header	(	h	,	pos	)	
h	.	header_base	=	h	.	header_size	
elif	h	.	type	==	RAR_BLOCK_OLD_AUTH	:	
h	.	header_base	+	=	8	
elif	h	.	type	==	RAR_BLOCK_OLD_EXTRA	:	
h	.	header_base	+	=	7	
else	:	
h	.	header_base	=	h	.	header_size	


if	h	.	type	==	RAR_BLOCK_OLD_SUB	:	
crcdat	=	h	.	header_data	[	2	:	]	+	fd	.	read	(	h	.	add_size	)	
else	:	
crcdat	=	h	.	header_data	[	2	:	h	.	header_base	]	

calc_crc	=	crc32	(	crcdat	)	&	0xFFFF	


if	h	.	header_crc	==	calc_crc	:	
return	h	


self	.	_set_error	(	"str"	,	
h	.	type	,	h	.	header_crc	,	calc_crc	,	len	(	crcdat	)	)	


return	None	


def	_parse_file_header	(	self	,	h	,	pos	)	:	
fld	=	S_FILE_HDR	.	unpack_from	(	h	.	header_data	,	pos	)	
h	.	compress_size	=	fld	[	0	]	
h	.	file_size	=	fld	[	1	]	
h	.	host_os	=	fld	[	2	]	
h	.	CRC	=	fld	[	3	]	
h	.	date_time	=	parse_dos_time	(	fld	[	4	]	)	
h	.	extract_version	=	fld	[	5	]	
h	.	compress_type	=	fld	[	6	]	
h	.	name_size	=	fld	[	7	]	
h	.	mode	=	fld	[	8	]	
pos	+	=	S_FILE_HDR	.	size	

if	h	.	flags	&	RAR_FILE_LARGE	:	
h1	=	S_LONG	.	unpack_from	(	h	.	header_data	,	pos	)	[	0	]	
h2	=	S_LONG	.	unpack_from	(	h	.	header_data	,	pos	+	4	)	[	0	]	
h	.	compress_size	|	=	h1	<<	32	
h	.	file_size	|	=	h2	<<	32	
pos	+	=	8	
h	.	add_size	=	h	.	compress_size	

name	=	h	.	header_data	[	pos	:	pos	+	h	.	name_size	]	
pos	+	=	h	.	name_size	
if	h	.	flags	&	RAR_FILE_UNICODE	:	
nul	=	name	.	find	(	ZERO	)	
h	.	orig_filename	=	name	[	:	nul	]	
u	=	UnicodeFilename	(	h	.	orig_filename	,	name	[	nul	+	1	:	]	)	
h	.	filename	=	u	.	decode	(	)	


if	u	.	failed	:	
h	.	filename	=	self	.	_decode	(	h	.	orig_filename	)	
else	:	
h	.	orig_filename	=	name	
h	.	filename	=	self	.	_decode	(	name	)	


if	PATH_SEP	!=	"str"	:	
h	.	filename	=	h	.	filename	.	replace	(	"str"	,	PATH_SEP	)	

if	h	.	flags	&	RAR_FILE_SALT	:	
h	.	salt	=	h	.	header_data	[	pos	:	pos	+	8	]	
pos	+	=	8	
else	:	
h	.	salt	=	None	


if	h	.	flags	&	RAR_FILE_EXTTIME	:	
pos	=	self	.	_parse_ext_time	(	h	,	pos	)	
else	:	
h	.	mtime	=	h	.	atime	=	h	.	ctime	=	h	.	arctime	=	None	


h	.	header_base	=	pos	

if	h	.	flags	&	RAR_FILE_COMMENT	:	
self	.	_parse_subblocks	(	h	,	pos	)	


if	USE_DATETIME	:	
h	.	date_time	=	to_datetime	(	h	.	date_time	)	
h	.	mtime	=	to_datetime	(	h	.	mtime	)	
h	.	atime	=	to_datetime	(	h	.	atime	)	
h	.	ctime	=	to_datetime	(	h	.	ctime	)	
h	.	arctime	=	to_datetime	(	h	.	arctime	)	


if	h	.	mtime	:	
if	USE_DATETIME	:	
h	.	date_time	=	h	.	mtime	
else	:	

h	.	date_time	=	h	.	mtime	[	:	5	]	+	(	int	(	h	.	mtime	[	5	]	)	,	)	

return	pos	


def	_parse_subblocks	(	self	,	h	,	pos	)	:	
hdata	=	h	.	header_data	
while	pos	<	len	(	hdata	)	:	

t	=	S_BLK_HDR	.	unpack_from	(	hdata	,	pos	)	
scrc	,	stype	,	sflags	,	slen	=	t	
pos_next	=	pos	+	slen	
pos	+	=	S_BLK_HDR	.	size	


if	pos_next	<	pos	:	
break	


if	stype	==	RAR_BLOCK_OLD_COMMENT	and	pos	+	S_COMMENT_HDR	.	size	<	=	pos_next	:	
declen	,	ver	,	meth	,	crc	=	S_COMMENT_HDR	.	unpack_from	(	hdata	,	pos	)	
pos	+	=	S_COMMENT_HDR	.	size	
data	=	hdata	[	pos	:	pos_next	]	
cmt	=	rar_decompress	(	ver	,	meth	,	data	,	declen	,	sflags	,	
crc	,	self	.	_password	)	
if	not	self	.	_crc_check	:	
h	.	comment	=	self	.	_decode_comment	(	cmt	)	
elif	crc32	(	cmt	)	&	0xFFFF	==	crc	:	
h	.	comment	=	self	.	_decode_comment	(	cmt	)	

pos	=	pos_next	

def	_parse_ext_time	(	self	,	h	,	pos	)	:	
data	=	h	.	header_data	


flags	=	0	
if	pos	+	2	<	=	len	(	data	)	:	
flags	=	S_SHORT	.	unpack_from	(	data	,	pos	)	[	0	]	
pos	+	=	2	

h	.	mtime	,	pos	=	self	.	_parse_xtime	(	flags	>>	3	*	4	,	data	,	pos	,	h	.	date_time	)	
h	.	ctime	,	pos	=	self	.	_parse_xtime	(	flags	>>	2	*	4	,	data	,	pos	)	
h	.	atime	,	pos	=	self	.	_parse_xtime	(	flags	>>	1	*	4	,	data	,	pos	)	
h	.	arctime	,	pos	=	self	.	_parse_xtime	(	flags	>>	0	*	4	,	data	,	pos	)	
return	pos	

def	_parse_xtime	(	self	,	flag	,	data	,	pos	,	dostime	=	None	)	:	
unit	=	10000000.0	
if	flag	&	8	:	
if	not	dostime	:	
t	=	S_LONG	.	unpack_from	(	data	,	pos	)	[	0	]	
dostime	=	parse_dos_time	(	t	)	
pos	+	=	4	
rem	=	0	
cnt	=	flag	&	3	
for	i	in	range	(	cnt	)	:	
b	=	S_BYTE	.	unpack_from	(	data	,	pos	)	[	0	]	
rem	=	(	b	<<	16	)	|	(	rem	>>	8	)	
pos	+	=	1	
sec	=	dostime	[	5	]	+	rem	/	unit	
if	flag	&	4	:	
sec	+	=	1	
dostime	=	dostime	[	:	5	]	+	(	sec	,	)	
return	dostime	,	pos	


def	_next_volname	(	self	,	volfile	)	:	
if	is_filelike	(	volfile	)	:	
raise	IOError	(	"str"	)	
if	self	.	_main	.	flags	&	RAR_MAIN_NEWNUMBERING	:	
return	self	.	_next_newvol	(	volfile	)	
return	self	.	_next_oldvol	(	volfile	)	


def	_next_newvol	(	self	,	volfile	)	:	
i	=	len	(	volfile	)	-	1	
while	i	>	=	0	:	
if	volfile	[	i	]	>	=	"str"	and	volfile	[	i	]	<	=	"str"	:	
return	self	.	_inc_volname	(	volfile	,	i	)	
i	-	=	1	
raise	BadRarName	(	"str"	+	volfile	)	


def	_next_oldvol	(	self	,	volfile	)	:	

if	volfile	[	-	4	:	]	.	lower	(	)	==	"str"	:	
return	volfile	[	:	-	2	]	+	"str"	
return	self	.	_inc_volname	(	volfile	,	len	(	volfile	)	-	1	)	


def	_inc_volname	(	self	,	volfile	,	i	)	:	
fn	=	list	(	volfile	)	
while	i	>	=	0	:	
if	fn	[	i	]	!=	"str"	:	
fn	[	i	]	=	chr	(	ord	(	fn	[	i	]	)	+	1	)	
break	
fn	[	i	]	=	"str"	
i	-	=	1	
return	"str"	.	join	(	fn	)	

def	_open_clear	(	self	,	inf	)	:	
return	DirectReader	(	self	,	inf	)	



def	_open_hack	(	self	,	inf	,	psw	=	None	)	:	
BSIZE	=	32	*	1024	

size	=	inf	.	compress_size	+	inf	.	header_size	
rf	=	XFile	(	inf	.	volume_file	,	0	)	
rf	.	seek	(	inf	.	header_offset	)	

tmpfd	,	tmpname	=	mkstemp	(	suffix	=	"str"	)	
tmpf	=	os	.	fdopen	(	tmpfd	,	"str"	)	

try	:	

mh	=	S_BLK_HDR	.	pack	(	0x90CF	,	0x73	,	0	,	13	)	+	ZERO	*	(	2	+	4	)	
tmpf	.	write	(	RAR_ID	+	mh	)	
while	size	>	0	:	
if	size	>	BSIZE	:	
buf	=	rf	.	read	(	BSIZE	)	
else	:	
buf	=	rf	.	read	(	size	)	
if	not	buf	:	
raise	BadRarFile	(	"str"	+	inf	.	filename	)	
tmpf	.	write	(	buf	)	
size	-	=	len	(	buf	)	
tmpf	.	close	(	)	
rf	.	close	(	)	
except	:	
rf	.	close	(	)	
tmpf	.	close	(	)	
os	.	unlink	(	tmpname	)	
raise	

return	self	.	_open_unrar	(	tmpname	,	inf	,	psw	,	tmpname	)	

def	_read_comment_v3	(	self	,	inf	,	psw	=	None	)	:	


rf	=	XFile	(	inf	.	volume_file	)	
rf	.	seek	(	inf	.	file_offset	)	
data	=	rf	.	read	(	inf	.	compress_size	)	
rf	.	close	(	)	


cmt	=	rar_decompress	(	inf	.	extract_version	,	inf	.	compress_type	,	data	,	
inf	.	file_size	,	inf	.	flags	,	inf	.	CRC	,	psw	,	inf	.	salt	)	


if	self	.	_crc_check	:	
crc	=	crc32	(	cmt	)	
if	crc	<	0	:	
crc	+	=	(	1	<<	32	)	
if	crc	!=	inf	.	CRC	:	
return	None	

return	self	.	_decode_comment	(	cmt	)	


def	_open_unrar_membuf	(	self	,	memfile	,	inf	,	psw	)	:	
tmpname	=	membuf_tempfile	(	memfile	)	
return	self	.	_open_unrar	(	tmpname	,	inf	,	psw	,	tmpname	)	


def	_open_unrar	(	self	,	rarfile	,	inf	,	psw	=	None	,	tmpfile	=	None	)	:	
if	is_filelike	(	rarfile	)	:	
raise	ValueError	(	"str"	)	
cmd	=	[	UNRAR_TOOL	]	+	list	(	OPEN_ARGS	)	
add_password_arg	(	cmd	,	psw	)	
cmd	.	append	(	"str"	)	
cmd	.	append	(	rarfile	)	


if	not	tmpfile	:	
fn	=	inf	.	filename	
if	PATH_SEP	!=	os	.	sep	:	
fn	=	fn	.	replace	(	PATH_SEP	,	os	.	sep	)	
cmd	.	append	(	fn	)	


return	PipeReader	(	self	,	inf	,	cmd	,	tmpfile	)	

def	_decode	(	self	,	val	)	:	
for	c	in	TRY_ENCODINGS	:	
try	:	
return	val	.	decode	(	c	)	
except	UnicodeError	:	
pass	
return	val	.	decode	(	self	.	_charset	,	"str"	)	

def	_decode_comment	(	self	,	val	)	:	
if	UNICODE_COMMENTS	:	
return	self	.	_decode	(	val	)	
return	val	


def	_extract	(	self	,	fnlist	,	path	=	None	,	psw	=	None	)	:	
cmd	=	[	UNRAR_TOOL	]	+	list	(	EXTRACT_ARGS	)	


psw	=	psw	or	self	.	_password	
add_password_arg	(	cmd	,	psw	)	
cmd	.	append	(	"str"	)	


if	is_filelike	(	self	.	rarfile	)	:	
tmpname	=	membuf_tempfile	(	self	.	rarfile	)	
cmd	.	append	(	tmpname	)	
else	:	
tmpname	=	None	
cmd	.	append	(	self	.	rarfile	)	


for	fn	in	fnlist	:	
if	os	.	sep	!=	PATH_SEP	:	
fn	=	fn	.	replace	(	PATH_SEP	,	os	.	sep	)	
cmd	.	append	(	fn	)	


if	path	is	not	None	:	
cmd	.	append	(	path	+	os	.	sep	)	


try	:	
p	=	custom_popen	(	cmd	)	
output	=	p	.	communicate	(	)	[	0	]	
check_returncode	(	p	,	output	)	
finally	:	
if	tmpname	:	
os	.	unlink	(	tmpname	)	





class	UnicodeFilename	(	object	)	:	


def	__init__	(	self	,	name	,	encdata	)	:	
self	.	std_name	=	bytearray	(	name	)	
self	.	encdata	=	bytearray	(	encdata	)	
self	.	pos	=	self	.	encpos	=	0	
self	.	buf	=	bytearray	(	)	
self	.	failed	=	0	

def	enc_byte	(	self	)	:	
try	:	
c	=	self	.	encdata	[	self	.	encpos	]	
self	.	encpos	+	=	1	
return	c	
except	IndexError	:	
self	.	failed	=	1	
return	0	

def	std_byte	(	self	)	:	
try	:	
return	self	.	std_name	[	self	.	pos	]	
except	IndexError	:	
self	.	failed	=	1	
return	ord	(	"str"	)	

def	put	(	self	,	lo	,	hi	)	:	
self	.	buf	.	append	(	lo	)	
self	.	buf	.	append	(	hi	)	
self	.	pos	+	=	1	

def	decode	(	self	)	:	
hi	=	self	.	enc_byte	(	)	
flagbits	=	0	
while	self	.	encpos	<	len	(	self	.	encdata	)	:	
if	flagbits	==	0	:	
flags	=	self	.	enc_byte	(	)	
flagbits	=	8	
flagbits	-	=	2	
t	=	(	flags	>>	flagbits	)	&	3	
if	t	==	0	:	
self	.	put	(	self	.	enc_byte	(	)	,	0	)	
elif	t	==	1	:	
self	.	put	(	self	.	enc_byte	(	)	,	hi	)	
elif	t	==	2	:	
self	.	put	(	self	.	enc_byte	(	)	,	self	.	enc_byte	(	)	)	
else	:	
n	=	self	.	enc_byte	(	)	
if	n	&	0x80	:	
c	=	self	.	enc_byte	(	)	
for	i	in	range	(	(	n	&	0x7f	)	+	2	)	:	
lo	=	(	self	.	std_byte	(	)	+	c	)	&	0xFF	
self	.	put	(	lo	,	hi	)	
else	:	
for	i	in	range	(	n	+	2	)	:	
self	.	put	(	self	.	std_byte	(	)	,	0	)	
return	self	.	buf	.	decode	(	"str"	,	"str"	)	


class	RarExtFile	(	RawIOBase	)	:	



name	=	None	

def	__init__	(	self	,	rf	,	inf	)	:	
super	(	RarExtFile	,	self	)	.	__init__	(	)	


self	.	name	=	inf	.	filename	
self	.	mode	=	"str"	

self	.	rf	=	rf	
self	.	inf	=	inf	
self	.	crc_check	=	rf	.	_crc_check	
self	.	fd	=	None	
self	.	CRC	=	0	
self	.	remain	=	0	
self	.	returncode	=	0	

self	.	_open	(	)	

def	_open	(	self	)	:	
if	self	.	fd	:	
self	.	fd	.	close	(	)	
self	.	fd	=	None	
self	.	CRC	=	0	
self	.	remain	=	self	.	inf	.	file_size	

def	read	(	self	,	cnt	=	None	)	:	



if	cnt	is	None	or	cnt	<	0	:	
cnt	=	self	.	remain	
elif	cnt	>	self	.	remain	:	
cnt	=	self	.	remain	
if	cnt	==	0	:	
return	EMPTY	


data	=	self	.	_read	(	cnt	)	
if	data	:	
self	.	CRC	=	crc32	(	data	,	self	.	CRC	)	
self	.	remain	-	=	len	(	data	)	
if	len	(	data	)	!=	cnt	:	
raise	BadRarFile	(	"str"	)	


if	not	data	or	self	.	remain	==	0	:	

self	.	_check	(	)	
return	data	

def	_check	(	self	)	:	

if	not	self	.	crc_check	:	
return	
if	self	.	returncode	:	
check_returncode	(	self	,	"str"	)	
if	self	.	remain	!=	0	:	
raise	BadRarFile	(	"str"	)	
crc	=	self	.	CRC	
if	crc	<	0	:	
crc	+	=	(	1	<<	32	)	
if	crc	!=	self	.	inf	.	CRC	:	
raise	BadRarFile	(	"str"	+	self	.	inf	.	filename	)	

def	_read	(	self	,	cnt	)	:	


def	close	(	self	)	:	


super	(	RarExtFile	,	self	)	.	close	(	)	

if	self	.	fd	:	
self	.	fd	.	close	(	)	
self	.	fd	=	None	

def	__del__	(	self	)	:	

self	.	close	(	)	

def	readinto	(	self	,	buf	)	:	


data	=	self	.	read	(	len	(	buf	)	)	
n	=	len	(	data	)	
try	:	
buf	[	:	n	]	=	data	
except	TypeError	:	
import	array	
if	not	isinstance	(	buf	,	array	.	array	)	:	
raise	
buf	[	:	n	]	=	array	.	array	(	buf	.	typecode	,	data	)	
return	n	

def	tell	(	self	)	:	

return	self	.	inf	.	file_size	-	self	.	remain	

def	seek	(	self	,	ofs	,	whence	=	0	)	:	



self	.	crc_check	=	0	

fsize	=	self	.	inf	.	file_size	
cur_ofs	=	self	.	tell	(	)	

if	whence	==	0	:	
new_ofs	=	ofs	
elif	whence	==	1	:	
new_ofs	=	cur_ofs	+	ofs	
elif	whence	==	2	:	
new_ofs	=	fsize	+	ofs	
else	:	
raise	ValueError	(	"str"	)	


if	new_ofs	<	0	:	
new_ofs	=	0	
elif	new_ofs	>	fsize	:	
new_ofs	=	fsize	


if	new_ofs	>	=	cur_ofs	:	
self	.	_skip	(	new_ofs	-	cur_ofs	)	
else	:	



self	.	_open	(	)	
self	.	_skip	(	new_ofs	)	
return	self	.	tell	(	)	

def	_skip	(	self	,	cnt	)	:	

while	cnt	>	0	:	
if	cnt	>	8192	:	
buf	=	self	.	read	(	8192	)	
else	:	
buf	=	self	.	read	(	cnt	)	
if	not	buf	:	
break	
cnt	-	=	len	(	buf	)	

def	readable	(	self	)	:	

return	True	

def	writable	(	self	)	:	

return	False	

def	seekable	(	self	)	:	

return	True	

def	readall	(	self	)	:	


return	self	.	read	(	)	


class	PipeReader	(	RarExtFile	)	:	


def	__init__	(	self	,	rf	,	inf	,	cmd	,	tempfile	=	None	)	:	
self	.	cmd	=	cmd	
self	.	proc	=	None	
self	.	tempfile	=	tempfile	
super	(	PipeReader	,	self	)	.	__init__	(	rf	,	inf	)	

def	_close_proc	(	self	)	:	
if	not	self	.	proc	:	
return	
if	self	.	proc	.	stdout	:	
self	.	proc	.	stdout	.	close	(	)	
if	self	.	proc	.	stdin	:	
self	.	proc	.	stdin	.	close	(	)	
if	self	.	proc	.	stderr	:	
self	.	proc	.	stderr	.	close	(	)	
self	.	proc	.	wait	(	)	
self	.	returncode	=	self	.	proc	.	returncode	
self	.	proc	=	None	

def	_open	(	self	)	:	
super	(	PipeReader	,	self	)	.	_open	(	)	


self	.	_close_proc	(	)	


self	.	returncode	=	0	
self	.	proc	=	custom_popen	(	self	.	cmd	)	
self	.	fd	=	self	.	proc	.	stdout	


if	self	.	proc	.	stdin	:	
self	.	proc	.	stdin	.	close	(	)	

def	_read	(	self	,	cnt	)	:	



data	=	self	.	fd	.	read	(	cnt	)	
if	len	(	data	)	==	cnt	or	not	data	:	
return	data	


buf	=	[	data	]	
cnt	-	=	len	(	data	)	
while	cnt	>	0	:	
data	=	self	.	fd	.	read	(	cnt	)	
if	not	data	:	
break	
cnt	-	=	len	(	data	)	
buf	.	append	(	data	)	
return	EMPTY	.	join	(	buf	)	

def	close	(	self	)	:	


self	.	_close_proc	(	)	
super	(	PipeReader	,	self	)	.	close	(	)	

if	self	.	tempfile	:	
try	:	
os	.	unlink	(	self	.	tempfile	)	
except	OSError	:	
pass	
self	.	tempfile	=	None	

def	readinto	(	self	,	buf	)	:	

cnt	=	len	(	buf	)	
if	cnt	>	self	.	remain	:	
cnt	=	self	.	remain	
vbuf	=	memoryview	(	buf	)	
res	=	got	=	0	
while	got	<	cnt	:	
res	=	self	.	fd	.	readinto	(	vbuf	[	got	:	cnt	]	)	
if	not	res	:	
break	
if	self	.	crc_check	:	
self	.	CRC	=	crc32	(	vbuf	[	got	:	got	+	res	]	,	self	.	CRC	)	
self	.	remain	-	=	res	
got	+	=	res	
return	got	


class	DirectReader	(	RarExtFile	)	:	


def	_open	(	self	)	:	
super	(	DirectReader	,	self	)	.	_open	(	)	

self	.	volfile	=	self	.	inf	.	volume_file	
self	.	fd	=	XFile	(	self	.	volfile	,	0	)	
self	.	fd	.	seek	(	self	.	inf	.	header_offset	,	0	)	
self	.	cur	=	self	.	rf	.	_parse_header	(	self	.	fd	)	
self	.	cur_avail	=	self	.	cur	.	add_size	

def	_skip	(	self	,	cnt	)	:	


while	cnt	>	0	:	

if	self	.	cur_avail	==	0	:	
if	not	self	.	_open_next	(	)	:	
break	


if	cnt	>	self	.	cur_avail	:	
cnt	-	=	self	.	cur_avail	
self	.	remain	-	=	self	.	cur_avail	
self	.	cur_avail	=	0	
else	:	
self	.	fd	.	seek	(	cnt	,	1	)	
self	.	cur_avail	-	=	cnt	
self	.	remain	-	=	cnt	
cnt	=	0	

def	_read	(	self	,	cnt	)	:	


buf	=	[	]	
while	cnt	>	0	:	

if	self	.	cur_avail	==	0	:	
if	not	self	.	_open_next	(	)	:	
break	


if	cnt	>	self	.	cur_avail	:	
data	=	self	.	fd	.	read	(	self	.	cur_avail	)	
else	:	
data	=	self	.	fd	.	read	(	cnt	)	
if	not	data	:	
break	


cnt	-	=	len	(	data	)	
self	.	cur_avail	-	=	len	(	data	)	
buf	.	append	(	data	)	

if	len	(	buf	)	==	1	:	
return	buf	[	0	]	
return	EMPTY	.	join	(	buf	)	

def	_open_next	(	self	)	:	



if	(	self	.	cur	.	flags	&	RAR_FILE_SPLIT_AFTER	)	==	0	:	
return	False	

if	self	.	fd	:	
self	.	fd	.	close	(	)	
self	.	fd	=	None	


self	.	volfile	=	self	.	rf	.	_next_volname	(	self	.	volfile	)	
fd	=	open	(	self	.	volfile	,	"str"	,	0	)	
self	.	fd	=	fd	


while	1	:	
cur	=	self	.	rf	.	_parse_header	(	fd	)	
if	not	cur	:	
raise	BadRarFile	(	"str"	)	
if	cur	.	type	in	(	RAR_BLOCK_MARK	,	RAR_BLOCK_MAIN	)	:	
if	cur	.	add_size	:	
fd	.	seek	(	cur	.	add_size	,	1	)	
continue	
if	cur	.	orig_filename	!=	self	.	inf	.	orig_filename	:	
raise	BadRarFile	(	"str"	)	
self	.	cur	=	cur	
self	.	cur_avail	=	cur	.	add_size	
return	True	

def	readinto	(	self	,	buf	)	:	

got	=	0	
vbuf	=	memoryview	(	buf	)	
while	got	<	len	(	buf	)	:	

if	self	.	cur_avail	==	0	:	
if	not	self	.	_open_next	(	)	:	
break	


cnt	=	len	(	buf	)	-	got	
if	cnt	>	self	.	cur_avail	:	
cnt	=	self	.	cur_avail	


res	=	self	.	fd	.	readinto	(	vbuf	[	got	:	got	+	cnt	]	)	
if	not	res	:	
break	
if	self	.	crc_check	:	
self	.	CRC	=	crc32	(	vbuf	[	got	:	got	+	res	]	,	self	.	CRC	)	
self	.	cur_avail	-	=	res	
self	.	remain	-	=	res	
got	+	=	res	
return	got	


class	HeaderDecrypt	(	object	)	:	

def	__init__	(	self	,	f	,	key	,	iv	)	:	
self	.	f	=	f	
self	.	ciph	=	AES_CBC_Decrypt	(	key	,	iv	)	
self	.	buf	=	EMPTY	

def	tell	(	self	)	:	
return	self	.	f	.	tell	(	)	

def	read	(	self	,	cnt	=	None	)	:	
if	cnt	>	8	*	1024	:	
raise	BadRarFile	(	"str"	)	


if	cnt	<	=	len	(	self	.	buf	)	:	
res	=	self	.	buf	[	:	cnt	]	
self	.	buf	=	self	.	buf	[	cnt	:	]	
return	res	
res	=	self	.	buf	
self	.	buf	=	EMPTY	
cnt	-	=	len	(	res	)	


BLK	=	self	.	ciph	.	block_size	
while	cnt	>	0	:	
enc	=	self	.	f	.	read	(	BLK	)	
if	len	(	enc	)	<	BLK	:	
break	
dec	=	self	.	ciph	.	decrypt	(	enc	)	
if	cnt	>	=	len	(	dec	)	:	
res	+	=	dec	
cnt	-	=	len	(	dec	)	
else	:	
res	+	=	dec	[	:	cnt	]	
self	.	buf	=	dec	[	cnt	:	]	
cnt	=	0	

return	res	


class	XFile	(	object	)	:	
__slots__	=	(	"str"	,	"str"	)	
def	__init__	(	self	,	xfile	,	bufsize	=	1024	)	:	
if	is_filelike	(	xfile	)	:	
self	.	_need_close	=	False	
self	.	_fd	=	xfile	
self	.	_fd	.	seek	(	0	)	
else	:	
self	.	_need_close	=	True	
self	.	_fd	=	open	(	xfile	,	"str"	,	bufsize	)	
def	read	(	self	,	n	=	None	)	:	
return	self	.	_fd	.	read	(	n	)	
def	tell	(	self	)	:	
return	self	.	_fd	.	tell	(	)	
def	seek	(	self	,	ofs	,	whence	=	0	)	:	
return	self	.	_fd	.	seek	(	ofs	,	whence	)	
def	readinto	(	self	,	dst	)	:	
return	self	.	_fd	.	readinto	(	dst	)	
def	close	(	self	)	:	
if	self	.	_need_close	:	
self	.	_fd	.	close	(	)	
def	__enter__	(	self	)	:	
return	self	
def	__exit__	(	self	,	typ	,	val	,	tb	)	:	
self	.	close	(	)	





def	is_filelike	(	obj	)	:	
if	isinstance	(	obj	,	str	)	or	isinstance	(	obj	,	unicode	)	:	
return	False	
res	=	True	
for	a	in	(	"str"	,	"str"	,	"str"	)	:	
res	=	res	and	hasattr	(	obj	,	a	)	
if	not	res	:	
raise	ValueError	(	"str"	)	
return	True	

def	rar3_s2k	(	psw	,	salt	)	:	


seed	=	psw	.	encode	(	"str"	)	+	salt	
iv	=	EMPTY	
h	=	sha1	(	)	
for	i	in	range	(	16	)	:	
for	j	in	range	(	0x4000	)	:	
cnt	=	S_LONG	.	pack	(	i	*	0x4000	+	j	)	
h	.	update	(	seed	+	cnt	[	:	3	]	)	
if	j	==	0	:	
iv	+	=	h	.	digest	(	)	[	19	:	20	]	
key_be	=	h	.	digest	(	)	[	:	16	]	
key_le	=	pack	(	"str"	,	*	unpack	(	"str"	,	key_be	)	)	
return	key_le	,	iv	

def	rar_decompress	(	vers	,	meth	,	data	,	declen	=	0	,	flags	=	0	,	crc	=	0	,	psw	=	None	,	salt	=	None	)	:	



if	meth	==	RAR_M0	and	(	flags	&	RAR_FILE_PASSWORD	)	==	0	:	
return	data	


flags	=	flags	&	(	RAR_FILE_PASSWORD	|	RAR_FILE_SALT	|	RAR_FILE_DICTMASK	)	
flags	|	=	RAR_LONG_BLOCK	


fname	=	b	"str"	
date	=	0	
mode	=	0x20	
fhdr	=	S_FILE_HDR	.	pack	(	len	(	data	)	,	declen	,	RAR_OS_MSDOS	,	crc	,	
date	,	vers	,	meth	,	len	(	fname	)	,	mode	)	
fhdr	+	=	fname	
if	flags	&	RAR_FILE_SALT	:	
if	not	salt	:	
return	EMPTY	
fhdr	+	=	salt	


hlen	=	S_BLK_HDR	.	size	+	len	(	fhdr	)	
hdr	=	S_BLK_HDR	.	pack	(	0	,	RAR_BLOCK_FILE	,	flags	,	hlen	)	+	fhdr	
hcrc	=	crc32	(	hdr	[	2	:	]	)	&	0xFFFF	
hdr	=	S_BLK_HDR	.	pack	(	hcrc	,	RAR_BLOCK_FILE	,	flags	,	hlen	)	+	fhdr	


mh	=	S_BLK_HDR	.	pack	(	0x90CF	,	RAR_BLOCK_MAIN	,	0	,	13	)	+	ZERO	*	(	2	+	4	)	


tmpfd	,	tmpname	=	mkstemp	(	suffix	=	"str"	)	
tmpf	=	os	.	fdopen	(	tmpfd	,	"str"	)	
try	:	
tmpf	.	write	(	RAR_ID	+	mh	+	hdr	+	data	)	
tmpf	.	close	(	)	

cmd	=	[	UNRAR_TOOL	]	+	list	(	OPEN_ARGS	)	
add_password_arg	(	cmd	,	psw	,	(	flags	&	RAR_FILE_PASSWORD	)	)	
cmd	.	append	(	tmpname	)	

p	=	custom_popen	(	cmd	)	
return	p	.	communicate	(	)	[	0	]	
finally	:	
tmpf	.	close	(	)	
os	.	unlink	(	tmpname	)	

def	to_datetime	(	t	)	:	


if	t	is	None	:	
return	None	


year	,	mon	,	day	,	h	,	m	,	xs	=	t	
s	=	int	(	xs	)	
us	=	int	(	1000000	*	(	xs	-	s	)	)	


try	:	
return	datetime	(	year	,	mon	,	day	,	h	,	m	,	s	,	us	)	
except	ValueError	:	
pass	


MDAY	=	(	0	,	31	,	29	,	31	,	30	,	31	,	30	,	31	,	31	,	30	,	31	,	30	,	31	)	
if	mon	<	1	:	mon	=	1	
if	mon	>	12	:	mon	=	12	
if	day	<	1	:	day	=	1	
if	day	>	MDAY	[	mon	]	:	day	=	MDAY	[	mon	]	
if	h	>	23	:	h	=	23	
if	m	>	59	:	m	=	59	
if	s	>	59	:	s	=	59	
if	mon	==	2	and	day	==	29	:	
try	:	
return	datetime	(	year	,	mon	,	day	,	h	,	m	,	s	,	us	)	
except	ValueError	:	
day	=	28	
return	datetime	(	year	,	mon	,	day	,	h	,	m	,	s	,	us	)	

def	parse_dos_time	(	stamp	)	:	


sec	=	stamp	&	0x1F	;	stamp	=	stamp	>>	5	
min	=	stamp	&	0x3F	;	stamp	=	stamp	>>	6	
hr	=	stamp	&	0x1F	;	stamp	=	stamp	>>	5	
day	=	stamp	&	0x1F	;	stamp	=	stamp	>>	5	
mon	=	stamp	&	0x0F	;	stamp	=	stamp	>>	4	
yr	=	(	stamp	&	0x7F	)	+	1980	
return	(	yr	,	mon	,	day	,	hr	,	min	,	sec	*	2	)	

def	custom_popen	(	cmd	)	:	



creationflags	=	0	
if	sys	.	platform	==	"str"	:	
creationflags	=	0x08000000	


try	:	
p	=	Popen	(	cmd	,	bufsize	=	0	,	
stdout	=	PIPE	,	stdin	=	PIPE	,	stderr	=	STDOUT	,	
creationflags	=	creationflags	)	
except	OSError	as	ex	:	
if	ex	.	errno	==	errno	.	ENOENT	:	
raise	RarCannotExec	(	"str"	%	UNRAR_TOOL	)	
raise	
return	p	

def	custom_check	(	cmd	,	ignore_retcode	=	False	)	:	

p	=	custom_popen	(	cmd	)	
out	,	err	=	p	.	communicate	(	)	
if	p	.	returncode	and	not	ignore_retcode	:	
raise	RarExecError	(	"str"	)	
return	out	

def	add_password_arg	(	cmd	,	psw	,	required	=	False	)	:	

if	UNRAR_TOOL	==	ALT_TOOL	:	
return	
if	psw	is	not	None	:	
cmd	.	append	(	"str"	+	psw	)	
else	:	
cmd	.	append	(	"str"	)	

def	check_returncode	(	p	,	out	)	:	


code	=	p	.	returncode	
if	code	==	0	:	
return	


errmap	=	[	None	,	
RarWarning	,	RarFatalError	,	RarCRCError	,	RarLockedArchiveError	,	
RarWriteError	,	RarOpenError	,	RarUserError	,	RarMemoryError	,	
RarCreateError	,	RarNoFilesError	]	
if	UNRAR_TOOL	==	ALT_TOOL	:	
errmap	=	[	None	]	
if	code	>	0	and	code	<	len	(	errmap	)	:	
exc	=	errmap	[	code	]	
elif	code	==	255	:	
exc	=	RarUserBreak	
elif	code	<	0	:	
exc	=	RarSignalExit	
else	:	
exc	=	RarUnknownError	


if	out	:	
msg	=	"str"	%	(	exc	.	__doc__	,	p	.	returncode	,	out	)	
else	:	
msg	=	"str"	%	(	exc	.	__doc__	,	p	.	returncode	)	

raise	exc	(	msg	)	

def	membuf_tempfile	(	memfile	)	:	
memfile	.	seek	(	0	,	0	)	

tmpfd	,	tmpname	=	mkstemp	(	suffix	=	"str"	)	
tmpf	=	os	.	fdopen	(	tmpfd	,	"str"	)	

try	:	
BSIZE	=	32	*	1024	
while	True	:	
buf	=	memfile	.	read	(	BSIZE	)	
if	not	buf	:	
break	
tmpf	.	write	(	buf	)	
tmpf	.	close	(	)	
return	tmpname	
except	:	
tmpf	.	close	(	)	
os	.	unlink	(	tmpname	)	
raise	





try	:	

custom_check	(	[	UNRAR_TOOL	]	,	True	)	
except	RarCannotExec	:	
try	:	

custom_check	(	[	ALT_TOOL	]	+	list	(	ALT_CHECK_ARGS	)	,	True	)	

UNRAR_TOOL	=	ALT_TOOL	
OPEN_ARGS	=	ALT_OPEN_ARGS	
EXTRACT_ARGS	=	ALT_EXTRACT_ARGS	
TEST_ARGS	=	ALT_TEST_ARGS	
except	RarCannotExec	:	

pass	
	