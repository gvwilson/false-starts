

from	__future__	import	absolute_import	,	division	,	print_function	

import	sys	
import	logging	
import	imp	
import	contextlib	
import	types	
import	copy	
import	os	



flog	=	logging	.	getLogger	(	"str"	)	
_formatter	=	logging	.	Formatter	(	logging	.	BASIC_FORMAT	)	
_handler	=	logging	.	StreamHandler	(	)	
_handler	.	setFormatter	(	_formatter	)	
flog	.	addHandler	(	_handler	)	
flog	.	setLevel	(	logging	.	WARN	)	

from	future	.	utils	import	PY2	,	PY3	









REPLACED_MODULES	=	set	(	[	"str"	,	"str"	,	"str"	,	"str"	]	)	









RENAMES	=	{	




"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	















"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	







"str"	:	"str"	,	


















"str"	:	"str"	,	
"str"	:	"str"	,	


"str"	:	"str"	,	
}	






assert	len	(	set	(	RENAMES	.	values	(	)	)	&	set	(	REPLACED_MODULES	)	)	==	0	












MOVES	=	[	(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	



(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	)	,	







]	























class	RenameImport	(	object	)	:	






RENAMER	=	True	

def	__init__	(	self	,	old_to_new	)	:	

self	.	old_to_new	=	old_to_new	
both	=	set	(	old_to_new	.	keys	(	)	)	&	set	(	old_to_new	.	values	(	)	)	
assert	(	len	(	both	)	==	0	and	
len	(	set	(	old_to_new	.	values	(	)	)	)	==	len	(	old_to_new	.	values	(	)	)	)	,	"str"	
self	.	new_to_old	=	dict	(	(	new	,	old	)	for	(	old	,	new	)	in	old_to_new	.	items	(	)	)	

def	find_module	(	self	,	fullname	,	path	=	None	)	:	

new_base_names	=	set	(	[	s	.	split	(	"str"	)	[	0	]	for	s	in	self	.	new_to_old	]	)	

if	fullname	in	new_base_names	:	
return	self	
return	None	

def	load_module	(	self	,	name	)	:	
path	=	None	
if	name	in	sys	.	modules	:	
return	sys	.	modules	[	name	]	
elif	name	in	self	.	new_to_old	:	

oldname	=	self	.	new_to_old	[	name	]	
module	=	self	.	_find_and_load_module	(	oldname	)	

else	:	
module	=	self	.	_find_and_load_module	(	name	)	

sys	.	modules	[	name	]	=	module	
return	module	

def	_find_and_load_module	(	self	,	name	,	path	=	None	)	:	

bits	=	name	.	split	(	"str"	)	
while	len	(	bits	)	>	1	:	

packagename	=	bits	.	pop	(	0	)	
package	=	self	.	_find_and_load_module	(	packagename	,	path	)	
try	:	
path	=	package	.	__path__	
except	AttributeError	:	

flog	.	debug	(	"str"	.	format	(	package	)	)	
if	name	in	sys	.	modules	:	
return	sys	.	modules	[	name	]	
flog	.	debug	(	"str"	)	

name	=	bits	[	0	]	
module_info	=	imp	.	find_module	(	name	,	path	)	
return	imp	.	load_module	(	name	,	*	module_info	)	


class	hooks	(	object	)	:	

def	__enter__	(	self	)	:	

self	.	old_sys_modules	=	copy	.	copy	(	sys	.	modules	)	
self	.	hooks_were_installed	=	detect_hooks	(	)	

install_hooks	(	)	
return	self	

def	__exit__	(	self	,	*	args	)	:	


if	not	self	.	hooks_were_installed	:	
remove_hooks	(	)	




if	PY2	:	
assert	len	(	set	(	RENAMES	.	values	(	)	)	&	set	(	sys	.	builtin_module_names	)	)	==	0	


def	is_py2_stdlib_module	(	m	)	:	

if	PY3	:	
return	False	
if	not	"str"	in	is_py2_stdlib_module	.	__dict__	:	
stdlib_files	=	[	contextlib	.	__file__	,	os	.	__file__	,	copy	.	__file__	]	
stdlib_paths	=	[	os	.	path	.	split	(	f	)	[	0	]	for	f	in	stdlib_files	]	
if	not	len	(	set	(	stdlib_paths	)	)	==	1	:	


flog	.	warn	(	"str"	
"str"	%	stdlib_paths	)	

is_py2_stdlib_module	.	stdlib_path	=	stdlib_paths	[	0	]	

if	m	.	__name__	in	sys	.	builtin_module_names	:	
return	True	

if	hasattr	(	m	,	"str"	)	:	
modpath	=	os	.	path	.	split	(	m	.	__file__	)	
if	(	modpath	[	0	]	.	startswith	(	is_py2_stdlib_module	.	stdlib_path	)	and	
"str"	not	in	modpath	[	0	]	)	:	
return	True	

return	False	


def	scrub_py2_sys_modules	(	)	:	

if	PY3	:	
return	{	}	
scrubbed	=	{	}	
for	modulename	in	REPLACED_MODULES	&	set	(	RENAMES	.	keys	(	)	)	:	
if	not	modulename	in	sys	.	modules	:	
continue	

module	=	sys	.	modules	[	modulename	]	

if	is_py2_stdlib_module	(	module	)	:	
flog	.	debug	(	"str"	.	format	(	modulename	)	)	
scrubbed	[	modulename	]	=	sys	.	modules	[	modulename	]	
del	sys	.	modules	[	modulename	]	
return	scrubbed	


def	scrub_future_sys_modules	(	)	:	

return	{	}	

class	suspend_hooks	(	object	)	:	

def	__enter__	(	self	)	:	
self	.	hooks_were_installed	=	detect_hooks	(	)	
remove_hooks	(	)	

return	self	

def	__exit__	(	self	,	*	args	)	:	
if	self	.	hooks_were_installed	:	
install_hooks	(	)	



def	restore_sys_modules	(	scrubbed	)	:	

clash	=	set	(	sys	.	modules	)	&	set	(	scrubbed	)	
if	len	(	clash	)	!=	0	:	

first	=	list	(	clash	)	[	0	]	
raise	ImportError	(	"str"	
.	format	(	first	)	)	
sys	.	modules	.	update	(	scrubbed	)	


def	install_aliases	(	)	:	

if	PY3	:	
return	


for	(	newmodname	,	newobjname	,	oldmodname	,	oldobjname	)	in	MOVES	:	
__import__	(	newmodname	)	


newmod	=	sys	.	modules	[	newmodname	]	


__import__	(	oldmodname	)	
oldmod	=	sys	.	modules	[	oldmodname	]	

obj	=	getattr	(	oldmod	,	oldobjname	)	
setattr	(	newmod	,	newobjname	,	obj	)	


import	urllib	
from	future	.	backports	.	urllib	import	request	
from	future	.	backports	.	urllib	import	response	
from	future	.	backports	.	urllib	import	parse	
from	future	.	backports	.	urllib	import	error	
from	future	.	backports	.	urllib	import	robotparser	
urllib	.	request	=	request	
urllib	.	response	=	response	
urllib	.	parse	=	parse	
urllib	.	error	=	error	
urllib	.	robotparser	=	robotparser	
sys	.	modules	[	"str"	]	=	request	
sys	.	modules	[	"str"	]	=	response	
sys	.	modules	[	"str"	]	=	parse	
sys	.	modules	[	"str"	]	=	error	
sys	.	modules	[	"str"	]	=	robotparser	


try	:	
import	test	
except	ImportError	:	
pass	
try	:	
from	future	.	moves	.	test	import	support	
except	ImportError	:	
pass	
else	:	
test	.	support	=	support	
sys	.	modules	[	"str"	]	=	support	


try	:	
import	dbm	
except	ImportError	:	
pass	
else	:	
from	future	.	moves	.	dbm	import	dumb	
dbm	.	dumb	=	dumb	
sys	.	modules	[	"str"	]	=	dumb	
try	:	
from	future	.	moves	.	dbm	import	gnu	
except	ImportError	:	
pass	
else	:	
dbm	.	gnu	=	gnu	
sys	.	modules	[	"str"	]	=	gnu	
try	:	
from	future	.	moves	.	dbm	import	ndbm	
except	ImportError	:	
pass	
else	:	
dbm	.	ndbm	=	ndbm	
sys	.	modules	[	"str"	]	=	ndbm	




def	install_hooks	(	)	:	

if	PY3	:	
return	

install_aliases	(	)	

flog	.	debug	(	"str"	.	format	(	sys	.	meta_path	)	)	
flog	.	debug	(	"str"	)	


newhook	=	RenameImport	(	RENAMES	)	
if	not	detect_hooks	(	)	:	
sys	.	meta_path	.	append	(	newhook	)	
flog	.	debug	(	"str"	.	format	(	sys	.	meta_path	)	)	


def	enable_hooks	(	)	:	

install_hooks	(	)	


def	remove_hooks	(	scrub_sys_modules	=	False	)	:	

if	PY3	:	
return	
flog	.	debug	(	"str"	)	

for	i	,	hook	in	list	(	enumerate	(	sys	.	meta_path	)	)	[	:	:	-	1	]	:	
if	hasattr	(	hook	,	"str"	)	:	
del	sys	.	meta_path	[	i	]	





if	scrub_sys_modules	:	
scrub_future_sys_modules	(	)	


def	disable_hooks	(	)	:	

remove_hooks	(	)	


def	detect_hooks	(	)	:	

flog	.	debug	(	"str"	)	
present	=	any	(	[	hasattr	(	hook	,	"str"	)	for	hook	in	sys	.	meta_path	]	)	
if	present	:	
flog	.	debug	(	"str"	)	
else	:	
flog	.	debug	(	"str"	)	
return	present	







if	not	hasattr	(	sys	,	"str"	)	:	
sys	.	py2_modules	=	{	}	

def	cache_py2_modules	(	)	:	

if	len	(	sys	.	py2_modules	)	!=	0	:	
return	
assert	not	detect_hooks	(	)	
import	urllib	
sys	.	py2_modules	[	"str"	]	=	urllib	

import	email	
sys	.	py2_modules	[	"str"	]	=	email	

import	pickle	
sys	.	py2_modules	[	"str"	]	=	pickle	












def	import_	(	module_name	,	backport	=	False	)	:	




import	importlib	

if	PY3	:	
return	__import__	(	module_name	)	
else	:	



if	backport	:	
prefix	=	"str"	
else	:	
prefix	=	"str"	
parts	=	prefix	.	split	(	"str"	)	+	module_name	.	split	(	"str"	)	

modules	=	[	]	
for	i	,	part	in	enumerate	(	parts	)	:	
sofar	=	"str"	.	join	(	parts	[	:	i	+	1	]	)	
modules	.	append	(	importlib	.	import_module	(	sofar	)	)	
for	i	,	part	in	reversed	(	list	(	enumerate	(	parts	)	)	)	:	
if	i	==	0	:	
break	
setattr	(	modules	[	i	-	1	]	,	part	,	modules	[	i	]	)	


return	modules	[	2	]	


def	from_import	(	module_name	,	*	symbol_names	,	*	*	kwargs	)	:	


if	PY3	:	
return	__import__	(	module_name	)	
else	:	
if	"str"	in	kwargs	and	bool	(	kwargs	[	"str"	]	)	:	
prefix	=	"str"	
else	:	
prefix	=	"str"	
parts	=	prefix	.	split	(	"str"	)	+	module_name	.	split	(	"str"	)	
module	=	importlib	.	import_module	(	prefix	+	"str"	+	module_name	)	
output	=	[	getattr	(	module	,	name	)	for	name	in	symbol_names	]	
if	len	(	output	)	==	1	:	
return	output	[	0	]	
else	:	
return	output	


class	exclude_local_folder_imports	(	object	)	:	

def	__init__	(	self	,	*	args	)	:	
assert	len	(	args	)	>	0	
self	.	module_names	=	args	

if	any	(	[	"str"	in	m	for	m	in	self	.	module_names	]	)	:	
raise	NotImplementedError	(	"str"	)	

def	__enter__	(	self	)	:	
self	.	old_sys_path	=	copy	.	copy	(	sys	.	path	)	
self	.	old_sys_modules	=	copy	.	copy	(	sys	.	modules	)	
if	sys	.	version_info	[	0	]	<	3	:	
return	


FUTURE_SOURCE_SUBFOLDERS	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	


for	folder	in	self	.	old_sys_path	:	
if	all	(	[	os	.	path	.	exists	(	os	.	path	.	join	(	folder	,	subfolder	)	)	
for	subfolder	in	FUTURE_SOURCE_SUBFOLDERS	]	)	:	

sys	.	path	.	remove	(	folder	)	


for	m	in	self	.	module_names	:	







try	:	
module	=	__import__	(	m	,	level	=	0	)	
except	ImportError	:	


pass	

def	__exit__	(	self	,	*	args	)	:	

sys	.	path	=	self	.	old_sys_path	
for	m	in	set	(	self	.	old_sys_modules	.	keys	(	)	)	-	set	(	sys	.	modules	.	keys	(	)	)	:	
sys	.	modules	[	m	]	=	self	.	old_sys_modules	[	m	]	

TOP_LEVEL_MODULES	=	[	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	

def	import_top_level_modules	(	)	:	
with	exclude_local_folder_imports	(	*	TOP_LEVEL_MODULES	)	:	
for	m	in	TOP_LEVEL_MODULES	:	
try	:	
__import__	(	m	)	
except	ImportError	:	
pass	
	