

from	core	import	colors	
from	core	.	hakkuframework	import	*	
from	dns	import	resolver	
import	dns	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	
)	)	


changelog	=	"str"	


def	run	(	)	:	
apianswer	=	{	}	

ipresolver	=	resolver	.	Resolver	(	)	
ipresolver	.	timeout	=	float	(	variables	[	"str"	]	[	0	]	)	
ipresolver	.	lifetime	=	float	(	variables	[	"str"	]	[	0	]	)	

variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
sub	=	(	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
try	:	
orgip	=	ipresolver	.	query	(	variables	[	"str"	]	[	0	]	,	"str"	)	
print	(	colors	.	green	+	"str"	+	colors	.	end	)	
print	(	colors	.	green	+	"str"	%	orgip	[	0	]	+	colors	.	end	)	
print	(	colors	.	green	+	"str"	+	colors	.	end	)	
apianswer	[	variables	[	"str"	]	[	0	]	]	=	orgip	
except	(	dns	.	exception	.	Timeout	)	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
except	dns	.	resolver	.	NoAnswer	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	
for	i	in	sub	:	
host	=	i	+	"str"	+	variables	[	"str"	]	[	0	]	
try	:	
query	=	ipresolver	.	query	(	host	,	"str"	)	
if	query	[	0	]	==	orgip	[	0	]	:	
print	(	colors	.	yellow	+	"str"	%	(	host	,	query	[	0	]	)	+	colors	.	end	)	
apianswer	[	host	]	=	query	[	0	]	
else	:	
print	(	colors	.	green	+	"str"	%	(	host	,	query	[	0	]	)	+	colors	.	end	)	
apianswer	[	host	]	=	query	[	0	]	
except	(	dns	.	exception	.	Timeout	)	:	
if	variables	[	"str"	]	[	0	]	!=	"str"	:	
print	(	colors	.	red	+	"str"	%	host	+	colors	.	end	)	
except	dns	.	resolver	.	NoAnswer	:	
if	variables	[	"str"	]	[	0	]	!=	"str"	:	
print	(	colors	.	red	+	"str"	+	colors	.	end	)	

return	apianswer	
	