
import	sys	
from	core	import	colors	
import	urllib	.	request	
import	socket	
from	core	.	hakkuframework	import	*	
import	http	.	client	
import	re	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	

}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


changelog	=	"str"	

def	run	(	)	:	
commonports	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	
if	variables	[	"str"	]	[	0	]	==	"str"	:	
printError	(	"str"	)	
return	
try	:	
try	:	
socket	.	setdefaulttimeout	(	int	(	variables	[	"str"	]	[	0	]	)	)	
except	ValueError	:	
printError	(	"str"	)	
return	
if	variables	[	"str"	]	[	0	]	!=	"str"	and	variables	[	"str"	]	[	0	]	!=	"str"	:	
proxy_support	=	urllib	.	request	.	ProxyHandler	(	{	"str"	:	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	}	)	
opener	=	urllib	.	request	.	build_opener	(	proxy_support	)	
urllib	.	request	.	install_opener	(	opener	)	

html	=	urllib	.	request	.	urlopen	(	"str"	)	.	read	(	)	
printSuccess	(	"str"	)	
if	variables	[	"str"	]	[	0	]	==	"str"	:	
for	port	in	commonports	:	
try	:	
status	=	colors	.	yellow	+	"str"	+	port	+	colors	.	end	
sys	.	stdout	.	write	(	"str"	%	status	)	
sys	.	stdout	.	flush	(	)	
proxy_support	=	urllib	.	request	.	ProxyHandler	(	{	"str"	:	variables	[	"str"	]	[	0	]	+	"str"	+	port	}	)	
opener	=	urllib	.	request	.	build_opener	(	proxy_support	)	
urllib	.	request	.	install_opener	(	opener	)	

html	=	urllib	.	request	.	urlopen	(	"str"	)	.	read	(	)	
print	(	"str"	+	colors	.	green	+	"str"	+	colors	.	end	)	

except	http	.	client	.	BadStatusLine	:	
printSuccess	(	"str"	)	
break	

except	urllib	.	error	.	URLError	:	
pass	

except	socket	.	timeout	:	
pass	

except	ConnectionResetError	:	
print	(	"str"	+	colors	.	green	+	"str"	+	colors	.	end	)	
printSuccess	(	"str"	)	

if	variables	[	"str"	]	[	0	]	==	"str"	:	
ports	=	re	.	sub	(	"str"	,	"str"	,	variables	[	"str"	]	[	0	]	)	.	split	(	)	
for	port	in	range	(	int	(	ports	[	0	]	)	,	int	(	ports	[	1	]	)	)	:	
try	:	
status	=	colors	.	yellow	+	"str"	+	str	(	port	)	+	colors	.	end	
sys	.	stdout	.	write	(	"str"	%	status	)	
sys	.	stdout	.	flush	(	)	
proxy_support	=	urllib	.	request	.	ProxyHandler	(	{	"str"	:	variables	[	"str"	]	[	0	]	+	"str"	+	str	(	port	)	}	)	
opener	=	urllib	.	request	.	build_opener	(	proxy_support	)	
urllib	.	request	.	install_opener	(	opener	)	

html	=	urllib	.	request	.	urlopen	(	"str"	)	.	read	(	)	
print	(	"str"	+	colors	.	green	+	"str"	+	colors	.	end	)	

except	http	.	client	.	BadStatusLine	:	
printSuccess	(	"str"	)	
break	

except	urllib	.	error	.	URLError	:	
pass	

except	socket	.	timeout	:	
pass	

except	ConnectionResetError	:	
print	(	"str"	+	colors	.	green	+	"str"	+	colors	.	end	)	
printSuccess	(	"str"	)	

except	http	.	client	.	BadStatusLine	:	
printSuccess	(	"str"	)	

except	urllib	.	error	.	URLError	:	
printError	(	"str"	)	

except	socket	.	timeout	:	
printError	(	"str"	)	

except	ConnectionResetError	:	
printSuccess	(	"str"	)	
	