from	core	import	getpath	
import	xml	.	etree	.	ElementTree	as	ET	


def	parsemoddb	(	)	:	
tree	=	ET	.	parse	(	getpath	.	core	(	)	+	"str"	)	
root	=	tree	.	getroot	(	)	
return	root	,	tree	
	