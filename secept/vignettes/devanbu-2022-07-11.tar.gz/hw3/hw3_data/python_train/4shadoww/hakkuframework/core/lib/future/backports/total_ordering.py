

import	sys	
if	sys	.	version_info	>	=	(	2	,	7	,	2	)	:	
from	functools	import	total_ordering	
else	:	
def	total_ordering	(	cls	)	:	

convert	=	{	
"str"	:	[	(	"str"	,	lambda	self	,	other	:	not	(	self	<	other	or	self	==	other	)	)	,	
(	"str"	,	lambda	self	,	other	:	self	<	other	or	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	not	self	<	other	)	]	,	
"str"	:	[	(	"str"	,	lambda	self	,	other	:	not	self	<	=	other	or	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	self	<	=	other	and	not	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	not	self	<	=	other	)	]	,	
"str"	:	[	(	"str"	,	lambda	self	,	other	:	not	(	self	>	other	or	self	==	other	)	)	,	
(	"str"	,	lambda	self	,	other	:	self	>	other	or	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	not	self	>	other	)	]	,	
"str"	:	[	(	"str"	,	lambda	self	,	other	:	(	not	self	>	=	other	)	or	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	self	>	=	other	and	not	self	==	other	)	,	
(	"str"	,	lambda	self	,	other	:	not	self	>	=	other	)	]	
}	
roots	=	set	(	dir	(	cls	)	)	&	set	(	convert	)	
if	not	roots	:	
raise	ValueError	(	"str"	)	
root	=	max	(	roots	)	
for	opname	,	opfunc	in	convert	[	root	]	:	
if	opname	not	in	roots	:	
opfunc	.	__name__	=	opname	
opfunc	.	__doc__	=	getattr	(	int	,	opname	)	.	__doc__	
setattr	(	cls	,	opname	,	opfunc	)	
return	cls	
	