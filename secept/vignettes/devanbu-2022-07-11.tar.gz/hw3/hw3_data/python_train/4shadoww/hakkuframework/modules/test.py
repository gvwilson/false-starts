

from	core	.	hakkuframework	import	*	



conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	,	

"str"	:	"str"	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	0	,	"str"	]	)	,	
)	)	

customcommands	=	{	
"str"	:	"str"	
}	


changelog	=	"str"	

def	run	(	)	:	
print	(	variables	[	"str"	]	[	0	]	)	
print	(	variables	[	"str"	]	[	1	]	)	
printWarning	(	"str"	)	
return	variables	

def	test	(	args	)	:	
return	"str"	
	