

from	core	.	hakkuframework	import	*	
import	os	
import	subprocess	
import	time	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	1	,	
"str"	:	[	"str"	,	"str"	,	"str"	]	

}	



variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


customcommands	=	{	
"str"	:	"str"	
}	


changelog	=	"str"	

def	run	(	)	:	
printInfo	(	"str"	)	
try	:	
for	i	in	range	(	1	,	10000	)	:	
xterm_1	=	"str"	%	(	variables	[	"str"	]	[	0	]	,	variables	[	"str"	]	[	0	]	,	variables	[	"str"	]	[	0	]	)	
subprocess	.	Popen	(	xterm_1	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
time	.	sleep	(	3	)	
except	(	OSError	)	:	
printError	(	"str"	)	


def	scan	(	args	)	:	
os	.	system	(	"str"	)	
	