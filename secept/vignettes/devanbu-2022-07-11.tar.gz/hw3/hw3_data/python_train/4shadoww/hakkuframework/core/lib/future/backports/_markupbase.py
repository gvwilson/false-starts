

import	re	

_declname_match	=	re	.	compile	(	"str"	)	.	match	
_declstringlit_match	=	re	.	compile	(	"str"	)	.	match	
_commentclose	=	re	.	compile	(	"str"	)	
_markedsectionclose	=	re	.	compile	(	"str"	)	




_msmarkedsectionclose	=	re	.	compile	(	"str"	)	

del	re	


class	ParserBase	(	object	)	:	


def	__init__	(	self	)	:	
if	self	.	__class__	is	ParserBase	:	
raise	RuntimeError	(	
"str"	)	

def	error	(	self	,	message	)	:	
raise	NotImplementedError	(	
"str"	)	

def	reset	(	self	)	:	
self	.	lineno	=	1	
self	.	offset	=	0	

def	getpos	(	self	)	:	

return	self	.	lineno	,	self	.	offset	





def	updatepos	(	self	,	i	,	j	)	:	
if	i	>	=	j	:	
return	j	
rawdata	=	self	.	rawdata	
nlines	=	rawdata	.	count	(	"str"	,	i	,	j	)	
if	nlines	:	
self	.	lineno	=	self	.	lineno	+	nlines	
pos	=	rawdata	.	rindex	(	"str"	,	i	,	j	)	
self	.	offset	=	j	-	(	pos	+	1	)	
else	:	
self	.	offset	=	self	.	offset	+	j	-	i	
return	j	

_decl_otherchars	=	"str"	


def	parse_declaration	(	self	,	i	)	:	










rawdata	=	self	.	rawdata	
j	=	i	+	2	
assert	rawdata	[	i	:	j	]	==	"str"	,	"str"	
if	rawdata	[	j	:	j	+	1	]	==	"str"	:	

return	j	+	1	
if	rawdata	[	j	:	j	+	1	]	in	(	"str"	,	"str"	)	:	


return	-	1	

n	=	len	(	rawdata	)	
if	rawdata	[	j	:	j	+	2	]	==	"str"	:	

return	self	.	parse_comment	(	i	)	
elif	rawdata	[	j	]	==	"str"	:	




return	self	.	parse_marked_section	(	i	)	
else	:	
decltype	,	j	=	self	.	_scan_name	(	j	,	i	)	
if	j	<	0	:	
return	j	
if	decltype	==	"str"	:	
self	.	_decl_otherchars	=	"str"	
while	j	<	n	:	
c	=	rawdata	[	j	]	
if	c	==	"str"	:	

data	=	rawdata	[	i	+	2	:	j	]	
if	decltype	==	"str"	:	
self	.	handle_decl	(	data	)	
else	:	




self	.	unknown_decl	(	data	)	
return	j	+	1	
if	c	in	"str"	:	
m	=	_declstringlit_match	(	rawdata	,	j	)	
if	not	m	:	
return	-	1	
j	=	m	.	end	(	)	
elif	c	in	"str"	:	
name	,	j	=	self	.	_scan_name	(	j	,	i	)	
elif	c	in	self	.	_decl_otherchars	:	
j	=	j	+	1	
elif	c	==	"str"	:	

if	decltype	==	"str"	:	
j	=	self	.	_parse_doctype_subset	(	j	+	1	,	i	)	
elif	decltype	in	set	(	[	"str"	,	"str"	,	"str"	,	"str"	]	)	:	




self	.	error	(	"str"	%	decltype	)	
else	:	
self	.	error	(	"str"	)	
else	:	
self	.	error	(	
"str"	%	rawdata	[	j	]	)	
if	j	<	0	:	
return	j	
return	-	1	



def	parse_marked_section	(	self	,	i	,	report	=	1	)	:	
rawdata	=	self	.	rawdata	
assert	rawdata	[	i	:	i	+	3	]	==	"str"	,	"str"	
sectName	,	j	=	self	.	_scan_name	(	i	+	3	,	i	)	
if	j	<	0	:	
return	j	
if	sectName	in	set	(	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	)	:	

match	=	_markedsectionclose	.	search	(	rawdata	,	i	+	3	)	
elif	sectName	in	set	(	[	"str"	,	"str"	,	"str"	]	)	:	

match	=	_msmarkedsectionclose	.	search	(	rawdata	,	i	+	3	)	
else	:	
self	.	error	(	"str"	%	rawdata	[	i	+	3	:	j	]	)	
if	not	match	:	
return	-	1	
if	report	:	
j	=	match	.	start	(	0	)	
self	.	unknown_decl	(	rawdata	[	i	+	3	:	j	]	)	
return	match	.	end	(	0	)	


def	parse_comment	(	self	,	i	,	report	=	1	)	:	
rawdata	=	self	.	rawdata	
if	rawdata	[	i	:	i	+	4	]	!=	"str"	:	
self	.	error	(	"str"	)	
match	=	_commentclose	.	search	(	rawdata	,	i	+	4	)	
if	not	match	:	
return	-	1	
if	report	:	
j	=	match	.	start	(	0	)	
self	.	handle_comment	(	rawdata	[	i	+	4	:	j	]	)	
return	match	.	end	(	0	)	



def	_parse_doctype_subset	(	self	,	i	,	declstartpos	)	:	
rawdata	=	self	.	rawdata	
n	=	len	(	rawdata	)	
j	=	i	
while	j	<	n	:	
c	=	rawdata	[	j	]	
if	c	==	"str"	:	
s	=	rawdata	[	j	:	j	+	2	]	
if	s	==	"str"	:	

return	-	1	
if	s	!=	"str"	:	
self	.	updatepos	(	declstartpos	,	j	+	1	)	
self	.	error	(	"str"	%	s	)	
if	(	j	+	2	)	==	n	:	

return	-	1	
if	(	j	+	4	)	>	n	:	

return	-	1	
if	rawdata	[	j	:	j	+	4	]	==	"str"	:	
j	=	self	.	parse_comment	(	j	,	report	=	0	)	
if	j	<	0	:	
return	j	
continue	
name	,	j	=	self	.	_scan_name	(	j	+	2	,	declstartpos	)	
if	j	==	-	1	:	
return	-	1	
if	name	not	in	set	(	[	"str"	,	"str"	,	"str"	,	"str"	]	)	:	
self	.	updatepos	(	declstartpos	,	j	+	2	)	
self	.	error	(	
"str"	%	name	)	

meth	=	getattr	(	self	,	"str"	+	name	)	
j	=	meth	(	j	,	declstartpos	)	
if	j	<	0	:	
return	j	
elif	c	==	"str"	:	

if	(	j	+	1	)	==	n	:	

return	-	1	
s	,	j	=	self	.	_scan_name	(	j	+	1	,	declstartpos	)	
if	j	<	0	:	
return	j	
if	rawdata	[	j	]	==	"str"	:	
j	=	j	+	1	
elif	c	==	"str"	:	
j	=	j	+	1	
while	j	<	n	and	rawdata	[	j	]	.	isspace	(	)	:	
j	=	j	+	1	
if	j	<	n	:	
if	rawdata	[	j	]	==	"str"	:	
return	j	
self	.	updatepos	(	declstartpos	,	j	)	
self	.	error	(	"str"	)	
else	:	
return	-	1	
elif	c	.	isspace	(	)	:	
j	=	j	+	1	
else	:	
self	.	updatepos	(	declstartpos	,	j	)	
self	.	error	(	"str"	%	c	)	

return	-	1	


def	_parse_doctype_element	(	self	,	i	,	declstartpos	)	:	
name	,	j	=	self	.	_scan_name	(	i	,	declstartpos	)	
if	j	==	-	1	:	
return	-	1	

rawdata	=	self	.	rawdata	
if	"str"	in	rawdata	[	j	:	]	:	
return	rawdata	.	find	(	"str"	,	j	)	+	1	
return	-	1	


def	_parse_doctype_attlist	(	self	,	i	,	declstartpos	)	:	
rawdata	=	self	.	rawdata	
name	,	j	=	self	.	_scan_name	(	i	,	declstartpos	)	
c	=	rawdata	[	j	:	j	+	1	]	
if	c	==	"str"	:	
return	-	1	
if	c	==	"str"	:	
return	j	+	1	
while	1	:	


name	,	j	=	self	.	_scan_name	(	j	,	declstartpos	)	
if	j	<	0	:	
return	j	
c	=	rawdata	[	j	:	j	+	1	]	
if	c	==	"str"	:	
return	-	1	
if	c	==	"str"	:	

if	"str"	in	rawdata	[	j	:	]	:	
j	=	rawdata	.	find	(	"str"	,	j	)	+	1	
else	:	
return	-	1	
while	rawdata	[	j	:	j	+	1	]	.	isspace	(	)	:	
j	=	j	+	1	
if	not	rawdata	[	j	:	]	:	

return	-	1	
else	:	
name	,	j	=	self	.	_scan_name	(	j	,	declstartpos	)	
c	=	rawdata	[	j	:	j	+	1	]	
if	not	c	:	
return	-	1	
if	c	in	"str"	:	
m	=	_declstringlit_match	(	rawdata	,	j	)	
if	m	:	
j	=	m	.	end	(	)	
else	:	
return	-	1	
c	=	rawdata	[	j	:	j	+	1	]	
if	not	c	:	
return	-	1	
if	c	==	"str"	:	
if	rawdata	[	j	:	]	==	"str"	:	

return	-	1	
name	,	j	=	self	.	_scan_name	(	j	+	1	,	declstartpos	)	
if	j	<	0	:	
return	j	
c	=	rawdata	[	j	:	j	+	1	]	
if	not	c	:	
return	-	1	
if	c	==	"str"	:	

return	j	+	1	


def	_parse_doctype_notation	(	self	,	i	,	declstartpos	)	:	
name	,	j	=	self	.	_scan_name	(	i	,	declstartpos	)	
if	j	<	0	:	
return	j	
rawdata	=	self	.	rawdata	
while	1	:	
c	=	rawdata	[	j	:	j	+	1	]	
if	not	c	:	

return	-	1	
if	c	==	"str"	:	
return	j	+	1	
if	c	in	"str"	:	
m	=	_declstringlit_match	(	rawdata	,	j	)	
if	not	m	:	
return	-	1	
j	=	m	.	end	(	)	
else	:	
name	,	j	=	self	.	_scan_name	(	j	,	declstartpos	)	
if	j	<	0	:	
return	j	


def	_parse_doctype_entity	(	self	,	i	,	declstartpos	)	:	
rawdata	=	self	.	rawdata	
if	rawdata	[	i	:	i	+	1	]	==	"str"	:	
j	=	i	+	1	
while	1	:	
c	=	rawdata	[	j	:	j	+	1	]	
if	not	c	:	
return	-	1	
if	c	.	isspace	(	)	:	
j	=	j	+	1	
else	:	
break	
else	:	
j	=	i	
name	,	j	=	self	.	_scan_name	(	j	,	declstartpos	)	
if	j	<	0	:	
return	j	
while	1	:	
c	=	self	.	rawdata	[	j	:	j	+	1	]	
if	not	c	:	
return	-	1	
if	c	in	"str"	:	
m	=	_declstringlit_match	(	rawdata	,	j	)	
if	m	:	
j	=	m	.	end	(	)	
else	:	
return	-	1	
elif	c	==	"str"	:	
return	j	+	1	
else	:	
name	,	j	=	self	.	_scan_name	(	j	,	declstartpos	)	
if	j	<	0	:	
return	j	



def	_scan_name	(	self	,	i	,	declstartpos	)	:	
rawdata	=	self	.	rawdata	
n	=	len	(	rawdata	)	
if	i	==	n	:	
return	None	,	-	1	
m	=	_declname_match	(	rawdata	,	i	)	
if	m	:	
s	=	m	.	group	(	)	
name	=	s	.	strip	(	)	
if	(	i	+	len	(	s	)	)	==	n	:	
return	None	,	-	1	
return	name	.	lower	(	)	,	m	.	end	(	)	
else	:	
self	.	updatepos	(	declstartpos	,	i	)	
self	.	error	(	"str"	
%	rawdata	[	declstartpos	:	declstartpos	+	20	]	)	


def	unknown_decl	(	self	,	data	)	:	
pass	
	