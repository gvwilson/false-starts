

purple	=	"str"	
blue	=	"str"	
green	=	"str"	
cyan	=	"str"	
yellow	=	"str"	
red	=	"str"	
end	=	"str"	
bold	=	"str"	
uline	=	"str"	
	