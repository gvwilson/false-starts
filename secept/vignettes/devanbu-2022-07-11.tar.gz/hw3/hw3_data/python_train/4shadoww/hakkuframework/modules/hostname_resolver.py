

from	core	.	hakkuframework	import	*	
import	socket	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


changelog	=	"str"	

def	run	(	)	:	
try	:	
querly	=	socket	.	gethostbyaddr	(	variables	[	"str"	]	[	0	]	)	
printSuccess	(	"str"	+	querly	[	0	]	)	
return	querly	[	0	]	
except	(	socket	.	herror	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
except	(	socket	.	gaierror	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
	