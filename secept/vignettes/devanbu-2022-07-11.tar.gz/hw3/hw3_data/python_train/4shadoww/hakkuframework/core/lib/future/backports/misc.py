

from	__future__	import	absolute_import	

import	subprocess	
from	math	import	ceil	as	oldceil	
from	collections	import	Mapping	,	MutableMapping	

from	operator	import	itemgetter	as	_itemgetter	,	eq	as	_eq	
import	sys	
import	heapq	as	_heapq	
from	_weakref	import	proxy	as	_proxy	
from	itertools	import	repeat	as	_repeat	,	chain	as	_chain	,	starmap	as	_starmap	
from	socket	import	getaddrinfo	,	SOCK_STREAM	,	error	,	socket	

from	future	.	utils	import	iteritems	,	itervalues	,	PY26	,	PY3	


def	ceil	(	x	)	:	

return	int	(	oldceil	(	x	)	)	






from	itertools	import	islice	

if	PY3	:	
try	:	
from	_thread	import	get_ident	
except	ImportError	:	
from	_dummy_thread	import	get_ident	
else	:	
try	:	
from	thread	import	get_ident	
except	ImportError	:	
from	dummy_thread	import	get_ident	


def	recursive_repr	(	fillvalue	=	"str"	)	:	
"str"	

def	decorating_function	(	user_function	)	:	
repr_running	=	set	(	)	

def	wrapper	(	self	)	:	
key	=	id	(	self	)	,	get_ident	(	)	
if	key	in	repr_running	:	
return	fillvalue	
repr_running	.	add	(	key	)	
try	:	
result	=	user_function	(	self	)	
finally	:	
repr_running	.	discard	(	key	)	
return	result	


wrapper	.	__module__	=	getattr	(	user_function	,	"str"	)	
wrapper	.	__doc__	=	getattr	(	user_function	,	"str"	)	
wrapper	.	__name__	=	getattr	(	user_function	,	"str"	)	
wrapper	.	__annotations__	=	getattr	(	user_function	,	"str"	,	{	}	)	
return	wrapper	

return	decorating_function	






class	_Link	(	object	)	:	
__slots__	=	"str"	,	"str"	,	"str"	,	"str"	

class	OrderedDict	(	dict	)	:	
"str"	













def	__init__	(	*	args	,	*	*	kwds	)	:	

if	not	args	:	
raise	TypeError	(	"str"	
"str"	)	
self	=	args	[	0	]	
args	=	args	[	1	:	]	
if	len	(	args	)	>	1	:	
raise	TypeError	(	"str"	%	len	(	args	)	)	
try	:	
self	.	__root	
except	AttributeError	:	
self	.	__hardroot	=	_Link	(	)	
self	.	__root	=	root	=	_proxy	(	self	.	__hardroot	)	
root	.	prev	=	root	.	next	=	root	
self	.	__map	=	{	}	
self	.	__update	(	*	args	,	*	*	kwds	)	

def	__setitem__	(	self	,	key	,	value	,	
dict_setitem	=	dict	.	__setitem__	,	proxy	=	_proxy	,	Link	=	_Link	)	:	
"str"	


if	key	not	in	self	:	
self	.	__map	[	key	]	=	link	=	Link	(	)	
root	=	self	.	__root	
last	=	root	.	prev	
link	.	prev	,	link	.	next	,	link	.	key	=	last	,	root	,	key	
last	.	next	=	link	
root	.	prev	=	proxy	(	link	)	
dict_setitem	(	self	,	key	,	value	)	

def	__delitem__	(	self	,	key	,	dict_delitem	=	dict	.	__delitem__	)	:	
"str"	


dict_delitem	(	self	,	key	)	
link	=	self	.	__map	.	pop	(	key	)	
link_prev	=	link	.	prev	
link_next	=	link	.	next	
link_prev	.	next	=	link_next	
link_next	.	prev	=	link_prev	

def	__iter__	(	self	)	:	
"str"	

root	=	self	.	__root	
curr	=	root	.	next	
while	curr	is	not	root	:	
yield	curr	.	key	
curr	=	curr	.	next	

def	__reversed__	(	self	)	:	
"str"	

root	=	self	.	__root	
curr	=	root	.	prev	
while	curr	is	not	root	:	
yield	curr	.	key	
curr	=	curr	.	prev	

def	clear	(	self	)	:	
"str"	
root	=	self	.	__root	
root	.	prev	=	root	.	next	=	root	
self	.	__map	.	clear	(	)	
dict	.	clear	(	self	)	

def	popitem	(	self	,	last	=	True	)	:	

if	not	self	:	
raise	KeyError	(	"str"	)	
root	=	self	.	__root	
if	last	:	
link	=	root	.	prev	
link_prev	=	link	.	prev	
link_prev	.	next	=	root	
root	.	prev	=	link_prev	
else	:	
link	=	root	.	next	
link_next	=	link	.	next	
root	.	next	=	link_next	
link_next	.	prev	=	root	
key	=	link	.	key	
del	self	.	__map	[	key	]	
value	=	dict	.	pop	(	self	,	key	)	
return	key	,	value	

def	move_to_end	(	self	,	key	,	last	=	True	)	:	

link	=	self	.	__map	[	key	]	
link_prev	=	link	.	prev	
link_next	=	link	.	next	
link_prev	.	next	=	link_next	
link_next	.	prev	=	link_prev	
root	=	self	.	__root	
if	last	:	
last	=	root	.	prev	
link	.	prev	=	last	
link	.	next	=	root	
last	.	next	=	root	.	prev	=	link	
else	:	
first	=	root	.	next	
link	.	prev	=	root	
link	.	next	=	first	
root	.	next	=	first	.	prev	=	link	

def	__sizeof__	(	self	)	:	
sizeof	=	sys	.	getsizeof	
n	=	len	(	self	)	+	1	
size	=	sizeof	(	self	.	__dict__	)	
size	+	=	sizeof	(	self	.	__map	)	*	2	
size	+	=	sizeof	(	self	.	__hardroot	)	*	n	
size	+	=	sizeof	(	self	.	__root	)	*	n	
return	size	

update	=	__update	=	MutableMapping	.	update	
keys	=	MutableMapping	.	keys	
values	=	MutableMapping	.	values	
items	=	MutableMapping	.	items	
__ne__	=	MutableMapping	.	__ne__	

__marker	=	object	(	)	

def	pop	(	self	,	key	,	default	=	__marker	)	:	

if	key	in	self	:	
result	=	self	[	key	]	
del	self	[	key	]	
return	result	
if	default	is	self	.	__marker	:	
raise	KeyError	(	key	)	
return	default	

def	setdefault	(	self	,	key	,	default	=	None	)	:	
"str"	
if	key	in	self	:	
return	self	[	key	]	
self	[	key	]	=	default	
return	default	

@recursive_repr	(	)	
def	__repr__	(	self	)	:	
"str"	
if	not	self	:	
return	"str"	%	(	self	.	__class__	.	__name__	,	)	
return	"str"	%	(	self	.	__class__	.	__name__	,	list	(	self	.	items	(	)	)	)	

def	__reduce__	(	self	)	:	
"str"	
inst_dict	=	vars	(	self	)	.	copy	(	)	
for	k	in	vars	(	OrderedDict	(	)	)	:	
inst_dict	.	pop	(	k	,	None	)	
return	self	.	__class__	,	(	)	,	inst_dict	or	None	,	None	,	iter	(	self	.	items	(	)	)	

def	copy	(	self	)	:	
"str"	
return	self	.	__class__	(	self	)	

@classmethod	
def	fromkeys	(	cls	,	iterable	,	value	=	None	)	:	

self	=	cls	(	)	
for	key	in	iterable	:	
self	[	key	]	=	value	
return	self	

def	__eq__	(	self	,	other	)	:	

if	isinstance	(	other	,	OrderedDict	)	:	
return	dict	.	__eq__	(	self	,	other	)	and	all	(	map	(	_eq	,	self	,	other	)	)	
return	dict	.	__eq__	(	self	,	other	)	




try	:	
from	operator	import	itemgetter	
from	heapq	import	nlargest	
except	ImportError	:	
pass	





def	_count_elements	(	mapping	,	iterable	)	:	
"str"	
mapping_get	=	mapping	.	get	
for	elem	in	iterable	:	
mapping	[	elem	]	=	mapping_get	(	elem	,	0	)	+	1	

class	Counter	(	dict	)	:	








def	__init__	(	*	args	,	*	*	kwds	)	:	

if	not	args	:	
raise	TypeError	(	"str"	
"str"	)	
self	=	args	[	0	]	
args	=	args	[	1	:	]	
if	len	(	args	)	>	1	:	
raise	TypeError	(	"str"	%	len	(	args	)	)	
super	(	Counter	,	self	)	.	__init__	(	)	
self	.	update	(	*	args	,	*	*	kwds	)	

def	__missing__	(	self	,	key	)	:	
"str"	

return	0	

def	most_common	(	self	,	n	=	None	)	:	


if	n	is	None	:	
return	sorted	(	self	.	items	(	)	,	key	=	_itemgetter	(	1	)	,	reverse	=	True	)	
return	_heapq	.	nlargest	(	n	,	self	.	items	(	)	,	key	=	_itemgetter	(	1	)	)	

def	elements	(	self	)	:	


return	_chain	.	from_iterable	(	_starmap	(	_repeat	,	self	.	items	(	)	)	)	



@classmethod	
def	fromkeys	(	cls	,	iterable	,	v	=	None	)	:	


raise	NotImplementedError	(	
"str"	)	

def	update	(	*	args	,	*	*	kwds	)	:	








if	not	args	:	
raise	TypeError	(	"str"	
"str"	)	
self	=	args	[	0	]	
args	=	args	[	1	:	]	
if	len	(	args	)	>	1	:	
raise	TypeError	(	"str"	%	len	(	args	)	)	
iterable	=	args	[	0	]	if	args	else	None	
if	iterable	is	not	None	:	
if	isinstance	(	iterable	,	Mapping	)	:	
if	self	:	
self_get	=	self	.	get	
for	elem	,	count	in	iterable	.	items	(	)	:	
self	[	elem	]	=	count	+	self_get	(	elem	,	0	)	
else	:	
super	(	Counter	,	self	)	.	update	(	iterable	)	
else	:	
_count_elements	(	self	,	iterable	)	
if	kwds	:	
self	.	update	(	kwds	)	

def	subtract	(	*	args	,	*	*	kwds	)	:	

if	not	args	:	
raise	TypeError	(	"str"	
"str"	)	
self	=	args	[	0	]	
args	=	args	[	1	:	]	
if	len	(	args	)	>	1	:	
raise	TypeError	(	"str"	%	len	(	args	)	)	
iterable	=	args	[	0	]	if	args	else	None	
if	iterable	is	not	None	:	
self_get	=	self	.	get	
if	isinstance	(	iterable	,	Mapping	)	:	
for	elem	,	count	in	iterable	.	items	(	)	:	
self	[	elem	]	=	self_get	(	elem	,	0	)	-	count	
else	:	
for	elem	in	iterable	:	
self	[	elem	]	=	self_get	(	elem	,	0	)	-	1	
if	kwds	:	
self	.	subtract	(	kwds	)	

def	copy	(	self	)	:	
"str"	
return	self	.	__class__	(	self	)	

def	__reduce__	(	self	)	:	
return	self	.	__class__	,	(	dict	(	self	)	,	)	

def	__delitem__	(	self	,	elem	)	:	
"str"	
if	elem	in	self	:	
super	(	Counter	,	self	)	.	__delitem__	(	elem	)	

def	__repr__	(	self	)	:	
if	not	self	:	
return	"str"	%	self	.	__class__	.	__name__	
try	:	
items	=	"str"	.	join	(	map	(	"str"	.	__mod__	,	self	.	most_common	(	)	)	)	
return	"str"	%	(	self	.	__class__	.	__name__	,	items	)	
except	TypeError	:	

return	"str"	.	format	(	self	.	__class__	.	__name__	,	dict	(	self	)	)	










def	__add__	(	self	,	other	)	:	

if	not	isinstance	(	other	,	Counter	)	:	
return	NotImplemented	
result	=	Counter	(	)	
for	elem	,	count	in	self	.	items	(	)	:	
newcount	=	count	+	other	[	elem	]	
if	newcount	>	0	:	
result	[	elem	]	=	newcount	
for	elem	,	count	in	other	.	items	(	)	:	
if	elem	not	in	self	and	count	>	0	:	
result	[	elem	]	=	count	
return	result	

def	__sub__	(	self	,	other	)	:	

if	not	isinstance	(	other	,	Counter	)	:	
return	NotImplemented	
result	=	Counter	(	)	
for	elem	,	count	in	self	.	items	(	)	:	
newcount	=	count	-	other	[	elem	]	
if	newcount	>	0	:	
result	[	elem	]	=	newcount	
for	elem	,	count	in	other	.	items	(	)	:	
if	elem	not	in	self	and	count	<	0	:	
result	[	elem	]	=	0	-	count	
return	result	

def	__or__	(	self	,	other	)	:	

if	not	isinstance	(	other	,	Counter	)	:	
return	NotImplemented	
result	=	Counter	(	)	
for	elem	,	count	in	self	.	items	(	)	:	
other_count	=	other	[	elem	]	
newcount	=	other_count	if	count	<	other_count	else	count	
if	newcount	>	0	:	
result	[	elem	]	=	newcount	
for	elem	,	count	in	other	.	items	(	)	:	
if	elem	not	in	self	and	count	>	0	:	
result	[	elem	]	=	count	
return	result	

def	__and__	(	self	,	other	)	:	

if	not	isinstance	(	other	,	Counter	)	:	
return	NotImplemented	
result	=	Counter	(	)	
for	elem	,	count	in	self	.	items	(	)	:	
other_count	=	other	[	elem	]	
newcount	=	count	if	count	<	other_count	else	other_count	
if	newcount	>	0	:	
result	[	elem	]	=	newcount	
return	result	

def	__pos__	(	self	)	:	
"str"	
return	self	+	Counter	(	)	

def	__neg__	(	self	)	:	

return	Counter	(	)	-	self	

def	_keep_positive	(	self	)	:	

nonpositive	=	[	elem	for	elem	,	count	in	self	.	items	(	)	if	not	count	>	0	]	
for	elem	in	nonpositive	:	
del	self	[	elem	]	
return	self	

def	__iadd__	(	self	,	other	)	:	

for	elem	,	count	in	other	.	items	(	)	:	
self	[	elem	]	+	=	count	
return	self	.	_keep_positive	(	)	

def	__isub__	(	self	,	other	)	:	

for	elem	,	count	in	other	.	items	(	)	:	
self	[	elem	]	-	=	count	
return	self	.	_keep_positive	(	)	

def	__ior__	(	self	,	other	)	:	

for	elem	,	other_count	in	other	.	items	(	)	:	
count	=	self	[	elem	]	
if	other_count	>	count	:	
self	[	elem	]	=	other_count	
return	self	.	_keep_positive	(	)	

def	__iand__	(	self	,	other	)	:	

for	elem	,	count	in	self	.	items	(	)	:	
other_count	=	other	[	elem	]	
if	other_count	<	count	:	
self	[	elem	]	=	other_count	
return	self	.	_keep_positive	(	)	


def	check_output	(	*	popenargs	,	*	*	kwargs	)	:	


if	"str"	in	kwargs	:	
raise	ValueError	(	"str"	)	
process	=	subprocess	.	Popen	(	stdout	=	subprocess	.	PIPE	,	*	popenargs	,	*	*	kwargs	)	
output	,	unused_err	=	process	.	communicate	(	)	
retcode	=	process	.	poll	(	)	
if	retcode	:	
cmd	=	kwargs	.	get	(	"str"	)	
if	cmd	is	None	:	
cmd	=	popenargs	[	0	]	
raise	subprocess	.	CalledProcessError	(	retcode	,	cmd	)	
return	output	


def	count	(	start	=	0	,	step	=	1	)	:	

while	True	:	
yield	start	
start	+	=	step	








class	ChainMap	(	MutableMapping	)	:	


def	__init__	(	self	,	*	maps	)	:	

self	.	maps	=	list	(	maps	)	or	[	{	}	]	

def	__missing__	(	self	,	key	)	:	
raise	KeyError	(	key	)	

def	__getitem__	(	self	,	key	)	:	
for	mapping	in	self	.	maps	:	
try	:	
return	mapping	[	key	]	
except	KeyError	:	
pass	
return	self	.	__missing__	(	key	)	

def	get	(	self	,	key	,	default	=	None	)	:	
return	self	[	key	]	if	key	in	self	else	default	

def	__len__	(	self	)	:	
return	len	(	set	(	)	.	union	(	*	self	.	maps	)	)	

def	__iter__	(	self	)	:	
return	iter	(	set	(	)	.	union	(	*	self	.	maps	)	)	

def	__contains__	(	self	,	key	)	:	
return	any	(	key	in	m	for	m	in	self	.	maps	)	

def	__bool__	(	self	)	:	
return	any	(	self	.	maps	)	


__nonzero__	=	__bool__	

@recursive_repr	(	)	
def	__repr__	(	self	)	:	
return	"str"	.	format	(	
self	,	"str"	.	join	(	map	(	repr	,	self	.	maps	)	)	)	

@classmethod	
def	fromkeys	(	cls	,	iterable	,	*	args	)	:	
"str"	
return	cls	(	dict	.	fromkeys	(	iterable	,	*	args	)	)	

def	copy	(	self	)	:	
"str"	
return	self	.	__class__	(	self	.	maps	[	0	]	.	copy	(	)	,	*	self	.	maps	[	1	:	]	)	

__copy__	=	copy	

def	new_child	(	self	,	m	=	None	)	:	

if	m	is	None	:	
m	=	{	}	
return	self	.	__class__	(	m	,	*	self	.	maps	)	

@property	
def	parents	(	self	)	:	
"str"	
return	self	.	__class__	(	*	self	.	maps	[	1	:	]	)	

def	__setitem__	(	self	,	key	,	value	)	:	
self	.	maps	[	0	]	[	key	]	=	value	

def	__delitem__	(	self	,	key	)	:	
try	:	
del	self	.	maps	[	0	]	[	key	]	
except	KeyError	:	
raise	KeyError	(	"str"	.	format	(	key	)	)	

def	popitem	(	self	)	:	
"str"	
try	:	
return	self	.	maps	[	0	]	.	popitem	(	)	
except	KeyError	:	
raise	KeyError	(	"str"	)	

def	pop	(	self	,	key	,	*	args	)	:	
"str"	
try	:	
return	self	.	maps	[	0	]	.	pop	(	key	,	*	args	)	
except	KeyError	:	
raise	KeyError	(	"str"	.	format	(	key	)	)	

def	clear	(	self	)	:	
"str"	
self	.	maps	[	0	]	.	clear	(	)	



from	socket	import	_GLOBAL_DEFAULT_TIMEOUT	



def	create_connection	(	address	,	timeout	=	_GLOBAL_DEFAULT_TIMEOUT	,	
source_address	=	None	)	:	


host	,	port	=	address	
err	=	None	
for	res	in	getaddrinfo	(	host	,	port	,	0	,	SOCK_STREAM	)	:	
af	,	socktype	,	proto	,	canonname	,	sa	=	res	
sock	=	None	
try	:	
sock	=	socket	(	af	,	socktype	,	proto	)	
if	timeout	is	not	_GLOBAL_DEFAULT_TIMEOUT	:	
sock	.	settimeout	(	timeout	)	
if	source_address	:	
sock	.	bind	(	source_address	)	
sock	.	connect	(	sa	)	
return	sock	

except	error	as	_	:	
err	=	_	
if	sock	is	not	None	:	
sock	.	close	(	)	

if	err	is	not	None	:	
raise	err	
else	:	
raise	error	(	"str"	)	


def	cmp_to_key	(	mycmp	)	:	

class	K	(	object	)	:	
__slots__	=	[	"str"	]	
def	__init__	(	self	,	obj	,	*	args	)	:	
self	.	obj	=	obj	
def	__lt__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	<	0	
def	__gt__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	>	0	
def	__eq__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	==	0	
def	__le__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	<	=	0	
def	__ge__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	>	=	0	
def	__ne__	(	self	,	other	)	:	
return	mycmp	(	self	.	obj	,	other	.	obj	)	!=	0	
def	__hash__	(	self	)	:	
raise	TypeError	(	"str"	)	
return	K	


_OrderedDict	=	OrderedDict	
_Counter	=	Counter	
_check_output	=	check_output	
_count	=	count	
_ceil	=	ceil	
__count_elements	=	_count_elements	
_recursive_repr	=	recursive_repr	
_ChainMap	=	ChainMap	
_create_connection	=	create_connection	
_cmp_to_key	=	cmp_to_key	



if	sys	.	version_info	>	=	(	2	,	7	)	:	
from	collections	import	OrderedDict	,	Counter	
from	itertools	import	count	
from	functools	import	cmp_to_key	
try	:	
from	subprocess	import	check_output	
except	ImportError	:	

pass	
from	socket	import	create_connection	

if	sys	.	version_info	>	=	(	3	,	0	)	:	
from	math	import	ceil	
from	collections	import	_count_elements	

if	sys	.	version_info	>	=	(	3	,	3	)	:	
from	reprlib	import	recursive_repr	
from	collections	import	ChainMap	
	