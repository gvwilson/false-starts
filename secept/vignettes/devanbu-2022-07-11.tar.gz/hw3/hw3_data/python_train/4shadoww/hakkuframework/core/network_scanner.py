import	sys	
import	os	
from	scapy	.	all	import	srp	,	Ether	,	ARP	,	conf	
from	datetime	import	datetime	
import	traceback	
from	core	import	colors	
from	core	.	messages	import	*	

try	:	
import	netifaces	
except	ImportError	:	
print	(	colors	.	red	+	"str"	)	
traceback	.	print_exc	(	)	
print	(	colors	.	end	)	


def	scan	(	)	:	
try	:	
print	(	colors	.	blue	+	"str"	+	colors	.	end	)	
for	iface	in	netifaces	.	interfaces	(	)	:	
print	(	colors	.	yellow	+	iface	+	colors	.	end	)	
print	(	"str"	)	
interface	=	input	(	colors	.	purple	+	"str"	+	colors	.	end	)	
try	:	
ip	=	netifaces	.	ifaddresses	(	interface	)	[	2	]	[	0	]	[	"str"	]	
except	(	ValueError	,	KeyError	)	:	
printError	(	"str"	)	
return	
ips	=	ip	+	"str"	
printInfo	(	"str"	,	start	=	"str"	)	
print	(	colors	.	blue	+	"str"	+	colors	.	end	)	

start_time	=	datetime	.	now	(	)	

conf	.	verb	=	0	
try	:	
ans	,	unans	=	srp	(	Ether	(	dst	=	"str"	)	/	ARP	(	pdst	=	ips	)	,	timeout	=	2	,	iface	=	interface	,	inter	=	0.1	)	
except	PermissionError	:	
printError	(	"str"	)	
return	

for	snd	,	rcv	in	ans	:	
print	(	rcv	.	sprintf	(	colors	.	yellow	+	"str"	+	colors	.	end	)	)	
stop_time	=	datetime	.	now	(	)	
total_time	=	stop_time	-	start_time	
printSuccess	(	"str"	,	start	=	"str"	)	
printSuccess	(	"str"	+	str	(	total_time	)	)	
except	KeyboardInterrupt	:	
printInfo	(	"str"	,	start	=	"str"	)	
	