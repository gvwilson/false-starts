
from	core	.	hakkuframework	import	*	
from	core	import	colors	
import	socket	
import	subprocess	
from	datetime	import	datetime	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	1	,	"str"	]	)	,	
(	"str"	,	[	100	,	"str"	]	)	,	
)	)	


changelog	=	"str"	

def	run	(	)	:	
open_ports	=	[	]	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
try	:	
targetip	=	socket	.	gethostbyname	(	variables	[	"str"	]	[	0	]	)	
except	(	socket	.	gaierror	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	

socket	.	setdefaulttimeout	(	0.5	)	

print	(	colors	.	blue	+	"str"	*	60	)	
print	(	"str"	,	targetip	)	
print	(	"str"	*	60	+	colors	.	end	)	

t1	=	datetime	.	now	(	)	

end	=	variables	[	"str"	]	[	0	]	+	1	

try	:	
for	port	in	range	(	int	(	variables	[	"str"	]	[	0	]	)	,	int	(	end	)	)	:	
sock	=	socket	.	socket	(	socket	.	AF_INET	,	socket	.	SOCK_STREAM	)	
result	=	sock	.	connect_ex	(	(	targetip	,	port	)	)	
if	result	==	0	:	
print	(	colors	.	green	+	"str"	.	format	(	port	)	+	colors	.	end	)	
open_ports	.	append	(	port	)	
else	:	
print	(	colors	.	red	+	"str"	.	format	(	port	)	+	colors	.	end	)	

sock	.	close	(	)	

except	(	socket	.	gaierror	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
except	(	socket	.	error	)	:	
printError	(	colors	.	red	+	"str"	+	colors	.	end	)	
return	ModuleError	(	"str"	)	
except	(	ValueError	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	


t2	=	datetime	.	now	(	)	


total	=	t2	-	t1	


printInfo	(	"str"	+	str	(	total	)	)	
return	open_ports	
	