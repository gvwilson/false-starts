

from	core	.	hakkuframework	import	*	
from	core	import	colors	
import	smtplib	
from	email	.	mime	.	multipart	import	MIMEMultipart	
from	email	.	mime	.	text	import	MIMEText	
import	socket	
import	random	
from	string	import	ascii_lowercase	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	587	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	1	,	"str"	]	)	,	
(	"str"	,	[	0	,	"str"	]	)	,	
(	"str"	,	[	0	,	"str"	]	)	,	
(	"str"	,	[	1	,	"str"	]	)	,	
(	"str"	,	[	1	,	"str"	]	)	,	
)	)	

s_nouns	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
p_nouns	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
s_verbs	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
p_verbs	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
infinitives	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	

option_notes	=	colors	.	yellow	+	"str"	+	colors	.	end	

changelog	=	"str"	

def	run	(	)	:	
fromaddr	=	variables	[	"str"	]	[	0	]	
toaddr	=	variables	[	"str"	]	[	0	]	
msg	=	MIMEMultipart	(	)	
msg	[	"str"	]	=	variables	[	"str"	]	[	0	]	
msg	[	"str"	]	=	variables	[	"str"	]	[	0	]	
msg	[	"str"	]	=	variables	[	"str"	]	[	0	]	

domains	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
letters	=	ascii_lowercase	[	:	12	]	

body	=	variables	[	"str"	]	[	0	]	
msg	.	attach	(	MIMEText	(	body	,	"str"	)	)	
try	:	
server	=	smtplib	.	SMTP	(	variables	[	"str"	]	[	0	]	,	int	(	variables	[	"str"	]	[	0	]	)	)	
except	(	ValueError	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
except	socket	.	gaierror	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
except	(	ConnectionRefusedError	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
except	(	TimeoutError	)	:	
printError	(	"str"	)	
return	ModuleError	(	"str"	)	
if	int	(	variables	[	"str"	]	[	0	]	)	==	1	:	
server	.	starttls	(	)	
if	int	(	variables	[	"str"	]	[	0	]	)	==	1	:	
server	.	login	(	fromaddr	,	variables	[	"str"	]	[	0	]	)	
text	=	msg	.	as_string	(	)	

if	int	(	variables	[	"str"	]	[	0	]	)	>	0	:	
for	i	in	range	(	0	,	int	(	variables	[	"str"	]	[	0	]	)	)	:	
if	int	(	variables	[	"str"	]	[	0	]	==	1	)	:	
fakemail	=	generate_random_email	(	)	
msg	[	"str"	]	=	fakemail	[	0	]	
if	int	(	variables	[	"str"	]	[	0	]	)	==	1	:	
list0	=	random	.	choice	(	s_nouns	)	,	random	.	choice	(	s_verbs	)	,	random	.	choice	(	s_nouns	)	.	lower	(	)	or	random	.	choice	(	p_nouns	)	.	lower	(	)	,	random	.	choice	(	infinitives	)	
words	=	"str"	.	join	(	list0	)	
msg	.	attach	(	MIMEText	(	words	,	"str"	)	)	
server	.	sendmail	(	fromaddr	,	toaddr	,	text	)	
printSuccess	(	"str"	)	

if	int	(	variables	[	"str"	]	[	0	]	)	==	0	:	
printInfo	(	"str"	)	
while	True	:	
if	int	(	variables	[	"str"	]	[	0	]	)	==	1	:	
fakemail	=	generate_random_email	(	)	
msg	[	"str"	]	=	fakemail	[	0	]	
if	int	(	variables	[	"str"	]	[	0	]	)	==	1	:	
list0	=	random	.	choice	(	s_nouns	)	,	random	.	choice	(	s_verbs	)	,	random	.	choice	(	s_nouns	)	.	lower	(	)	or	random	.	choice	(	p_nouns	)	.	lower	(	)	,	random	.	choice	(	infinitives	)	
words	=	"str"	.	join	(	list0	)	
msg	.	attach	(	MIMEText	(	words	,	"str"	)	)	
server	.	sendmail	(	fromaddr	,	toaddr	,	text	)	
printSuccess	(	"str"	)	
server	.	quit	(	)	

def	get_random_domain	(	domains	)	:	
return	random	.	choice	(	domains	)	

def	get_random_name	(	letters	,	length	)	:	
return	"str"	.	join	(	random	.	choice	(	letters	)	for	i	in	range	(	length	)	)	

def	generate_random_email	(	)	:	
return	[	get_random_name	(	letters	,	8	)	+	"str"	+	get_random_domain	(	domains	)	for	i	in	range	(	1	)	]	
	