commands	=	[	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	
]	

mcommands	=	[	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	,	
[	"str"	,	"str"	]	
]	
	