from	prettytable	import	PrettyTable	
from	core	import	colors	

def	generateTable	(	hlist	)	:	
t	=	PrettyTable	(	[	colors	.	bold	+	"str"	+	colors	.	end	,	"str"	,	colors	.	bold	+	"str"	+	colors	.	end	]	)	
t	.	add_row	(	[	"str"	,	"str"	,	"str"	]	)	
t	.	align	=	"str"	
t	.	valing	=	"str"	
t	.	border	=	False	

for	val	in	hlist	:	
t	.	add_row	(	[	val	[	0	]	,	"str"	,	val	[	1	]	]	)	

return	t	

def	generatemTable	(	hlist1	,	hlist2	)	:	
t	=	PrettyTable	(	[	colors	.	bold	+	"str"	+	colors	.	end	,	"str"	,	colors	.	bold	+	"str"	+	colors	.	end	]	)	
t	.	add_row	(	[	"str"	,	"str"	,	"str"	]	)	
t	.	align	=	"str"	
t	.	valing	=	"str"	
t	.	border	=	False	

for	val	in	hlist1	:	
t	.	add_row	(	[	val	[	0	]	,	"str"	,	val	[	1	]	]	)	

for	key	,	val	in	hlist2	.	items	(	)	:	
t	.	add_row	(	[	key	,	"str"	,	val	]	)	

return	t	
	