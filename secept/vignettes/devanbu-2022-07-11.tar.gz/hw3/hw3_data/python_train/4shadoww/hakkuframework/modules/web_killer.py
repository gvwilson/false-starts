

from	core	.	hakkuframework	import	*	
import	time	
import	os	
import	subprocess	
from	core	import	colors	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	[	"str"	]	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	

)	)	


changelog	=	"str"	


def	run	(	)	:	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
variables	[	"str"	]	[	0	]	=	variables	[	"str"	]	[	0	]	.	replace	(	"str"	,	"str"	)	
printInfo	(	"str"	)	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
time	.	sleep	(	2	)	
command_1	=	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	
subprocess	.	Popen	(	command_1	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
line_3	=	colors	.	green	+	"str"	
press_ak	=	input	(	line_3	)	
os	.	system	(	"str"	)	
printInfo	(	"str"	)	
	