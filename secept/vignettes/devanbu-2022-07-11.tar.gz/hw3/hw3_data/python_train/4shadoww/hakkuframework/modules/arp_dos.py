
from	core	.	hakkuframework	import	*	
from	core	import	colors	
import	subprocess	
from	time	import	sleep	
import	os	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	1	,	
"str"	:	False	,	
"str"	:	[	"str"	,	"str"	]	

}	



variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	



help_notes	=	colors	.	red	+	"str"	+	colors	.	end	


changelog	=	"str"	

def	run	(	)	:	
printInfo	(	"str"	)	
command	=	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	"str"	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	
subprocess	.	Popen	(	command	,	stderr	=	subprocess	.	PIPE	,	stdout	=	subprocess	.	PIPE	,	shell	=	True	)	
line_4	=	colors	.	blue	+	"str"	+	colors	.	end	
fin	=	input	(	line_4	)	
os	.	system	(	"str"	)	
printInfo	(	"str"	)	
	