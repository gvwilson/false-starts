

from	core	.	hakkuframework	import	*	
from	core	import	colors	
import	subprocess	
import	os	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	1	,	
"str"	:	[	"str"	,	"str"	,	"str"	,	"str"	]	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


option_notes	=	colors	.	green	+	"str"	+	colors	.	end	+	"str"	


changelog	=	"str"	

def	run	(	)	:	
if	variables	[	"str"	]	[	0	]	==	"str"	:	
selected_sniffer	=	"str"	+	variables	[	"str"	]	[	0	]	
elif	variables	[	"str"	]	[	0	]	==	"str"	:	
selected_sniffer	=	"str"	+	variables	[	"str"	]	[	0	]	
elif	variables	[	"str"	]	[	0	]	==	"str"	:	
selected_sniffer	=	"str"	+	variables	[	"str"	]	[	0	]	
elif	variables	[	"str"	]	[	0	]	==	"str"	:	
selected_sniffer	=	"str"	+	variables	[	"str"	]	[	0	]	
else	:	
printError	(	"str"	)	

if	variables	[	"str"	]	[	0	]	==	"str"	:	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
printInfo	(	"str"	)	
subprocess	.	Popen	(	"str"	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
printInfo	(	"str"	)	
arp_spoofing1	=	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	
subprocess	.	Popen	(	arp_spoofing1	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
arp_spoofing2	=	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	+	"str"	+	variables	[	"str"	]	[	0	]	
subprocess	.	Popen	(	arp_spoofing2	,	stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	shell	=	True	)	
printInfo	(	"str"	)	
printInfo	(	"str"	)	
os	.	system	(	selected_sniffer	)	
	