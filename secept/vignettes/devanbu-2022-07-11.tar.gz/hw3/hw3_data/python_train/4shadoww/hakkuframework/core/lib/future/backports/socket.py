




from	__future__	import	unicode_literals	
from	__future__	import	print_function	
from	__future__	import	division	
from	__future__	import	absolute_import	
from	future	.	builtins	import	super	

import	_socket	
from	_socket	import	*	

import	os	,	sys	,	io	

try	:	
import	errno	
except	ImportError	:	
errno	=	None	
EBADF	=	getattr	(	errno	,	"str"	,	9	)	
EAGAIN	=	getattr	(	errno	,	"str"	,	11	)	
EWOULDBLOCK	=	getattr	(	errno	,	"str"	,	11	)	

__all__	=	[	"str"	,	"str"	]	
__all__	.	extend	(	os	.	_get_exports_list	(	_socket	)	)	


_realsocket	=	socket	


if	sys	.	platform	.	lower	(	)	.	startswith	(	"str"	)	:	
errorTab	=	{	}	
errorTab	[	10004	]	=	"str"	
errorTab	[	10009	]	=	"str"	
errorTab	[	10013	]	=	"str"	
errorTab	[	10014	]	=	"str"	
errorTab	[	10022	]	=	"str"	
errorTab	[	10035	]	=	"str"	
errorTab	[	10036	]	=	"str"	
errorTab	[	10048	]	=	"str"	
errorTab	[	10054	]	=	"str"	
errorTab	[	10058	]	=	"str"	
errorTab	[	10060	]	=	"str"	
errorTab	[	10061	]	=	"str"	
errorTab	[	10063	]	=	"str"	
errorTab	[	10064	]	=	"str"	
errorTab	[	10065	]	=	"str"	
__all__	.	append	(	"str"	)	


class	socket	(	_socket	.	socket	)	:	



__slots__	=	[	"str"	,	"str"	,	"str"	]	

def	__init__	(	self	,	family	=	AF_INET	,	type	=	SOCK_STREAM	,	proto	=	0	,	fileno	=	None	)	:	
if	fileno	is	None	:	
_socket	.	socket	.	__init__	(	self	,	family	,	type	,	proto	)	
else	:	
_socket	.	socket	.	__init__	(	self	,	family	,	type	,	proto	,	fileno	)	
self	.	_io_refs	=	0	
self	.	_closed	=	False	

def	__enter__	(	self	)	:	
return	self	

def	__exit__	(	self	,	*	args	)	:	
if	not	self	.	_closed	:	
self	.	close	(	)	

def	__repr__	(	self	)	:	

s	=	_socket	.	socket	.	__repr__	(	self	)	
if	s	.	startswith	(	"str"	)	:	
s	=	"str"	%	(	self	.	__class__	.	__module__	,	
self	.	__class__	.	__name__	,	
getattr	(	self	,	"str"	,	False	)	and	"str"	or	"str"	,	
s	[	7	:	]	)	
return	s	

def	__getstate__	(	self	)	:	
raise	TypeError	(	"str"	)	

def	dup	(	self	)	:	

fd	=	dup	(	self	.	fileno	(	)	)	
sock	=	self	.	__class__	(	self	.	family	,	self	.	type	,	self	.	proto	,	fileno	=	fd	)	
sock	.	settimeout	(	self	.	gettimeout	(	)	)	
return	sock	

def	accept	(	self	)	:	

fd	,	addr	=	self	.	_accept	(	)	
sock	=	socket	(	self	.	family	,	self	.	type	,	self	.	proto	,	fileno	=	fd	)	



if	getdefaulttimeout	(	)	is	None	and	self	.	gettimeout	(	)	:	
sock	.	setblocking	(	True	)	
return	sock	,	addr	

def	makefile	(	self	,	mode	=	"str"	,	buffering	=	None	,	*	*	_3to2kwargs	)	:	

if	"str"	in	_3to2kwargs	:	newline	=	_3to2kwargs	[	"str"	]	;	del	_3to2kwargs	[	"str"	]	
else	:	newline	=	None	
if	"str"	in	_3to2kwargs	:	errors	=	_3to2kwargs	[	"str"	]	;	del	_3to2kwargs	[	"str"	]	
else	:	errors	=	None	
if	"str"	in	_3to2kwargs	:	encoding	=	_3to2kwargs	[	"str"	]	;	del	_3to2kwargs	[	"str"	]	
else	:	encoding	=	None	
for	c	in	mode	:	
if	c	not	in	(	"str"	,	"str"	,	"str"	)	:	
raise	ValueError	(	"str"	)	
writing	=	"str"	in	mode	
reading	=	"str"	in	mode	or	not	writing	
assert	reading	or	writing	
binary	=	"str"	in	mode	
rawmode	=	"str"	
if	reading	:	
rawmode	+	=	"str"	
if	writing	:	
rawmode	+	=	"str"	
raw	=	SocketIO	(	self	,	rawmode	)	
self	.	_io_refs	+	=	1	
if	buffering	is	None	:	
buffering	=	-	1	
if	buffering	<	0	:	
buffering	=	io	.	DEFAULT_BUFFER_SIZE	
if	buffering	==	0	:	
if	not	binary	:	
raise	ValueError	(	"str"	)	
return	raw	
if	reading	and	writing	:	
buffer	=	io	.	BufferedRWPair	(	raw	,	raw	,	buffering	)	
elif	reading	:	
buffer	=	io	.	BufferedReader	(	raw	,	buffering	)	
else	:	
assert	writing	
buffer	=	io	.	BufferedWriter	(	raw	,	buffering	)	
if	binary	:	
return	buffer	
text	=	io	.	TextIOWrapper	(	buffer	,	encoding	,	errors	,	newline	)	
text	.	mode	=	mode	
return	text	

def	_decref_socketios	(	self	)	:	
if	self	.	_io_refs	>	0	:	
self	.	_io_refs	-	=	1	
if	self	.	_closed	:	
self	.	close	(	)	

def	_real_close	(	self	,	_ss	=	_socket	.	socket	)	:	

_ss	.	close	(	self	)	

def	close	(	self	)	:	

self	.	_closed	=	True	
if	self	.	_io_refs	<	=	0	:	
self	.	_real_close	(	)	

def	detach	(	self	)	:	

self	.	_closed	=	True	
return	super	(	)	.	detach	(	)	

def	fromfd	(	fd	,	family	,	type	,	proto	=	0	)	:	

nfd	=	dup	(	fd	)	
return	socket	(	family	,	type	,	proto	,	nfd	)	

if	hasattr	(	_socket	.	socket	,	"str"	)	:	
def	fromshare	(	info	)	:	

return	socket	(	0	,	0	,	0	,	info	)	

if	hasattr	(	_socket	,	"str"	)	:	

def	socketpair	(	family	=	None	,	type	=	SOCK_STREAM	,	proto	=	0	)	:	

if	family	is	None	:	
try	:	
family	=	AF_UNIX	
except	NameError	:	
family	=	AF_INET	
a	,	b	=	_socket	.	socketpair	(	family	,	type	,	proto	)	
a	=	socket	(	family	,	type	,	proto	,	a	.	detach	(	)	)	
b	=	socket	(	family	,	type	,	proto	,	b	.	detach	(	)	)	
return	a	,	b	


_blocking_errnos	=	set	(	[	EAGAIN	,	EWOULDBLOCK	]	)	

class	SocketIO	(	io	.	RawIOBase	)	:	












def	__init__	(	self	,	sock	,	mode	)	:	
if	mode	not	in	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	:	
raise	ValueError	(	"str"	%	mode	)	
io	.	RawIOBase	.	__init__	(	self	)	
self	.	_sock	=	sock	
if	"str"	not	in	mode	:	
mode	+	=	"str"	
self	.	_mode	=	mode	
self	.	_reading	=	"str"	in	mode	
self	.	_writing	=	"str"	in	mode	
self	.	_timeout_occurred	=	False	

def	readinto	(	self	,	b	)	:	

self	.	_checkClosed	(	)	
self	.	_checkReadable	(	)	
if	self	.	_timeout_occurred	:	
raise	IOError	(	"str"	)	
while	True	:	
try	:	
return	self	.	_sock	.	recv_into	(	b	)	
except	timeout	:	
self	.	_timeout_occurred	=	True	
raise	


except	error	as	e	:	
if	e	.	args	[	0	]	in	_blocking_errnos	:	
return	None	
raise	

def	write	(	self	,	b	)	:	

self	.	_checkClosed	(	)	
self	.	_checkWritable	(	)	
try	:	
return	self	.	_sock	.	send	(	b	)	
except	error	as	e	:	

if	e	.	args	[	0	]	in	_blocking_errnos	:	
return	None	
raise	

def	readable	(	self	)	:	

if	self	.	closed	:	
raise	ValueError	(	"str"	)	
return	self	.	_reading	

def	writable	(	self	)	:	

if	self	.	closed	:	
raise	ValueError	(	"str"	)	
return	self	.	_writing	

def	seekable	(	self	)	:	

if	self	.	closed	:	
raise	ValueError	(	"str"	)	
return	super	(	)	.	seekable	(	)	

def	fileno	(	self	)	:	

self	.	_checkClosed	(	)	
return	self	.	_sock	.	fileno	(	)	

@property	
def	name	(	self	)	:	
if	not	self	.	closed	:	
return	self	.	fileno	(	)	
else	:	
return	-	1	

@property	
def	mode	(	self	)	:	
return	self	.	_mode	

def	close	(	self	)	:	

if	self	.	closed	:	
return	
io	.	RawIOBase	.	close	(	self	)	
self	.	_sock	.	_decref_socketios	(	)	
self	.	_sock	=	None	


def	getfqdn	(	name	=	"str"	)	:	

name	=	name	.	strip	(	)	
if	not	name	or	name	==	"str"	:	
name	=	gethostname	(	)	
try	:	
hostname	,	aliases	,	ipaddrs	=	gethostbyaddr	(	name	)	
except	error	:	
pass	
else	:	
aliases	.	insert	(	0	,	hostname	)	
for	name	in	aliases	:	
if	"str"	in	name	:	
break	
else	:	
name	=	hostname	
return	name	



from	socket	import	_GLOBAL_DEFAULT_TIMEOUT	



def	create_connection	(	address	,	timeout	=	_GLOBAL_DEFAULT_TIMEOUT	,	
source_address	=	None	)	:	


host	,	port	=	address	
err	=	None	
for	res	in	getaddrinfo	(	host	,	port	,	0	,	SOCK_STREAM	)	:	
af	,	socktype	,	proto	,	canonname	,	sa	=	res	
sock	=	None	
try	:	
sock	=	socket	(	af	,	socktype	,	proto	)	
if	timeout	is	not	_GLOBAL_DEFAULT_TIMEOUT	:	
sock	.	settimeout	(	timeout	)	
if	source_address	:	
sock	.	bind	(	source_address	)	
sock	.	connect	(	sa	)	
return	sock	

except	error	as	_	:	
err	=	_	
if	sock	is	not	None	:	
sock	.	close	(	)	

if	err	is	not	None	:	
raise	err	
else	:	
raise	error	(	"str"	)	
	