

from	core	.	hakkuframework	import	*	
import	os	
import	signal	
from	time	import	sleep	
import	logging	
from	scapy	.	all	import	*	
from	core	import	colors	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	False	,	
"str"	:	1	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


help_notes	=	colors	.	red	+	"str"	+	colors	.	end	


changelog	=	"str"	

def	run	(	)	:	
printInfo	(	"str"	)	
printInfo	(	"str"	)	
packet	=	ARP	(	)	
packet	.	psrc	=	variables	[	"str"	]	[	0	]	
packet	.	pdst	=	variables	[	"str"	]	[	0	]	
while	1	:	
send	(	packet	,	verbose	=	False	)	
sleep	(	10	)	
	