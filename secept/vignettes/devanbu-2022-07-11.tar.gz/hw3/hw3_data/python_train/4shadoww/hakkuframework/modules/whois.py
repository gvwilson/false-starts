
from	core	.	hakkuframework	import	*	
import	whois	

conf	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	True	
}	


variables	=	OrderedDict	(	(	
(	"str"	,	[	"str"	,	"str"	]	)	,	
)	)	


changelog	=	"str"	

def	run	(	)	:	

w	=	whois	.	whois	(	variables	[	"str"	]	[	0	]	)	
print	(	w	)	
return	w	
	