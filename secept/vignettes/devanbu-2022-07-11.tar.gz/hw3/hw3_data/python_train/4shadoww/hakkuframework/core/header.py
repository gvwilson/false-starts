from	core	import	info	
from	core	import	colors	
from	core	.	moduleop	import	count	

hakku	=	"str"	

def	print_info	(	)	:	
count	(	)	

print	(	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	)	
print	(	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	+	info	.	version	+	"str"	+	info	.	codename	+	"str"	+	colors	.	end	)	
print	(	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	+	info	.	apiversion	+	"str"	+	colors	.	end	)	
print	(	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	+	info	.	update_date	+	"str"	+	colors	.	end	)	
print	(	"str"	+	colors	.	bold	+	"str"	+	colors	.	end	+	"str"	+	count	.	mod	+	"str"	+	"str"	+	colors	.	end	)	
print	(	"str"	)	
	