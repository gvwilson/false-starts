

import	sys	
from	core	import	colors	

errorstr	=	"str"	+	colors	.	bold	+	colors	.	red	+	"str"	+	colors	.	end	+	"str"	
infostr	=	"str"	+	colors	.	bold	+	colors	.	blue	+	"str"	+	colors	.	end	+	"str"	
warningstr	=	"str"	+	colors	.	bold	+	colors	.	yellow	+	"str"	+	colors	.	end	+	"str"	
successstr	=	"str"	+	colors	.	bold	+	colors	.	green	+	"str"	+	colors	.	end	+	"str"	

def	animline	(	message	,	last	=	False	)	:	
sys	.	stdout	.	write	(	"str"	)	
if	last	==	False	:	
sys	.	stdout	.	write	(	message	+	"str"	)	
else	:	
sys	.	stdout	.	write	(	message	+	"str"	)	

def	animError	(	message	,	last	=	False	)	:	
sys	.	stdout	.	write	(	"str"	)	
if	last	==	False	:	
sys	.	stdout	.	write	(	errorstr	+	message	+	"str"	)	
else	:	
sys	.	stdout	.	write	(	errorstr	+	message	+	"str"	)	

def	animWarning	(	message	,	last	=	False	)	:	
sys	.	stdout	.	write	(	"str"	)	
if	last	==	False	:	
sys	.	stdout	.	write	(	warningstr	+	message	+	"str"	)	
else	:	
sys	.	stdout	.	write	(	warningstr	+	message	+	"str"	)	

def	animInfo	(	message	,	last	=	False	)	:	
sys	.	stdout	.	write	(	"str"	)	
if	last	==	False	:	
sys	.	stdout	.	write	(	infostr	+	message	+	"str"	)	
else	:	
sys	.	stdout	.	write	(	infostr	+	message	+	"str"	)	

def	animSuccess	(	message	,	last	=	False	)	:	
sys	.	stdout	.	write	(	"str"	)	
if	last	==	False	:	
sys	.	stdout	.	write	(	successstr	+	text	+	"str"	)	
else	:	
sys	.	stdout	.	write	(	successstr	+	text	+	"str"	)	
	