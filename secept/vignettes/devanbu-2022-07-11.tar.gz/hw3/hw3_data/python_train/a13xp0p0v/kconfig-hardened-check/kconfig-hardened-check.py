








































import	sys	
from	argparse	import	ArgumentParser	
from	collections	import	OrderedDict	
import	re	
import	json	

debug_mode	=	False	
json_mode	=	False	

supported_archs	=	[	"str"	,	"str"	,	"str"	,	"str"	]	


class	OptCheck	:	
def	__init__	(	self	,	name	,	expected	,	decision	,	reason	)	:	
self	.	name	=	name	
self	.	expected	=	expected	
self	.	decision	=	decision	
self	.	reason	=	reason	
self	.	state	=	None	
self	.	result	=	None	

def	check	(	self	)	:	
if	self	.	expected	==	self	.	state	:	
self	.	result	=	"str"	
elif	self	.	state	is	None	:	
if	self	.	expected	==	"str"	:	
self	.	result	=	"str"	
else	:	
self	.	result	=	"str"	
else	:	
self	.	result	=	"str"	+	self	.	state	+	"str"	

if	self	.	result	.	startswith	(	"str"	)	:	
return	True	,	self	.	result	
else	:	
return	False	,	self	.	result	

def	__repr__	(	self	)	:	
return	"str"	.	format	(	self	.	name	,	self	.	state	)	


class	ComplexOptCheck	:	
def	__init__	(	self	,	*	opts	)	:	
self	.	opts	=	opts	
self	.	result	=	None	

@property	
def	name	(	self	)	:	
return	self	.	opts	[	0	]	.	name	

@property	
def	expected	(	self	)	:	
return	self	.	opts	[	0	]	.	expected	

@property	
def	state	(	self	)	:	
return	self	.	opts	[	0	]	.	state	

@property	
def	decision	(	self	)	:	
return	self	.	opts	[	0	]	.	decision	

@property	
def	reason	(	self	)	:	
return	self	.	opts	[	0	]	.	reason	


class	OR	(	ComplexOptCheck	)	:	





def	check	(	self	)	:	
if	not	self	.	opts	:	
sys	.	exit	(	"str"	)	

for	i	,	opt	in	enumerate	(	self	.	opts	)	:	
ret	,	msg	=	opt	.	check	(	)	
if	ret	:	
if	i	==	0	:	
self	.	result	=	opt	.	result	
else	:	
self	.	result	=	"str"	.	format	(	opt	.	name	,	opt	.	expected	)	
return	True	,	self	.	result	
self	.	result	=	self	.	opts	[	0	]	.	result	
return	False	,	self	.	result	


class	AND	(	ComplexOptCheck	)	:	




def	check	(	self	)	:	
for	i	,	opt	in	reversed	(	list	(	enumerate	(	self	.	opts	)	)	)	:	
ret	,	msg	=	opt	.	check	(	)	
if	i	==	0	:	
self	.	result	=	opt	.	result	
return	ret	,	self	.	result	
elif	not	ret	:	
self	.	result	=	"str"	.	format	(	opt	.	name	)	
return	False	,	self	.	result	

sys	.	exit	(	"str"	)	


def	detect_arch	(	fname	)	:	
with	open	(	fname	,	"str"	)	as	f	:	
arch_pattern	=	re	.	compile	(	"str"	)	
arch	=	None	
msg	=	None	
if	not	json_mode	:	
print	(	"str"	.	format	(	fname	)	)	
for	line	in	f	.	readlines	(	)	:	
if	arch_pattern	.	match	(	line	)	:	
option	,	value	=	line	[	7	:	]	.	split	(	"str"	,	1	)	
if	option	in	supported_archs	:	
if	not	arch	:	
arch	=	option	
else	:	
return	None	,	"str"	
if	not	arch	:	
return	None	,	"str"	
else	:	
return	arch	,	"str"	


def	construct_checklist	(	checklist	,	arch	)	:	
modules_not_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
devmem_not_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	modules_not_set	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
randstruct_is_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
checklist	.	append	(	randstruct_is_set	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
page_poisoning_is_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
checklist	.	append	(	page_poisoning_is_set	)	
hardened_usercopy_is_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
checklist	.	append	(	hardened_usercopy_is_set	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	hardened_usercopy_is_set	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	modules_not_set	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	modules_not_set	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	modules_not_set	)	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	modules_not_set	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	randstruct_is_set	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	or	arch	==	"str"	:	
stackleak_is_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
checklist	.	append	(	stackleak_is_set	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	stackleak_is_set	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	stackleak_is_set	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
iommu_support_is_set	=	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	
checklist	.	append	(	iommu_support_is_set	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	iommu_support_is_set	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	iommu_support_is_set	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	iommu_support_is_set	)	)	

checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	page_poisoning_is_set	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	page_poisoning_is_set	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	iommu_support_is_set	)	)	
checklist	.	append	(	AND	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	iommu_support_is_set	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	devmem_not_set	)	)	

checklist	.	append	(	modules_not_set	)	
checklist	.	append	(	devmem_not_set	)	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	devmem_not_set	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OR	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	,	devmem_not_set	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	

if	debug_mode	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	
if	debug_mode	or	arch	==	"str"	or	arch	==	"str"	:	
checklist	.	append	(	OptCheck	(	"str"	,	"str"	,	"str"	,	"str"	)	)	




def	print_checklist	(	checklist	,	with_results	)	:	
if	json_mode	:	
opts	=	[	]	
for	o	in	checklist	:	
opt	=	[	"str"	+	o	.	name	,	o	.	expected	,	o	.	decision	,	o	.	reason	]	
if	with_results	:	
opt	.	append	(	o	.	result	)	
opts	.	append	(	opt	)	
print	(	json	.	dumps	(	opts	)	)	
return	


print	(	"str"	.	format	(	"str"	,	"str"	,	"str"	,	"str"	)	,	end	=	"str"	)	
sep_line_len	=	86	
if	with_results	:	
print	(	"str"	.	format	(	"str"	)	,	end	=	"str"	)	
sep_line_len	+	=	30	
print	(	)	

print	(	"str"	*	sep_line_len	)	

for	opt	in	checklist	:	
print	(	"str"	.	format	(	opt	.	name	,	opt	.	expected	,	opt	.	decision	,	opt	.	reason	)	,	end	=	"str"	)	
if	with_results	:	
print	(	"str"	.	format	(	opt	.	result	)	,	end	=	"str"	)	
print	(	)	
print	(	)	


def	get_option_state	(	options	,	name	)	:	
return	options	.	get	(	name	,	None	)	


def	perform_checks	(	checklist	,	parsed_options	)	:	
for	opt	in	checklist	:	
if	hasattr	(	opt	,	"str"	)	:	
for	o	in	opt	.	opts	:	
o	.	state	=	get_option_state	(	parsed_options	,	o	.	name	)	
else	:	
opt	.	state	=	get_option_state	(	parsed_options	,	opt	.	name	)	
opt	.	check	(	)	


def	check_config_file	(	checklist	,	fname	)	:	
with	open	(	fname	,	"str"	)	as	f	:	
parsed_options	=	OrderedDict	(	)	
opt_is_on	=	re	.	compile	(	"str"	)	
opt_is_off	=	re	.	compile	(	"str"	)	

if	not	json_mode	:	
print	(	"str"	.	format	(	fname	)	)	
for	line	in	f	.	readlines	(	)	:	
line	=	line	.	strip	(	)	
option	=	None	
value	=	None	

if	opt_is_on	.	match	(	line	)	:	
option	,	value	=	line	[	7	:	]	.	split	(	"str"	,	1	)	
elif	opt_is_off	.	match	(	line	)	:	
option	,	value	=	line	[	9	:	]	.	split	(	"str"	,	1	)	
if	value	!=	"str"	:	
sys	.	exit	(	"str"	.	format	(	line	)	)	

if	option	in	parsed_options	:	
sys	.	exit	(	"str"	.	format	(	line	)	)	

if	option	is	not	None	:	
parsed_options	[	option	]	=	value	

perform_checks	(	checklist	,	parsed_options	)	

if	debug_mode	:	
known_options	=	[	opt	.	name	for	opt	in	checklist	]	
for	option	,	value	in	parsed_options	.	items	(	)	:	
if	option	not	in	known_options	:	
print	(	"str"	.	format	(	option	,	value	)	)	

print_checklist	(	checklist	,	True	)	


if	__name__	==	"str"	:	
config_checklist	=	[	]	

parser	=	ArgumentParser	(	description	=	"str"	)	
parser	.	add_argument	(	"str"	,	"str"	,	choices	=	supported_archs	,	
help	=	"str"	)	
parser	.	add_argument	(	"str"	,	"str"	,	
help	=	"str"	)	
parser	.	add_argument	(	"str"	,	action	=	"str"	,	
help	=	"str"	)	
parser	.	add_argument	(	"str"	,	action	=	"str"	,	
help	=	"str"	)	
args	=	parser	.	parse_args	(	)	

if	args	.	debug	:	
debug_mode	=	True	
if	args	.	json	:	
json_mode	=	True	
if	debug_mode	and	json_mode	:	
sys	.	exit	(	"str"	)	

if	args	.	config	:	
arch	,	msg	=	detect_arch	(	args	.	config	)	
if	not	arch	:	
sys	.	exit	(	"str"	.	format	(	msg	)	)	
elif	not	json_mode	:	
print	(	"str"	.	format	(	arch	)	)	

construct_checklist	(	config_checklist	,	arch	)	
check_config_file	(	config_checklist	,	args	.	config	)	
error_count	=	len	(	list	(	filter	(	lambda	opt	:	opt	.	result	.	startswith	(	"str"	)	,	config_checklist	)	)	)	
ok_count	=	len	(	list	(	filter	(	lambda	opt	:	opt	.	result	.	startswith	(	"str"	)	,	config_checklist	)	)	)	
if	debug_mode	:	
sys	.	exit	(	0	)	
if	not	json_mode	:	
print	(	"str"	.	format	(	ok_count	,	error_count	)	)	
sys	.	exit	(	0	)	

if	args	.	print	:	
arch	=	args	.	print	
construct_checklist	(	config_checklist	,	arch	)	
if	not	json_mode	:	
print	(	"str"	.	format	(	arch	)	)	
print_checklist	(	config_checklist	,	False	)	
sys	.	exit	(	0	)	

parser	.	print_help	(	)	
	