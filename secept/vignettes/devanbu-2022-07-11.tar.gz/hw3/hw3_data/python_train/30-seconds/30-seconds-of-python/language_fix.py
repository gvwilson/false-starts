print	(	"str"	)	
	