



from	process	import	od	
from	config	import	config	
from	utils	import	path_format	
from	flask	import	Flask	,	abort	,	redirect	,	render_template	,	Blueprint	

bp	=	Blueprint	(	"str"	,	__name__	,	url_prefix	=	config	.	location_path	)	



@bp.route	(	"str"	)	
def	favicon	(	)	:	
return	abort	(	404	)	


@bp.route	(	"str"	,	defaults	=	{	"str"	:	"str"	}	)	
@bp.route	(	"str"	)	
def	catch_all	(	path	)	:	
info	=	od	.	list_items_with_cache	(	
path_format	(	config	.	start_directory	+	"str"	+	path	)	)	

if	info	.	is_file	:	
return	redirect	(	info	.	files	[	0	]	[	"str"	]	)	

return	render_template	(	"str"	,	info	=	info	,	path	=	path_format	(	path	)	.	strip	(	"str"	)	)	



@bp.app_template_filter	(	"str"	)	
def	date_format	(	str	,	format	=	"str"	)	:	
from	dateutil	import	tz	
from	datetime	import	datetime	

dt	=	datetime	.	strptime	(	str	,	"str"	)	
return	dt	.	replace	(	tzinfo	=	tz	.	tzutc	(	)	)	.	astimezone	(	tz	.	gettz	(	"str"	)	)	.	strftime	(	format	)	


@bp.app_template_filter	(	"str"	)	
def	file_size	(	size	)	:	
unit	=	(	
(	"str"	,	2	*	*	0	)	,	
(	"str"	,	2	*	*	10	)	,	
(	"str"	,	2	*	*	20	)	,	
(	"str"	,	2	*	*	30	)	,	
(	"str"	,	2	*	*	40	)	,	
(	"str"	,	2	*	*	50	)	,	
(	"str"	,	2	*	*	60	)	,	
(	"str"	,	2	*	*	70	)	,	
(	"str"	,	2	*	*	80	)	
)	

for	k	,	v	in	unit	:	
if	size	<	=	v	*	1024	:	
return	"str"	%	(	round	(	size	/	v	,	2	)	,	k	)	
return	"str"	


app	=	Flask	(	__name__	)	
app	.	register_blueprint	(	bp	)	

if	__name__	==	"str"	:	
app	.	run	(	host	=	"str"	,	port	=	"str"	,	debug	=	True	)	
	