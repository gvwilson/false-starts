import	pickle	
import	hashlib	
from	datetime	import	datetime	


def	path_format	(	path	)	:	
while	"str"	in	path	:	
path	=	path	.	replace	(	"str"	,	"str"	)	

return	"str"	+	path	.	strip	(	"str"	)	
	