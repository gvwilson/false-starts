























































































































































































































import	glob	
import	datetime	
import	socket	
import	os	,	sys	
import	win32process	
import	re	
import	win32security	,	ntsecuritycon	,	win32api	,	win32con	,	win32file	
import	win32service	
import	pywintypes	
import	win32net	
import	ctypes	
import	getopt	
import	_winreg	
import	win32netcon	
from	subprocess	import	Popen	,	PIPE	,	STDOUT	

from	ntsecuritycon	import	TokenSessionId	,	TokenSandBoxInert	,	TokenType	,	TokenImpersonationLevel	,	TokenVirtualizationEnabled	,	TokenVirtualizationAllowed	,	TokenHasRestrictions	,	TokenElevationType	,	TokenUIAccess	,	TokenUser	,	TokenOwner	,	TokenGroups	,	TokenRestrictedSids	,	TokenPrivileges	,	TokenPrimaryGroup	,	TokenSource	,	TokenDefaultDacl	,	TokenStatistics	,	TokenOrigin	,	TokenLinkedToken	,	TokenLogonSid	,	TokenElevation	,	TokenIntegrityLevel	,	TokenMandatoryPolicy	,	SE_ASSIGNPRIMARYTOKEN_NAME	,	SE_BACKUP_NAME	,	SE_CREATE_PAGEFILE_NAME	,	SE_CREATE_TOKEN_NAME	,	SE_DEBUG_NAME	,	SE_LOAD_DRIVER_NAME	,	SE_MACHINE_ACCOUNT_NAME	,	SE_RESTORE_NAME	,	SE_SHUTDOWN_NAME	,	SE_TAKE_OWNERSHIP_NAME	,	SE_TCB_NAME	

k32	=	ctypes	.	windll	.	kernel32	
wow64	=	ctypes	.	c_long	(	0	)	
on64bitwindows	=	1	
remote_server	=	None	
remote_username	=	None	
remote_password	=	None	
remote_domain	=	None	
local_ips	=	socket	.	gethostbyname_ex	(	socket	.	gethostname	(	)	)	[	2	]	

version	=	"str"	
svnversion	=	"str"	
svnnum	=	re	.	sub	(	"str"	,	"str"	,	svnversion	)	
if	svnnum	:	
version	=	version	+	"str"	+	svnnum	

all_checks	=	0	
registry_checks	=	0	
path_checks	=	0	
service_checks	=	0	
service_audit	=	0	
drive_checks	=	0	
eventlog_checks	=	0	
progfiles_checks	=	0	
process_checks	=	0	
share_checks	=	0	
passpol_audit	=	0	
user_group_audit	=	0	
logged_in_audit	=	0	
process_audit	=	0	
admin_users_audit	=	0	
host_info_audit	=	0	
ignore_trusted	=	0	
owner_info	=	0	
weak_perms_only	=	0	
host_info_audit	=	0	
patch_checks	=	0	
verbose	=	0	
report_file_name	=	None	

kb_nos	=	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	
}	

reg_paths	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	



trusted_principles_fq	=	(	
"str"	,	
"str"	,	
"str"	
)	



tmp_trusted_principles_fq	=	(	
)	

eventlog_key_hklm	=	"str"	



trusted_principles	=	(	
"str"	,	
"str"	,	
"str"	,	
)	


windows_privileges	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

share_types	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	

sv_types	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	

"str"	,	
"str"	,	
"str"	,	
"str"	
)	

win32netcon	.	SV_TYPE_TERMINALSERVER	=	0x2000000	

dangerous_perms_write	=	{	

"str"	:	{	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
ntsecuritycon	:	(	

"str"	,	
"str"	,	

"str"	,	


"str"	,	
"str"	,	

"str"	,	
"str"	,	

)	
}	,	























"str"	:	{	
_winreg	:	(	


"str"	,	
"str"	,	
"str"	,	







)	,	
ntsecuritycon	:	(	
"str"	,	

"str"	,	
"str"	,	



)	
}	,	
"str"	:	{	
ntsecuritycon	:	(	

"str"	,	
"str"	,	

"str"	,	

"str"	,	

"str"	,	
"str"	,	

"str"	,	
"str"	,	

)	
}	,	
"str"	:	{	









win32service	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	












win32service	:	(	



"str"	,	
"str"	,	
"str"	,	

"str"	,	
"str"	,	

)	
}	,	
}	

all_perms	=	{	
"str"	:	{	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
_winreg	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	,	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
win32service	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
win32service	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
"str"	:	{	
win32con	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	,	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	
}	,	
"str"	:	{	
win32con	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	,	
ntsecuritycon	:	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	
}	,	
}	



issues	=	{	}	

issue_template	=	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	

"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	,	
}	
}	,	
}	

issue_template_html	=	"str"	

issue_list_html	=	"str"	



overview_template_html	=	"str"	

def	usage	(	)	:	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	

print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	

print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
sys	.	exit	(	0	)	





def	format_issues	(	format	,	issue_template	,	issue_data	)	:	
report	=	"str"	
toc	=	"str"	
overview	=	overview_template_html	
overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	)	
overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	)	

for	item	in	audit_data	[	"str"	]	:	
overview	=	overview	.	replace	(	"str"	,	list_item	(	"str"	,	item	)	)	
overview	=	overview	.	replace	(	"str"	,	"str"	)	

overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	+	"str"	+	audit_data	[	"str"	]	+	"str"	)	

overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	)	
overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	)	
overview	=	overview	.	replace	(	"str"	,	audit_data	[	"str"	]	)	

for	item	in	audit_data	[	"str"	]	:	
overview	=	overview	.	replace	(	"str"	,	list_item	(	"str"	,	item	)	)	
overview	=	overview	.	replace	(	"str"	,	"str"	)	

for	item	in	audit_data	[	"str"	]	:	
overview	=	overview	.	replace	(	"str"	,	list_item	(	"str"	,	item	)	)	
overview	=	overview	.	replace	(	"str"	,	"str"	)	

permlist	=	"str"	
for	permtype	in	dangerous_perms_write	.	keys	(	)	:	
permlist	+	=	"str"	+	permtype	+	"str"	
permlist	+	=	"str"	
for	location	in	dangerous_perms_write	[	permtype	]	.	keys	(	)	:	
for	item	in	dangerous_perms_write	[	permtype	]	[	location	]	:	
permlist	+	=	"str"	+	item	+	"str"	
permlist	+	=	"str"	




overview	=	overview	.	replace	(	"str"	,	permlist	)	

for	item	in	audit_data	[	"str"	]	:	
overview	=	overview	.	replace	(	"str"	,	list_item	(	"str"	,	item	)	)	
overview	=	overview	.	replace	(	"str"	,	"str"	)	

for	issue_no	in	issue_data	:	

report	=	report	+	format_issue	(	format	,	issue_no	,	issue_data	,	issue_template	)	
toc	=	toc	+	"str"	+	issue_template	[	issue_no	]	[	"str"	]	+	"str"	+	issue_template	[	issue_no	]	[	"str"	]	+	"str"	

if	report	:	
overview	=	overview	.	replace	(	"str"	,	report	)	
overview	=	overview	.	replace	(	"str"	,	toc	)	
else	:	
overview	=	overview	.	replace	(	"str"	,	"str"	)	
overview	=	overview	.	replace	(	"str"	,	"str"	)	

return	overview	

def	list_item	(	tag	,	item	)	:	
return	"str"	+	item	+	"str"	+	tag	

def	format_issue	(	format	,	issue_no	,	issue_data	,	issue_template	)	:	
if	not	issue_no	in	issue_template	:	
print	"str"	
sys	.	exit	(	1	)	

issue	=	issue_template_html	
issue	=	issue	.	replace	(	"str"	,	"str"	+	issue_template	[	issue_no	]	[	"str"	]	+	"str"	+	issue_template	[	issue_no	]	[	"str"	]	+	"str"	)	
description	=	issue_template	[	issue_no	]	[	"str"	]	
description	=	description	.	replace	(	"str"	,	"str"	)	
for	key	in	issue_data	[	issue_no	]	:	








preamble	=	issue_template	[	issue_no	]	[	"str"	]	[	key	]	[	"str"	]	
data	=	issue_list_html	
data	=	data	.	replace	(	"str"	,	preamble	)	
for	item	in	issue_data	[	issue_no	]	[	key	]	:	


perm_string	=	"str"	.	join	(	issue_data	[	issue_no	]	[	key	]	[	item	]	)	
data	=	data	.	replace	(	"str"	,	list_item	(	"str"	,	item	+	"str"	+	perm_string	)	)	

data	=	data	.	replace	(	"str"	,	"str"	)	
issue	=	issue	.	replace	(	"str"	,	data	+	"str"	)	




issue	=	issue	.	replace	(	"str"	,	"str"	)	
issue	=	issue	.	replace	(	"str"	,	"str"	)	
issue	=	issue	.	replace	(	"str"	,	description	+	"str"	)	
recommendation	=	issue_template	[	issue_no	]	[	"str"	]	
issue	=	issue	.	replace	(	"str"	,	recommendation	+	"str"	)	
recommendation	=	recommendation	.	replace	(	"str"	,	"str"	)	
return	issue	

def	format_audit_data	(	format	,	audit_data	)	:	
print	"str"	




def	save_issue	(	issue_name	,	data_type	,	weak_perms	)	:	

global	issues	
if	not	issue_name	in	issues	:	
issues	[	issue_name	]	=	{	}	


for	weak_perm	in	weak_perms	:	
object	=	weak_perm	[	0	]	
domain	=	weak_perm	[	1	]	
name	=	weak_perm	[	2	]	
permission	=	weak_perm	[	3	]	
key	=	object	+	"str"	+	domain	+	"str"	+	name	
if	not	data_type	in	issues	[	issue_name	]	:	
issues	[	issue_name	]	[	data_type	]	=	{	}	
if	not	key	in	issues	[	issue_name	]	[	data_type	]	:	
issues	[	issue_name	]	[	data_type	]	[	key	]	=	[	]	
issues	[	issue_name	]	[	data_type	]	[	key	]	.	append	(	permission	)	
issues	[	issue_name	]	[	data_type	]	[	key	]	=	list	(	set	(	issues	[	issue_name	]	[	data_type	]	[	key	]	)	)	

def	save_issue_string	(	issue_name	,	data_type	,	issue_string	)	:	

global	issues	
if	not	issue_name	in	issues	:	
issues	[	issue_name	]	=	{	}	
if	not	data_type	in	issues	[	issue_name	]	:	
issues	[	issue_name	]	[	data_type	]	=	{	}	
if	not	issue_string	in	issues	[	issue_name	]	[	data_type	]	:	
issues	[	issue_name	]	[	data_type	]	[	issue_string	]	=	[	]	




def	principle_is_trusted	(	principle	,	domain	)	:	

if	domain	+	"str"	+	principle	in	trusted_principles_fq	:	
return	1	

if	principle	in	trusted_principles	:	
return	1	

global	tmp_trusted_principles_fq	
if	domain	+	"str"	+	principle	in	tmp_trusted_principles_fq	:	
return	1	


try	:	
memberdict	,	total	,	rh	=	win32net	.	NetLocalGroupGetMembers	(	remote_server	,	principle	,	1	,	0	,	100000	)	
if	len	(	memberdict	)	==	0	:	
return	1	
except	:	

try	:	
group_attrs	=	win32net	.	NetUserGetLocalGroups	(	remote_server	,	principle	)	
if	set	(	group_attrs	)	.	intersection	(	set	(	trusted_principles	)	)	:	
return	1	
except	:	
pass	

return	0	























def	check_weak_perms	(	object_name	,	object_type_s	,	perms	)	:	
object_type	=	None	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_FILE_OBJECT	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_FILE_OBJECT	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_SERVICE	

if	object_type	==	win32security	.	SE_FILE_OBJECT	:	



if	os	.	path	.	isfile	(	object_name	)	:	
object_type_s	=	"str"	
else	:	
object_type_s	=	"str"	

if	object_type	==	None	:	
print	"str"	%	object_type_s	
exit	(	1	)	

try	:	
sd	=	win32security	.	GetNamedSecurityInfo	(	
object_name	,	
object_type	,	
win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	
)	
except	:	

return	[	]	

return	check_weak_perms_sd	(	object_name	,	object_type_s	,	sd	,	perms	)	

def	check_weak_write_perms_by_sd	(	object_name	,	object_type_s	,	sd	)	:	
return	check_weak_perms_sd	(	object_name	,	object_type_s	,	sd	,	dangerous_perms_write	)	

def	check_weak_perms_sd	(	object_name	,	object_type_s	,	sd	,	perms	)	:	
dacl	=	sd	.	GetSecurityDescriptorDacl	(	)	
if	dacl	==	None	:	
print	"str"	
return	[	]	

owner_sid	=	sd	.	GetSecurityDescriptorOwner	(	)	
try	:	
owner_name	,	owner_domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	owner_sid	)	
owner_fq	=	owner_domain	+	"str"	+	owner_name	
except	:	
try	:	
owner_fq	=	owner_name	=	win32security	.	ConvertSidToStringSid	(	owner_sid	)	
owner_domain	=	"str"	
except	:	
owner_domain	=	"str"	
owner_fq	=	owner_name	=	"str"	

weak_perms	=	[	]	
for	ace_no	in	range	(	0	,	dacl	.	GetAceCount	(	)	)	:	

ace	=	dacl	.	GetAce	(	ace_no	)	
flags	=	ace	[	0	]	[	1	]	

try	:	
principle	,	domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	ace	[	2	]	)	
except	:	
principle	=	win32security	.	ConvertSidToStringSid	(	ace	[	2	]	)	
domain	=	"str"	





if	principle_is_trusted	(	principle	,	domain	)	:	

continue	

if	principle	==	"str"	:	
if	principle_is_trusted	(	owner_name	,	owner_domain	)	:	
continue	
else	:	
principle	=	"str"	%	owner_fq	

for	i	in	(	"str"	,	"str"	,	"str"	,	"str"	)	:	
if	getattr	(	ntsecuritycon	,	i	)	==	ace	[	0	]	[	0	]	:	
ace_type_s	=	i	

if	not	ace_type_s	==	"str"	:	
vprint	(	"str"	+	ace_type_s	+	"str"	)	
continue	

for	mod	,	perms_tuple	in	perms	[	object_type_s	]	.	iteritems	(	)	:	
for	perm	in	perms_tuple	:	
if	getattr	(	mod	,	perm	)	&	ace	[	1	]	==	getattr	(	mod	,	perm	)	:	
weak_perms	.	append	(	[	object_name	,	domain	,	principle	,	perm	]	)	
return	weak_perms	

def	dump_perms	(	object_name	,	object_type_s	,	options	=	{	}	)	:	
object_type	=	None	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_FILE_OBJECT	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_FILE_OBJECT	
if	object_type_s	==	"str"	:	
object_type	=	win32security	.	SE_SERVICE	

if	object_type	==	win32security	.	SE_FILE_OBJECT	:	



if	os	.	path	.	isfile	(	object_name	)	:	
object_type_s	=	"str"	
else	:	
object_type_s	=	"str"	

if	object_type	==	None	:	
print	"str"	%	object_type_s	
exit	(	1	)	

try	:	
sd	=	win32security	.	GetNamedSecurityInfo	(	
object_name	,	
object_type	,	
win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	
)	
except	:	

return	[	]	

return	dump_sd	(	object_name	,	object_type_s	,	sd	,	options	)	

def	dump_sd	(	object_name	,	object_type_s	,	sd	,	options	=	{	}	)	:	
perms	=	all_perms	
if	not	sd	:	
return	
dacl	=	sd	.	GetSecurityDescriptorDacl	(	)	
if	dacl	==	None	:	
print	"str"	
return	[	]	

owner_sid	=	sd	.	GetSecurityDescriptorOwner	(	)	

try	:	
owner_name	,	owner_domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	owner_sid	)	
owner_fq	=	owner_domain	+	"str"	+	owner_name	
except	:	
try	:	
owner_fq	=	owner_name	=	win32security	.	ConvertSidToStringSid	(	owner_sid	)	
owner_domain	=	"str"	
except	:	
owner_domain	=	"str"	
owner_fq	=	owner_name	=	None	

group_sid	=	sd	.	GetSecurityDescriptorGroup	(	)	
try	:	
group_name	,	group_domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	group_sid	)	
group_fq	=	group_domain	+	"str"	+	group_name	
except	:	
try	:	
group_fq	=	group_name	=	win32security	.	ConvertSidToStringSid	(	group_sid	)	
group_domain	=	"str"	
except	:	
group_domain	=	"str"	
group_fq	=	group_name	=	"str"	

if	owner_info	:	
print	"str"	+	str	(	owner_fq	)	
print	"str"	+	str	(	group_fq	)	

weak_perms	=	[	]	
dump_acl	(	object_name	,	object_type_s	,	dacl	,	options	)	
return	

def	dump_acl	(	object_name	,	object_type_s	,	sd	,	options	=	{	}	)	:	
dacl	=	sd	
if	dacl	==	None	:	
print	"str"	
return	[	]	

weak_perms	=	[	]	
for	ace_no	in	range	(	0	,	dacl	.	GetAceCount	(	)	)	:	

ace	=	dacl	.	GetAce	(	ace_no	)	
flags	=	ace	[	0	]	[	1	]	

try	:	
principle	,	domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	ace	[	2	]	)	
except	:	
principle	=	win32security	.	ConvertSidToStringSid	(	ace	[	2	]	)	
domain	=	"str"	

mask	=	ace	[	1	]	
if	ace	[	1	]	<	0	:	
mask	=	ace	[	1	]	+	2	*	*	32	

if	ignore_trusted	and	principle_is_trusted	(	principle	,	domain	)	:	

continue	

if	principle	==	"str"	:	
if	ignore_trusted	and	principle_is_trusted	(	owner_name	,	owner_domain	)	:	

continue	
else	:	
principle	=	"str"	%	(	domain	,	principle	)	

for	i	in	(	"str"	,	"str"	,	"str"	,	"str"	)	:	
if	getattr	(	ntsecuritycon	,	i	)	==	ace	[	0	]	[	0	]	:	
ace_type_s	=	i	

ace_type_short	=	ace_type_s	

if	ace_type_s	==	"str"	:	
ace_type_short	=	"str"	

if	ace_type_s	==	"str"	:	
ace_type_short	=	"str"	

if	weak_perms_only	:	
perms	=	dangerous_perms_write	
else	:	
perms	=	all_perms	

for	mod	,	perms_tuple	in	perms	[	object_type_s	]	.	iteritems	(	)	:	
for	perm	in	perms_tuple	:	

if	getattr	(	mod	,	perm	)	&	mask	==	getattr	(	mod	,	perm	)	:	
weak_perms	.	append	(	[	object_name	,	domain	,	principle	,	perm	,	ace_type_short	]	)	
print_weak_perms	(	object_type_s	,	weak_perms	,	options	)	

def	check_weak_write_perms	(	object_name	,	object_type_s	)	:	
return	check_weak_perms	(	object_name	,	object_type_s	,	dangerous_perms_write	)	

def	check_registry	(	)	:	
for	key_string	in	reg_paths	:	
parts	=	key_string	.	split	(	"str"	)	
hive	=	parts	[	0	]	
key_string	=	"str"	.	join	(	parts	[	1	:	]	)	
try	:	
keyh	=	win32api	.	RegOpenKeyEx	(	getattr	(	win32con	,	hive	)	,	key_string	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	

continue	

sd	=	win32api	.	RegGetKeySecurity	(	keyh	,	win32security	.	DACL_SECURITY_INFORMATION	|	win32security	.	OWNER_SECURITY_INFORMATION	)	
weak_perms	=	check_weak_write_perms_by_sd	(	hive	+	"str"	+	key_string	,	"str"	,	sd	)	
if	weak_perms	:	
vprint	(	hive	+	"str"	+	key_string	)	

if	verbose	==	0	:	
sys	.	stdout	.	write	(	"str"	)	
save_issue	(	"str"	,	"str"	,	weak_perms	)	

print	


def	check_event_logs	(	)	:	
key_string	=	"str"	+	eventlog_key_hklm	
try	:	
keyh	=	win32api	.	RegOpenKeyEx	(	win32con	.	HKEY_LOCAL_MACHINE	,	eventlog_key_hklm	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	
print	"str"	+	key_string	
return	0	

subkeys	=	win32api	.	RegEnumKeyEx	(	keyh	)	
for	subkey	in	subkeys	:	

sys	.	stdout	.	write	(	"str"	)	
try	:	
subkeyh	=	win32api	.	RegOpenKeyEx	(	keyh	,	subkey	[	0	]	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	
print	"str"	+	key_string	
else	:	
subkey_count	,	value_count	,	mod_time	=	win32api	.	RegQueryInfoKey	(	subkeyh	)	


try	:	
filename	,	type	=	win32api	.	RegQueryValueEx	(	subkeyh	,	"str"	)	
except	:	
pass	
else	:	
weak_perms	=	check_weak_write_perms	(	os	.	path	.	expandvars	(	filename	)	,	"str"	)	
if	weak_perms	:	



sys	.	stdout	.	write	(	"str"	)	
save_issue	(	"str"	,	"str"	,	weak_perms	)	

try	:	
filename	,	type	=	win32api	.	RegQueryValueEx	(	subkeyh	,	"str"	)	
except	:	
pass	
else	:	
weak_perms	=	check_weak_write_perms	(	os	.	path	.	expandvars	(	filename	)	,	"str"	)	
if	weak_perms	:	



sys	.	stdout	.	write	(	"str"	)	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
print	



def	get_extra_privs	(	)	:	








th	=	win32security	.	OpenProcessToken	(	win32api	.	GetCurrentProcess	(	)	,	win32con	.	TOKEN_ADJUST_PRIVILEGES	|	win32con	.	TOKEN_QUERY	)	
privs	=	win32security	.	GetTokenInformation	(	th	,	TokenPrivileges	)	
newprivs	=	[	]	
for	privtuple	in	privs	:	
if	privtuple	[	0	]	==	win32security	.	LookupPrivilegeValue	(	remote_server	,	"str"	)	or	privtuple	[	0	]	==	win32security	.	LookupPrivilegeValue	(	remote_server	,	"str"	)	or	privtuple	[	0	]	==	win32security	.	LookupPrivilegeValue	(	remote_server	,	"str"	)	:	
print	"str"	+	str	(	privtuple	[	0	]	)	

newprivs	.	append	(	(	privtuple	[	0	]	,	2	)	)	
else	:	
newprivs	.	append	(	(	privtuple	[	0	]	,	privtuple	[	1	]	)	)	


privs	=	tuple	(	newprivs	)	
str	(	win32security	.	AdjustTokenPrivileges	(	th	,	False	,	privs	)	)	

def	audit_processes	(	)	:	
get_extra_privs	(	)	





pids	=	win32process	.	EnumProcesses	(	)	
for	pid	in	sorted	(	pids	)	:	
print	"str"	
print	"str"	%	pid	


ph	=	0	
gotph	=	0	
try	:	

ph	=	win32api	.	OpenProcess	(	win32con	.	PROCESS_QUERY_INFORMATION	|	win32con	.	PROCESS_VM_READ	,	False	,	pid	)	
gotph	=	1	
vprint	(	"str"	)	
except	:	
print	(	"str"	)	
try	:	

ph	=	win32api	.	OpenProcess	(	win32con	.	PROCESS_QUERY_INFORMATION	,	False	,	pid	)	
gotph	=	1	
vprint	(	"str"	)	
except	:	
print	"str"	
try	:	


ph	=	win32api	.	OpenProcess	(	win32con	.	PROCESS_QUERY_LIMITED_INFORMATION	,	False	,	pid	)	
gotph	=	1	
vprint	(	"str"	)	
except	:	
print	"str"	


exe	=	"str"	
gotexe	=	0	
mhs	=	0	
try	:	
mhs	=	win32process	.	EnumProcessModules	(	ph	)	
mhs	=	list	(	mhs	)	
exe	=	win32process	.	GetModuleFileNameEx	(	ph	,	mhs	.	pop	(	0	)	)	
gotexe	=	1	
except	:	
pass	
print	"str"	%	exe	

gottokenh	=	0	

try	:	
tokenh	=	win32security	.	OpenProcessToken	(	ph	,	win32con	.	TOKEN_QUERY	)	
gottokenh	=	1	

sidObj	,	intVal	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenUser	)	
if	sidObj	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	remote_server	,	sidObj	)	
print	"str"	%	(	domainName	,	accountName	,	accountTypeInt	)	

sidObj	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenOwner	)	
if	sidObj	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	remote_server	,	sidObj	)	
print	"str"	%	(	domainName	,	accountName	,	accountTypeInt	)	

sidObj	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenPrimaryGroup	)	
if	sidObj	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	remote_server	,	sidObj	)	
print	"str"	%	(	domainName	,	accountName	,	accountTypeInt	)	
except	:	
print	"str"	
print	"str"	
print	"str"	
print	"str"	
pass	

user	=	"str"	



























if	ph	:	
print	"str"	%	win32process	.	IsWow64Process	(	ph	)	

if	gottokenh	:	
vprint	(	"str"	)	
imp_levels	=	{	
"str"	:	0	,	
"str"	:	1	,	
"str"	:	2	,	
"str"	:	3	
}	







tokentype	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenType	)	
tokentype_str	=	"str"	
if	tokentype	==	1	:	
tokentype_str	=	"str"	
print	"str"	+	tokentype_str	
print	"str"	+	str	(	win32security	.	GetTokenInformation	(	tokenh	,	TokenOrigin	)	)	
try	:	
source	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenSource	)	
print	"str"	+	source	
except	:	
print	"str"	

try	:	
print	"str"	%	win32security	.	GetTokenInformation	(	tokenh	,	TokenImpersonationLevel	)	
except	:	
pass	

try	:	
r	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenHasRestrictions	)	
if	r	==	0	:	
print	"str"	
else	:	
print	"str"	%	r	
except	:	
pass	

try	:	
e	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenElevationType	)	
if	e	==	1	:	
print	"str"	
elif	e	==	2	:	
print	"str"	
elif	e	==	3	:	
print	"str"	
else	:	
print	"str"	%	e	
except	:	
pass	

try	:	
print	"str"	%	win32security	.	GetTokenInformation	(	tokenh	,	TokenUIAccess	)	
except	:	
pass	

try	:	
print	"str"	%	win32security	.	GetTokenInformation	(	tokenh	,	TokenLinkedToken	)	
except	:	
pass	

try	:	
print	"str"	%	win32security	.	GetTokenInformation	(	tokenh	,	TokenLogonSid	)	
print	"str"	%	win32security	.	GetTokenInformation	(	tokenh	,	TokenElevation	)	
except	:	
pass	

try	:	
sid	,	i	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenIntegrityLevel	)	
try	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	None	,	sid	)	
user	=	domainName	+	"str"	+	accountName	+	"str"	+	win32security	.	ConvertSidToStringSid	(	sid	)	+	"str"	
except	:	
user	=	win32security	.	ConvertSidToStringSid	(	sid	)	
print	"str"	%	(	user	,	i	)	
except	:	
pass	

try	:	
m	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenMandatoryPolicy	)	
if	m	==	0	:	
print	"str"	
elif	m	==	1	:	
print	"str"	
elif	m	==	2	:	
print	"str"	
elif	m	==	3	:	
print	"str"	
else	:	
print	"str"	%	m	
except	:	
pass	

print	"str"	+	str	(	win32security	.	GetTokenInformation	(	tokenh	,	TokenRestrictedSids	)	)	
print	"str"	+	str	(	win32security	.	IsTokenRestricted	(	tokenh	)	)	
print	"str"	
for	tup	in	win32security	.	GetTokenInformation	(	tokenh	,	TokenGroups	)	:	
sid	=	tup	[	0	]	
attr	=	tup	[	1	]	
attr_str	=	attr	
if	attr	<	0	:	
attr	=	2	*	*	32	+	attr	
attr_str_a	=	[	]	
if	attr	&	1	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	2	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	4	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	8	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	0x40000000	:	

attr_str_a	.	append	(	"str"	)	
attr_str	=	(	"str"	.	join	(	attr_str_a	)	)	
try	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	remote_server	,	sid	)	
user	=	domainName	+	"str"	+	accountName	+	"str"	+	win32security	.	ConvertSidToStringSid	(	sid	)	+	"str"	
except	:	
user	=	win32security	.	ConvertSidToStringSid	(	sid	)	
print	"str"	%	(	user	,	attr_str	)	


print	"str"	
privs	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenPrivileges	)	
for	priv_tuple	in	privs	:	
priv_val	=	priv_tuple	[	0	]	
attr	=	priv_tuple	[	1	]	
attr_str	=	"str"	+	str	(	attr	)	+	"str"	
attr_str_a	=	[	]	
if	attr	==	0	:	
attr_str_a	.	append	(	"str"	)	
if	attr	&	1	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	2	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	0x80000000	:	

attr_str_a	.	append	(	"str"	)	
if	attr	&	4	:	

attr_str_a	.	append	(	"str"	)	
if	attr_str_a	:	
attr_str	=	(	"str"	)	.	join	(	attr_str_a	)	
print	"str"	%	(	win32security	.	LookupPrivilegeName	(	remote_server	,	priv_val	)	,	attr_str	)	








if	gotexe	:	
print	"str"	%	exe	
dump_perms	(	exe	,	"str"	,	{	"str"	:	1	}	)	
print	

if	mhs	and	ph	:	
for	mh	in	mhs	:	
dll	=	win32process	.	GetModuleFileNameEx	(	ph	,	mh	)	
print	"str"	%	dll	
dump_perms	(	dll	,	"str"	,	{	"str"	:	1	}	)	

print	


def	check_processes	(	)	:	
pids	=	win32process	.	EnumProcesses	(	)	










for	pid	in	sorted	(	pids	)	:	


try	:	
ph	=	win32api	.	OpenProcess	(	win32con	.	PROCESS_VM_READ	|	win32con	.	PROCESS_QUERY_INFORMATION	,	False	,	pid	)	
except	:	

sys	.	stdout	.	write	(	"str"	)	
continue	
else	:	
user	=	"str"	
try	:	
tokenh	=	win32security	.	OpenProcessToken	(	ph	,	win32con	.	TOKEN_QUERY	)	
except	:	
pass	
else	:	
sidObj	,	intVal	=	win32security	.	GetTokenInformation	(	tokenh	,	TokenUser	)	

if	sidObj	:	
accountName	,	domainName	,	accountTypeInt	=	win32security	.	LookupAccountSid	(	remote_server	,	sidObj	)	

user	=	domainName	+	"str"	+	accountName	


sys	.	stdout	.	write	(	"str"	)	
try	:	
mhs	=	win32process	.	EnumProcessModules	(	ph	)	

except	:	
continue	

mhs	=	list	(	mhs	)	
exe	=	win32process	.	GetModuleFileNameEx	(	ph	,	mhs	.	pop	(	0	)	)	
weak_perms	=	check_weak_write_perms	(	exe	,	"str"	)	

if	weak_perms	:	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
sys	.	stdout	.	write	(	"str"	)	

for	mh	in	mhs	:	

dll	=	win32process	.	GetModuleFileNameEx	(	ph	,	mh	)	
weak_perms	=	check_weak_write_perms	(	dll	,	"str"	)	

if	weak_perms	:	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
sys	.	stdout	.	write	(	"str"	)	
print	

def	check_services	(	)	:	
sch	=	win32service	.	OpenSCManager	(	remote_server	,	None	,	win32service	.	SC_MANAGER_ENUMERATE_SERVICE	)	
try	:	

sd	=	win32service	.	QueryServiceObjectSecurity	(	sch	,	win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	)	
print	check_weak_write_perms_by_sd	(	"str"	,	"str"	,	sd	)	
except	:	
pass	
















services	=	win32service	.	EnumServicesStatus	(	sch	,	win32service	.	SERVICE_WIN32	,	win32service	.	SERVICE_STATE_ALL	)	
for	service	in	services	:	
try	:	
sh	=	win32service	.	OpenService	(	sch	,	service	[	0	]	,	win32service	.	SC_MANAGER_CONNECT	)	
service_info	=	win32service	.	QueryServiceConfig	(	sh	)	
except	:	
print	"str"	+	service	[	0	]	
continue	

try	:	
sh	=	win32service	.	OpenService	(	sch	,	service	[	0	]	,	win32con	.	GENERIC_READ	)	
sd	=	win32service	.	QueryServiceObjectSecurity	(	sh	,	win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	)	
except	:	

continue	

weak_perms	=	check_weak_write_perms_by_sd	(	"str"	+	service	[	1	]	+	"str"	+	service	[	0	]	+	"str"	+	service_info	[	7	]	+	"str"	,	"str"	,	sd	)	
binary	=	None	
weak_perms_binary	=	[	]	
if	not	remote_server	:	
binary	=	get_binary	(	service_info	[	3	]	)	
if	binary	:	
weak_perms_binary	=	check_weak_write_perms	(	binary	,	"str"	)	


if	weak_perms	or	weak_perms_binary	:	
vprint	(	"str"	)	
vprint	(	"str"	+	service	[	0	]	)	
vprint	(	"str"	+	service	[	1	]	)	
vprint	(	"str"	+	service_info	[	3	]	)	
if	binary	:	
vprint	(	"str"	+	binary	)	
else	:	
vprint	(	"str"	)	
vprint	(	"str"	+	service_info	[	7	]	)	
vprint	(	"str"	)	


print_weak_perms	(	"str"	,	weak_perms_binary	)	
if	weak_perms_binary	:	
save_issue	(	"str"	,	"str"	,	weak_perms_binary	)	

print_weak_perms	(	"str"	,	weak_perms	)	
if	weak_perms	:	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
if	verbose	==	0	:	
sys	.	stdout	.	write	(	"str"	)	
else	:	
if	verbose	==	0	:	
sys	.	stdout	.	write	(	"str"	)	
print	

def	audit_services	(	)	:	
print	
sch	=	win32service	.	OpenSCManager	(	remote_server	,	None	,	win32service	.	SC_MANAGER_ENUMERATE_SERVICE	)	
try	:	

sd	=	win32service	.	QueryServiceObjectSecurity	(	sch	,	win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	)	
print	check_weak_write_perms_by_sd	(	"str"	,	"str"	,	sd	)	
except	:	

pass	
















services	=	win32service	.	EnumServicesStatus	(	sch	,	win32service	.	SERVICE_WIN32	,	win32service	.	SERVICE_STATE_ALL	)	
for	service	in	services	:	
sh	=	win32service	.	OpenService	(	sch	,	service	[	0	]	,	win32service	.	SC_MANAGER_CONNECT	)	
service_info	=	win32service	.	QueryServiceConfig	(	sh	)	
binary	=	None	
if	remote_server	:	
print	"str"	
else	:	
binary	=	get_binary	(	service_info	[	3	]	)	
print	"str"	
print	(	"str"	+	service	[	0	]	)	
print	(	"str"	+	service	[	1	]	)	
print	(	"str"	+	service_info	[	3	]	)	
if	binary	:	
print	(	"str"	+	binary	)	
else	:	
if	remote_server	:	
print	(	"str"	)	
else	:	
print	(	"str"	)	
print	(	"str"	+	service_info	[	7	]	)	

print	"str"	%	binary	
if	binary	:	
dump_perms	(	binary	,	"str"	,	{	"str"	:	1	}	)	
else	:	
print	"str"	

print	"str"	

try	:	
sh	=	win32service	.	OpenService	(	sch	,	service	[	0	]	,	win32con	.	GENERIC_READ	)	
except	:	
print	"str"	

try	:	
sd	=	win32service	.	QueryServiceObjectSecurity	(	sh	,	win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	)	
except	:	
print	"str"	

dump_sd	(	"str"	+	service	[	1	]	+	"str"	+	service	[	0	]	+	"str"	+	service_info	[	7	]	+	"str"	,	"str"	,	sd	,	{	"str"	:	1	}	)	

print	"str"	
print	"str"	


print	

def	vprint	(	string	)	:	
if	(	verbose	)	:	
print	string	

def	get_binary	(	binary_dirty	)	:	
m	=	re	.	search	(	"str"	,	binary_dirty	)	

if	m	and	os	.	path	.	exists	(	m	.	group	(	1	)	)	:	
return	m	.	group	(	1	)	
else	:	
if	m	:	
binary_dirty	=	m	.	group	(	1	)	

chunks	=	binary_dirty	.	split	(	"str"	)	
candidate	=	"str"	
for	chunk	in	chunks	:	
if	candidate	:	
candidate	=	candidate	+	"str"	
candidate	=	candidate	+	chunk	

if	os	.	path	.	exists	(	candidate	)	and	os	.	path	.	isfile	(	candidate	)	:	
return	candidate	
if	os	.	path	.	exists	(	candidate	+	"str"	)	and	os	.	path	.	isfile	(	candidate	+	"str"	)	:	
return	candidate	+	"str"	
global	on64bitwindows	
if	on64bitwindows	:	
candidate2	=	candidate	.	replace	(	"str"	,	"str"	)	
if	os	.	path	.	exists	(	candidate2	)	and	os	.	path	.	isfile	(	candidate2	)	:	
return	candidate2	
if	os	.	path	.	exists	(	candidate2	+	"str"	)	and	os	.	path	.	isfile	(	candidate2	+	"str"	)	:	
return	candidate2	+	"str"	

return	None	

def	print_weak_perms	(	type	,	weak_perms	,	options	=	{	}	)	:	
brief	=	0	
if	options	:	
if	options	[	"str"	]	:	
brief	=	1	
for	perms	in	weak_perms	:	
object_name	=	perms	[	0	]	
domain	=	perms	[	1	]	
principle	=	perms	[	2	]	
perm	=	perms	[	3	]	
if	len	(	perms	)	==	5	:	
acl_type	=	perms	[	4	]	
if	acl_type	==	"str"	:	
acl_type	=	"str"	
else	:	
acl_type	=	acl_type	+	"str"	
else	:	
acl_type	=	"str"	
slash	=	"str"	
if	domain	==	"str"	:	
slash	=	"str"	

if	brief	:	
print	"str"	%	(	acl_type	,	domain	,	slash	,	principle	,	perm	)	
else	:	
print	"str"	%	(	acl_type	,	domain	,	slash	,	principle	,	perm	,	type	,	object_name	)	

def	check_path	(	path	,	issue_no	)	:	
dirs	=	set	(	path	.	split	(	"str"	)	)	
exts	=	(	"str"	,	"str"	,	"str"	,	"str"	)	
for	dir	in	dirs	:	
weak_flag	=	0	
weak_perms	=	check_weak_write_perms	(	dir	,	"str"	)	
if	weak_perms	:	
save_issue	(	issue_no	,	"str"	,	weak_perms	)	
print_weak_perms	(	"str"	,	weak_perms	)	
weak_flag	=	1	
for	ext	in	exts	:	
for	file	in	glob	.	glob	(	dir	+	"str"	+	ext	)	:	

weak_perms	=	check_weak_write_perms	(	file	,	"str"	)	
if	weak_perms	:	
save_issue	(	issue_no	,	"str"	,	weak_perms	)	
print_weak_perms	(	"str"	,	weak_perms	)	
weak_flag	=	1	
if	weak_flag	==	1	:	
sys	.	stdout	.	write	(	"str"	)	
else	:	
sys	.	stdout	.	write	(	"str"	)	

def	get_user_paths	(	)	:	
try	:	
keyh	=	win32api	.	RegOpenKeyEx	(	win32con	.	HKEY_USERS	,	None	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	
return	0	
paths	=	[	]	
subkeys	=	win32api	.	RegEnumKeyEx	(	keyh	)	
for	subkey	in	subkeys	:	
try	:	
subkeyh	=	win32api	.	RegOpenKeyEx	(	keyh	,	subkey	[	0	]	+	"str"	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	
pass	
else	:	
subkey_count	,	value_count	,	mod_time	=	win32api	.	RegQueryInfoKey	(	subkeyh	)	

try	:	
path	,	type	=	win32api	.	RegQueryValueEx	(	subkeyh	,	"str"	)	
paths	.	append	(	(	subkey	[	0	]	,	path	)	)	
except	:	
pass	
return	paths	

def	get_system_path	(	)	:	

key_string	=	"str"	
try	:	
keyh	=	win32api	.	RegOpenKeyEx	(	win32con	.	HKEY_LOCAL_MACHINE	,	key_string	,	0	,	win32con	.	KEY_ENUMERATE_SUB_KEYS	|	win32con	.	KEY_QUERY_VALUE	|	win32con	.	KEY_READ	)	
except	:	
return	None	

try	:	
path	,	type	=	win32api	.	RegQueryValueEx	(	keyh	,	"str"	)	
return	path	
except	:	
return	None	







def	check_user_paths	(	)	:	
for	user_path	in	get_user_paths	(	)	:	
user_sid_s	=	user_path	[	0	]	
try	:	
user_sid	=	win32security	.	ConvertStringSidToSid	(	user_sid_s	)	
principle	,	domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	user_sid	)	
user_fq	=	domain	+	"str"	+	principle	
except	:	
print	"str"	%	user_sid_s	
continue	

path	=	user_path	[	1	]	
vprint	(	"str"	%	user_fq	)	
global	tmp_trusted_principles_fq	
tmp_trusted_principles_fq	=	(	user_fq	)	
check_path	(	path	,	"str"	)	
tmp_trusted_principles_fq	=	(	)	

def	check_current_path	(	)	:	
vprint	(	"str"	)	
global	tmp_trusted_principles_fq	
tmp_trusted_principles_fq	=	(	os	.	environ	[	"str"	]	+	"str"	+	os	.	environ	[	"str"	]	)	
check_path	(	os	.	environ	[	"str"	]	,	"str"	)	
tmp_trusted_principles_fq	=	(	)	

def	check_system_path	(	)	:	
vprint	(	"str"	)	
check_path	(	get_system_path	(	)	,	"str"	)	

def	check_paths	(	)	:	
check_system_path	(	)	
check_current_path	(	)	
check_user_paths	(	)	
print	

def	check_drives	(	)	:	
for	drive	in	win32api	.	GetLogicalDriveStrings	(	)	.	split	(	"str"	)	:	
sys	.	stdout	.	write	(	"str"	)	
type	=	win32file	.	GetDriveType	(	drive	)	
if	type	==	win32con	.	DRIVE_FIXED	:	
fs	=	win32api	.	GetVolumeInformation	(	drive	)	[	4	]	
if	fs	==	"str"	:	
warning	=	"str"	
weak_perms	=	check_weak_write_perms	(	drive	,	"str"	)	
if	weak_perms	:	


sys	.	stdout	.	write	(	"str"	)	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
elif	fs	==	"str"	:	
save_issue_string	(	"str"	,	"str"	,	"str"	+	drive	+	"str"	+	fs	+	"str"	)	
sys	.	stdout	.	write	(	"str"	)	
elif	fs	==	"str"	:	
save_issue_string	(	"str"	,	"str"	,	"str"	+	drive	+	"str"	+	fs	+	"str"	)	
sys	.	stdout	.	write	(	"str"	)	
else	:	
warning	=	"str"	
save_issue_string	(	"str"	,	"str"	,	"str"	+	drive	+	"str"	+	fs	+	"str"	)	
sys	.	stdout	.	write	(	"str"	)	




print	

def	check_shares	(	)	:	
resume	=	0	;	
try	:	
(	sharelist	,	total	,	resume	)	=	win32net	.	NetShareEnum	(	None	,	502	,	resume	,	9999	)	
for	share	in	sharelist	:	
sys	.	stdout	.	write	(	"str"	)	
sd	=	share	[	"str"	]	

if	sd	:	
weak_perms	=	check_weak_write_perms_by_sd	(	"str"	+	share	[	"str"	]	+	"str"	+	share	[	"str"	]	+	"str"	,	"str"	,	sd	)	
if	weak_perms	:	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
sys	.	stdout	.	write	(	"str"	)	
except	:	
print	"str"	


def	audit_shares	(	)	:	
print	
print	"str"	
print	

resume	=	0	;	
try	:	
(	sharelist	,	total	,	resume	)	=	win32net	.	NetShareEnum	(	remote_server	,	502	,	resume	,	999999	)	


for	share	in	sharelist	:	

types	=	[	]	
if	share	[	"str"	]	&	getattr	(	win32netcon	,	"str"	)	:	

types	.	append	(	"str"	)	
share	[	"str"	]	=	share	[	"str"	]	&	3	

for	stype	in	share_types	:	
if	share	[	"str"	]	==	getattr	(	win32netcon	,	stype	)	:	
types	.	append	(	stype	)	

break	
print	"str"	
print	"str"	+	share	[	"str"	]	
print	"str"	+	share	[	"str"	]	
print	"str"	+	share	[	"str"	]	
print	"str"	+	"str"	.	join	(	types	)	
print	"str"	%	share	[	"str"	]	
print	"str"	%	share	[	"str"	]	
print	"str"	%	share	[	"str"	]	
print	"str"	%	share	[	"str"	]	
print	"str"	%	share	[	"str"	]	
print	"str"	
dump_sd	(	share	[	"str"	]	,	"str"	,	share	[	"str"	]	)	
except	:	
print	"str"	

print	
print	"str"	
print	

def	check_progfiles	(	)	:	


prog_dirs	=	[	]	

exts	=	(	"str"	,	"str"	,	"str"	,	"str"	)	

if	os	.	getenv	(	"str"	)	:	
prog_dirs	.	append	(	os	.	environ	[	"str"	]	)	

if	os	.	getenv	(	"str"	)	:	
prog_dirs	.	append	(	os	.	environ	[	"str"	]	)	

dot_count	=	0	
weak_flag	=	0	
for	prog_dir	in	prog_dirs	:	

for	root	,	dirs	,	files	in	os	.	walk	(	prog_dir	)	:	









for	file	in	dirs	:	

weak_perms	=	check_weak_write_perms	(	os	.	path	.	join	(	root	,	file	)	,	"str"	)	
if	weak_perms	:	

save_issue	(	"str"	,	"str"	,	weak_perms	)	
weak_flag	=	1	
dir	=	file	
for	ext	in	exts	:	
for	f	in	glob	.	glob	(	root	+	"str"	+	dir	+	"str"	+	ext	)	:	

weak_perms	=	check_weak_write_perms	(	f	,	"str"	)	
if	weak_perms	:	
print_weak_perms	(	"str"	,	weak_perms	)	
save_issue	(	"str"	,	"str"	,	weak_perms	)	
weak_flag	=	1	
dot_count	=	dot_count	+	1	;	

if	dot_count	>	10	:	
if	weak_flag	==	1	:	
sys	.	stdout	.	write	(	"str"	)	
else	:	
sys	.	stdout	.	write	(	"str"	)	
dot_count	=	0	;	
weak_flag	=	0	;	
print	

def	check_patches	(	)	:	


patchlist	=	Popen	(	[	"str"	]	,	stdout	=	PIPE	)	.	communicate	(	)	[	0	]	






def	print_section	(	title	)	:	
if	(	verbose	!=	0	)	:	
print	"str"	
print	title	
print	"str"	
print	
else	:	
sys	.	stdout	.	write	(	title	+	"str"	)	


def	int2bin	(	n	)	:	
bStr	=	"str"	
if	n	<	0	:	n	=	n	+	2	^	32	
if	n	==	0	:	return	"str"	
while	n	>	0	:	
bStr	=	str	(	n	%	2	)	+	bStr	
n	=	n	>>	1	
return	bStr	

def	impersonate	(	username	,	password	,	domain	)	:	
if	username	:	
print	"str"	
print	"str"	+	str	(	username	)	
print	"str"	+	str	(	password	)	
print	"str"	+	str	(	domain	)	
handle	=	win32security	.	LogonUser	(	username	,	domain	,	password	,	win32security	.	LOGON32_LOGON_NEW_CREDENTIALS	,	win32security	.	LOGON32_PROVIDER_WINNT50	)	
win32security	.	ImpersonateLoggedOnUser	(	handle	)	
else	:	
print	"str"	
print	

def	audit_passpol	(	)	:	
print	
print	"str"	
print	

try	:	
data	=	win32net	.	NetUserModalsGet	(	remote_server	,	0	)	
for	key	in	data	.	keys	(	)	:	
print	"str"	%	(	key	,	data	[	key	]	)	
data	=	win32net	.	NetUserModalsGet	(	remote_server	,	1	)	
for	key	in	data	.	keys	(	)	:	
print	"str"	%	(	key	,	data	[	key	]	)	
data	=	win32net	.	NetUserModalsGet	(	remote_server	,	2	)	
for	key	in	data	.	keys	(	)	:	
if	key	==	"str"	:	
print	"str"	%	(	key	,	win32security	.	ConvertSidToStringSid	(	data	[	key	]	)	)	
elif	key	==	"str"	and	data	[	key	]	==	"str"	:	
print	"str"	%	(	key	,	data	[	key	]	)	
else	:	
print	"str"	%	(	key	,	data	[	key	]	)	
data	=	win32net	.	NetUserModalsGet	(	remote_server	,	3	)	
for	key	in	data	.	keys	(	)	:	
if	key	==	"str"	and	data	[	key	]	==	0	:	
print	"str"	%	(	key	,	data	[	key	]	)	
else	:	
print	"str"	%	(	key	,	data	[	key	]	)	
except	:	
print	"str"	


def	get_group_members	(	server	,	group	,	depth	)	:	
resume	=	0	
indent	=	"str"	*	depth	
members	=	[	]	
while	True	:	
try	:	
m	,	total	,	resume	=	win32net	.	NetLocalGroupGetMembers	(	server	,	group	,	2	,	resume	,	999999	)	
except	:	
break	
for	member	in	m	:	
if	member	[	"str"	]	==	4	:	
type	=	"str"	
g	=	member	[	"str"	]	.	split	(	"str"	)	
print	indent	+	member	[	"str"	]	+	"str"	+	str	(	type	)	+	"str"	
get_group_members	(	server	,	g	[	1	]	,	depth	+	1	)	
elif	member	[	"str"	]	==	2	:	
type	=	"str"	
print	indent	+	member	[	"str"	]	+	"str"	+	str	(	type	)	+	"str"	
elif	member	[	"str"	]	==	1	:	
type	=	"str"	
print	indent	+	member	[	"str"	]	+	"str"	+	str	(	type	)	+	"str"	
else	:	
type	=	"str"	+	str	(	member	[	"str"	]	)	
print	indent	+	member	[	"str"	]	+	"str"	+	str	(	type	)	+	"str"	
if	resume	==	0	:	
break	

def	audit_admin_users	(	)	:	
print	
for	group	in	(	"str"	,	"str"	,	"str"	)	:	
print	"str"	+	group	+	"str"	
get_group_members	(	remote_server	,	group	,	0	)	
print	





























def	audit_logged_in	(	)	:	
resume	=	0	
print	"str"	
try	:	
while	True	:	
users	,	total	,	resume	=	win32net	.	NetWkstaUserEnum	(	remote_server	,	1	,	resume	,	999999	)	
for	user	in	users	:	
print	"str"	%	(	user	[	"str"	]	,	user	[	"str"	]	,	user	[	"str"	]	)	
if	resume	==	0	:	
break	
except	:	
print	"str"	

def	audit_host_info	(	)	:	
print	"str"	
if	remote_server	:	
print	"str"	+	remote_server	














print	
print	"str"	
print	

try	:	


serverinfo	=	win32net	.	NetWkstaGetInfo	(	remote_server	,	102	)	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	(	serverinfo	[	"str"	]	,	serverinfo	[	"str"	]	)	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	serverinfo	[	"str"	]	

if	serverinfo	[	"str"	]	&	win32netcon	.	PLATFORM_ID_NT	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_OS2	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_DOS	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_OSF	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_VMS	:	
print	"str"	
except	:	
print	"str"	

print	
print	"str"	
print	

try	:	


serverinfo	=	win32net	.	NetServerGetInfo	(	remote_server	,	102	)	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	(	serverinfo	[	"str"	]	,	serverinfo	[	"str"	]	)	
print	"str"	%	serverinfo	[	"str"	]	
print	"str"	%	serverinfo	[	"str"	]	

if	serverinfo	[	"str"	]	&	win32netcon	.	PLATFORM_ID_NT	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_OS2	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_DOS	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_OSF	:	
print	"str"	
if	serverinfo	[	"str"	]	==	win32netcon	.	PLATFORM_ID_VMS	:	
print	"str"	
for	sv_type	in	sv_types	:	
if	serverinfo	[	"str"	]	&	getattr	(	win32netcon	,	sv_type	)	:	
print	"str"	+	sv_type	
except	:	
print	"str"	


print	
print	"str"	
print	

try	:	
ph	=	win32security	.	LsaOpenPolicy	(	remote_server	,	win32security	.	POLICY_VIEW_LOCAL_INFORMATION	|	win32security	.	POLICY_LOOKUP_NAMES	)	
print	"str"	
print	win32security	.	LsaQueryInformationPolicy	(	ph	,	win32security	.	PolicyDnsDomainInformation	)	
print	"str"	
print	win32security	.	LsaQueryInformationPolicy	(	ph	,	win32security	.	PolicyPrimaryDomainInformation	)	
print	"str"	
print	win32security	.	LsaQueryInformationPolicy	(	ph	,	win32security	.	PolicyAccountDomainInformation	)	
print	"str"	
print	win32security	.	LsaQueryInformationPolicy	(	ph	,	win32security	.	PolicyLsaServerRoleInformation	)	
except	:	
print	"str"	






























print	
print	"str"	
print	

try	:	
domain	=	None	
print	"str"	+	win32net	.	NetGetDCName	(	remote_server	,	domain	)	


dc_seen	=	{	}	
for	filter	in	(	0	,	0x00004000	,	0x00000080	,	0x00001000	,	0x00000400	,	0x00000040	,	0x00000010	)	:	
dc_info	=	win32security	.	DsGetDcName	(	remote_server	,	None	,	None	,	None	,	filter	)	
if	not	dc_info	[	"str"	]	in	dc_seen	:	
print	"str"	
for	k	in	dc_info	:	
print	k	+	"str"	+	str	(	dc_info	[	k	]	)	
dc_seen	[	dc_info	[	"str"	]	]	=	1	
print	"str"	







except	:	
print	"str"	





def	audit_user_group	(	)	:	
try	:	
ph	=	win32security	.	LsaOpenPolicy	(	remote_server	,	win32security	.	POLICY_VIEW_LOCAL_INFORMATION	|	win32security	.	POLICY_LOOKUP_NAMES	)	
except	:	
pass	

print	
print	"str"	
print	
resume	=	0	
groups	=	[	]	
while	True	:	
try	:	
g	,	total	,	resume	=	win32net	.	NetLocalGroupEnum	(	remote_server	,	0	,	resume	,	999999	)	
groups	=	groups	+	g	
if	resume	==	0	:	
break	
except	:	
print	"str"	
break	
for	group	in	groups	:	
members	=	[	]	
while	True	:	
m	,	total	,	resume	=	win32net	.	NetLocalGroupGetMembers	(	remote_server	,	group	[	"str"	]	,	1	,	resume	,	999999	)	
for	member	in	m	:	
members	.	append	(	member	[	"str"	]	)	
if	resume	==	0	:	
break	
sid	,	s	,	i	=	win32security	.	LookupAccountName	(	remote_server	,	group	[	"str"	]	)	
sid_string	=	win32security	.	ConvertSidToStringSid	(	sid	)	
print	"str"	%	(	group	[	"str"	]	,	sid_string	)	
for	m	in	members	:	
print	"str"	%	(	group	[	"str"	]	,	m	)	
if	verbose	:	
try	:	
privs	=	win32security	.	LsaEnumerateAccountRights	(	ph	,	sid	)	
for	priv	in	privs	:	
print	"str"	%	(	group	[	"str"	]	,	priv	)	
except	:	
print	"str"	%	(	group	[	"str"	]	)	

print	
print	"str"	
print	
resume	=	0	
groups	=	[	]	
while	True	:	
try	:	
g	,	total	,	resume	=	win32net	.	NetGroupEnum	(	remote_server	,	0	,	resume	,	999999	)	
groups	=	groups	+	g	
if	resume	==	0	:	
break	
except	:	
print	"str"	
break	

for	group	in	groups	:	
members	=	[	]	
while	True	:	
try	:	
m	,	total	,	resume	=	win32net	.	NetGroupGetUsers	(	remote_server	,	group	[	"str"	]	,	0	,	resume	,	999999	)	
for	member	in	m	:	
members	.	append	(	member	[	"str"	]	)	
if	resume	==	0	:	
break	
except	:	
print	"str"	
break	
sid	,	s	,	i	=	win32security	.	LookupAccountName	(	remote_server	,	group	[	"str"	]	)	
sid_string	=	win32security	.	ConvertSidToStringSid	(	sid	)	
print	"str"	%	(	group	[	"str"	]	,	sid_string	)	
for	m	in	members	:	
print	"str"	%	(	group	[	"str"	]	,	m	)	
if	verbose	:	
try	:	
privs	=	win32security	.	LsaEnumerateAccountRights	(	ph	,	sid	)	
for	priv	in	privs	:	
print	"str"	%	(	group	[	"str"	]	,	priv	)	
except	:	
print	"str"	%	(	group	[	"str"	]	)	

print	
print	"str"	
print	
resume	=	0	
users	=	[	]	
if	verbose	:	
level	=	11	
else	:	
level	=	0	
while	True	:	
try	:	


u	,	total	,	resume	=	win32net	.	NetUserEnum	(	remote_server	,	level	,	0	,	resume	,	999999	)	
for	user	in	u	:	
if	verbose	:	
for	k	in	user	:	
if	k	!=	"str"	:	
print	k	+	"str"	+	str	(	user	[	k	]	)	
print	
users	.	append	(	user	[	"str"	]	)	
if	resume	==	0	:	
break	
except	:	
print	"str"	
break	

for	user	in	users	:	
gprivs	=	[	]	
sid	,	s	,	i	=	win32security	.	LookupAccountName	(	remote_server	,	user	)	
sid_string	=	win32security	.	ConvertSidToStringSid	(	sid	)	
print	"str"	%	(	user	,	sid_string	)	
groups	=	win32net	.	NetUserGetLocalGroups	(	remote_server	,	user	,	0	)	
for	group	in	groups	:	
gsid	,	s	,	i	=	win32security	.	LookupAccountName	(	remote_server	,	group	)	
try	:	
privs	=	win32security	.	LsaEnumerateAccountRights	(	ph	,	gsid	)	
gprivs	=	list	(	list	(	gprivs	)	+	list	(	privs	)	)	
except	:	
pass	
print	"str"	%	(	user	,	group	)	
group_list	=	win32net	.	NetUserGetGroups	(	remote_server	,	user	)	
groups	=	[	]	
for	g	in	group_list	:	
groups	.	append	(	g	[	0	]	)	
for	group	in	groups	:	
print	"str"	%	(	user	,	group	)	
if	verbose	:	
privs	=	[	]	
try	:	
privs	=	win32security	.	LsaEnumerateAccountRights	(	ph	,	sid	)	
except	:	
pass	
for	priv	in	list	(	set	(	list	(	gprivs	)	+	list	(	privs	)	)	)	:	
print	"str"	%	(	user	,	priv	)	

if	verbose	:	
print	
print	"str"	
print	

for	priv	in	windows_privileges	:	
try	:	
for	s	in	win32security	.	LsaEnumerateAccountsWithUserRight	(	ph	,	priv	)	:	
priv_desc	=	"str"	
try	:	
priv_desc	=	win32security	.	LookupPrivilegeDisplayName	(	remote_server	,	priv	)	
except	:	
pass	

name	,	domain	,	type	=	win32security	.	LookupAccountSid	(	remote_server	,	s	)	
type_string	=	"str"	
if	type	==	4	:	
type_string	=	"str"	
if	type	==	5	:	
type_string	=	"str"	
print	"str"	%	(	priv	,	priv_desc	,	domain	,	name	,	type_string	)	

except	:	

pass	

print	"str"	%	version	


try	:	
opts	,	args	=	getopt	.	getopt	(	sys	.	argv	[	1	:	]	,	"str"	,	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	)	
except	getopt	.	GetoptError	,	err	:	

print	str	(	err	)	
usage	(	)	
sys	.	exit	(	2	)	
output	=	None	
for	o	,	a	in	opts	:	
if	o	in	(	"str"	,	"str"	)	:	
all_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
registry_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
path_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
service_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
drive_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
eventlog_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
progfiles_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
process_checks	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
share_checks	=	1	


elif	o	in	(	"str"	,	"str"	)	:	
logged_in_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
user_group_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
passpol_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
admin_users_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
process_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
host_info_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
service_audit	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
usage	(	)	
sys	.	exit	(	)	
elif	o	in	(	"str"	,	"str"	)	:	
weak_perms_only	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
ignore_trusted	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
owner_info	=	1	
elif	o	in	(	"str"	,	"str"	)	:	
verbose	=	verbose	+	1	
elif	o	in	(	"str"	,	"str"	)	:	
report_file_name	=	a	
elif	o	in	(	"str"	,	"str"	)	:	
remote_server	=	a	
print	"str"	+	a	
elif	o	in	(	"str"	,	"str"	)	:	
remote_username	=	a	
elif	o	in	(	"str"	,	"str"	)	:	
remote_password	=	a	
elif	o	in	(	"str"	,	"str"	)	:	
remote_domain	=	a	
else	:	
assert	False	,	"str"	

if	all_checks	:	
registry_checks	=	1	
path_checks	=	1	
service_checks	=	1	
service_audit	=	1	
drive_checks	=	1	
eventlog_checks	=	1	
progfiles_checks	=	1	
process_checks	=	1	
share_checks	=	1	
user_group_audit	=	1	
passpol_audit	=	1	
logged_in_audit	=	1	
admin_users_audit	=	1	
host_info_audit	=	1	
patch_checks	=	1	
process_audit	=	1	


if	not	(	
registry_checks	or	
path_checks	or	
service_checks	or	
service_audit	or	
drive_checks	or	
eventlog_checks	or	
progfiles_checks	or	
process_checks	or	
share_checks	or	
logged_in_audit	or	
user_group_audit	or	
passpol_audit	or	
admin_users_audit	or	
host_info_audit	or	
process_audit	or	
patch_checks	
)	:	
usage	(	)	

if	report_file_name	==	None	:	
report_file_name	=	"str"	+	socket	.	gethostname	(	)	+	"str"	


REPORT	=	open	(	report_file_name	,	"str"	)	


print	"str"	
print	"str"	+	str	(	registry_checks	)	
print	"str"	+	str	(	path_checks	)	
print	"str"	+	str	(	service_checks	)	
print	"str"	+	str	(	drive_checks	)	
print	"str"	+	str	(	eventlog_checks	)	
print	"str"	+	str	(	progfiles_checks	)	
print	"str"	+	str	(	patch_checks	)	
print	"str"	+	str	(	user_group_audit	)	
print	"str"	+	str	(	passpol_audit	)	
print	"str"	+	str	(	logged_in_audit	)	
print	"str"	+	str	(	admin_users_audit	)	
print	"str"	+	str	(	host_info_audit	)	
print	"str"	+	str	(	process_audit	)	
print	"str"	+	str	(	service_audit	)	
print	"str"	+	str	(	ignore_trusted	)	
print	"str"	+	str	(	owner_info	)	
print	"str"	+	str	(	weak_perms_only	)	
print	"str"	+	str	(	verbose	)	
print	"str"	+	report_file_name	
print	

impersonate	(	remote_username	,	remote_password	,	remote_domain	)	







try	:	
sd	=	win32security	.	GetNamedSecurityInfo	(	
"str"	,	
win32security	.	SE_FILE_OBJECT	,	
win32security	.	OWNER_SECURITY_INFORMATION	|	win32security	.	DACL_SECURITY_INFORMATION	
)	
except	:	

pass	





dummy	=	win32net	.	NetLocalGroupEnum	(	None	,	0	,	0	,	1000	)	




try	:	
k32	.	Wow64DisableWow64FsRedirection	(	ctypes	.	byref	(	wow64	)	)	
except	:	
on64bitwindows	=	0	




if	registry_checks	:	
print_section	(	"str"	)	
check_registry	(	)	

if	path_checks	:	
print_section	(	"str"	)	
check_paths	(	)	

if	service_checks	:	
print_section	(	"str"	)	
check_services	(	)	

if	service_audit	:	
print_section	(	"str"	)	
audit_services	(	)	

if	drive_checks	:	
print_section	(	"str"	)	
check_drives	(	)	

if	eventlog_checks	:	
print_section	(	"str"	)	
check_event_logs	(	)	

if	progfiles_checks	:	
print_section	(	"str"	)	
check_progfiles	(	)	

if	process_checks	:	
print_section	(	"str"	)	
check_processes	(	)	

if	share_checks	:	
print_section	(	"str"	)	
check_shares	(	)	

if	logged_in_audit	:	
print_section	(	"str"	)	
audit_logged_in	(	)	

if	user_group_audit	:	
print_section	(	"str"	)	
audit_user_group	(	)	

if	passpol_audit	:	
print_section	(	"str"	)	
audit_passpol	(	)	

if	admin_users_audit	:	
print_section	(	"str"	)	
audit_admin_users	(	)	

if	host_info_audit	:	
print_section	(	"str"	)	
audit_host_info	(	)	

if	process_audit	:	
print_section	(	"str"	)	
audit_processes	(	)	

if	patch_checks	:	
print_section	(	"str"	)	
check_patches	(	)	










audit_data	=	{	}	

audit_data	[	"str"	]	=	socket	.	gethostname	(	)	
ver_list	=	win32api	.	GetVersionEx	(	1	)	
os_ver	=	str	(	ver_list	[	0	]	)	+	"str"	+	str	(	ver_list	[	1	]	)	

if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	
if	os_ver	==	"str"	:	
os_str	=	"str"	

audit_data	[	"str"	]	=	os_str	


audit_data	[	"str"	]	=	str	(	ver_list	[	0	]	)	+	"str"	+	str	(	ver_list	[	1	]	)	+	"str"	+	str	(	ver_list	[	2	]	)	+	"str"	+	str	(	ver_list	[	5	]	)	

audit_data	[	"str"	]	=	local_ips	
audit_data	[	"str"	]	=	win32api	.	GetDomainName	(	)	
audit_data	[	"str"	]	=	version	
audit_data	[	"str"	]	=	datetime	.	datetime	.	now	(	)	.	strftime	(	"str"	)	
audit_data	[	"str"	]	=	os	.	environ	[	"str"	]	+	"str"	+	os	.	environ	[	"str"	]	
audit_data	[	"str"	]	=	trusted_principles_fq	
audit_data	[	"str"	]	=	trusted_principles	
audit_data	[	"str"	]	=	"str"	

REPORT	.	write	(	format_issues	(	"str"	,	issue_template	,	issues	)	)	
REPORT	.	close	
print	
print	
print	"str"	+	report_file_name	
print	
	