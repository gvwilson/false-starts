










BOT_NAME	=	"str"	

SPIDER_MODULES	=	[	"str"	]	
NEWSPIDER_MODULE	=	"str"	

LOG_LEVEL	=	"str"	
IMAGES_STORE	=	"str"	


USER_AGENT	=	"str"	


ROBOTSTXT_OBEY	=	False	










CONCURRENT_REQUESTS_PER_IP	=	1	


COOKIES_ENABLED	=	True	






























ITEM_PIPELINES	=	{	
"str"	:	1	,	
"str"	:	300	,	
}	





















	