


import	hashlib	

import	douban	.	database	as	db	

from	douban	.	items	import	Comment	,	BookMeta	,	MovieMeta	,	Subject	

from	scrapy	import	Request	
from	scrapy	.	pipelines	.	images	import	ImagesPipeline	
from	scrapy	.	utils	.	misc	import	arg_to_iter	
from	scrapy	.	utils	.	python	import	to_bytes	

from	twisted	.	internet	.	defer	import	DeferredList	

cursor	=	db	.	connection	.	cursor	(	)	


class	DoubanPipeline	(	object	)	:	
def	get_subject	(	self	,	item	)	:	
sql	=	"str"	%	item	[	"str"	]	
cursor	.	execute	(	sql	)	
return	cursor	.	fetchone	(	)	

def	save_subject	(	self	,	item	)	:	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
fields	=	"str"	.	join	(	keys	)	
temp	=	"str"	.	join	(	[	"str"	]	*	len	(	keys	)	)	
sql	=	"str"	%	(	fields	,	temp	)	
cursor	.	execute	(	sql	,	values	)	
return	db	.	connection	.	commit	(	)	

def	get_movie_meta	(	self	,	item	)	:	
sql	=	"str"	%	item	[	"str"	]	
cursor	.	execute	(	sql	)	
return	cursor	.	fetchone	(	)	

def	save_movie_meta	(	self	,	item	)	:	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
fields	=	"str"	.	join	(	keys	)	
temp	=	"str"	.	join	(	[	"str"	]	*	len	(	keys	)	)	
sql	=	"str"	%	(	fields	,	temp	)	
cursor	.	execute	(	sql	,	tuple	(	i	.	strip	(	)	for	i	in	values	)	)	
return	db	.	connection	.	commit	(	)	

def	update_movie_meta	(	self	,	item	)	:	
douban_id	=	item	.	pop	(	"str"	)	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
values	.	append	(	douban_id	)	
fields	=	[	"str"	%	i	+	"str"	for	i	in	keys	]	
sql	=	"str"	%	(	"str"	.	join	(	fields	)	,	"str"	)	
cursor	.	execute	(	sql	,	tuple	(	i	.	strip	(	)	for	i	in	values	)	)	
return	db	.	connection	.	commit	(	)	

def	get_book_meta	(	self	,	item	)	:	
sql	=	"str"	%	item	[	"str"	]	
cursor	.	execute	(	sql	)	
return	cursor	.	fetchone	(	)	

def	save_book_meta	(	self	,	item	)	:	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
fields	=	"str"	.	join	(	keys	)	
temp	=	"str"	.	join	(	[	"str"	]	*	len	(	keys	)	)	
sql	=	"str"	%	(	fields	,	temp	)	
cursor	.	execute	(	sql	,	tuple	(	i	.	strip	(	)	for	i	in	values	)	)	
return	db	.	connection	.	commit	(	)	

def	update_book_meta	(	self	,	item	)	:	
douban_id	=	item	.	pop	(	"str"	)	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
values	.	append	(	douban_id	)	
fields	=	[	"str"	%	i	+	"str"	for	i	in	keys	]	
sql	=	"str"	%	(	"str"	.	join	(	fields	)	,	"str"	)	
cursor	.	execute	(	sql	,	values	)	
return	db	.	connection	.	commit	(	)	

def	get_comment	(	self	,	item	)	:	
sql	=	"str"	%	item	[	"str"	]	
cursor	.	execute	(	sql	)	
return	cursor	.	fetchone	(	)	

def	save_comment	(	self	,	item	)	:	
keys	=	item	.	keys	(	)	
values	=	tuple	(	item	.	values	(	)	)	
fields	=	"str"	.	join	(	keys	)	
temp	=	"str"	.	join	(	[	"str"	]	*	len	(	keys	)	)	
sql	=	"str"	%	(	fields	,	temp	)	
cursor	.	execute	(	sql	,	values	)	
return	db	.	connection	.	commit	(	)	

def	process_item	(	self	,	item	,	spider	)	:	
if	isinstance	(	item	,	Subject	)	:	

exist	=	self	.	get_subject	(	item	)	
if	not	exist	:	
self	.	save_subject	(	item	)	
elif	isinstance	(	item	,	MovieMeta	)	:	

exist	=	self	.	get_movie_meta	(	item	)	
if	not	exist	:	
try	:	
self	.	save_movie_meta	(	item	)	
except	Exception	as	e	:	
print	(	item	)	
print	(	e	)	
else	:	
self	.	update_movie_meta	(	item	)	
elif	isinstance	(	item	,	BookMeta	)	:	

exist	=	self	.	get_book_meta	(	item	)	
if	not	exist	:	
try	:	
self	.	save_book_meta	(	item	)	
except	Exception	as	e	:	
print	(	item	)	
print	(	e	)	
else	:	
self	.	update_book_meta	(	item	)	
elif	isinstance	(	item	,	Comment	)	:	

exist	=	self	.	get_comment	(	item	)	
if	not	exist	:	
try	:	
self	.	save_comment	(	item	)	
except	Exception	as	e	:	
print	(	item	)	
print	(	e	)	
return	item	


class	CoverPipeline	(	ImagesPipeline	)	:	
def	process_item	(	self	,	item	,	spider	)	:	
if	"str"	not	in	spider	.	name	:	
return	item	
info	=	self	.	spiderinfo	
requests	=	arg_to_iter	(	self	.	get_media_requests	(	item	,	info	)	)	
dlist	=	[	self	.	_process_request	(	r	,	info	)	for	r	in	requests	]	
dfd	=	DeferredList	(	dlist	,	consumeErrors	=	1	)	
return	dfd	.	addCallback	(	self	.	item_completed	,	item	,	info	)	

def	file_path	(	self	,	request	,	response	=	None	,	info	=	None	)	:	

def	_warn	(	)	:	
from	scrapy	.	exceptions	import	ScrapyDeprecationWarning	
import	warnings	
warnings	.	warn	(	"str"	
"str"	,	
category	=	ScrapyDeprecationWarning	,	stacklevel	=	1	)	


if	not	isinstance	(	request	,	Request	)	:	
_warn	(	)	
url	=	request	
else	:	
url	=	request	.	url	


if	not	hasattr	(	self	.	file_key	,	"str"	)	:	
_warn	(	)	
return	self	.	file_key	(	url	)	
elif	not	hasattr	(	self	.	image_key	,	"str"	)	:	
_warn	(	)	
return	self	.	image_key	(	url	)	


image_guid	=	hashlib	.	sha1	(	to_bytes	(	url	)	)	.	hexdigest	(	)	
return	"str"	%	(	image_guid	[	9	]	,	image_guid	[	19	]	,	image_guid	[	29	]	,	image_guid	[	39	]	,	image_guid	)	

def	get_media_requests	(	self	,	item	,	info	)	:	
if	item	[	"str"	]	:	
return	Request	(	item	[	"str"	]	)	

def	item_completed	(	self	,	results	,	item	,	info	)	:	
image_paths	=	[	x	[	"str"	]	for	ok	,	x	in	results	if	ok	]	
if	image_paths	:	
item	[	"str"	]	=	image_paths	[	0	]	
else	:	
item	[	"str"	]	=	"str"	
return	item	
	