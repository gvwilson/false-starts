



import	string	
import	random	
import	douban	.	util	as	util	
import	douban	.	database	as	db	
import	douban	.	validator	as	validator	

from	scrapy	import	Request	,	Spider	
from	douban	.	items	import	MovieMeta	


cursor	=	db	.	connection	.	cursor	(	)	


class	MovieMetaSpider	(	Spider	)	:	
name	=	"str"	
user_agent	=	"str"	
allowed_domains	=	[	"str"	]	
sql	=	"str"	
cursor	.	execute	(	sql	)	
movies	=	cursor	.	fetchall	(	)	
start_urls	=	(	
"str"	%	i	[	"str"	]	for	i	in	movies	
)	

def	start_requests	(	self	)	:	
for	url	in	self	.	start_urls	:	
bid	=	"str"	.	join	(	random	.	choice	(	string	.	ascii_letters	+	string	.	digits	)	for	x	in	range	(	11	)	)	
cookies	=	{	
"str"	:	bid	,	
"str"	:	True	,	
"str"	:	[	302	]	,	
}	
yield	Request	(	url	,	cookies	=	cookies	)	

def	get_douban_id	(	self	,	meta	,	response	)	:	
meta	[	"str"	]	=	response	.	url	[	33	:	-	1	]	
return	meta	

def	get_type	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	"str"	
else	:	
meta	[	"str"	]	=	"str"	
return	meta	

def	get_cover	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
if	(	data	[	0	]	.	find	(	"str"	)	==	-	1	)	:	
meta	[	"str"	]	=	data	[	0	]	.	replace	(	"str"	,	"str"	)	.	replace	(	"str"	,	"str"	)	
else	:	
meta	[	"str"	]	=	"str"	
return	meta	

def	get_name	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	[	:	-	5	]	.	strip	(	)	
return	meta	

def	get_slug	(	self	,	meta	,	response	)	:	
meta	[	"str"	]	=	util	.	shorturl	(	meta	[	"str"	]	)	
return	meta	

def	get_year	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	validator	.	match_year	(	data	[	0	]	)	
return	meta	

def	get_directors	(	self	,	meta	,	response	)	:	
regx	=	"str"	
directors	=	response	.	xpath	(	regx	)	.	extract	(	)	
meta	[	"str"	]	=	validator	.	process_slash_str	(	"str"	.	join	(	directors	)	)	
return	meta	

def	get_actors	(	self	,	meta	,	response	)	:	
regx	=	"str"	
actors	=	response	.	xpath	(	regx	)	.	extract	(	)	
meta	[	"str"	]	=	validator	.	process_slash_str	(	"str"	.	join	(	actors	)	)	
return	meta	

def	get_genres	(	self	,	meta	,	response	)	:	
regx	=	"str"	
genres	=	response	.	xpath	(	regx	)	.	extract	(	)	
meta	[	"str"	]	=	"str"	.	join	(	genres	)	
return	meta	

def	get_official_site	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	validator	.	process_url	(	data	[	0	]	)	
return	meta	

def	get_regions	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	get_languages	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	get_release_date	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
release_date	=	validator	.	str_to_date	(	validator	.	match_date	(	data	[	0	]	)	)	
if	release_date	:	
meta	[	"str"	]	=	release_date	
return	meta	

def	get_runtime	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	get_alias	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	validator	.	process_slash_str	(	data	[	0	]	)	
return	meta	

def	get_imdb_id	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	.	strip	(	)	.	split	(	"str"	)	[	0	]	[	26	:	]	
return	meta	

def	get_score	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	get_votes	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	get_tags	(	self	,	meta	,	response	)	:	
regx	=	"str"	
tags	=	response	.	xpath	(	regx	)	.	extract	(	)	
meta	[	"str"	]	=	"str"	.	join	(	tags	)	
return	meta	

def	get_comments	(	self	,	meta	,	response	)	:	
regx	=	"str"	
comments	=	response	.	xpath	(	regx	)	.	extract	(	)	
meta	[	"str"	]	=	"str"	.	join	(	(	i	.	strip	(	)	for	i	in	comments	)	)	
return	meta	

def	get_storyline	(	self	,	meta	,	response	)	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
else	:	
regx	=	"str"	
data	=	response	.	xpath	(	regx	)	.	extract	(	)	
if	data	:	
meta	[	"str"	]	=	data	[	0	]	
return	meta	

def	parse	(	self	,	response	)	:	
if	35000	>	len	(	response	.	body	)	:	
print	(	response	.	body	)	
print	(	response	.	url	)	
elif	404	==	response	.	status	:	
print	(	response	.	url	)	
else	:	
meta	=	MovieMeta	(	)	
self	.	get_douban_id	(	meta	,	response	)	
self	.	get_type	(	meta	,	response	)	
self	.	get_cover	(	meta	,	response	)	
self	.	get_name	(	meta	,	response	)	
self	.	get_year	(	meta	,	response	)	
self	.	get_directors	(	meta	,	response	)	
self	.	get_actors	(	meta	,	response	)	
self	.	get_genres	(	meta	,	response	)	
self	.	get_official_site	(	meta	,	response	)	
self	.	get_regions	(	meta	,	response	)	
self	.	get_languages	(	meta	,	response	)	
self	.	get_release_date	(	meta	,	response	)	
self	.	get_runtime	(	meta	,	response	)	
self	.	get_alias	(	meta	,	response	)	
self	.	get_imdb_id	(	meta	,	response	)	
self	.	get_score	(	meta	,	response	)	
self	.	get_votes	(	meta	,	response	)	
self	.	get_tags	(	meta	,	response	)	
self	.	get_storyline	(	meta	,	response	)	
self	.	get_slug	(	meta	,	response	)	
return	meta	
	