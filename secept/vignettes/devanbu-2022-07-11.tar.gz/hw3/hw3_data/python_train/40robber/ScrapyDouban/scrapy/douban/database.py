


import	pymysql	

MYSQL_DB	=	"str"	
MYSQL_USER	=	"str"	
MYSQL_PASS	=	"str"	
MYSQL_HOST	=	"str"	

connection	=	pymysql	.	connect	(	host	=	MYSQL_HOST	,	user	=	MYSQL_USER	,	
password	=	MYSQL_PASS	,	db	=	MYSQL_DB	,	
charset	=	"str"	,	
cursorclass	=	pymysql	.	cursors	.	DictCursor	)	
	