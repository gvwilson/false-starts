







from	__future__	import	print_function	
import	sys	
import	os	

CONTENT_FLAG	=	"str"	
NUM_FLAG	=	"str"	


class	InputError	(	Exception	)	:	
def	__init__	(	self	,	message	)	:	
self	.	message	=	message	

def	__str__	(	self	)	:	
return	repr	(	self	.	message	)	


def	check_path	(	path	)	:	

if	not	os	.	path	.	exists	(	path	)	:	
print	(	"str"	.	format	(	path	=	path	)	)	
return	False	
else	:	
return	True	


def	read_file	(	input_path	)	:	
with	open	(	input_path	,	"str"	)	as	fb	:	
return	fb	.	read	(	)	


def	write_file	(	output_path	,	output_data	)	:	
with	open	(	output_path	,	"str"	)	as	fb	:	
fb	.	write	(	output_data	)	


def	make_content	(	num	)	:	
template_path	=	os	.	path	.	join	(	os	.	path	.	abspath	(	os	.	curdir	)	,	"str"	)	
output_path	=	os	.	path	.	join	(	os	.	path	.	abspath	(	os	.	curdir	)	,	num	)	
content_path	=	os	.	path	.	join	(	output_path	,	"str"	+	num	+	"str"	)	
if	not	(	check_path	(	content_path	)	and	check_path	(	template_path	)	)	:	

return	None	
temple_data	=	read_file	(	template_path	)	.	replace	(	NUM_FLAG	,	num	)	

content_data	=	read_file	(	content_path	)	

output_data	=	temple_data	.	replace	(	CONTENT_FLAG	,	content_data	)	

write_file	(	os	.	path	.	join	(	output_path	,	"str"	.	format	(	num	=	num	)	)	,	output_data	)	
print	(	"str"	.	format	(	num	=	num	)	)	


def	make_all_content	(	)	:	
dir_list	=	os	.	listdir	(	os	.	path	.	abspath	(	os	.	curdir	)	)	
for	fi_dir	in	dir_list	:	

if	os	.	path	.	isdir	(	fi_dir	)	and	"str"	not	in	fi_dir	:	
make_content	(	fi_dir	)	


def	main	(	)	:	

input_list	=	sys	.	argv	

if	len	(	input_list	)	!=	2	:	
raise	InputError	(	"str"	)	
else	:	
try	:	
input_arg	=	input_list	[	1	]	
except	Exception	:	
raise	InputError	(	"str"	)	
if	len	(	input_arg	)	==	1	:	
make_content	(	"str"	+	input_arg	)	
elif	input_arg	==	"str"	:	
make_all_content	(	)	
else	:	
make_content	(	input_arg	)	

if	__name__	==	"str"	:	
main	(	)	
	