





from	huey	import	crontab	

from	config	import	huey	,	tiobe_config	
from	tiobe_spider	import	Tiobe	


@huey.periodic_task	(	crontab	(	minute	=	"str"	)	)	
def	tiobe_spider	(	)	:	
t	=	Tiobe	(	tiobe_config	[	"str"	]	,	tiobe_config	[	"str"	]	)	
t	.	fetch	(	)	
	