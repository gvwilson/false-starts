





from	peewee	import	Model	
from	playhouse	.	db_url	import	connect	
from	playhouse	.	sqlite_ext	import	PrimaryKeyAutoIncrementField	

from		.		.	config	import	DATABASE_URL	

database	=	connect	(	DATABASE_URL	)	


class	BaseModel	(	Model	)	:	
class	Meta	:	
database	=	database	

id	=	PrimaryKeyAutoIncrementField	(	)	
	