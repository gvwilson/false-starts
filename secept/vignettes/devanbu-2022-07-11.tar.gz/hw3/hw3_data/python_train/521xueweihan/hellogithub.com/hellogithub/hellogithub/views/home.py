





import	random	
from	urllib	import	quote	,	urlencode	

import	requests	
from	flask	import	render_template	,	session	,	request	,	redirect	,	abort	,	url_for	,	Blueprint	
from	playhouse	.	flask_utils	import	PaginatedQuery	
from	peewee	import	DoesNotExist	

from	tools	import	markdown2html	,	make_image_url	
from		.		.	models	.	hellogithub	import	Category	,	Volume	,	Content	,	User	,	Collection	,	CollectionProject	
from		.		.	models	.	tiobe	import	TiobeContent	,	TiobeHall	,	TiobeRank	
from		.		.	config	import	CLIENT_ID	,	CLIENT_SECRET	,	ACCESS_URL	,	PAGE_MAX	,	AUTHORIZE_URL	,	logger	

home	=	Blueprint	(	"str"	,	__name__	)	


def	update_session	(	user_object	)	:	

session	[	"str"	]	=	True	
session	[	"str"	]	=	user_object	.	uuid	
if	user_object	.	admin	:	
session	[	"str"	]	=	True	
else	:	
session	[	"str"	]	=	False	


def	get_collected_project_status	(	project_url	)	:	
uuid	=	session	.	get	(	"str"	)	

if	uuid	:	
collected_projects	=	CollectionProject	.	select	(	CollectionProject	,	
Collection	)	.	join	(	Collection	)	.	where	(	CollectionProject	.	status	==	1	,	
Collection	.	uuid	==	uuid	)	
collected_project_list	=	[	
{	fi_collected_project_obj	.	project_url	:	fi_collected_project_obj	.	id	}	
for	fi_collected_project_obj	in	collected_projects	]	
else	:	
collected_project_list	=	[	]	

for	fi_collected_project	in	collected_project_list	:	
if	fi_collected_project	.	get	(	project_url	)	:	
return	1	,	fi_collected_project	.	get	(	project_url	)	
return	0	,	0	


def	get_user_collections_list	(	)	:	
uuid	=	session	.	get	(	"str"	)	
if	uuid	:	
collections	=	Collection	.	select	(	)	.	where	(	Collection	.	uuid	==	uuid	,	
Collection	.	status	==	1	)	.	order_by	(	Collection	.	create_time	)	
if	not	collections	:	
collection	=	Collection	.	create	(	name	=	"str"	,	uuid	=	uuid	)	
collections	=	[	collection	]	
else	:	
return	[	]	
return	collections	


@home.route	(	"str"	)	
def	index	(	)	:	
uuid	=	session	.	get	(	"str"	)	
user_info	=	"str"	

try	:	
user_info	=	User	.	get	(	User	.	uuid	==	uuid	)	
except	DoesNotExist	:	
session	.	clear	(	)	

categories	=	Category	.	select	(	Content	,	Category	)	.	join	(	Content	)	.	where	(	Content	.	status	==	1	)	.	group_by	(	Category	.	id	)	.	order_by	(	Category	.	name	)	


for	fi_category	in	categories	:	
fi_category	.	quote_name	=	quote	(	fi_category	.	name	.	encode	(	"str"	)	)	

volumes	=	Volume	.	select	(	Volume	.	name	)	.	where	(	Volume	.	status	==	1	)	.	order_by	(	Volume	.	name	.	desc	(	)	)	
contents	=	Content	.	select	(	)	.	where	(	Content	.	status	==	1	)	
select_category	=	random	.	choice	(	categories	)	

return	render_template	(	"str"	,	user_info	=	user_info	,	
page_title	=	"str"	,	
contents	=	contents	,	
select_category	=	select_category	,	
categories	=	categories	,	volumes	=	volumes	)	


@home.route	(	"str"	)	
def	sign_in	(	)	:	

code	=	request	.	args	.	get	(	"str"	)	
if	code	:	
params	=	urlencode	(	{	
"str"	:	CLIENT_ID	,	
"str"	:	CLIENT_SECRET	,	
"str"	:	code	
}	)	
try	:	
access_token_response	=	requests	.	post	(	ACCESS_URL	,	
params	,	timeout	=	10	)	
github_user_response	=	requests	.	get	(	
"str"	+	access_token_response	.	text	,	
timeout	=	10	)	
except	Exception	as	e	:	
logger	.	error	(	e	)	
return	abort	(	500	)	

github_user_json	=	github_user_response	.	json	(	)	
github_user_id	=	github_user_json	.	get	(	"str"	)	

name	=	github_user_json	.	get	(	"str"	)	or	github_user_json	.	get	(	"str"	)	
avatar_url	=	github_user_json	.	get	(	"str"	)	
email	=	github_user_json	.	get	(	"str"	)	


try	:	
user_object	=	User	.	get	(	User	.	uuid	==	github_user_id	)	
update_session	(	user_object	)	
return	redirect	(	url_for	(	"str"	)	)	
except	DoesNotExist	:	
user_object	=	User	(	uuid	=	github_user_id	,	name	=	name	,	
avatar_url	=	avatar_url	,	email	=	email	)	
user_object	.	save	(	)	
update_session	(	user_object	)	
return	redirect	(	url_for	(	"str"	)	)	
except	Exception	as	e	:	
logger	.	error	(	e	)	
return	abort	(	500	)	
else	:	
params	=	urlencode	(	{	"str"	:	CLIENT_ID	}	)	
return	redirect	(	AUTHORIZE_URL	+	"str"	+	params	)	


@home.route	(	"str"	)	
def	sign_out	(	)	:	
session	.	clear	(	)	
return	redirect	(	url_for	(	"str"	)	)	


@home.route	(	"str"	)	
def	category	(	input_category	)	:	


menu_url	=	quote	(	request	.	path	.	encode	(	"str"	)	)	
contents	=	Content	.	select	(	Category	,	Content	)	.	join	(	Category	)	.	where	(	Category	.	name	==	input_category	,	
Content	.	status	==	1	)	

page_object	=	PaginatedQuery	(	contents	,	
paginate_by	=	PAGE_MAX	,	
check_bounds	=	True	)	
page_count	=	page_object	.	get_page_count	(	)	
current_page	=	page_object	.	get_page	(	)	
projects	=	page_object	.	get_object_list	(	)	

for	project	in	projects	:	
collected	,	collected_project_id	=	get_collected_project_status	(	
project	.	project_url	)	
if	collected	:	
project	.	collected	=	collected	
project	.	collected_project_id	=	collected_project_id	

project	.	description	=	markdown2html	(	project	.	description	)	
project	.	image_url	=	make_image_url	(	project	.	image_path	)	
return	render_template	(	"str"	,	projects	=	projects	,	
menu_url	=	menu_url	,	page_title	=	input_category	,	
category_url	=	quote	(	input_category	.	encode	(	"str"	)	)	,	
page_count	=	page_count	,	current_page	=	current_page	)	


@home.route	(	"str"	)	
def	volume	(	input_volume	)	:	
menu_url	=	quote	(	request	.	path	.	encode	(	"str"	)	)	

content_objects	=	Content	.	select	(	Content	,	Volume	)	.	join	(	Volume	)	.	where	(	Volume	.	name	==	input_volume	,	
Volume	.	status	==	1	,	
Content	.	status	==	1	)	

categories	=	Category	.	select	(	)	.	order_by	(	Category	.	name	)	

volumes	=	Volume	.	select	(	)	.	where	(	Volume	.	status	==	1	)	.	order_by	(	Volume	.	name	.	asc	(	)	)	
volume_name_list	=	[	fi_volume_obj	.	name	for	fi_volume_obj	in	volumes	]	
if	input_volume	in	volume_name_list	:	
current_volume_index	=	volume_name_list	.	index	(	input_volume	)	
else	:	
current_volume_index	=	-	1	

contents	=	[	]	
index_num	=	0	
for	category_object	in	categories	:	
projects	=	[	category_object	.	name	]	
for	fi_content	in	content_objects	:	
if	fi_content	.	category	.	name	==	category_object	.	name	:	
collected	,	collected_project_id	=	get_collected_project_status	(	
fi_content	.	project_url	)	
if	collected	:	
fi_content	.	collected	=	collected	
fi_content	.	collected_project_id	=	collected_project_id	
index_num	+	=	1	
fi_content	.	index_num	=	index_num	
fi_content	.	description	=	markdown2html	(	fi_content	.	description	)	
fi_content	.	image_url	=	make_image_url	(	fi_content	.	image_path	)	
projects	.	append	(	fi_content	)	
if	not	len	(	projects	)	==	1	:	
contents	.	append	(	projects	)	
return	render_template	(	"str"	,	contents	=	contents	,	
menu_url	=	menu_url	,	
volume_name_list	=	volume_name_list	,	
current_volume_index	=	current_volume_index	,	
page_title	=	"str"	.	format	(	vol	=	input_volume	)	)	


@home.route	(	"str"	)	
def	about	(	)	:	
content_menu_url	=	quote	(	request	.	args	.	get	(	"str"	,	"str"	)	.	encode	(	"str"	)	)	
return	render_template	(	"str"	,	page_title	=	"str"	,	
menu_url	=	content_menu_url	)	

@home.route	(	"str"	)	
@home.route	(	"str"	)	
def	tiobe_index	(	year	=	None	,	month	=	None	)	:	
content_menu_url	=	quote	(	request	.	args	.	get	(	"str"	,	"str"	)	.	encode	(	"str"	)	)	
try	:	
if	year	and	month	:	
content	=	TiobeContent	.	select	(	)	.	where	(	TiobeContent	.	publish_date	.	month	==	month	,	
TiobeContent	.	publish_date	.	year	==	year	)	.	get	(	)	
else	:	
content	=	TiobeContent	.	select	(	)	.	order_by	(	TiobeContent	.	publish_date	.	desc	(	)	)	.	get	(	)	
except	DoesNotExist	:	
abort	(	404	)	

ranks	=	TiobeRank	.	raw	(	"str"	,	content	.	publish_date	.	month	-	1	,	content	.	publish_date	.	year	,	content	.	publish_date	.	month	,	content	.	publish_date	.	year	)	

halls	=	TiobeHall	.	select	(	)	.	where	(	TiobeHall	.	publish_date	.	month	==	content	.	publish_date	.	month	,	
TiobeHall	.	publish_date	.	year	==	content	.	publish_date	.	year	)	

for	rank	in	ranks	:	
for	hall	in	halls	:	
if	rank	.	language	==	hall	.	language	:	

if	hasattr	(	rank	,	"str"	)	:	
rank	.	star	=	str	(	rank	.	star	)	+	"str"	+	str	(	hall	.	year	)	
else	:	
rank	.	star	=	hall	.	year	

page_title	=	content	.	publish_date	.	strftime	(	"str"	)	.	decode	(	"str"	)	+	"str"	

return	render_template	(	"str"	,	content	=	content	,	
ranks	=	ranks	,	menu_url	=	content_menu_url	,	
page_title	=	page_title	)	
	