







class	InvalidUsage	(	Exception	)	:	
status_code	=	400	

def	__init__	(	self	,	message	,	status_code	=	None	,	payload	=	None	)	:	
Exception	.	__init__	(	self	)	
self	.	message	=	message	
if	status_code	is	not	None	:	
self	.	status_code	=	status_code	
self	.	payload	=	payload	

def	to_dict	(	self	)	:	
rv	=	dict	(	self	.	payload	or	(	)	)	
rv	[	"str"	]	=	self	.	message	
return	rv	


class	InvalidParams	(	InvalidUsage	)	:	
def	__init__	(	self	,	message	=	"str"	)	:	
super	(	InvalidParams	,	self	)	.	__init__	(	message	)	


class	ParamsConflict	(	InvalidUsage	)	:	
def	__init__	(	self	,	message	=	"str"	,	status_code	=	409	)	:	
super	(	ParamsConflict	,	self	)	.	__init__	(	message	,	status_code	)	


class	Unauthorized	(	InvalidUsage	)	:	
def	__init__	(	self	,	message	=	"str"	,	status_code	=	401	)	:	
super	(	Unauthorized	,	self	)	.	__init__	(	message	,	status_code	)	


class	Forbidden	(	InvalidUsage	)	:	
def	__init__	(	self	,	message	=	"str"	,	status_code	=	403	)	:	
super	(	Forbidden	,	self	)	.	__init__	(	message	,	status_code	)	
	