





from	os	import	path	
from	logging	.	handlers	import	RotatingFileHandler	
from	logging	import	getLogger	,	Formatter	,	INFO	


def	setting_logger	(	name	)	:	
handler	=	RotatingFileHandler	(	"str"	%	name	,	maxBytes	=	10000000	,	backupCount	=	3	)	
log_object	=	getLogger	(	name	)	
formatter	=	Formatter	(	
"str"	)	
handler	.	setFormatter	(	formatter	)	
log_object	.	setLevel	(	INFO	)	
log_object	.	addHandler	(	handler	)	
return	log_object	

flask_config	=	{	
"str"	:	True	,	
"str"	:	"str"	,	
"str"	:	path	.	join	(	path	.	dirname	(	__file__	)	,	"str"	)	
}	

APP_NAME	=	"str"	
APP_DIR	=	path	.	dirname	(	path	.	dirname	(	__file__	)	)	
logger	=	setting_logger	(	APP_NAME	)	
DATABASE_URL	=	"str"	%	path	.	join	(	APP_DIR	,	"str"	)	


PAGE_MAX	=	5	
GITHUB_IMAGE_URL	=	"str"	
GITHUB_IMAGE_PREFIX	=	"str"	
GITHUB_IMAGE_PATH_PREFIX	=	"str"	


GITHUB_TEMPLAT_PATH	=	path	.	join	(	APP_DIR	,	"str"	)	
GITBOOK_TEMPLAT_PATH	=	path	.	join	(	APP_DIR	,	"str"	)	



CLIENT_ID	=	"str"	
CLIENT_SECRET	=	"str"	
AUTHORIZE_URL	=	"str"	
ACCESS_URL	=	"str"	
	