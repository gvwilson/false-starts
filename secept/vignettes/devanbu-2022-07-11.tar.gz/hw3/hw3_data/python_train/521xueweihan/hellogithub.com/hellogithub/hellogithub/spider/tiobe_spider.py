





import	datetime	
import	re	
from	decimal	import	*	

from	lxml	import	html	,	etree	
from	peewee	import	DoesNotExist	

from	base_spider	import	BaseSpider	
from	hellogithub	.	models	.	base	import	database	
from	hellogithub	.	models	.	tiobe	import	TiobeHall	,	TiobeRank	,	TiobeContent	


class	Tiobe	(	BaseSpider	)	:	
spider_name	=	"str"	

def	__init__	(	self	,	rss_url	,	index_url	)	:	
super	(	Tiobe	,	self	)	.	__init__	(	)	
self	.	rss_url	=	rss_url	
self	.	index_url	=	index_url	
self	.	publish_date	=	None	

@property	
def	today	(	self	)	:	
return	datetime	.	date	.	today	(	)	

def	check_content	(	self	)	:	

try	:	
content_obj	=	TiobeContent	.	select	(	)	.	order_by	(	TiobeContent	.	publish_date	)	.	get	(	)	
return	content_obj	.	publish_date	.	month	==	self	.	today	.	month	
except	DoesNotExist	:	
return	False	

def	check_publish	(	self	)	:	
response_obj	=	self	.	get_data	(	self	.	rss_url	)	
if	not	response_obj	:	
self	.	logger	.	error	(	"str"	)	
return	None	
tree	=	etree	.	fromstring	(	response_obj	.	text	)	
publish_date	=	tree	.	xpath	(	"str"	)	

if	publish_date	:	
publish_date	=	datetime	.	datetime	.	strptime	(	
publish_date	[	0	]	.	strip	(	)	,	"str"	)	.	date	(	)	
self	.	publish_date	=	publish_date	
return	publish_date	<	=	self	.	today	
else	:	
self	.	logger	.	warning	(	"str"	)	
return	False	

def	fetch	(	self	,	force	=	False	)	:	
if	self	.	check_content	(	)	:	
self	.	logger	.	info	(	"str"	)	
return	
if	self	.	check_publish	(	)	or	force	:	
self	.	logger	.	info	(	"str"	)	
response_obj	=	self	.	get_data	(	self	.	index_url	)	
if	response_obj	:	
self	.	logger	.	info	(	"str"	)	
tree	=	html	.	fromstring	(	response_obj	.	text	)	
rank_result	,	hall_result	=	self	.	parse_table	(	tree	)	
chart_result	=	self	.	parse_chart	(	tree	)	
title	,	description	=	self	.	parse_content	(	tree	)	

if	(	self	.	save_content	(	title	,	description	,	chart_result	)	and	
self	.	save_rank	(	rank_result	)	and	self	.	save_hall	(	hall_result	)	)	:	
self	.	logger	.	info	(	"str"	)	
else	:	
self	.	logger	.	info	(	"str"	)	

else	:	
self	.	logger	.	error	(	"str"	)	
elif	self	.	check_publish	(	)	is	None	:	
pass	
else	:	
self	.	logger	.	info	(	"str"	)	

@staticmethod	
def	percentage2int	(	input_str	)	:	

return	int	(	Decimal	(	input_str	.	strip	(	)	[	:	-	1	]	)	.	quantize	(	Decimal	(	"str"	)	)	*	1000	)	

def	parse_rank	(	self	,	top20	,	next30	)	:	

rank_list	=	[	]	
positions_list	=	top20	.	xpath	(	"str"	)	
languages_list	=	top20	.	xpath	(	"str"	)	
ratings_list	=	top20	.	xpath	(	"str"	)	
positions_list	.	extend	(	next30	.	xpath	(	"str"	)	)	
languages_list	.	extend	(	next30	.	xpath	(	"str"	)	)	
ratings_list	.	extend	(	next30	.	xpath	(	"str"	)	)	
for	i	,	position	in	enumerate	(	positions_list	)	:	
rank_list	.	append	(	{	"str"	:	int	(	position	)	,	
"str"	:	languages_list	[	i	]	.	strip	(	)	,	
"str"	:	ratings_list	[	i	]	.	strip	(	)	,	
"str"	:	self	.	percentage2int	(	ratings_list	[	i	]	)	,	
"str"	:	self	.	publish_date	}	)	
return	rank_list	

def	parse_hall	(	self	,	hall_of_fame	)	:	

hall_list	=	[	]	

year_list	=	hall_of_fame	.	xpath	(	"str"	)	
winners_list	=	hall_of_fame	.	xpath	(	"str"	)	
for	i	,	year	in	enumerate	(	year_list	)	:	
hall_list	.	append	(	{	"str"	:	int	(	year	)	,	
"str"	:	self	.	publish_date	,	
"str"	:	winners_list	[	i	]	.	strip	(	)	}	)	
return	hall_list	

def	parse_table	(	self	,	tree_element	)	:	

tables	=	tree_element	.	xpath	(	"str"	)	
top20_element	,	next30_element	,	history_element	,	hall_of_fame_element	=	tables	[	0	]	,	tables	[	1	]	,	tables	[	2	]	,	tables	[	3	]	
rank_result	=	self	.	parse_rank	(	top20_element	,	next30_element	)	
hall_result	=	self	.	parse_hall	(	hall_of_fame_element	)	
return	rank_result	,	hall_result	

@staticmethod	
def	parse_chart	(	tree_element	)	:	

javascript_str	=	tree_element	.	xpath	(	"str"	)	[	1	]	
pattern	=	re	.	compile	(	"str"	)	
s	=	re	.	search	(	pattern	,	javascript_str	)	
if	s	:	
series_str	=	s	.	group	(	)	
else	:	
series_str	=	"str"	
return	series_str	

@staticmethod	
def	parse_content	(	tree_element	)	:	

title	=	tree_element	.	xpath	(	"str"	)	
description	=	tree_element	.	xpath	(	"str"	)	
if	title	and	description	:	
return	title	[	0	]	,	description	[	0	]	.	strip	(	)	
else	:	
return	"str"	"str"	

def	save_rank	(	self	,	rank_data_list	)	:	
count	=	0	
for	rank_data	in	rank_data_list	:	
_	,	create_result	=	TiobeRank	.	get_or_create	(	*	*	rank_data	)	
if	create_result	:	
count	+	=	1	
if	count	:	
self	.	logger	.	info	(	"str"	.	format	(	count	)	)	
return	True	

def	save_hall	(	self	,	hall_data_list	)	:	
count	=	0	
for	hall_data	in	hall_data_list	:	
_	,	create_result	=	TiobeHall	.	get_or_create	(	*	*	hall_data	)	
if	create_result	:	
count	+	=	1	
if	count	:	
self	.	logger	.	info	(	"str"	.	format	(	count	)	)	
return	True	

def	save_content	(	self	,	title	,	description	,	chart	)	:	
_	,	create_result	=	TiobeContent	.	get_or_create	(	
title	=	title	,	description	=	description	,	
publish_date	=	self	.	publish_date	,	chart_str	=	chart	)	
if	create_result	:	
self	.	logger	.	info	(	"str"	)	
return	True	

if	__name__	==	"str"	:	
database	.	create_tables	(	[	TiobeContent	,	TiobeRank	,	TiobeHall	]	,	safe	=	True	)	

RSS_URL	=	"str"	
INDEX_URL	=	"str"	

t	=	Tiobe	(	RSS_URL	,	INDEX_URL	)	
t	.	fetch	(	)	
	