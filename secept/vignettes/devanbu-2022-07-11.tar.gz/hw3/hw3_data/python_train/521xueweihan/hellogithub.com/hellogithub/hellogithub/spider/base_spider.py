





import	os	
import	logging	

import	requests	


class	BaseSpider	(	object	)	:	
spider_name	=	"str"	

def	__init__	(	self	)	:	
self	.	logger	=	logging	.	getLogger	(	self	.	spider_name	)	

def	get_data	(	self	,	url	)	:	
try	:	
response	=	requests	.	get	(	url	,	timeout	=	20	,	verify	=	False	)	
return	response	
except	Exception	as	e	:	
self	.	logger	.	error	(	"str"	.	format	(	url	=	url	,	e	=	e	)	)	
return	None	
	