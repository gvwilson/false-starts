

from	memobject	import	MemObject	,	CACHE_TIMEOUT	
import	util	
from	gevent	import	Greenlet	,	queue	
from	gevent_zeromq	import	zmq	
from	gfirefly	.	utils	.	singleton	import	Singleton	
from	util	import	ToDBAddress	
import	traceback	
from	gtwisted	.	utils	import	log	

MMODE_STATE_NEW	=	1	
MMODE_STATE_UPDATE	=	2	
MMODE_STATE_DEL	=	3	


class	PKValueError	(	ValueError	)	:	

def	__init__	(	self	,	data	)	:	
ValueError	.	__init__	(	self	)	
self	.	data	=	data	
def	__str__	(	self	)	:	
return	"str"	%	(	self	.	data	)	

class	DBPub	(	Greenlet	)	:	

__metaclass__	=	Singleton	

def	__init__	(	self	,	run	=	None	,	*	args	,	*	*	kwargs	)	:	
Greenlet	.	__init__	(	self	)	
self	.	isStart	=	False	
self	.	inbox	=	queue	.	Queue	(	)	
context	=	zmq	.	Context	(	)	
self	.	sock	=	context	.	socket	(	zmq	.	PUB	)	
self	.	to_db_address	=	(	ToDBAddress	(	)	.	m2db_host	,	ToDBAddress	(	)	.	m2db_port	)	

def	send	(	self	,	message	)	:	

if	not	self	.	isStart	:	
self	.	start	(	)	
self	.	isStart	=	True	
self	.	inbox	.	put	(	message	)	

def	_run	(	self	)	:	

address	=	"str"	%	self	.	to_db_address	
self	.	sock	.	connect	(	address	)	
while	True	:	
try	:	
message	=	self	.	inbox	.	get	(	)	
self	.	sock	.	send_pyobj	(	message	)	
except	Exception	as	e	:	
log	.	err	(	_stuff	=	e	,	_why	=	traceback	.	format_exc	(	)	)	
log	.	msg	(	str	(	message	)	)	

class	MMode	(	MemObject	)	:	

def	__init__	(	self	,	name	,	pk	,	data	=	{	}	,	fk	=	None	,	*	*	kw	)	:	

MemObject	.	__init__	(	self	,	name	,	*	*	kw	)	
self	.	_pk	=	pk	
self	.	_fk	=	fk	
self	.	data	=	data	

def	_update_fk	(	self	,	pk	,	old_fk_value	,	fk_value	)	:	

tb_name	=	self	.	_name	.	split	(	"str"	)	[	0	]	
old_name	=	"str"	%	(	tb_name	,	old_fk_value	)	
old_fkmm	=	MFKMode	(	old_name	)	
old_pklist	=	old_fkmm	.	get	(	"str"	)	
if	old_pklist	is	None	:	
props	=	{	self	.	_fk	:	old_fk_value	}	
old_pklist	=	util	.	getAllPkByFkInDB	(	tb_name	,	self	.	_pk	,	props	)	
if	old_pklist	and	pk	in	old_pklist	:	
old_pklist	.	remove	(	pk	)	
old_fkmm	.	update	(	"str"	,	old_pklist	)	
if	fk_value	is	None	:	
return	
new_name	=	"str"	%	(	tb_name	,	fk_value	)	
new_fkmm	=	MFKMode	(	new_name	)	
new_pklist	=	new_fkmm	.	get	(	"str"	)	
if	new_pklist	is	None	:	
props	=	{	self	.	_fk	:	fk_value	}	
new_pklist	=	util	.	getAllPkByFkInDB	(	tb_name	,	self	.	_pk	,	props	)	
if	pk	not	in	new_pklist	:	
new_pklist	.	append	(	pk	)	
new_fkmm	.	update	(	"str"	,	new_pklist	)	

def	update	(	self	,	key	,	values	)	:	
data	=	self	.	getData	(	)	
if	self	.	_fk	and	self	.	_fk	==	key	:	
fk	=	data	.	get	(	self	.	_fk	,	"str"	)	
pk	=	data	.	get	(	self	.	_pk	)	
self	.	_update_fk	(	pk	,	fk	,	values	)	
data	.	update	(	{	key	:	values	}	)	
result	=	MemObject	.	update	(	self	,	"str"	,	data	)	
self	.	syncDB	(	)	
return	result	

def	update_multi	(	self	,	mapping	)	:	
data	=	self	.	getData	(	)	
if	self	.	_fk	and	self	.	_fk	in	mapping	.	keys	(	)	:	
fk	=	data	.	get	(	self	.	_fk	,	"str"	)	
new_fk	=	mapping	.	get	(	self	.	_fk	,	fk	)	
if	new_fk	!=	fk	:	
pk	=	data	.	get	(	self	.	_pk	)	
self	.	_update_fk	(	pk	,	fk	,	new_fk	)	
data	.	update	(	mapping	)	
result	=	MemObject	.	update	(	self	,	"str"	,	data	)	
self	.	syncDB	(	)	
return	result	

def	get_multi	(	self	,	keys	)	:	
return	MemObject	.	get_multi	(	self	,	keys	)	

def	getData	(	self	)	:	

data	=	self	.	get	(	"str"	)	
if	data	:	
return	data	
tablename	,	pk_value	=	self	.	_name	.	split	(	"str"	)	
props	=	{	self	.	_pk	:	int	(	pk_value	)	}	
record	=	util	.	GetOneRecordInfo	(	tablename	,	props	)	
if	record	:	
self	.	data	=	record	
self	.	insert	(	)	
return	self	.	data	
return	None	

def	delete	(	self	)	:	

self	.	syncDB	(	state	=	MMODE_STATE_DEL	)	
if	self	.	_fk	:	
data	=	self	.	getData	(	)	
if	data	:	
fk	=	data	.	get	(	self	.	_fk	,	"str"	)	
pk	=	data	.	get	(	self	.	_pk	)	
self	.	_update_fk	(	pk	,	fk	,	None	)	
self	.	mdelete	(	)	

def	IsEffective	(	self	)	:	

return	True	

def	syncDB	(	self	,	state	=	MMODE_STATE_UPDATE	)	:	

tablename	=	self	.	_name	.	split	(	"str"	)	[	0	]	
if	state	==	MMODE_STATE_NEW	:	
props	=	self	.	getData	(	)	
pk	=	self	.	_pk	
result	=	util	.	InsertIntoDB	(	tablename	,	props	)	
elif	state	==	MMODE_STATE_UPDATE	:	
props	=	self	.	getData	(	)	
pk	=	self	.	_pk	
prere	=	{	pk	:	props	.	get	(	pk	)	}	
sql	=	util	.	UpdateWithDictSQL	(	tablename	,	props	,	prere	)	
DBPub	(	)	.	send	(	(	tablename	,	sql	)	)	
result	=	True	
else	:	
pk	=	self	.	_pk	
props	=	self	.	getData	(	)	
prere	=	{	pk	:	props	.	get	(	pk	)	}	
result	=	util	.	DeleteFromDB	(	tablename	,	prere	)	
return	result	


class	MFKMode	(	MemObject	)	:	

def	__init__	(	self	,	name	,	pklist	=	[	]	)	:	
MemObject	.	__init__	(	self	,	name	)	
self	.	pklist	=	pklist	

class	MAdmin	(	object	)	:	


def	__init__	(	self	,	name	,	pk	,	*	*	kw	)	:	
self	.	_name	=	name	
self	.	pk	=	pk	
self	.	_fk	=	kw	.	get	(	"str"	,	"str"	)	
self	.	incrkey	=	kw	.	get	(	"str"	,	"str"	)	
self	.	timeout	=	kw	.	get	(	"str"	,	CACHE_TIMEOUT	)	

def	load	(	self	)	:	

mmname	=	self	.	_name	
recordlist	=	util	.	ReadDataFromDB	(	mmname	)	
for	record	in	recordlist	:	
pk	=	record	[	self	.	pk	]	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	record	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
mm	.	insert	(	)	

def	getAllPkByFk	(	self	,	fk	)	:	

name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
pklist	=	fkmm	.	get	(	"str"	)	
if	pklist	is	not	None	:	
return	pklist	
props	=	{	self	.	_fk	:	fk	}	
dbkeylist	=	util	.	getAllPkByFkInDB	(	self	.	_name	,	self	.	pk	,	props	)	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	,	pklist	=	dbkeylist	)	
fkmm	.	insert	(	)	
return	dbkeylist	

def	getObj	(	self	,	pk	)	:	

mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
if	mm	.	get	(	"str"	)	:	
return	mm	
props	=	{	self	.	pk	:	pk	}	
record	=	util	.	GetOneRecordInfo	(	self	.	_name	,	props	)	
if	not	record	:	
return	None	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	record	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
mm	.	insert	(	)	
return	mm	

def	getObjData	(	self	,	pk	)	:	

mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
if	not	mm	.	IsEffective	(	)	:	
return	None	
data	=	mm	.	get	(	"str"	)	
if	data	:	
return	data	
props	=	{	self	.	pk	:	pk	}	
record	=	util	.	GetOneRecordInfo	(	self	.	_name	,	props	)	
if	not	record	:	
return	None	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	record	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
mm	.	insert	(	)	
return	record	


def	getObjList	(	self	,	pklist	)	:	

_pklist	=	[	]	
objlist	=	[	]	
for	pk	in	pklist	:	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
if	not	mm	.	IsEffective	(	)	:	
continue	
if	mm	.	get	(	"str"	)	:	
objlist	.	append	(	mm	)	
else	:	
_pklist	.	append	(	pk	)	
if	_pklist	:	
recordlist	=	util	.	GetRecordList	(	self	.	_name	,	self	.	pk	,	_pklist	)	
for	record	in	recordlist	:	
pk	=	record	[	self	.	pk	]	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	record	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
mm	.	insert	(	)	
objlist	.	append	(	mm	)	
return	objlist	

def	deleteMode	(	self	,	pk	)	:	

mm	=	self	.	getObj	(	pk	)	
if	mm	:	










mm	.	delete	(	)	
return	True	



























def	new	(	self	,	data	)	:	

incrkey	=	self	.	incrkey	
tablename	=	self	.	_name	
if	incrkey	:	
result	=	util	.	InsertIntoDBAndReturnID	(	tablename	,	data	)	
data	[	incrkey	]	=	result	[	0	]	
pk	=	data	.	get	(	self	.	pk	)	
if	pk	is	None	:	
raise	PKValueError	(	data	)	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	data	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
else	:	
pk	=	data	.	get	(	self	.	pk	)	
result	=	util	.	InsertIntoDB	(	tablename	,	data	)	
if	not	result	:	
raise	util	.	SQLError	(	)	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	pk	,	data	=	data	,	fk	=	self	.	_fk	,	timeout	=	self	.	timeout	)	
mm	.	insert	(	)	
if	self	.	_fk	:	
fk	=	data	.	get	(	self	.	_fk	,	0	)	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
pklist	=	fkmm	.	get	(	"str"	)	
pklist	=	self	.	getAllPkByFk	(	fk	)	
pklist	.	append	(	pk	)	
fkmm	.	update	(	"str"	,	pklist	)	
return	mm	

def	insert	(	self	)	:	
pass	


if	__name__	==	"str"	:	
from	dbpool	import	dbpool	
from	memclient	import	memcached_connect	
from	madminanager	import	MAdminManager	
memcached_connect	(	[	"str"	]	)	
aa	=	{	"str"	:	{	"str"	:	"str"	,	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	,	
"str"	:	{	"str"	:	"str"	,	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	
}	
dbpool	.	initPool	(	aa	)	

class	router	:	
def	db_for_read	(	self	,	*	*	kw	)	:	
return	"str"	
def	db_for_write	(	self	,	*	*	kw	)	:	
return	"str"	

dbpool	.	bind_router	(	router	)	

ma	=	MAdmin	(	"str"	,	"str"	,	incrkey	=	"str"	,	fk	=	"str"	)	
mm	=	ma	.	getObj	(	19	)	
mm	.	update	(	"str"	,	"str"	)	
print	ma	.	getAllPkByFk	(	"str"	)	
MAdminManager	(	)	.	checkAdmins	(	)	

print	"str"	
print	ma	.	getAllPkByFk	(	"str"	)	
print	ma	.	getAllPkByFk	(	"str"	)	
import	gevent	

gevent	.	sleep	(	100	)	


	