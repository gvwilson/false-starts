


def	println	(	a	)	:	
print	a	

if	__name__	==	"str"	:	
from	gfirefly	.	master	.	master	import	Master	
master	=	Master	(	)	
master	.	config	(	"str"	,	"str"	)	
master	.	start	(	)	


	