

import	memcache	
MEMCS	=	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	}	
_DEAD_RETRY	=	5	
mclient	=	object	(	)	

class	MemConnError	(	Exception	)	:	


def	__str__	(	self	)	:	
return	"str"	


def	memcached_connect	(	servers	,	mem_lib	=	"str"	,	dead_retry	=	_DEAD_RETRY	,	*	*	kw	)	:	

global	mclient	
memcache	=	__import__	(	MEMCS	.	get	(	mem_lib	)	)	
mclient	=	memcache	.	Client	(	servers	,	dead_retry	=	dead_retry	,	*	*	kw	)	
server	,	key	=	mclient	.	_get_server	(	"str"	)	
if	not	server	or	not	key	:	
raise	MemConnError	(	)	



if	__name__	==	"str"	:	

import	time	
memcached_connect	(	[	"str"	]	)	
print	mclient	.	add	(	"str"	,	1	,	time	=	1	)	
print	mclient	.	delete	(	"str"	)	
print	mclient	.	add	(	"str"	,	1	,	time	=	1	)	
while	True	:	
time	.	sleep	(	1	)	
print	mclient	.	get	(	"str"	)	
print	mclient	.	add	(	"str"	,	1	,	time	=	1	)	



	