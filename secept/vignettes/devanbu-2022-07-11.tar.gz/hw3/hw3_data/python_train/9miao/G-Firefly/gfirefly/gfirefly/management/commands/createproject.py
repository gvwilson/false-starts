

import	sys	,	os	
startmasterfile	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
configfile	=	[	"str"	,	
"str"	,	
"str"	,	"str"	,	
"str"	,	
"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	]	
appmainfile	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
apptestfile	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
clientfile	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	


def	createfile	(	rootpath	,	path	,	filecontent	)	:	

mfile	=	open	(	rootpath	+	"str"	+	path	,	"str"	)	
mfile	.	writelines	(	filecontent	)	
mfile	.	close	(	)	


def	execute	(	*	args	)	:	
if	not	args	:	
sys	.	stdout	.	write	(	"str"	)	
projectname	=	args	[	0	]	
sys	.	stdout	.	write	(	"str"	%	projectname	)	
rootpath	=	projectname	
os	.	mkdir	(	rootpath	)	
createfile	(	rootpath	,	"str"	,	startmasterfile	)	
createfile	(	rootpath	,	"str"	,	configfile	)	
createfile	(	rootpath	,	"str"	,	appmainfile	)	

rootpath	=	projectname	+	"str"	+	"str"	
os	.	mkdir	(	rootpath	)	
createfile	(	rootpath	,	"str"	,	[	]	)	
createfile	(	rootpath	,	"str"	,	apptestfile	)	

rootpath	=	projectname	+	"str"	+	"str"	
os	.	mkdir	(	rootpath	)	
createfile	(	rootpath	,	"str"	,	[	]	)	
createfile	(	rootpath	,	"str"	,	clientfile	)	

sys	.	stdout	.	write	(	"str"	)	


	