

from	gfirefly	.	server	.	globalobject	import	GlobalObject	
from	gtwisted	.	utils	import	log	


def	_doChildConnect	(	name	,	transport	)	:	

server_config	=	GlobalObject	(	)	.	json_config	.	get	(	"str"	,	{	}	)	.	get	(	name	,	{	}	)	
remoteport	=	server_config	.	get	(	"str"	,	[	]	)	
child_host	=	transport	.	transport	.	address	[	0	]	
root_list	=	[	rootport	.	get	(	"str"	)	for	rootport	in	remoteport	]	
GlobalObject	(	)	.	remote_map	[	name	]	=	{	"str"	:	child_host	,	"str"	:	root_list	}	

for	servername	,	remote_list	in	GlobalObject	(	)	.	remote_map	.	items	(	)	:	
remote_host	=	remote_list	.	get	(	"str"	,	"str"	)	
remote_name_host	=	remote_list	.	get	(	"str"	,	"str"	)	
if	name	in	remote_name_host	:	
GlobalObject	(	)	.	root	.	callChild	(	servername	,	"str"	,	name	,	remote_host	)	

master_node_list	=	GlobalObject	(	)	.	remote_map	.	keys	(	)	
for	root_name	in	root_list	:	
if	root_name	in	master_node_list	:	
root_host	=	GlobalObject	(	)	.	remote_map	[	root_name	]	[	"str"	]	
GlobalObject	(	)	.	root	.	callChild	(	name	,	"str"	,	root_name	,	root_host	)	

def	_doChildLostConnect	(	childId	)	:	

try	:	
del	GlobalObject	(	)	.	remote_map	[	childId	]	
except	Exception	,	e	:	
log	.	msg	(	str	(	e	)	)	

GlobalObject	(	)	.	root	.	doChildConnect	=	_doChildConnect	
GlobalObject	(	)	.	root	.	doChildLostConnect	=	_doChildLostConnect	
	