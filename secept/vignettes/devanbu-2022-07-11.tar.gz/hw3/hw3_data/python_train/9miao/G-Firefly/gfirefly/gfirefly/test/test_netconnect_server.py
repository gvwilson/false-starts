

import	sys	
from	gtwisted	.	core	import	reactor	

from	gtwisted	.	utils	import	log	
from	gfirefly	.	utils	import	services	
from	gfirefly	.	netconnect	.	protoc	import	LiberateFactory	


service	=	services	.	CommandService	(	"str"	)	

def	serviceHandle	(	target	)	:	

service	.	mapTarget	(	target	)	

factory	=	LiberateFactory	(	)	

def	doConnectionLost	(	conn	)	:	
print	conn	.	transport	

factory	.	doConnectionLost	=	doConnectionLost	

def	serverstart	(	)	:	

log	.	startLogging	(	sys	.	stdout	)	
factory	.	addServiceChannel	(	service	)	
reactor	.	callLater	(	10	,	factory	.	pushObject	,	111	,	"str"	,	[	0	,	1	]	)	

reactor	.	listenTCP	(	1000	,	factory	)	
reactor	.	run	(	)	

a	=	0	

@serviceHandle	
def	echo_1	(	_conn	,	data	)	:	
global	a	
a	+	=	1	
print	a	
return	"str"	

if	__name__	==	"str"	:	

serverstart	(	)	
	