

from	__future__	import	unicode_literals	

import	datetime	
import	os	
import	subprocess	

def	get_version	(	version	=	None	)	:	
"str"	
if	version	is	None	:	
from	gfirefly	import	VERSION	as	version	
else	:	
assert	len	(	version	)	==	5	
assert	version	[	3	]	in	(	"str"	,	"str"	,	"str"	,	"str"	)	

parts	=	2	if	version	[	2	]	==	0	else	3	
main	=	"str"	.	join	(	str	(	x	)	for	x	in	version	[	:	parts	]	)	

sub	=	"str"	
if	version	[	3	]	==	"str"	and	version	[	4	]	==	0	:	
git_changeset	=	get_git_changeset	(	)	
if	git_changeset	:	
sub	=	"str"	%	git_changeset	

elif	version	[	3	]	!=	"str"	:	
mapping	=	{	"str"	:	"str"	,	"str"	:	"str"	,	"str"	:	"str"	}	
sub	=	mapping	[	version	[	3	]	]	+	str	(	version	[	4	]	)	

return	str	(	main	+	sub	)	


def	get_git_changeset	(	)	:	

repo_dir	=	os	.	path	.	dirname	(	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	)	
git_log	=	subprocess	.	Popen	(	"str"	,	
stdout	=	subprocess	.	PIPE	,	stderr	=	subprocess	.	PIPE	,	
shell	=	True	,	cwd	=	repo_dir	,	universal_newlines	=	True	)	
timestamp	=	git_log	.	communicate	(	)	[	0	]	
try	:	
timestamp	=	datetime	.	datetime	.	utcfromtimestamp	(	int	(	timestamp	)	)	
except	ValueError	:	
return	None	
return	timestamp	.	strftime	(	"str"	)	
	