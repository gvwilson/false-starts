

from	gtwisted	.	core	import	protocols	,	reactor	
from	gtwisted	.	utils	import	log	
from	gfirefly	.	netconnect	.	manager	import	ConnectionManager	
from	gfirefly	.	netconnect	.	datapack	import	DataPackProtoc	
reactor	=	reactor	

class	LiberateProtocol	(	protocols	.	BaseProtocol	)	:	


buff	=	"str"	

def	connectionMade	(	self	)	:	

address	=	self	.	transport	.	getAddress	(	)	
log	.	msg	(	"str"	%	(	self	.	transport	.	sessionno	,	address	[	0	]	,	address	[	1	]	)	)	
self	.	factory	.	connmanager	.	addConnection	(	self	)	
self	.	factory	.	doConnectionMade	(	self	)	

def	connectionLost	(	self	,	reason	)	:	

log	.	msg	(	"str"	%	(	self	.	transport	.	sessionno	)	)	
self	.	factory	.	doConnectionLost	(	self	)	
self	.	factory	.	connmanager	.	dropConnectionByID	(	self	.	transport	.	sessionno	)	

def	safeToWriteData	(	self	,	data	,	command	)	:	

if	data	is	None	:	
return	
senddata	=	self	.	factory	.	produceResult	(	command	,	data	)	
self	.	transport	.	sendall	(	senddata	)	

def	dataReceived	(	self	,	data	)	:	

length	=	self	.	factory	.	dataprotocl	.	getHeadlength	(	)	
self	.	buff	+	=	data	
while	self	.	buff	.	__len__	(	)	>	=	length	:	
unpackdata	=	self	.	factory	.	dataprotocl	.	unpack	(	self	.	buff	[	:	length	]	)	
if	not	unpackdata	.	get	(	"str"	)	:	
log	.	msg	(	"str"	)	
self	.	factory	.	connmanager	.	loseConnection	(	self	.	transport	.	sessionno	)	
break	
command	=	unpackdata	.	get	(	"str"	)	
rlength	=	unpackdata	.	get	(	"str"	)	
request	=	self	.	buff	[	length	:	length	+	rlength	]	
if	request	.	__len__	(	)	<	rlength	:	
log	.	msg	(	"str"	)	
break	
self	.	buff	=	self	.	buff	[	length	+	rlength	:	]	
response	=	self	.	factory	.	doDataReceived	(	self	,	command	,	request	)	
if	not	response	:	
continue	
self	.	safeToWriteData	(	response	,	command	)	

class	LiberateFactory	(	protocols	.	ServerFactory	)	:	


protocol	=	LiberateProtocol	

def	__init__	(	self	,	dataprotocl	=	DataPackProtoc	(	)	)	:	

protocols	.	ServerFactory	.	__init__	(	self	)	
self	.	service	=	None	
self	.	connmanager	=	ConnectionManager	(	)	
self	.	dataprotocl	=	dataprotocl	

def	setDataProtocl	(	self	,	dataprotocl	)	:	

self	.	dataprotocl	=	dataprotocl	

def	doConnectionMade	(	self	,	conn	)	:	

pass	

def	doConnectionLost	(	self	,	conn	)	:	

pass	

def	addServiceChannel	(	self	,	service	)	:	

self	.	service	=	service	

def	doDataReceived	(	self	,	conn	,	commandID	,	data	)	:	

response	=	self	.	service	.	callTarget	(	commandID	,	conn	,	data	)	
return	response	

def	produceResult	(	self	,	command	,	response	)	:	

return	self	.	dataprotocl	.	pack	(	command	,	response	)	

def	loseConnection	(	self	,	connID	)	:	

self	.	connmanager	.	loseConnection	(	connID	)	

def	pushObject	(	self	,	topicID	,	msg	,	sendList	)	:	

self	.	connmanager	.	pushObject	(	topicID	,	msg	,	sendList	)	

	