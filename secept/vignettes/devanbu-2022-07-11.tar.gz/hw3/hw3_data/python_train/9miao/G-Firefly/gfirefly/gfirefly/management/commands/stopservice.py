

import	urllib	,	sys	

def	execute	(	*	args	)	:	

if	not	args	:	
masterport	=	9998	
hostname	=	"str"	
else	:	
if	len	(	args	)	>	1	:	
hostname	=	args	[	0	]	
masterport	=	int	(	args	[	1	]	)	
else	:	
hostname	=	"str"	
masterport	=	int	(	args	[	0	]	)	

url	=	"str"	%	(	hostname	,	masterport	)	
try	:	
response	=	urllib	.	urlopen	(	url	)	
except	:	
response	=	None	
if	response	:	
sys	.	stdout	.	write	(	"str"	)	
else	:	
sys	.	stdout	.	write	(	"str"	)	


	