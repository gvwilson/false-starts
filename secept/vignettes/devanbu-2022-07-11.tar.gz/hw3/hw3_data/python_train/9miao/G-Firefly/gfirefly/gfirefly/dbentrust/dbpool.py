

from	DBUtils	.	PooledDB	import	PooledDB	

DBCS	=	{	"str"	:	"str"	,	}	








class	MultiDBPool	(	object	)	:	

def	__init__	(	self	)	:	

self	.	router	=	None	

def	initPool	(	self	,	config	)	:	

self	.	dbpool	=	{	}	
for	dbkey	,	dbconfig	in	config	.	items	(	)	:	
_creator	=	DBCS	.	get	(	dbconfig	.	get	(	"str"	,	"str"	)	)	
creator	=	__import__	(	_creator	)	
self	.	dbpool	[	dbkey	]	=	PooledDB	(	creator	,	*	*	dbconfig	)	

def	bind_router	(	self	,	router	)	:	

self	.	router	=	router	(	)	

def	getPool	(	self	,	write	=	True	,	*	*	kw	)	:	

if	not	self	.	router	:	
return	self	.	dbpool	.	values	(	)	[	0	]	
if	write	:	
dbkey	=	self	.	router	.	db_for_write	(	*	*	kw	)	
return	self	.	dbpool	[	dbkey	]	
else	:	
dbkey	=	self	.	router	.	db_for_read	(	*	*	kw	)	
return	self	.	dbpool	[	dbkey	]	

def	connection	(	self	,	write	=	True	,	*	*	kw	)	:	

if	not	self	.	router	:	
return	self	.	dbpool	.	values	(	)	[	0	]	.	connection	(	shareable	=	kw	.	get	(	"str"	,	True	)	)	
if	write	:	
dbkey	=	self	.	router	.	db_for_write	(	*	*	kw	)	
return	self	.	dbpool	[	dbkey	]	.	connection	(	shareable	=	kw	.	get	(	"str"	,	True	)	)	
else	:	
dbkey	=	self	.	router	.	db_for_read	(	*	*	kw	)	
return	self	.	dbpool	[	dbkey	]	.	connection	(	shareable	=	kw	.	get	(	"str"	,	True	)	)	


dbpool	=	MultiDBPool	(	)	
	