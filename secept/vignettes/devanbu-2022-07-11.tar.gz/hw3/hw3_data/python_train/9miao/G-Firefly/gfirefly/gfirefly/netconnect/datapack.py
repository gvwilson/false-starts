

from	gtwisted	.	utils	import	log	
import	struct	
import	traceback	

class	DataPackError	(	Exception	)	:	


def	__str__	(	self	)	:	
s	=	self	.	__doc__	
if	self	.	args	:	
s	=	"str"	%	(	s	,	"str"	.	join	(	self	.	args	)	)	
s	=	"str"	%	s	
return	s	

class	DataPackProtoc	:	

def	__init__	(	self	,	HEAD_0	=	0	,	HEAD_1	=	0	,	HEAD_2	=	0	,	HEAD_3	=	0	,	protoVersion	=	0	,	serverVersion	=	0	)	:	

self	.	HEAD_0	=	HEAD_0	
self	.	HEAD_1	=	HEAD_1	
self	.	HEAD_2	=	HEAD_2	
self	.	HEAD_3	=	HEAD_3	
self	.	protoVersion	=	protoVersion	
self	.	serverVersion	=	serverVersion	

def	setHEAD_0	(	self	,	HEAD_0	)	:	
self	.	HEAD_0	=	HEAD_0	

def	setHEAD_1	(	self	,	HEAD_1	)	:	
self	.	HEAD_1	=	HEAD_1	

def	setHEAD_2	(	self	,	HEAD_2	)	:	
self	.	HEAD_2	=	HEAD_2	

def	setHEAD_3	(	self	,	HEAD_3	)	:	
self	.	HEAD_3	=	HEAD_3	

def	setprotoVersion	(	self	,	protoVersion	)	:	
self	.	protoVersion	=	protoVersion	

def	setserverVersion	(	self	,	serverVersion	)	:	
self	.	serverVersion	=	serverVersion	

def	getHeadlength	(	self	)	:	

return	17	

def	unpack	(	self	,	dpack	)	:	

try	:	
ud	=	struct	.	unpack	(	"str"	,	dpack	)	
except	struct	.	error	,	de	:	
log	.	err	(	de	,	traceback	.	format_exc	(	)	)	
return	{	"str"	:	False	,	"str"	:	0	,	"str"	:	0	}	
HEAD_0	=	ord	(	ud	[	0	]	)	
HEAD_1	=	ord	(	ud	[	1	]	)	
HEAD_2	=	ord	(	ud	[	2	]	)	
HEAD_3	=	ord	(	ud	[	3	]	)	
protoVersion	=	ord	(	ud	[	4	]	)	
serverVersion	=	ud	[	5	]	
length	=	ud	[	6	]	-	4	
command	=	ud	[	7	]	
if	HEAD_0	<	>	self	.	HEAD_0	or	HEAD_1	<	>	self	.	HEAD_1	or	HEAD_2	<	>	self	.	HEAD_2	or	HEAD_3	<	>	self	.	HEAD_3	or	protoVersion	<	>	self	.	protoVersion	or	serverVersion	<	>	self	.	serverVersion	:	
return	{	"str"	:	False	,	"str"	:	0	,	"str"	:	0	}	
return	{	"str"	:	True	,	"str"	:	command	,	"str"	:	length	}	

def	pack	(	self	,	command	,	response	)	:	

HEAD_0	=	chr	(	self	.	HEAD_0	)	
HEAD_1	=	chr	(	self	.	HEAD_1	)	
HEAD_2	=	chr	(	self	.	HEAD_2	)	
HEAD_3	=	chr	(	self	.	HEAD_3	)	
protoVersion	=	chr	(	self	.	protoVersion	)	
serverVersion	=	self	.	serverVersion	
length	=	response	.	__len__	(	)	+	4	
commandID	=	command	
data	=	struct	.	pack	(	"str"	,	HEAD_0	,	HEAD_1	,	HEAD_2	,	HEAD_3	,	protoVersion	,	serverVersion	,	length	,	commandID	)	
data	=	data	+	response	
return	data	



	