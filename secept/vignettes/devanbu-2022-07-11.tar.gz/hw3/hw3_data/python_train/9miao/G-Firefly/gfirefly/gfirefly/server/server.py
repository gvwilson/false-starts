

from	gfirefly	.	netconnect	.	protoc	import	LiberateFactory	
from	flask	import	Flask	
from	gfirefly	.	distributed	.	root	import	PBRoot	,	BilateralFactory	
from	gfirefly	.	distributed	.	node	import	RemoteObject	
from	gfirefly	.	dbentrust	.	dbpool	import	dbpool	
from	gfirefly	.	dbentrust	.	memclient	import	memcached_connect	
from	gfirefly	.	server	.	logobj	import	loogoo	
from	gfirefly	.	server	.	globalobject	import	GlobalObject	
from	gtwisted	.	utils	import	log	
from	gtwisted	.	core	import	reactor	
from	gfirefly	.	utils	import	services	
import	os	,	sys	,	affinity	

reactor	=	reactor	

def	serverStop	(	)	:	

log	.	msg	(	"str"	)	
if	GlobalObject	(	)	.	stophandler	:	
GlobalObject	(	)	.	stophandler	(	)	
reactor	.	callLater	(	0.5	,	reactor	.	stop	)	
return	True	

class	FFServer	:	


def	__init__	(	self	)	:	

self	.	netfactory	=	None	
self	.	root	=	None	
self	.	webroot	=	None	
self	.	remote	=	{	}	
self	.	master_remote	=	None	
self	.	db	=	None	
self	.	mem	=	None	
self	.	servername	=	None	
self	.	remoteportlist	=	[	]	

def	config	(	self	,	config	,	servername	=	None	,	dbconfig	=	None	,	
memconfig	=	None	,	masterconf	=	None	)	:	

GlobalObject	(	)	.	json_config	=	config	
GlobalObject	(	)	.	remote_connect	=	self	.	remote_connect	
netport	=	config	.	get	(	"str"	)	
webport	=	config	.	get	(	"str"	)	
rootport	=	config	.	get	(	"str"	)	
self	.	remoteportlist	=	config	.	get	(	"str"	,	[	]	)	
if	not	servername	:	
servername	=	config	.	get	(	"str"	)	
logpath	=	config	.	get	(	"str"	)	
hasdb	=	config	.	get	(	"str"	)	
hasmem	=	config	.	get	(	"str"	)	
app	=	config	.	get	(	"str"	)	
cpuid	=	config	.	get	(	"str"	)	
mreload	=	config	.	get	(	"str"	)	
self	.	servername	=	servername	

if	netport	:	
self	.	netfactory	=	LiberateFactory	(	)	
netservice	=	services	.	CommandService	(	"str"	)	
self	.	netfactory	.	addServiceChannel	(	netservice	)	
reactor	.	listenTCP	(	netport	,	self	.	netfactory	)	

if	webport	:	
self	.	webroot	=	Flask	(	"str"	)	
GlobalObject	(	)	.	webroot	=	self	.	webroot	
reactor	.	listenWSGI	(	webport	,	self	.	webroot	)	

if	rootport	:	
self	.	root	=	PBRoot	(	)	
rootservice	=	services	.	Service	(	"str"	)	
self	.	root	.	addServiceChannel	(	rootservice	)	
reactor	.	listenTCP	(	rootport	,	BilateralFactory	(	self	.	root	)	)	

for	cnf	in	self	.	remoteportlist	:	
rname	=	cnf	.	get	(	"str"	)	
self	.	remote	[	rname	]	=	RemoteObject	(	self	.	servername	)	

if	hasdb	and	dbconfig	:	
if	dbconfig	.	has_key	(	"str"	)	and	dbconfig	.	has_key	(	"str"	)	and	dbconfig	.	has_key	(	"str"	)	:	
dbpool	.	initPool	(	{	"str"	:	dbconfig	}	)	
else	:	
dbpool	.	initPool	(	dbconfig	)	

if	hasmem	and	memconfig	:	
urls	=	memconfig	.	get	(	"str"	)	

memcached_connect	(	urls	)	
from	gfirefly	.	dbentrust	.	util	import	M2DB_PORT	,	M2DB_HOST	,	ToDBAddress	
ToDBAddress	(	)	.	setToDBHost	(	memconfig	.	get	(	"str"	,	M2DB_HOST	)	)	
ToDBAddress	(	)	.	setToDBPort	(	memconfig	.	get	(	"str"	,	M2DB_PORT	)	)	

if	logpath	:	
log	.	addObserver	(	loogoo	(	logpath	)	)	
log	.	startLogging	(	sys	.	stdout	)	

if	cpuid	:	
affinity	.	set_process_affinity_mask	(	os	.	getpid	(	)	,	cpuid	)	
GlobalObject	(	)	.	config	(	netfactory	=	self	.	netfactory	,	root	=	self	.	root	,	
remote	=	self	.	remote	)	

if	app	:	
__import__	(	app	)	
if	mreload	:	
_path_list	=	mreload	.	split	(	"str"	)	
GlobalObject	(	)	.	reloadmodule	=	__import__	(	mreload	,	fromlist	=	_path_list	[	:	1	]	)	

if	masterconf	:	
masterport	=	masterconf	.	get	(	"str"	)	
masterhost	=	masterconf	.	get	(	"str"	)	
self	.	master_remote	=	RemoteObject	(	servername	)	
GlobalObject	(	)	.	masterremote	=	self	.	master_remote	
import	admin	
addr	=	(	"str"	,	masterport	)	if	not	masterhost	else	(	masterhost	,	masterport	)	
self	.	master_remote	.	connect	(	addr	)	

def	remote_connect	(	self	,	rname	,	rhost	)	:	

for	cnf	in	self	.	remoteportlist	:	
_rname	=	cnf	.	get	(	"str"	)	
if	rname	==	_rname	:	
rport	=	cnf	.	get	(	"str"	)	
if	not	rhost	:	
addr	=	(	"str"	,	rport	)	
else	:	
addr	=	(	rhost	,	rport	)	
self	.	remote	[	rname	]	.	connect	(	addr	)	
break	

def	start	(	self	)	:	

log	.	msg	(	"str"	%	self	.	servername	)	
log	.	msg	(	"str"	%	(	self	.	servername	,	os	.	getpid	(	)	)	)	
reactor	.	run	(	)	




	