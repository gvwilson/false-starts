

from	gfirefly	.	management	import	commands	
import	sys	

class	CommandError	(	Exception	)	:	

def	__str__	(	self	)	:	
return	"str"	

class	Command	:	

def	__init__	(	self	,	subcommond	,	*	args	)	:	

self	.	subcommond	=	subcommond	
self	.	args	=	args	

def	execute	(	self	)	:	

try	:	
commmd	=	getattr	(	commands	,	self	.	subcommond	)	
commmd	.	execute	(	*	self	.	args	)	
except	:	
modes	=	dir	(	commands	)	
lines	=	[	"str"	+	m	+	"str"	for	m	in	modes	if	not	m	.	startswith	(	"str"	)	]	
firstline	=	"str"	
print	"str"	.	join	(	[	firstline	,	]	+	lines	)	


def	execute_commands	(	*	args	)	:	

if	len	(	args	)	<	2	:	
raise	CommandError	(	)	
subcommand	=	args	[	1	]	
comm	=	Command	(	subcommand	,	*	tuple	(	args	[	2	:	]	)	)	
comm	.	execute	(	)	



	