

import	memclient	
import	time	
LOCK_TIMEOUT	=	2	
CACHE_TIMEOUT	=	60	*	60	

class	MEMKeyError	(	Exception	)	:	


def	__str__	(	self	)	:	
return	"str"	

class	MemFields	(	object	)	:	


def	__init__	(	self	,	value	=	None	,	cache	=	True	,	timeout	=	CACHE_TIMEOUT	)	:	

self	.	name	=	"str"	
self	.	value	=	value	
self	.	cache	=	cache	
self	.	timeout	=	timeout	

def	getValue	(	self	)	:	

if	self	.	cache	and	self	.	value	:	
return	self	.	value	
else	:	
self	.	refreshValue	(	)	
return	self	.	value	

def	refreshValue	(	self	)	:	

self	.	value	=	memclient	.	mclient	.	get	(	self	.	name	)	
return	self	.	value	

def	setValue	(	self	,	value	)	:	

self	.	value	=	value	
result	=	memclient	.	mclient	.	set	(	self	.	name	,	value	,	time	=	self	.	timeout	)	
return	result	

class	MemObj	(	object	)	:	

def	__init__	(	self	,	name	,	*	*	kw	)	:	

self	.	_name	=	name	
self	.	_locked	=	False	
self	.	_timestamp	=	0	
self	.	_cas	=	kw	.	get	(	"str"	,	False	)	
self	.	_cache	=	kw	.	get	(	"str"	,	True	)	
self	.	_timeout	=	kw	.	get	(	"str"	,	CACHE_TIMEOUT	)	
if	self	.	_cas	:	
self	.	lock	(	)	

def	initFields	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
for	item_key	,	item_value	in	nowdict	.	items	(	)	:	
if	isinstance	(	item_value	,	MemFields	)	:	
item_value	.	name	=	self	.	produceKey	(	item_key	)	
item_value	.	timeout	=	self	.	_timeout	
item_value	.	cache	=	self	.	_cache	

def	produceKey	(	self	,	keyname	)	:	

if	isinstance	(	keyname	,	basestring	)	:	
return	"str"	.	join	(	[	self	.	_name	,	"str"	,	keyname	]	)	
else	:	
raise	MEMKeyError	(	)	

def	isLocked	(	self	)	:	

tdelta	=	time	.	time	(	)	-	self	.	_timestamp	
if	tdelta	>	=	LOCK_TIMEOUT	:	
self	.	_locked	=	False	
return	self	.	_locked	

def	lock	(	self	)	:	

print	"str"	
if	not	self	.	isLocked	(	)	:	
key	=	self	.	produceKey	(	"str"	)	
result	=	memclient	.	mclient	.	add	(	key	,	1	,	LOCK_TIMEOUT	)	
if	result	:	
self	.	_timestamp	=	time	.	time	(	)	
self	.	_locked	=	result	
return	self	.	_locked	

def	release	(	self	)	:	

if	self	.	isLocked	(	)	:	
key	=	self	.	produceKey	(	"str"	)	
memclient	.	mclient	.	delete	(	key	)	
self	.	_locked	=	False	

def	insert	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
newmapping	=	dict	(	[	(	self	.	produceKey	(	item_key	)	,	item_value	.	value	)	for	item_key	,	item_value	in	nowdict	.	items	(	)	if	isinstance	(	item_value	,	MemFields	)	and	item_value	.	value	]	)	
memclient	.	mclient	.	set_multi	(	newmapping	,	time	=	self	.	_timeout	)	

def	mdelete	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
keys	=	[	self	.	produceKey	(	item_key	)	for	item_key	,	item_value	in	nowdict	.	items	(	)	if	isinstance	(	item_value	,	MemFields	)	]	
return	memclient	.	mclient	.	delete_multi	(	keys	)	

def	__getattribute__	(	self	,	attr	)	:	

value	=	object	.	__getattribute__	(	self	,	attr	)	
if	isinstance	(	value	,	MemFields	)	:	
print	"str"	,	self	.	isLocked	(	)	
if	self	.	_cas	and	not	self	.	isLocked	(	)	:	
for	_	in	xrange	(	10	)	:	
if	not	self	.	lock	(	)	:	
time	.	sleep	(	0.2	)	
continue	
break	
else	:	
return	None	
return	value	.	getValue	(	)	
return	value	

def	__setattr__	(	self	,	attr	,	value	)	:	

if	self	.	__dict__	.	has_key	(	attr	)	:	
_value	=	object	.	__getattribute__	(	self	,	attr	)	
if	isinstance	(	_value	,	MemFields	)	:	
result	=	_value	.	setValue	(	value	)	


return	result	
else	:	
return	object	.	__setattr__	(	self	,	attr	,	value	)	
else	:	
return	object	.	__setattr__	(	self	,	attr	,	value	)	

def	__del__	(	self	)	:	

try	:	
if	self	.	isLocked	(	)	:	
self	.	release	(	)	
except	Exception	as	e	:	
print	e	


if	__name__	==	"str"	:	
from	memclient	import	memcached_connect	
memcached_connect	(	[	"str"	]	)	
class	Mcharacter	(	MemObj	)	:	
def	__init__	(	self	,	name	,	*	*	kw	)	:	
MemObj	.	__init__	(	self	,	name	,	*	*	kw	)	
self	.	id	=	MemFields	(	1	)	
self	.	level	=	MemFields	(	0	)	
self	.	profession	=	MemFields	(	9	)	
self	.	nickname	=	MemFields	(	"str"	)	
self	.	guanqia	=	MemFields	(	100	)	
self	.	initFields	(	)	

mcharacter	=	Mcharacter	(	"str"	,	cas	=	True	)	
mcharacter	.	nickname	=	"str"	
mcharacter	.	insert	(	)	
print	"str"	,	mcharacter	.	nickname	
mcharacter	.	release	(	)	
mc_other	=	Mcharacter	(	"str"	,	cas	=	True	)	
mc_other2	=	Mcharacter	(	"str"	,	cas	=	True	)	
print	"str"	,	mc_other	.	nickname	
print	"str"	,	mc_other2	.	nickname	
print	"str"	,	mc_other	.	guanqia	
print	type	(	mc_other	.	guanqia	)	
del	mc_other	,	mc_other2	

	