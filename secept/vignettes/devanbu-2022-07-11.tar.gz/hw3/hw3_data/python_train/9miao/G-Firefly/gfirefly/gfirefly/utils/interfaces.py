

from	__future__	import	division	,	absolute_import	
from	zope	.	interface	import	Interface	


class	IDataPackProtoc	(	Interface	)	:	

def	getHeadlength	(	)	:	

pass	

def	unpack	(	)	:	


def	pack	(	)	:	




	