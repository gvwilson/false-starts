

from	gfirefly	.	dbentrust	.	memclient	import	memcached_connect	
memcached_connect	(	[	"str"	]	)	
from	gfirefly	.	dbentrust	.	memfields	import	MemObj	,	MemFields	
class	Mcharacter	(	MemObj	)	:	
def	__init__	(	self	,	name	)	:	
MemObj	.	__init__	(	self	,	name	)	
self	.	id	=	MemFields	(	)	
self	.	level	=	MemFields	(	)	
self	.	profession	=	MemFields	(	)	
self	.	nickname	=	MemFields	(	)	
self	.	guanqia	=	MemFields	(	)	
self	.	initFields	(	)	

mcharacter	=	Mcharacter	(	"str"	)	
mcharacter	.	nickname	=	"str"	
mc_other	=	Mcharacter	(	"str"	)	
mc_other2	=	Mcharacter	(	"str"	)	
print	"str"	,	mcharacter	.	nickname	
print	"str"	,	mc_other	.	nickname	
print	"str"	,	mc_other2	.	nickname	
mcharacter	.	mdelete	(	)	
	