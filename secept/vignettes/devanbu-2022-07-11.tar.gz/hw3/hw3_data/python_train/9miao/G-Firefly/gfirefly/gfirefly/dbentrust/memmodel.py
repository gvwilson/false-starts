

from	memfields	import	MemObj	,	MemFields	
import	util	

MMODE_STATE_ORI	=	1	
MMODE_STATE_NEW	=	2	
MMODE_STATE_UPDATE	=	3	
MMODE_STATE_DEL	=	4	

class	PKValueError	(	ValueError	)	:	

def	__init__	(	self	,	data	)	:	
ValueError	.	__init__	(	self	)	
self	.	data	=	data	
def	__str__	(	self	)	:	
return	"str"	%	(	self	.	data	)	

class	MemModel	(	MemObj	)	:	

def	__init__	(	self	,	name	,	pk	,	data	=	{	}	,	*	*	kw	)	:	
MemObj	.	__init__	(	self	,	name	,	*	*	kw	)	
self	.	pk	=	pk	
dataField	=	MemFields	(	data	)	
self	.	data	=	dataField	
self	.	initFields	(	)	

def	__getattribute__	(	self	,	attr	)	:	
_value	=	object	.	__getattribute__	(	self	,	attr	)	
value	=	MemObj	.	__getattribute__	(	self	,	attr	)	
if	attr	==	"str"	:	
if	not	value	:	
tablename	,	pid	=	self	.	_name	.	split	(	"str"	)	
props	=	{	self	.	pk	:	int	(	pid	)	}	
record	=	util	.	GetOneRecordInfo	(	tablename	,	props	)	
if	record	:	
_value	.	setValue	(	record	)	
return	record	
return	value	

def	delete	(	self	)	:	

tablename	,	pid	=	self	.	_name	.	split	(	"str"	)	
pk	=	self	.	pk	
prere	=	{	pk	:	int	(	pid	)	}	
result	=	util	.	DeleteFromDB	(	tablename	,	prere	)	
self	.	mdelete	(	)	
return	result	

def	syncDB	(	self	)	:	

tablename	=	self	.	_name	.	split	(	"str"	)	[	0	]	
data_item	=	self	.	__dict__	.	get	(	"str"	)	
data_item	.	setValue	(	data_item	.	value	)	
if	self	.	_cas	:	
self	.	release	(	)	
props	=	self	.	data	
pk	=	self	.	pk	
prere	=	{	pk	:	props	.	get	(	pk	)	}	
result	=	util	.	UpdateWithDict	(	tablename	,	props	,	prere	)	
return	result	

save	=	syncDB	

def	__repr__	(	self	)	:	

return	"str"	%	(	self	.	_name	,	self	.	data	)	

def	__str__	(	self	)	:	

return	"str"	%	(	self	.	_name	,	self	.	data	)	

class	MemAdmin	(	object	)	:	

def	__init__	(	self	,	name	,	pk	,	*	*	kw	)	:	
self	.	name	=	name	
self	.	pk	=	pk	
self	.	kw	=	kw	
self	.	incrkey	=	kw	.	get	(	"str"	,	"str"	)	

def	load	(	self	)	:	

mmname	=	self	.	name	
recordlist	=	util	.	ReadDataFromDB	(	mmname	)	
for	record	in	recordlist	:	
pk	=	record	[	self	.	pk	]	
mm	=	MemModel	(	self	.	name	+	"str"	%	pk	,	self	.	pk	,	data	=	record	,	*	*	self	.	kw	)	
mm	.	insert	(	)	

def	new	(	self	,	data	)	:	

incrkey	=	self	.	incrkey	
tablename	=	self	.	name	
if	incrkey	:	
result	=	util	.	InsertIntoDBAndReturnID	(	tablename	,	data	)	
data	[	incrkey	]	=	result	
pk	=	data	.	get	(	self	.	pk	)	
if	pk	is	None	:	
raise	PKValueError	(	data	)	
mm	=	MemModel	(	self	.	name	+	"str"	%	pk	,	self	.	pk	,	data	=	data	,	*	*	self	.	kw	)	
setattr	(	mm	,	incrkey	,	pk	)	
else	:	
pk	=	data	.	get	(	self	.	pk	)	
result	=	util	.	InsertIntoDB	(	tablename	,	data	)	
if	not	result	:	
raise	util	.	SQLError	(	)	
mm	=	MemModel	(	self	.	name	+	"str"	%	pk	,	self	.	pk	,	data	=	data	,	*	*	self	.	kw	)	
mm	.	insert	(	)	
return	mm	

def	getObj	(	self	,	pk	)	:	

mm	=	MemModel	(	self	.	name	+	"str"	%	pk	,	self	.	pk	,	*	*	self	.	kw	)	
if	mm	.	data	:	
return	mm	
else	:	
return	None	

def	getAllPkByFk	(	self	,	*	*	kw	)	:	

dbkeylist	=	util	.	getAllPkByFkInDB	(	self	.	_name	,	self	.	_pk	,	kw	)	
return	dbkeylist	

def	getObjList	(	self	,	pklist	)	:	

objlist	=	[	]	
for	pk	in	pklist	:	
mm	=	MemModel	(	self	.	name	+	"str"	%	pk	,	self	.	pk	,	*	*	self	.	kw	)	
objlist	.	append	(	mm	)	
return	objlist	


if	__name__	==	"str"	:	
from	dbpool	import	dbpool	
from	memclient	import	memcached_connect	
memcached_connect	(	[	"str"	]	)	
from	memclient	import	mclient	
import	time	
aa	=	{	"str"	:	{	"str"	:	"str"	,	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	,	
}	
dbpool	.	initPool	(	aa	)	

ma	=	MemAdmin	(	"str"	,	"str"	,	incrkey	=	"str"	,	cas	=	True	)	
ma	.	load	(	)	
t1	=	time	.	time	(	)	
mm	=	ma	.	getObj	(	1	)	
mm	.	data	[	"str"	]	=	123	
print	"str"	,	mm	.	data	
print	"str"	,	time	.	time	(	)	-	t1	
data	=	dict	(	mm	.	data	)	
print	"str"	,	mclient	.	get	(	"str"	)	
del	data	[	"str"	]	
mm_new	=	ma	.	new	(	data	)	
print	"str"	,	mclient	.	get	(	"str"	)	
print	"str"	,	mm_new	.	data	
del	mm	,	mm_new	
	