

from	gtwisted	.	core	import	rpc	
from	gtwisted	.	core	import	reactor	
reactor	=	reactor	
from	reference	import	ProxyReference	


class	BilateralClientProtocol	(	rpc	.	PBClientProtocl	)	:	

def	__init__	(	self	,	transport	,	factory	)	:	
rpc	.	PBClientProtocl	.	__init__	(	self	,	transport	,	factory	)	

def	setProxyReference	(	self	,	pr	)	:	

self	.	reference	=	pr	

def	getRemoteMethod	(	self	,	_name	)	:	

method	=	getattr	(	self	.	reference	,	"str"	%	_name	)	
return	method	

def	connectionLost	(	self	,	reason	)	:	
rpc	.	PBClientProtocl	.	connectionLost	(	self	,	reason	)	
self	.	factory	


class	BilateralClientFactory	(	rpc	.	PBClientFactory	)	:	

protocol	=	BilateralClientProtocol	

def	__init__	(	self	,	ro	=	None	)	:	
self	.	ro	=	ro	
rpc	.	PBClientFactory	.	__init__	(	self	)	

def	doconnectionLost	(	self	)	:	

if	self	.	ro	:	
self	.	ro	.	reconnect	(	)	



class	RemoteObject	(	object	)	:	


def	__init__	(	self	,	name	,	timeout	=	600	)	:	

self	.	_name	=	name	
self	.	_factory	=	BilateralClientFactory	(	self	)	
self	.	_reference	=	ProxyReference	(	)	
self	.	_addr	=	None	
self	.	_timeout	=	timeout	

def	setName	(	self	,	name	)	:	

self	.	_name	=	name	

def	getName	(	self	)	:	

return	self	.	_name	

def	connect	(	self	,	addr	)	:	

self	.	_addr	=	addr	
reactor	.	connectTCP	(	addr	[	0	]	,	addr	[	1	]	,	self	.	_factory	)	
self	.	takeProxy	(	)	

def	reconnect	(	self	,	addr	=	(	)	)	:	

if	addr	:	
self	.	connect	(	addr	)	
else	:	
self	.	connect	(	self	.	_addr	)	

def	addServiceChannel	(	self	,	service	)	:	

self	.	_reference	.	addService	(	service	)	

def	takeProxy	(	self	)	:	

self	.	_factory	.	_protocol	.	setProxyReference	(	self	.	_reference	)	
deferedRemote	=	self	.	_factory	.	getRootObject	(	timeout	=	self	.	_timeout	)	
deferedRemote	.	callRemoteNotForResult	(	"str"	,	self	.	_name	)	

def	callRemote	(	self	,	commandId	,	*	args	,	*	*	kw	)	:	

deferedRemote	=	self	.	_factory	.	getRootObject	(	timeout	=	self	.	_timeout	)	
return	deferedRemote	.	callRemoteForResult	(	"str"	,	commandId	,	*	args	,	*	*	kw	)	

def	callRemoteForResult	(	self	,	commandId	,	*	args	,	*	*	kw	)	:	

deferedRemote	=	self	.	_factory	.	getRootObject	(	timeout	=	self	.	_timeout	)	
return	deferedRemote	.	callRemoteForResult	(	"str"	,	commandId	,	*	args	,	*	*	kw	)	

def	callRemoteNotForResult	(	self	,	commandId	,	*	args	,	*	*	kw	)	:	

deferedRemote	=	self	.	_factory	.	getRootObject	(	timeout	=	self	.	_timeout	)	
return	deferedRemote	.	callRemoteNotForResult	(	"str"	,	commandId	,	*	args	,	*	*	kw	)	


	