

from	gtwisted	.	utils	import	log	

class	ChildsManager	(	object	)	:	


def	__init__	(	self	)	:	

self	.	_childs	=	{	}	

def	getChild	(	self	,	childname	)	:	

for	key	,	child	in	self	.	_childs	.	items	(	)	:	
if	child	.	getName	(	)	==	childname	:	
return	self	.	_childs	[	key	]	
return	None	

def	addChild	(	self	,	child	)	:	

key	=	child	.	getName	(	)	
if	self	.	_childs	.	has_key	(	key	)	:	
raise	"str"	%	key	
self	.	_childs	[	key	]	=	child	

def	dropChild	(	self	,	child	)	:	

key	=	child	.	getName	(	)	
try	:	
del	self	.	_childs	[	key	]	
except	Exception	,	e	:	
log	.	msg	(	str	(	e	)	)	

def	dropChildByID	(	self	,	childId	)	:	

try	:	
del	self	.	_childs	[	childId	]	
except	Exception	,	e	:	
log	.	msg	(	str	(	e	)	)	

def	callChild	(	self	,	childname	,	*	args	,	*	*	kw	)	:	

child	=	self	.	getChild	(	childname	)	
if	not	child	:	
log	.	err	(	"str"	%	childname	)	
return	
return	child	.	callbackChild	(	*	args	,	*	*	kw	)	

def	callChildNotForResult	(	self	,	childname	,	*	args	,	*	*	kw	)	:	

child	=	self	.	_childs	.	get	(	childname	,	None	)	
if	not	child	:	
log	.	err	(	"str"	%	childname	)	
return	
child	.	callbackChildNotForResult	(	*	args	,	*	*	kw	)	

def	getChildBYSessionId	(	self	,	session_id	)	:	

for	child	in	self	.	_childs	.	values	(	)	:	
if	child	.	_transport	.	transport	.	sessionno	==	session_id	:	
return	child	
return	None	


	