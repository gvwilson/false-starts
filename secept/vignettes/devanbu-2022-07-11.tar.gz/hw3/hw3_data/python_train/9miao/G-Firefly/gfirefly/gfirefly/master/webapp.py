

from	gtwisted	.	core	import	reactor	
from	gfirefly	.	server	.	globalobject	import	webserviceHandle	,	GlobalObject	
reactor	=	reactor	

@webserviceHandle	(	"str"	)	
def	stop	(	)	:	

for	child	in	GlobalObject	(	)	.	root	.	childsmanager	.	_childs	.	values	(	)	:	
child	.	callbackChildNotForResult	(	"str"	)	
reactor	.	callLater	(	0.5	,	reactor	.	stop	)	
return	"str"	

@webserviceHandle	(	"str"	)	
def	reloadmodule	(	)	:	

for	child	in	GlobalObject	(	)	.	root	.	childsmanager	.	_childs	.	values	(	)	:	
child	.	callbackChildNotForResult	(	"str"	)	
return	"str"	
	