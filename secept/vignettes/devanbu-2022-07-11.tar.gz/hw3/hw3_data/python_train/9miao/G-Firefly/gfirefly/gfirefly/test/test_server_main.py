

import	json	,	sys	
from	gfirefly	.	server	.	server	import	FFServer	

if	__name__	==	"str"	:	
args	=	sys	.	argv	
servername	=	None	
config	=	None	
if	len	(	args	)	>	2	:	
servername	=	args	[	1	]	
config	=	json	.	load	(	open	(	args	[	2	]	,	"str"	)	)	
else	:	
raise	ValueError	
dbconf	=	config	.	get	(	"str"	)	
memconf	=	config	.	get	(	"str"	)	
sersconf	=	config	.	get	(	"str"	,	{	}	)	
masterconf	=	config	.	get	(	"str"	,	{	}	)	
serconfig	=	sersconf	.	get	(	servername	)	
ser	=	FFServer	(	)	
ser	.	config	(	serconfig	,	dbconfig	=	dbconf	,	memconfig	=	memconf	,	masterconf	=	masterconf	)	
ser	.	start	(	)	


	