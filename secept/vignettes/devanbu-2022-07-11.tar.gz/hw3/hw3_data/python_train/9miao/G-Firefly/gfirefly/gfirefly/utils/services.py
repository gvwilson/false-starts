

from	gtwisted	.	utils	import	log	


class	Service	(	object	)	:	


def	__init__	(	self	,	name	)	:	
self	.	_name	=	name	
self	.	unDisplay	=	set	(	)	
self	.	_targets	=	{	}	

def	__iter__	(	self	)	:	
return	self	.	_targets	.	itervalues	(	)	

def	addUnDisplayTarget	(	self	,	command	)	:	

self	.	unDisplay	.	add	(	command	)	

def	mapTarget	(	self	,	target	)	:	

key	=	target	.	__name__	
if	self	.	_targets	.	has_key	(	key	)	:	
exist_target	=	self	.	_targets	.	get	(	key	)	
raise	"str"	%	(	key	,	exist_target	.	__name__	,	target	.	__name__	)	
self	.	_targets	[	key	]	=	target	

def	unMapTarget	(	self	,	target	)	:	

key	=	target	.	__name__	
if	key	in	self	.	_targets	:	
del	self	.	_targets	[	key	]	

def	unMapTargetByKey	(	self	,	targetKey	)	:	

del	self	.	_targets	[	targetKey	]	

def	getTarget	(	self	,	targetKey	)	:	

target	=	self	.	_targets	.	get	(	targetKey	,	None	)	
return	target	

def	callTarget	(	self	,	targetKey	,	*	args	,	*	*	kw	)	:	

target	=	self	.	getTarget	(	targetKey	)	
if	not	target	:	
log	.	err	(	"str"	+	str	(	targetKey	)	+	"str"	)	
return	None	
if	targetKey	not	in	self	.	unDisplay	:	
log	.	msg	(	"str"	%	target	.	__name__	)	
response	=	target	(	*	args	,	*	*	kw	)	
return	response	


class	CommandService	(	Service	)	:	

def	mapTarget	(	self	,	target	)	:	

key	=	int	(	(	target	.	__name__	)	.	split	(	"str"	)	[	-	1	]	)	
if	self	.	_targets	.	has_key	(	key	)	:	
exist_target	=	self	.	_targets	.	get	(	key	)	
raise	"str"	%	(	key	,	exist_target	.	__name__	,	target	.	__name__	)	
self	.	_targets	[	key	]	=	target	

def	unMapTarget	(	self	,	target	)	:	

key	=	int	(	(	target	.	__name__	)	.	split	(	"str"	)	[	-	1	]	)	
if	key	in	self	.	_targets	:	
del	self	.	_targets	[	key	]	






	