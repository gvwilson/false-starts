













import	sys	
import	os	




sys	.	path	.	insert	(	0	,	os	.	path	.	abspath	(	"str"	)	)	









extensions	=	[	
"str"	,	
]	


templates_path	=	[	"str"	]	


source_suffix	=	"str"	





master_doc	=	"str"	


project	=	"str"	
copyright	=	"str"	






version	=	"str"	

release	=	"str"	













exclude_patterns	=	[	]	

















pygments_style	=	"str"	












html_theme	=	"str"	




























html_static_path	=	[	"str"	]	
















































htmlhelp_basename	=	"str"	




latex_elements	=	{	








}	




latex_documents	=	[	
(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	,	
]	


























man_pages	=	[	
(	"str"	,	"str"	,	"str"	,	
[	"str"	]	,	1	)	
]	










texinfo_documents	=	[	
(	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	
"str"	)	,	
]	












	