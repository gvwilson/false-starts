

from	gfirefly	.	dbentrust	.	dbpool	import	dbpool	,	RouterBase	
from	gfirefly	.	dbentrust	.	memclient	import	memcached_connect	
memcached_connect	(	[	"str"	]	)	
from	gfirefly	.	dbentrust	.	memmodel	import	MemAdmin	
aa	=	{	"str"	:	{	"str"	:	"str"	,	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	,	
"str"	:	{	"str"	:	"str"	,	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	
}	
dbpool	.	initPool	(	aa	)	

class	router	(	RouterBase	)	:	
def	db_for_read	(	self	,	*	*	kw	)	:	
return	"str"	
def	db_for_write	(	self	,	*	*	kw	)	:	
return	"str"	

dbpool	.	bind_router	(	router	)	

ma	=	MemAdmin	(	"str"	,	"str"	,	incrkey	=	"str"	)	
mm	=	ma	.	getObj	(	1	)	
mm	.	data	[	"str"	]	=	123	
print	"str"	,	mm	.	data	
data	=	dict	(	mm	.	data	)	
del	data	[	"str"	]	
mm_new	=	ma	.	new	(	data	)	
print	mm_new	.	data	[	"str"	]	
	