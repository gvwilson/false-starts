

from	gtwisted	.	utils	import	log	
from	gtwisted	.	core	import	rpc	
from	manager	import	ChildsManager	
from	child	import	Child	

class	BilateralBroker	(	rpc	.	PBServerProtocl	)	:	

def	connectionLost	(	self	,	reason	)	:	
clientID	=	self	.	transport	.	sessionno	
log	.	msg	(	"str"	%	clientID	)	
self	.	factory	.	root	.	dropChildSessionId	(	clientID	)	

def	remote_takeProxy	(	self	,	name	)	:	

self	.	factory	.	root	.	remote_takeProxy	(	name	,	self	)	

def	remote_callTarget	(	self	,	command	,	*	args	,	*	*	kw	)	:	

data	=	self	.	factory	.	root	.	remote_callTarget	(	command	,	*	args	,	*	*	kw	)	
return	data	


class	BilateralFactory	(	rpc	.	PBServerFactory	)	:	

protocol	=	BilateralBroker	

def	__init__	(	self	,	root	)	:	
rpc	.	PBServerFactory	.	__init__	(	self	)	
self	.	root	=	root	

class	PBRoot	:	


def	__init__	(	self	,	dnsmanager	=	ChildsManager	(	)	)	:	

self	.	service	=	None	
self	.	childsmanager	=	dnsmanager	

def	addServiceChannel	(	self	,	service	)	:	

self	.	service	=	service	

def	remote_takeProxy	(	self	,	name	,	transport	)	:	

log	.	msg	(	"str"	%	name	)	
child	=	Child	(	name	)	
self	.	childsmanager	.	addChild	(	child	)	
child	.	setTransport	(	transport	)	
self	.	doChildConnect	(	name	,	transport	)	

def	doChildConnect	(	self	,	name	,	transport	)	:	

pass	

def	remote_callTarget	(	self	,	command	,	*	args	,	*	*	kw	)	:	

data	=	self	.	service	.	callTarget	(	command	,	*	args	,	*	*	kw	)	
return	data	

def	dropChild	(	self	,	*	args	,	*	*	kw	)	:	

self	.	childsmanager	.	dropChild	(	*	args	,	*	*	kw	)	

def	dropChildByID	(	self	,	childId	)	:	

self	.	doChildLostConnect	(	childId	)	
self	.	childsmanager	.	dropChildByID	(	childId	)	

def	dropChildSessionId	(	self	,	session_id	)	:	

child	=	self	.	childsmanager	.	getChildBYSessionId	(	session_id	)	
if	not	child	:	
return	
childname	=	child	.	getName	(	)	
self	.	doChildLostConnect	(	childname	)	
self	.	childsmanager	.	dropChildByID	(	childname	)	

def	doChildLostConnect	(	self	,	childname	)	:	

pass	

def	callChild	(	self	,	key	,	*	args	,	*	*	kw	)	:	

return	self	.	childsmanager	.	callChild	(	key	,	*	args	,	*	*	kw	)	

def	callChildNotForResult	(	self	,	childname	,	*	args	,	*	*	kw	)	:	

self	.	childsmanager	.	callChildNotForResult	(	childname	,	*	args	,	*	*	kw	)	
	