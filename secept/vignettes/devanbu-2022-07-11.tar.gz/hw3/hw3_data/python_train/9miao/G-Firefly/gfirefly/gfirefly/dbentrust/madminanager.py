

from	gfirefly	.	utils	.	singleton	import	Singleton	
from	gevent_zeromq	import	zmq	
import	gevent	
from	util	import	excuteSQL	

from	util	import	ToDBAddress	,	M2DB_PORT	
from	gtwisted	.	utils	import	log	
import	traceback	

class	MAdminManager	:	

__metaclass__	=	Singleton	

def	__init__	(	self	)	:	

self	.	isStart	=	False	
self	.	to_db_port	=	None	

def	registe	(	self	,	admin	)	:	

pass	


def	_run	(	self	)	:	

while	True	:	

try	:	
pyobj	=	self	.	sock	.	recv_pyobj	(	)	
tablename	,	sql	=	pyobj	
excuteSQL	(	tablename	,	sql	)	
except	Exception	,	e	:	
log	.	err	(	_stuff	=	e	,	_why	=	traceback	.	format_exc	(	)	)	

def	checkAdmins	(	self	,	port	=	M2DB_PORT	)	:	

if	self	.	isStart	:	
return	
self	.	isStart	=	True	
context	=	zmq	.	Context	(	)	
self	.	sock	=	context	.	socket	(	zmq	.	SUB	)	

if	port	==	M2DB_PORT	:	
port	=	ToDBAddress	(	)	.	m2db_port	
address	=	"str"	%	port	
self	.	sock	.	bind	(	address	)	
self	.	sock	.	setsockopt	(	zmq	.	SUBSCRIBE	,	"str"	)	
gevent	.	spawn	(	self	.	_run	)	



	