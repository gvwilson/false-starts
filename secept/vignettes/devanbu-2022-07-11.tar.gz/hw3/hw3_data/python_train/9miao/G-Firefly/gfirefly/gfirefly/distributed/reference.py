

from	gfirefly	.	utils	.	services	import	Service	


class	ProxyReference	:	


def	__init__	(	self	)	:	

self	.	_service	=	Service	(	"str"	)	

def	addService	(	self	,	service	)	:	

self	.	_service	=	service	

def	remote_callChild	(	self	,	command	,	*	arg	,	*	*	kw	)	:	

return	self	.	_service	.	callTarget	(	command	,	*	arg	,	*	*	kw	)	




	