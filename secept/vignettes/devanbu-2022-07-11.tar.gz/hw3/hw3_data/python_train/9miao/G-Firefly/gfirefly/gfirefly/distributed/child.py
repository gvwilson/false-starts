

class	Child	(	object	)	:	


def	__init__	(	self	,	name	)	:	

self	.	_name	=	name	
self	.	_transport	=	None	

def	getName	(	self	)	:	

return	self	.	_name	

def	setTransport	(	self	,	transport	)	:	

self	.	_transport	=	transport	

def	callbackChild	(	self	,	*	args	,	*	*	kw	)	:	

return	self	.	callbackChildForResult	(	*	args	,	*	*	kw	)	

def	callbackChildNotForResult	(	self	,	*	args	,	*	*	kw	)	:	

remote	=	self	.	_transport	.	getRootObject	(	)	
remote	.	callRemoteNotForResult	(	"str"	,	*	args	,	*	*	kw	)	

def	callbackChildForResult	(	self	,	*	args	,	*	*	kw	)	:	

remote	=	self	.	_transport	.	getRootObject	(	)	
recvdata	=	remote	.	callRemoteForResult	(	"str"	,	*	args	,	*	*	kw	)	
return	recvdata	





	