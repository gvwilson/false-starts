


from	dbpool	import	dbpool	
from	MySQLdb	.	cursors	import	DictCursor	
from	numbers	import	Number	
from	gtwisted	.	utils	import	log	
import	traceback	
from	gfirefly	.	utils	.	singleton	import	Singleton	

M2DB_PORT	=	5000	
M2DB_HOST	=	"str"	
SYNC_TYPE	=	1	

class	ToDBAddress	:	

__metaclass__	=	Singleton	

def	__init__	(	self	)	:	

self	.	m2db_host	=	M2DB_HOST	
self	.	m2db_port	=	M2DB_PORT	

def	setToDBHost	(	self	,	host	)	:	

self	.	m2db_host	=	host	

def	setToDBPort	(	self	,	port	)	:	

self	.	m2db_port	=	port	

class	SQLError	(	Exception	)	:	


def	__str__	(	self	)	:	
return	"str"	


def	forEachPlusInsertProps	(	tablename	,	props	)	:	
assert	isinstance	(	props	,	dict	)	
pkeysstr	=	str	(	tuple	(	props	.	keys	(	)	)	)	.	replace	(	"str"	,	"str"	)	
pvaluesstr	=	[	"str"	%	val	if	isinstance	(	val	,	Number	)	else	
"str"	%	str	(	val	)	.	replace	(	"str"	,	"str"	)	for	val	in	props	.	values	(	)	]	
pvaluesstr	=	"str"	.	join	(	pvaluesstr	)	[	:	-	1	]	
sqlstr	=	"str"	%	(	tablename	,	pkeysstr	,	pvaluesstr	)	
return	sqlstr	

def	FormatCondition	(	props	)	:	

items	=	props	.	items	(	)	
itemstrlist	=	[	]	
for	_item	in	items	:	
if	isinstance	(	_item	[	1	]	,	Number	)	:	
sqlstr	=	"str"	%	_item	
else	:	
sqlstr	=	"str"	%	(	_item	[	0	]	,	str	(	_item	[	1	]	)	.	replace	(	"str"	,	"str"	)	)	
itemstrlist	.	append	(	sqlstr	)	
sqlstr	=	"str"	.	join	(	itemstrlist	)	
return	sqlstr	[	:	-	4	]	

def	FormatUpdateStr	(	props	)	:	

items	=	props	.	items	(	)	
itemstrlist	=	[	]	
for	_item	in	items	:	
if	isinstance	(	_item	[	1	]	,	Number	)	:	
sqlstr	=	"str"	%	_item	
else	:	
sqlstr	=	"str"	%	(	_item	[	0	]	,	str	(	_item	[	1	]	)	.	replace	(	"str"	,	"str"	)	)	
itemstrlist	.	append	(	sqlstr	)	
sqlstr	=	"str"	.	join	(	itemstrlist	)	
return	sqlstr	[	:	-	1	]	

def	forEachUpdateProps	(	tablename	,	props	,	prere	)	:	

assert	isinstance	(	props	,	dict	)	
pro	=	FormatUpdateStr	(	props	)	
pre	=	FormatCondition	(	prere	)	
sqlstr	=	"str"	%	(	tablename	,	pro	,	pre	)	
return	sqlstr	

def	EachQueryProps	(	props	)	:	

sqlstr	=	"str"	
if	props	==	"str"	:	
return	"str"	
elif	type	(	props	)	==	type	(	[	0	]	)	:	
for	prop	in	props	:	
sqlstr	=	sqlstr	+	prop	+	"str"	
sqlstr	=	sqlstr	[	:	-	1	]	
return	sqlstr	
else	:	
raise	Exception	(	"str"	)	
return	

def	forEachQueryProps	(	sqlstr	,	props	)	:	

if	props	==	"str"	:	
sqlstr	+	=	"str"	
elif	type	(	props	)	==	type	(	[	0	]	)	:	
i	=	0	
for	prop	in	props	:	
if	(	i	==	0	)	:	
sqlstr	+	=	"str"	+	prop	
else	:	
sqlstr	+	=	"str"	+	prop	
i	+	=	1	
else	:	
raise	Exception	(	"str"	)	
return	
return	sqlstr	

def	GetTableIncrValue	(	tablename	)	:	

conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	tablename	)	
database	=	conn	.	_conn	.	_kwargs	.	get	(	"str"	)	
sql	=	"str"	%	(	database	,	tablename	)	
cursor	=	conn	.	cursor	(	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchone	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
if	result	:	
return	result	[	0	]	
return	result	

def	ReadDataFromDB	(	tablename	)	:	

sql	=	"str"	%	tablename	
conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	DeleteFromDB	(	tablename	,	props	)	:	

prers	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	tablename	,	prers	)	
conn	=	dbpool	.	connection	(	write	=	True	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	,	traceback	.	format_exc	(	)	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	bool	(	count	)	

def	InsertIntoDBAndReturnID	(	tablename	,	data	)	:	

sql	=	forEachPlusInsertProps	(	tablename	,	data	)	
conn	=	dbpool	.	connection	(	write	=	True	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
cursor	.	execute	(	"str"	)	
result	=	cursor	.	fetchall	(	)	[	0	]	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	InsertIntoDB	(	tablename	,	data	)	:	

sql	=	forEachPlusInsertProps	(	tablename	,	data	)	
conn	=	dbpool	.	connection	(	write	=	True	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	bool	(	count	)	

def	UpdateWithDictSQL	(	tablename	,	props	,	prere	)	:	

return	forEachUpdateProps	(	tablename	,	props	,	prere	)	

def	UpdateWithDict	(	tablename	,	props	,	prere	)	:	

sql	=	forEachUpdateProps	(	tablename	,	props	,	prere	)	
conn	=	dbpool	.	connection	(	write	=	True	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	,	traceback	.	format_exc	(	)	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
if	(	count	>	=	1	)	:	
return	True	
return	False	

def	getAllPkByFkInDB	(	tablename	,	pkname	,	props	)	:	

props	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	pkname	,	tablename	,	props	)	
conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	[	key	[	0	]	for	key	in	result	]	

def	GetOneRecordInfo	(	tablename	,	props	)	:	

props	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	tablename	,	props	)	
conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchone	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	GetRecordList	(	tablename	,	pkname	,	pklist	)	:	

pkliststr	=	"str"	
for	pkid	in	pklist	:	
pkliststr	+	=	"str"	%	pkid	
pkliststr	=	"str"	%	pkliststr	[	:	-	1	]	
sql	=	"str"	%	(	tablename	,	pkname	,	pkliststr	)	
conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	excuteSQL	(	tablename	,	sql	)	:	
conn	=	dbpool	.	connection	(	write	=	True	,	tablename	=	tablename	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	,	traceback	.	format_exc	(	)	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
if	(	count	>	=	1	)	:	
return	True	
return	False	

def	DBTest	(	)	:	
sql	=	"str"	
conn	=	dbpool	.	connection	(	write	=	False	,	tablename	=	"str"	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	getallkeys	(	key	,	mem	)	:	
itemsinfo	=	mem	.	get_stats	(	"str"	)	
itemindex	=	[	]	
for	items	in	itemsinfo	:	
itemindex	+	=	[	_key	.	split	(	"str"	)	[	1	]	for	_key	in	items	[	1	]	.	keys	(	)	]	
s	=	set	(	itemindex	)	
itemss	=	[	mem	.	get_stats	(	"str"	%	i	)	for	i	in	s	]	
allkeys	=	set	(	[	]	)	
for	item	in	itemss	:	
for	_item	in	item	:	
nowlist	=	set	(	[	]	)	
for	_key	in	_item	[	1	]	.	keys	(	)	:	
try	:	
keysplit	=	_key	.	split	(	"str"	)	
pk	=	keysplit	[	2	]	
except	:	
continue	
if	_key	.	startswith	(	key	)	and	not	pk	.	startswith	(	"str"	)	:	
nowlist	.	add	(	pk	)	
allkeys	=	allkeys	.	union	(	nowlist	)	
return	allkeys	

def	getAllPkByFkInMEM	(	key	,	fk	,	mem	)	:	
pass	
	