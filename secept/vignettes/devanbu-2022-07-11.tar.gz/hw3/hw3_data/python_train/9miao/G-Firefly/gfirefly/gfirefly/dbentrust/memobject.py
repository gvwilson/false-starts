

import	memclient	
import	gevent	
import	time	
LOCK_TIMEOUT	=	2	
CACHE_TIMEOUT	=	60	*	60	

class	MEMKeyError	(	Exception	)	:	


def	__str__	(	self	)	:	
return	"str"	

class	MemObject	:	


def	__init__	(	self	,	name	,	*	*	kw	)	:	

self	.	_name	=	name	
self	.	_locked	=	False	
self	.	_timestamp	=	0	
self	.	_cas	=	kw	.	get	(	"str"	,	False	)	
self	.	_cache	=	kw	.	get	(	"str"	,	True	)	
self	.	_timeout	=	kw	.	get	(	"str"	,	CACHE_TIMEOUT	)	
if	self	.	_cas	:	
self	.	lock	(	)	

def	produceKey	(	self	,	keyname	)	:	

if	isinstance	(	keyname	,	basestring	)	:	
return	str	(	"str"	.	join	(	[	self	.	_name	,	"str"	,	keyname	]	)	)	
else	:	
raise	MEMKeyError	(	)	

def	isLocked	(	self	)	:	

tdelta	=	time	.	time	(	)	-	self	.	_timestamp	
if	tdelta	>	=	LOCK_TIMEOUT	:	
self	.	_locked	=	False	
return	self	.	_locked	

def	lock	(	self	)	:	

print	"str"	
if	not	self	.	isLocked	(	)	:	
key	=	self	.	produceKey	(	"str"	)	
result	=	memclient	.	mclient	.	add	(	key	,	1	,	LOCK_TIMEOUT	)	
if	result	:	
self	.	_timestamp	=	time	.	time	(	)	
self	.	_locked	=	result	
return	self	.	_locked	

def	release	(	self	)	:	

if	self	.	isLocked	(	)	:	
print	"str"	
key	=	self	.	produceKey	(	"str"	)	
memclient	.	mclient	.	delete	(	key	)	
self	.	_locked	=	False	

def	get	(	self	,	key	)	:	

if	self	.	_cas	and	not	self	.	isLocked	(	)	:	
for	_	in	xrange	(	10	)	:	
if	not	self	.	lock	(	)	:	
gevent	.	sleep	(	0.2	)	
continue	
break	
else	:	
return	None	
key	=	self	.	produceKey	(	key	)	
return	memclient	.	mclient	.	get	(	key	)	

def	get_multi	(	self	,	keys	)	:	

if	self	.	_cas	and	not	self	.	isLocked	(	)	:	
for	_	in	xrange	(	10	)	:	
if	not	self	.	lock	(	)	:	
gevent	.	sleep	(	0.2	)	
continue	
break	
else	:	
return	None	
keynamelist	=	[	self	.	produceKey	(	keyname	)	for	keyname	in	keys	]	
olddict	=	memclient	.	mclient	.	get_multi	(	keynamelist	)	
newdict	=	dict	(	zip	(	[	keyname	.	split	(	"str"	)	[	-	1	]	for	keyname	in	olddict	.	keys	(	)	]	,	
olddict	.	values	(	)	)	)	
return	newdict	

def	update	(	self	,	key	,	values	)	:	

if	self	.	_cas	and	not	self	.	isLocked	(	)	:	
for	_	in	xrange	(	10	)	:	
if	not	self	.	lock	(	)	:	
gevent	.	sleep	(	0.2	)	
continue	
break	
else	:	
return	None	
key	=	self	.	produceKey	(	key	)	
return	memclient	.	mclient	.	set	(	key	,	values	,	time	=	self	.	_timeout	)	

def	update_multi	(	self	,	mapping	)	:	

if	self	.	_cas	and	not	self	.	isLocked	(	)	:	
for	_	in	xrange	(	10	)	:	
if	not	self	.	lock	(	)	:	
gevent	.	sleep	(	0.2	)	
continue	
break	
else	:	
return	None	
newmapping	=	dict	(	zip	(	[	self	.	produceKey	(	keyname	)	for	keyname	in	mapping	.	keys	(	)	]	,	
mapping	.	values	(	)	)	)	
return	memclient	.	mclient	.	set_multi	(	newmapping	,	time	=	self	.	_timeout	)	

def	mdelete	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
keys	=	[	keyname	for	keyname	in	nowdict	.	keys	(	)	if	not	keyname	.	startswith	(	"str"	)	]	
keys	=	[	self	.	produceKey	(	key	)	for	key	in	keys	]	
memclient	.	mclient	.	delete_multi	(	keys	)	

def	insert	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
newmapping	=	dict	(	[	(	self	.	produceKey	(	keyname	)	,	nowdict	[	keyname	]	)	for	keyname	in	nowdict	.	keys	(	)	if	not	keyname	.	startswith	(	"str"	)	]	)	
memclient	.	mclient	.	set_multi	(	newmapping	,	time	=	self	.	_timeout	)	

def	__del__	(	self	)	:	

try	:	
if	self	.	isLocked	(	)	:	
self	.	release	(	)	
except	Exception	as	e	:	
print	e	


if	__name__	==	"str"	:	

from	memclient	import	memcached_connect	
memcached_connect	(	[	"str"	]	)	
from	memclient	import	mclient	
class	Mcharacter	(	MemObject	)	:	
def	__init__	(	self	,	pid	,	name	,	*	*	kw	)	:	
MemObject	.	__init__	(	self	,	name	,	*	*	kw	)	
self	.	id	=	pid	
self	.	level	=	0	
self	.	profession	=	0	
self	.	nickname	=	"str"	
self	.	guanqia	=	1000000000000000	
mcharacter	=	Mcharacter	(	1	,	"str"	,	cas	=	True	)	
mcharacter	.	nickname	=	"str"	
mcharacter	.	insert	(	)	

_mcharacter	=	Mcharacter	(	1	,	"str"	,	cas	=	True	)	
mcharacter	.	release	(	)	
_mcharacter	.	release	(	)	
print	mcharacter	.	get	(	"str"	)	
mcharacter	.	release	(	)	
print	_mcharacter	.	get	(	"str"	)	
_mcharacter	.	release	(	)	
print	mcharacter	.	get	(	"str"	)	,	type	(	mcharacter	.	get	(	"str"	)	)	
mcharacter	.	release	(	)	
print	_mcharacter	.	get	(	"str"	)	,	type	(	_mcharacter	.	get	(	"str"	)	)	

	