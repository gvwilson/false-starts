

from	gfirefly	.	utils	import	services	
from	gfirefly	.	distributed	.	root	import	PBRoot	,	BilateralFactory	
from	gtwisted	.	core	import	reactor	
from	gtwisted	.	utils	import	log	
import	sys	
reactor	=	reactor	
log	.	startLogging	(	sys	.	stdout	)	

root	=	PBRoot	(	)	
ser	=	services	.	Service	(	"str"	)	
root	.	addServiceChannel	(	ser	)	


def	serviceHandle	(	target	)	:	

ser	.	mapTarget	(	target	)	

@serviceHandle	
def	printData1	(	data	,	data1	)	:	
print	data	,	data1	
print	"str"	
d	=	root	.	callChild	(	"str"	,	1	,	"str"	)	
return	data	

@serviceHandle	
def	printData2	(	data	,	data1	)	:	
print	data	,	data1	
print	"str"	
d	=	root	.	callChild	(	"str"	,	1	,	"str"	)	
return	data	

if	__name__	==	"str"	:	
reactor	.	listenTCP	(	9090	,	BilateralFactory	(	root	)	)	
reactor	.	run	(	)	
	