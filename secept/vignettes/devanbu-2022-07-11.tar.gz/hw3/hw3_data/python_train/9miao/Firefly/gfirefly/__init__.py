VERSION	=	(	0	,	1	,	5	,	"str"	,	0	)	

def	get_version	(	*	args	,	*	*	kwargs	)	:	

from	gfirefly	.	utils	.	version	import	get_version	
return	get_version	(	*	args	,	*	*	kwargs	)	
	