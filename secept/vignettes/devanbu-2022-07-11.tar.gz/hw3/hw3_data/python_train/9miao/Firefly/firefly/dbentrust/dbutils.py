

import	itertools	
import	datetime	


def	safeunicode	(	obj	,	encoding	=	"str"	)	:	

t	=	type	(	obj	)	
if	t	is	unicode	:	
return	obj	
elif	t	is	str	:	
return	obj	.	decode	(	encoding	)	
elif	t	in	[	int	,	float	,	bool	]	:	
return	unicode	(	obj	)	
elif	hasattr	(	obj	,	"str"	)	or	isinstance	(	obj	,	unicode	)	:	
return	unicode	(	obj	)	
else	:	
return	str	(	obj	)	.	decode	(	encoding	)	

def	safestr	(	obj	,	encoding	=	"str"	)	:	

if	isinstance	(	obj	,	unicode	)	:	
return	obj	.	encode	(	encoding	)	
elif	isinstance	(	obj	,	str	)	:	
return	obj	
elif	hasattr	(	obj	,	"str"	)	:	
return	itertools	.	imap	(	safestr	,	obj	)	
else	:	
return	str	(	obj	)	

def	sqlify	(	obj	)	:	




if	obj	is	None	:	
return	"str"	
elif	obj	is	True	:	
return	"str"	
elif	obj	is	False	:	
return	"str"	
elif	datetime	and	isinstance	(	obj	,	datetime	.	datetime	)	:	
return	repr	(	obj	.	isoformat	(	)	)	
else	:	
if	isinstance	(	obj	,	unicode	)	:	obj	=	obj	.	encode	(	"str"	)	
return	repr	(	obj	)	

def	sqllist	(	lst	)	:	

if	isinstance	(	lst	,	basestring	)	:	
return	lst	
else	:	
return	"str"	.	join	(	lst	)	

def	_sqllist	(	values	)	:	

items	=	[	]	
items	.	append	(	"str"	)	
for	i	,	v	in	enumerate	(	values	)	:	
if	i	!=	0	:	
items	.	append	(	"str"	)	
items	.	append	(	sqlparam	(	v	)	)	
items	.	append	(	"str"	)	
return	SQLQuery	(	items	)	

def	sqlquote	(	a	)	:	

if	isinstance	(	a	,	list	)	:	
return	_sqllist	(	a	)	
else	:	
return	sqlparam	(	a	)	.	sqlquery	(	)	

def	_interpolate	(	sformat	)	:	

from	tokenize	import	tokenprog	

tokenprog	=	tokenprog	

def	matchorfail	(	text	,	pos	)	:	
match	=	tokenprog	.	match	(	text	,	pos	)	
if	match	is	None	:	
raise	_ItplError	(	text	,	pos	)	
return	match	,	match	.	end	(	)	

namechars	=	"str"	"str"	;	
chunks	=	[	]	
pos	=	0	

while	1	:	
dollar	=	sformat	.	find	(	"str"	,	pos	)	
if	dollar	<	0	:	
break	
nextchar	=	sformat	[	dollar	+	1	]	

if	nextchar	==	"str"	:	
chunks	.	append	(	(	0	,	sformat	[	pos	:	dollar	]	)	)	
pos	,	level	=	dollar	+	2	,	1	
while	level	:	
match	,	pos	=	matchorfail	(	sformat	,	pos	)	
tstart	,	tend	=	match	.	regs	[	3	]	
token	=	sformat	[	tstart	:	tend	]	
if	token	==	"str"	:	
level	=	level	+	1	
elif	token	==	"str"	:	
level	=	level	-	1	
chunks	.	append	(	(	1	,	sformat	[	dollar	+	2	:	pos	-	1	]	)	)	

elif	nextchar	in	namechars	:	
chunks	.	append	(	(	0	,	sformat	[	pos	:	dollar	]	)	)	
match	,	pos	=	matchorfail	(	sformat	,	dollar	+	1	)	
while	pos	<	len	(	sformat	)	:	
if	sformat	[	pos	]	==	"str"	and	pos	+	1	<	len	(	sformat	)	and	sformat	[	pos	+	1	]	in	namechars	:	
match	,	pos	=	matchorfail	(	sformat	,	pos	+	1	)	
elif	sformat	[	pos	]	in	"str"	:	
pos	,	level	=	pos	+	1	,	1	
while	level	:	
match	,	pos	=	matchorfail	(	sformat	,	pos	)	
tstart	,	tend	=	match	.	regs	[	3	]	
token	=	sformat	[	tstart	:	tend	]	
if	token	[	0	]	in	"str"	:	
level	=	level	+	1	
elif	token	[	0	]	in	"str"	:	
level	=	level	-	1	
else	:	
break	
chunks	.	append	(	(	1	,	sformat	[	dollar	+	1	:	pos	]	)	)	
else	:	
chunks	.	append	(	(	0	,	sformat	[	pos	:	dollar	+	1	]	)	)	
pos	=	dollar	+	1	+	(	nextchar	==	"str"	)	

if	pos	<	len	(	sformat	)	:	
chunks	.	append	(	(	0	,	sformat	[	pos	:	]	)	)	
return	chunks	

def	sqlwhere	(	dictionary	,	grouping	=	"str"	)	:	

return	SQLQuery	.	join	(	[	k	+	"str"	+	sqlparam	(	v	)	for	k	,	v	in	dictionary	.	items	(	)	]	,	grouping	)	

def	reparam	(	string_	,	dictionary	)	:	

dictionary	=	dictionary	.	copy	(	)	
result	=	[	]	
for	live	,	chunk	in	_interpolate	(	string_	)	:	
if	live	:	
v	=	eval	(	chunk	,	dictionary	)	
result	.	append	(	sqlquote	(	v	)	)	
else	:	
result	.	append	(	chunk	)	
return	SQLQuery	.	join	(	result	,	"str"	)	

class	UnknownParamstyle	(	Exception	)	:	

pass	

class	_ItplError	(	ValueError	)	:	
def	__init__	(	self	,	text	,	pos	)	:	
ValueError	.	__init__	(	self	)	
self	.	text	=	text	
self	.	pos	=	pos	
def	__str__	(	self	)	:	
return	"str"	%	(	
repr	(	self	.	text	)	,	self	.	pos	)	

class	SQLParam	(	object	)	:	

__slots__	=	[	"str"	]	

def	__init__	(	self	,	value	)	:	
self	.	value	=	value	

def	get_marker	(	self	,	paramstyle	=	"str"	)	:	
if	paramstyle	==	"str"	:	
return	"str"	
elif	paramstyle	==	"str"	:	
return	"str"	
elif	paramstyle	is	None	or	paramstyle	in	[	"str"	,	"str"	]	:	
return	"str"	
raise	UnknownParamstyle	,	paramstyle	

def	sqlquery	(	self	)	:	
return	SQLQuery	(	[	self	]	)	

def	__add__	(	self	,	other	)	:	
return	self	.	sqlquery	(	)	+	other	

def	__radd__	(	self	,	other	)	:	
return	other	+	self	.	sqlquery	(	)	

def	__str__	(	self	)	:	
return	str	(	self	.	value	)	

def	__repr__	(	self	)	:	
return	"str"	%	repr	(	self	.	value	)	

sqlparam	=	SQLParam	

class	SQLQuery	(	object	)	:	

__slots__	=	[	"str"	]	


def	__init__	(	self	,	items	=	None	)	:	

if	items	is	None	:	
self	.	items	=	[	]	
elif	isinstance	(	items	,	list	)	:	
self	.	items	=	items	
elif	isinstance	(	items	,	SQLParam	)	:	
self	.	items	=	[	items	]	
elif	isinstance	(	items	,	SQLQuery	)	:	
self	.	items	=	list	(	items	.	items	)	
else	:	
self	.	items	=	[	items	]	


for	i	,	item	in	enumerate	(	self	.	items	)	:	
if	isinstance	(	item	,	SQLParam	)	and	isinstance	(	item	.	value	,	SQLLiteral	)	:	
self	.	items	[	i	]	=	item	.	value	.	v	

def	append	(	self	,	value	)	:	
self	.	items	.	append	(	value	)	

def	__add__	(	self	,	other	)	:	
if	isinstance	(	other	,	basestring	)	:	
items	=	[	other	]	
elif	isinstance	(	other	,	SQLQuery	)	:	
items	=	other	.	items	
else	:	
return	NotImplemented	
return	SQLQuery	(	self	.	items	+	items	)	

def	__radd__	(	self	,	other	)	:	
if	isinstance	(	other	,	basestring	)	:	
items	=	[	other	]	
else	:	
return	NotImplemented	

return	SQLQuery	(	items	+	self	.	items	)	

def	__iadd__	(	self	,	other	)	:	
if	isinstance	(	other	,	(	basestring	,	SQLParam	)	)	:	
self	.	items	.	append	(	other	)	
elif	isinstance	(	other	,	SQLQuery	)	:	
self	.	items	.	extend	(	other	.	items	)	
else	:	
return	NotImplemented	
return	self	

def	__len__	(	self	)	:	
return	len	(	self	.	query	(	)	)	

def	query	(	self	,	paramstyle	=	None	)	:	

s	=	[	]	
for	x	in	self	.	items	:	
if	isinstance	(	x	,	SQLParam	)	:	
x	=	x	.	get_marker	(	paramstyle	)	
s	.	append	(	safestr	(	x	)	)	
else	:	
x	=	safestr	(	x	)	


if	paramstyle	in	[	"str"	,	"str"	]	:	
if	"str"	in	x	and	"str"	not	in	x	:	
x	=	x	.	replace	(	"str"	,	"str"	)	
s	.	append	(	x	)	
return	"str"	.	join	(	s	)	

def	values	(	self	)	:	

return	[	i	.	value	for	i	in	self	.	items	if	isinstance	(	i	,	SQLParam	)	]	

def	join	(	items	,	sep	=	"str"	,	prefix	=	None	,	suffix	=	None	,	target	=	None	)	:	

if	target	is	None	:	
target	=	SQLQuery	(	)	

target_items	=	target	.	items	

if	prefix	:	
target_items	.	append	(	prefix	)	

for	i	,	item	in	enumerate	(	items	)	:	
if	i	!=	0	:	
target_items	.	append	(	sep	)	
if	isinstance	(	item	,	SQLQuery	)	:	
target_items	.	extend	(	item	.	items	)	
else	:	
target_items	.	append	(	item	)	

if	suffix	:	
target_items	.	append	(	suffix	)	
return	target	

join	=	staticmethod	(	join	)	

def	_str	(	self	)	:	
try	:	
return	self	.	query	(	)	%	tuple	(	[	sqlify	(	x	)	for	x	in	self	.	values	(	)	]	)	
except	(	ValueError	,	TypeError	)	:	
return	self	.	query	(	)	

def	__str__	(	self	)	:	
return	safestr	(	self	.	_str	(	)	)	

def	__unicode__	(	self	)	:	
return	safeunicode	(	self	.	_str	(	)	)	

def	__repr__	(	self	)	:	
return	"str"	%	repr	(	str	(	self	)	)	

class	SQLLiteral	:	

def	__init__	(	self	,	v	)	:	
self	.	v	=	v	

def	__repr__	(	self	)	:	
return	self	.	v	

class	SQLProducer	:	

def	__init__	(	self	)	:	

pass	

def	query	(	self	,	sql_query	,	processed	=	False	,	svars	=	None	)	:	

if	svars	is	None	:	
svars	=	{	}	

if	not	processed	and	not	isinstance	(	sql_query	,	SQLQuery	)	:	
sql_query	=	reparam	(	sql_query	,	svars	)	

return	sql_query	

def	sql_clauses	(	self	,	what	,	tables	,	where	,	group	,	order	,	limit	,	offset	)	:	
return	(	
(	"str"	,	what	)	,	
(	"str"	,	sqllist	(	tables	)	)	,	
(	"str"	,	where	)	,	
(	"str"	,	group	)	,	
(	"str"	,	order	)	,	
(	"str"	,	limit	)	,	
(	"str"	,	offset	)	)	

def	gen_clause	(	self	,	sql	,	val	,	svars	)	:	
if	isinstance	(	val	,	(	int	,	long	)	)	:	
if	sql	==	"str"	:	
nout	=	"str"	+	sqlquote	(	val	)	
else	:	
nout	=	SQLQuery	(	val	)	

elif	isinstance	(	val	,	(	list	,	tuple	)	)	and	len	(	val	)	==	2	:	
nout	=	SQLQuery	(	val	[	0	]	,	val	[	1	]	)	
elif	isinstance	(	val	,	SQLQuery	)	:	
nout	=	val	
else	:	
nout	=	reparam	(	val	,	svars	)	

def	xjoin	(	a	,	b	)	:	
if	a	and	b	:	return	a	+	"str"	+	b	
else	:	return	a	or	b	

return	xjoin	(	sql	,	nout	)	

def	_where	(	self	,	where	,	svars	)	:	
if	isinstance	(	where	,	(	int	,	long	)	)	:	
where	=	"str"	+	sqlparam	(	where	)	
elif	isinstance	(	where	,	(	list	,	tuple	)	)	and	len	(	where	)	==	2	:	
where	=	SQLQuery	(	where	[	0	]	,	where	[	1	]	)	
elif	isinstance	(	where	,	SQLQuery	)	:	
pass	
else	:	
where	=	reparam	(	where	,	svars	)	
return	where	

def	select	(	self	,	tables	,	svars	=	None	,	what	=	"str"	,	where	=	None	,	order	=	None	,	group	=	None	,	
limit	=	None	,	offset	=	None	,	_test	=	False	)	:	

if	svars	is	None	:	svars	=	{	}	
sql_clauses	=	self	.	sql_clauses	(	what	,	tables	,	where	,	group	,	order	,	limit	,	offset	)	
clauses	=	[	self	.	gen_clause	(	sql	,	val	,	svars	)	for	sql	,	val	in	sql_clauses	if	val	is	not	None	]	
qout	=	SQLQuery	.	join	(	clauses	)	
if	_test	:	return	qout	
return	self	.	query	(	qout	,	processed	=	True	)	

def	insert	(	self	,	tablename	,	seqname	=	None	,	_test	=	False	,	*	*	values	)	:	

def	q	(	x	)	:	return	"str"	+	x	+	"str"	

if	values	:	
_keys	=	SQLQuery	.	join	(	values	.	keys	(	)	,	"str"	)	
_values	=	SQLQuery	.	join	(	[	sqlparam	(	v	)	for	v	in	values	.	values	(	)	]	,	"str"	)	
sql_query	=	"str"	%	tablename	+	q	(	_keys	)	+	"str"	+	q	(	_values	)	
else	:	
sql_query	=	SQLQuery	(	self	.	_get_insert_default_values_query	(	tablename	)	)	

return	sql_query	

def	_get_insert_default_values_query	(	self	,	table	)	:	
return	"str"	%	table	

def	multiple_insert	(	self	,	tablename	,	values	,	seqname	=	None	,	_test	=	False	)	:	

if	not	values	:	
return	[	]	

if	not	self	.	supports_multiple_insert	:	
out	=	[	self	.	insert	(	tablename	,	seqname	=	seqname	,	_test	=	_test	,	*	*	v	)	for	v	in	values	]	
if	seqname	is	False	:	
return	None	
else	:	
return	out	

keys	=	values	[	0	]	.	keys	(	)	



for	v	in	values	:	
if	v	.	keys	(	)	!=	keys	:	
raise	ValueError	,	"str"	

sql_query	=	SQLQuery	(	"str"	%	(	tablename	,	"str"	.	join	(	keys	)	)	)	

for	i	,	row	in	enumerate	(	values	)	:	
if	i	!=	0	:	
sql_query	.	append	(	"str"	)	
SQLQuery	.	join	(	[	SQLParam	(	row	[	k	]	)	for	k	in	keys	]	,	sep	=	"str"	,	target	=	sql_query	,	prefix	=	"str"	,	suffix	=	"str"	)	

if	_test	:	return	sql_query	

db_cursor	=	self	.	_db_cursor	(	)	
if	seqname	is	not	False	:	
sql_query	=	self	.	_process_insert_query	(	sql_query	,	tablename	,	seqname	)	

if	isinstance	(	sql_query	,	tuple	)	:	


q1	,	q2	=	sql_query	
self	.	_db_execute	(	db_cursor	,	q1	)	
self	.	_db_execute	(	db_cursor	,	q2	)	
else	:	
self	.	_db_execute	(	db_cursor	,	sql_query	)	

try	:	
out	=	db_cursor	.	fetchone	(	)	[	0	]	
out	=	range	(	out	-	len	(	values	)	+	1	,	out	+	1	)	
except	Exception	:	
out	=	None	

if	not	self	.	ctx	.	transactions	:	
self	.	ctx	.	commit	(	)	
return	out	


def	update	(	self	,	tables	,	where	,	svars	=	None	,	_test	=	False	,	*	*	values	)	:	

if	svars	is	None	:	svars	=	{	}	
where	=	self	.	_where	(	where	,	svars	)	

query	=	(	
"str"	+	sqllist	(	tables	)	+	
"str"	+	sqlwhere	(	values	,	"str"	)	+	
"str"	+	where	)	

if	_test	:	return	query	

db_cursor	=	self	.	_db_cursor	(	)	
self	.	_db_execute	(	db_cursor	,	query	)	
if	not	self	.	ctx	.	transactions	:	
self	.	ctx	.	commit	(	)	
return	db_cursor	.	rowcount	

def	delete	(	self	,	table	,	where	,	using	=	None	,	svars	=	None	,	_test	=	False	)	:	

if	svars	is	None	:	
svars	=	{	}	
where	=	self	.	_where	(	where	,	svars	)	

q	=	"str"	+	table	
if	using	:	
q	+	=	"str"	+	sqllist	(	using	)	
if	where	:	
q	+	=	"str"	+	where	

return	q	

sqlproducer	=	SQLProducer	(	)	


print	sqlproducer	.	delete	(	"str"	,	where	=	"str"	)	

	