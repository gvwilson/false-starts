

from	twisted	.	spread	import	pb	
from	twisted	.	internet	import	reactor	
reactor	=	reactor	
from	reference	import	ProxyReference	

def	callRemote	(	obj	,	funcName	,	*	args	,	*	*	kw	)	:	

return	obj	.	callRemote	(	funcName	,	*	args	,	*	*	kw	)	


class	RemoteObject	(	object	)	:	


def	__init__	(	self	,	name	)	:	

self	.	_name	=	name	
self	.	_factory	=	pb	.	PBClientFactory	(	)	
self	.	_reference	=	ProxyReference	(	)	
self	.	_addr	=	None	

def	setName	(	self	,	name	)	:	

self	.	_name	=	name	

def	getName	(	self	)	:	

return	self	.	_name	

def	connect	(	self	,	addr	)	:	

self	.	_addr	=	addr	
reactor	.	connectTCP	(	addr	[	0	]	,	addr	[	1	]	,	self	.	_factory	)	
self	.	takeProxy	(	)	

def	reconnect	(	self	)	:	

self	.	connect	(	self	.	_addr	)	

def	addServiceChannel	(	self	,	service	)	:	

self	.	_reference	.	addService	(	service	)	

def	takeProxy	(	self	)	:	

deferedRemote	=	self	.	_factory	.	getRootObject	(	)	
deferedRemote	.	addCallback	(	callRemote	,	"str"	,	self	.	_name	,	self	.	_reference	)	

def	callRemote	(	self	,	commandId	,	*	args	,	*	*	kw	)	:	

deferedRemote	=	self	.	_factory	.	getRootObject	(	)	
return	deferedRemote	.	addCallback	(	callRemote	,	"str"	,	commandId	,	*	args	,	*	*	kw	)	




	