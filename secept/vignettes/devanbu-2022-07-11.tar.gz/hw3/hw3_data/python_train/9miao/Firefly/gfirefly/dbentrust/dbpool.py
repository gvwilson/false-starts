

from	DBUtils	.	PooledDB	import	PooledDB	
import	MySQLdb	

DBCS	=	{	"str"	:	MySQLdb	,	}	

class	DBPool	(	object	)	:	


def	initPool	(	self	,	*	*	kw	)	:	

self	.	config	=	kw	
creator	=	DBCS	.	get	(	kw	.	get	(	"str"	,	"str"	)	,	MySQLdb	)	
self	.	pool	=	PooledDB	(	creator	,	5	,	*	*	kw	)	

def	connection	(	self	)	:	
return	self	.	pool	.	connection	(	)	


dbpool	=	DBPool	(	)	
	