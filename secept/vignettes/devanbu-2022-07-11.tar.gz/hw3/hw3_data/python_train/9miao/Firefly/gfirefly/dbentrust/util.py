


from	dbpool	import	dbpool	
from	MySQLdb	.	cursors	import	DictCursor	
from	numbers	import	Number	
from	gtwisted	.	utils	import	log	


def	forEachPlusInsertProps	(	tablename	,	props	)	:	
assert	type	(	props	)	==	dict	
pkeysstr	=	str	(	tuple	(	props	.	keys	(	)	)	)	.	replace	(	"str"	,	"str"	)	
pvaluesstr	=	[	"str"	%	val	if	isinstance	(	val	,	Number	)	else	
"str"	%	str	(	val	)	.	replace	(	"str"	,	"str"	)	for	val	in	props	.	values	(	)	]	
pvaluesstr	=	"str"	.	join	(	pvaluesstr	)	[	:	-	1	]	
sqlstr	=	"str"	%	(	tablename	,	pkeysstr	,	pvaluesstr	)	
return	sqlstr	

def	FormatCondition	(	props	)	:	

items	=	props	.	items	(	)	
itemstrlist	=	[	]	
for	_item	in	items	:	
if	isinstance	(	_item	[	1	]	,	Number	)	:	
sqlstr	=	"str"	%	_item	
else	:	
sqlstr	=	"str"	%	(	_item	[	0	]	,	str	(	_item	[	1	]	)	.	replace	(	"str"	,	"str"	)	)	
itemstrlist	.	append	(	sqlstr	)	
sqlstr	=	"str"	.	join	(	itemstrlist	)	
return	sqlstr	[	:	-	4	]	

def	FormatUpdateStr	(	props	)	:	

items	=	props	.	items	(	)	
itemstrlist	=	[	]	
for	_item	in	items	:	
if	isinstance	(	_item	[	1	]	,	Number	)	:	
sqlstr	=	"str"	%	_item	
else	:	
sqlstr	=	"str"	%	(	_item	[	0	]	,	str	(	_item	[	1	]	)	.	replace	(	"str"	,	"str"	)	)	
itemstrlist	.	append	(	sqlstr	)	
sqlstr	=	"str"	.	join	(	itemstrlist	)	
return	sqlstr	[	:	-	1	]	

def	forEachUpdateProps	(	tablename	,	props	,	prere	)	:	

assert	type	(	props	)	==	dict	
pro	=	FormatUpdateStr	(	props	)	
pre	=	FormatCondition	(	prere	)	
sqlstr	=	"str"	%	(	tablename	,	pro	,	pre	)	
return	sqlstr	

def	EachQueryProps	(	props	)	:	

sqlstr	=	"str"	
if	props	==	"str"	:	
return	"str"	
elif	type	(	props	)	==	type	(	[	0	]	)	:	
for	prop	in	props	:	
sqlstr	=	sqlstr	+	prop	+	"str"	
sqlstr	=	sqlstr	[	:	-	1	]	
return	sqlstr	
else	:	
raise	Exception	(	"str"	)	
return	

def	forEachQueryProps	(	sqlstr	,	props	)	:	

if	props	==	"str"	:	
sqlstr	+	=	"str"	
elif	type	(	props	)	==	type	(	[	0	]	)	:	
i	=	0	
for	prop	in	props	:	
if	(	i	==	0	)	:	
sqlstr	+	=	"str"	+	prop	
else	:	
sqlstr	+	=	"str"	+	prop	
i	+	=	1	
else	:	
raise	Exception	(	"str"	)	
return	
return	sqlstr	

def	GetTableIncrValue	(	tablename	)	:	

database	=	dbpool	.	config	.	get	(	"str"	)	
sql	=	"str"	%	(	database	,	tablename	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchone	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
if	result	:	
return	result	[	0	]	
return	result	

def	ReadDataFromDB	(	tablename	)	:	

sql	=	"str"	%	tablename	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	DeleteFromDB	(	tablename	,	props	)	:	

prers	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	tablename	,	prers	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	bool	(	count	)	

def	InsertIntoDB	(	tablename	,	data	)	:	

sql	=	forEachPlusInsertProps	(	tablename	,	data	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	bool	(	count	)	

def	UpdateWithDict	(	tablename	,	props	,	prere	)	:	

sql	=	forEachUpdateProps	(	tablename	,	props	,	prere	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	)	
count	=	0	
try	:	
count	=	cursor	.	execute	(	sql	)	
conn	.	commit	(	)	
except	Exception	,	e	:	
log	.	err	(	e	)	
log	.	err	(	sql	)	
cursor	.	close	(	)	
conn	.	close	(	)	
if	(	count	>	=	1	)	:	
return	True	
return	False	

def	getAllPkByFkInDB	(	tablename	,	pkname	,	props	)	:	

props	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	pkname	,	tablename	,	props	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	[	key	[	0	]	for	key	in	result	]	

def	GetOneRecordInfo	(	tablename	,	props	)	:	

props	=	FormatCondition	(	props	)	
sql	=	"str"	%	(	tablename	,	props	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchone	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	GetRecordList	(	tablename	,	pkname	,	pklist	)	:	

pkliststr	=	"str"	
for	pkid	in	pklist	:	
pkliststr	+	=	"str"	%	pkid	
pkliststr	=	"str"	%	pkliststr	[	:	-	1	]	
sql	=	"str"	%	(	tablename	,	pkname	,	pkliststr	)	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	DBTest	(	)	:	
sql	=	"str"	
conn	=	dbpool	.	connection	(	)	
cursor	=	conn	.	cursor	(	cursorclass	=	DictCursor	)	
cursor	.	execute	(	sql	)	
result	=	cursor	.	fetchall	(	)	
cursor	.	close	(	)	
conn	.	close	(	)	
return	result	

def	getallkeys	(	key	,	mem	)	:	
itemsinfo	=	mem	.	get_stats	(	"str"	)	
itemindex	=	[	]	
for	items	in	itemsinfo	:	
itemindex	+	=	[	_key	.	split	(	"str"	)	[	1	]	for	_key	in	items	[	1	]	.	keys	(	)	]	
s	=	set	(	itemindex	)	
itemss	=	[	mem	.	get_stats	(	"str"	%	i	)	for	i	in	s	]	
allkeys	=	set	(	[	]	)	
for	item	in	itemss	:	
for	_item	in	item	:	
nowlist	=	set	(	[	]	)	
for	_key	in	_item	[	1	]	.	keys	(	)	:	
try	:	
keysplit	=	_key	.	split	(	"str"	)	
pk	=	keysplit	[	2	]	
except	:	
continue	
if	_key	.	startswith	(	key	)	and	not	pk	.	startswith	(	"str"	)	:	
nowlist	.	add	(	pk	)	
allkeys	=	allkeys	.	union	(	nowlist	)	
return	allkeys	

def	getAllPkByFkInMEM	(	key	,	fk	,	mem	)	:	

pass	
	