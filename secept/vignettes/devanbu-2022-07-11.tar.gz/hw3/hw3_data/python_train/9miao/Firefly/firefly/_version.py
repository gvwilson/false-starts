


from	twisted	.	python	import	versions	
version	=	versions	.	Version	(	"str"	,	1	,	3	,	3	)	
	