


class	Connection	:	

def	__init__	(	self	,	_conn	)	:	

self	.	id	=	_conn	.	transport	.	sessionno	
self	.	instance	=	_conn	

def	loseConnection	(	self	)	:	

self	.	instance	.	transport	.	loseConnection	(	)	

def	safeToWriteData	(	self	,	topicID	,	msg	)	:	

self	.	instance	.	safeToWriteData	(	msg	,	topicID	)	


	