

from	twisted	.	internet	import	protocol	,	reactor	
from	twisted	.	python	import	log	
from	manager	import	ConnectionManager	
from	datapack	import	DataPackProtoc	
reactor	=	reactor	

def	DefferedErrorHandle	(	e	)	:	

log	.	err	(	str	(	e	)	)	
return	

class	LiberateProtocol	(	protocol	.	Protocol	)	:	


buff	=	"str"	

def	connectionMade	(	self	)	:	

log	.	msg	(	"str"	%	(	self	.	transport	.	sessionno	,	self	.	transport	.	client	[	0	]	,	self	.	transport	.	client	[	1	]	)	)	
self	.	factory	.	connmanager	.	addConnection	(	self	)	
self	.	factory	.	doConnectionMade	(	self	)	
self	.	datahandler	=	self	.	dataHandleCoroutine	(	)	
self	.	datahandler	.	next	(	)	

def	connectionLost	(	self	,	reason	)	:	

log	.	msg	(	"str"	%	(	self	.	transport	.	sessionno	)	)	
self	.	factory	.	doConnectionLost	(	self	)	
self	.	factory	.	connmanager	.	dropConnectionByID	(	self	.	transport	.	sessionno	)	

def	safeToWriteData	(	self	,	data	,	command	)	:	

if	not	self	.	transport	.	connected	or	data	is	None	:	
return	
senddata	=	self	.	factory	.	produceResult	(	data	,	command	)	
reactor	.	callFromThread	(	self	.	transport	.	write	,	senddata	)	

def	dataHandleCoroutine	(	self	)	:	

length	=	self	.	factory	.	dataprotocl	.	getHeadlength	(	)	
while	True	:	
data	=	yield	
self	.	buff	+	=	data	
while	self	.	buff	.	__len__	(	)	>	=	length	:	
unpackdata	=	self	.	factory	.	dataprotocl	.	unpack	(	self	.	buff	[	:	length	]	)	
if	not	unpackdata	.	get	(	"str"	)	:	
log	.	msg	(	"str"	)	
self	.	transport	.	loseConnection	(	)	
break	
command	=	unpackdata	.	get	(	"str"	)	
rlength	=	unpackdata	.	get	(	"str"	)	
request	=	self	.	buff	[	length	:	length	+	rlength	]	
if	request	.	__len__	(	)	<	rlength	:	
log	.	msg	(	"str"	)	
break	
self	.	buff	=	self	.	buff	[	length	+	rlength	:	]	
d	=	self	.	factory	.	doDataReceived	(	self	,	command	,	request	)	
if	not	d	:	
continue	
d	.	addCallback	(	self	.	safeToWriteData	,	command	)	
d	.	addErrback	(	DefferedErrorHandle	)	



def	dataReceived	(	self	,	data	)	:	

self	.	datahandler	.	send	(	data	)	

class	LiberateFactory	(	protocol	.	ServerFactory	)	:	


protocol	=	LiberateProtocol	

def	__init__	(	self	,	dataprotocl	=	DataPackProtoc	(	)	)	:	

self	.	service	=	None	
self	.	connmanager	=	ConnectionManager	(	)	
self	.	dataprotocl	=	dataprotocl	

def	setDataProtocl	(	self	,	dataprotocl	)	:	

self	.	dataprotocl	=	dataprotocl	

def	doConnectionMade	(	self	,	conn	)	:	

pass	

def	doConnectionLost	(	self	,	conn	)	:	

pass	

def	addServiceChannel	(	self	,	service	)	:	

self	.	service	=	service	

def	doDataReceived	(	self	,	conn	,	commandID	,	data	)	:	

defer_tool	=	self	.	service	.	callTarget	(	commandID	,	conn	,	data	)	
return	defer_tool	

def	produceResult	(	self	,	command	,	response	)	:	

return	self	.	dataprotocl	.	pack	(	command	,	response	)	

def	loseConnection	(	self	,	connID	)	:	

self	.	connmanager	.	loseConnection	(	connID	)	

def	pushObject	(	self	,	topicID	,	msg	,	sendList	)	:	

self	.	connmanager	.	pushObject	(	topicID	,	msg	,	sendList	)	
	