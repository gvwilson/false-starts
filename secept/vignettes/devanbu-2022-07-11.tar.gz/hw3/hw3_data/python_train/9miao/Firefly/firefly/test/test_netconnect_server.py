

import	sys	,	os	

if	os	.	name	!=	"str"	:	
from	twisted	.	internet	import	epollreactor	
epollreactor	.	install	(	)	

from	twisted	.	internet	import	reactor	
from	twisted	.	python	import	log	
from	firefly	.	utils	import	services	
from	firefly	.	netconnect	.	protoc	import	LiberateFactory	

reactor	=	reactor	
service	=	services	.	CommandService	(	"str"	,	runstyle	=	services	.	Service	.	PARALLEL_STYLE	)	

def	serviceHandle	(	target	)	:	

service	.	mapTarget	(	target	)	

factory	=	LiberateFactory	(	)	

def	doConnectionLost	(	conn	)	:	
print	conn	.	transport	

factory	.	doConnectionLost	=	doConnectionLost	

def	serverstart	(	)	:	

log	.	startLogging	(	sys	.	stdout	)	
factory	.	addServiceChannel	(	service	)	
reactor	.	callLater	(	10	,	factory	.	pushObject	,	111	,	"str"	,	[	0	]	)	
reactor	.	callLater	(	15	,	factory	.	loseConnection	,	0	)	
reactor	.	listenTCP	(	1000	,	factory	)	
reactor	.	run	(	)	

@serviceHandle	
def	echo_1	(	_conn	,	data	)	:	
addr	=	_conn	.	transport	.	client	
print	addr	
return	"str"	

if	__name__	==	"str"	:	

serverstart	(	)	
	