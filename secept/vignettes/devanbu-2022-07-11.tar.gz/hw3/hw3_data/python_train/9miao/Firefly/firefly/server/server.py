

from	firefly	.	netconnect	.	protoc	import	LiberateFactory	
from	twisted	.	web	import	vhost	
from	firefly	.	web	.	delayrequest	import	DelaySite	
from	firefly	.	distributed	.	root	import	PBRoot	,	BilateralFactory	
from	firefly	.	distributed	.	node	import	RemoteObject	
from	firefly	.	dbentrust	.	dbpool	import	dbpool	
from	firefly	.	dbentrust	.	memclient	import	mclient	
from	logobj	import	loogoo	
from	globalobject	import	GlobalObject	
from	twisted	.	python	import	log	
from	twisted	.	internet	import	reactor	
from	firefly	.	utils	import	services	
import	os	,	sys	,	affinity	

reactor	=	reactor	

def	serverStop	(	)	:	
log	.	msg	(	"str"	)	
if	GlobalObject	(	)	.	stophandler	:	
GlobalObject	(	)	.	stophandler	(	)	
reactor	.	callLater	(	0.5	,	reactor	.	stop	)	
return	True	

class	FFServer	:	

def	__init__	(	self	)	:	

self	.	netfactory	=	None	
self	.	root	=	None	
self	.	webroot	=	None	
self	.	remote	=	{	}	
self	.	master_remote	=	None	
self	.	db	=	None	
self	.	mem	=	None	
self	.	servername	=	None	
self	.	remoteportlist	=	[	]	

def	config	(	self	,	config	,	servername	=	None	,	dbconfig	=	None	,	
memconfig	=	None	,	masterconf	=	None	)	:	

GlobalObject	(	)	.	json_config	=	config	
netport	=	config	.	get	(	"str"	)	
webport	=	config	.	get	(	"str"	)	
rootport	=	config	.	get	(	"str"	)	
self	.	remoteportlist	=	config	.	get	(	"str"	,	[	]	)	
if	not	servername	:	
servername	=	config	.	get	(	"str"	)	
logpath	=	config	.	get	(	"str"	)	
hasdb	=	config	.	get	(	"str"	)	
hasmem	=	config	.	get	(	"str"	)	
app	=	config	.	get	(	"str"	)	
cpuid	=	config	.	get	(	"str"	)	
mreload	=	config	.	get	(	"str"	)	
self	.	servername	=	servername	

if	netport	:	
self	.	netfactory	=	LiberateFactory	(	)	
netservice	=	services	.	CommandService	(	"str"	)	
self	.	netfactory	.	addServiceChannel	(	netservice	)	
reactor	.	listenTCP	(	netport	,	self	.	netfactory	)	

if	webport	:	
self	.	webroot	=	vhost	.	NameVirtualHost	(	)	
GlobalObject	(	)	.	webroot	=	self	.	webroot	
reactor	.	listenTCP	(	webport	,	DelaySite	(	self	.	webroot	)	)	

if	rootport	:	
self	.	root	=	PBRoot	(	)	
rootservice	=	services	.	Service	(	"str"	)	
self	.	root	.	addServiceChannel	(	rootservice	)	
reactor	.	listenTCP	(	rootport	,	BilateralFactory	(	self	.	root	)	)	

for	cnf	in	self	.	remoteportlist	:	
rname	=	cnf	.	get	(	"str"	)	
self	.	remote	[	rname	]	=	RemoteObject	(	self	.	servername	)	

if	hasdb	and	dbconfig	:	
log	.	msg	(	str	(	dbconfig	)	)	
dbpool	.	initPool	(	*	*	dbconfig	)	

if	hasmem	and	memconfig	:	
urls	=	memconfig	.	get	(	"str"	)	
hostname	=	str	(	memconfig	.	get	(	"str"	)	)	
mclient	.	connect	(	urls	,	hostname	)	

if	logpath	:	
log	.	addObserver	(	loogoo	(	logpath	)	)	
log	.	startLogging	(	sys	.	stdout	)	

if	cpuid	:	
affinity	.	set_process_affinity_mask	(	os	.	getpid	(	)	,	cpuid	)	
GlobalObject	(	)	.	config	(	netfactory	=	self	.	netfactory	,	root	=	self	.	root	,	
remote	=	self	.	remote	)	
if	app	:	
__import__	(	app	)	
if	mreload	:	
_path_list	=	mreload	.	split	(	"str"	)	
GlobalObject	(	)	.	reloadmodule	=	__import__	(	mreload	,	fromlist	=	_path_list	[	:	1	]	)	
GlobalObject	(	)	.	remote_connect	=	self	.	remote_connect	
if	masterconf	:	
masterport	=	masterconf	.	get	(	"str"	)	
masterhost	=	masterconf	.	get	(	"str"	)	
self	.	master_remote	=	RemoteObject	(	servername	)	
addr	=	(	"str"	,	masterport	)	if	not	masterhost	else	(	masterhost	,	masterport	)	
self	.	master_remote	.	connect	(	addr	)	
GlobalObject	(	)	.	masterremote	=	self	.	master_remote	
import	admin	

def	remote_connect	(	self	,	rname	,	rhost	)	:	

for	cnf	in	self	.	remoteportlist	:	
_rname	=	cnf	.	get	(	"str"	)	
if	rname	==	_rname	:	
rport	=	cnf	.	get	(	"str"	)	
if	not	rhost	:	
addr	=	(	"str"	,	rport	)	
else	:	
addr	=	(	rhost	,	rport	)	
self	.	remote	[	rname	]	.	connect	(	addr	)	
break	

def	start	(	self	)	:	

log	.	msg	(	"str"	%	self	.	servername	)	
log	.	msg	(	"str"	%	(	self	.	servername	,	os	.	getpid	(	)	)	)	
reactor	.	run	(	)	


	