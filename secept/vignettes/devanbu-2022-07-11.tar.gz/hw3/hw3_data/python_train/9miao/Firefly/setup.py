from	setuptools	import	setup	,	find_packages	
import	sys	,	os	

version	=	"str"	

setup	(	name	=	"str"	,	
version	=	version	,	
description	=	"str"	,	
long_description	=	"str"	,	
classifiers	=	[	]	,	
keywords	=	"str"	,	
author	=	"str"	,	
author_email	=	"str"	,	
url	=	"str"	,	
license	=	"str"	,	
packages	=	find_packages	(	exclude	=	[	"str"	,	"str"	,	"str"	]	)	,	
scripts	=	[	"str"	]	,	
include_package_data	=	True	,	
zip_safe	=	False	,	
install_requires	=	[	

"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
]	,	
entry_points	=	"str"	,	
)	
	