

from	memclient	import	mclient	
from	memobject	import	MemObject	
import	util	
import	time	

MMODE_STATE_ORI	=	0	
MMODE_STATE_NEW	=	1	
MMODE_STATE_UPDATE	=	2	
MMODE_STATE_DEL	=	3	



TIMEOUT	=	1800	

def	_insert	(	args	)	:	
record	,	pkname	,	mmname	,	cls	=	args	
pk	=	record	[	pkname	]	
mm	=	cls	(	mmname	+	"str"	%	pk	,	pkname	,	data	=	record	)	
mm	.	insert	(	)	
return	pk	

class	PKValueError	(	ValueError	)	:	

def	__init__	(	self	,	data	)	:	
ValueError	.	__init__	(	self	)	
self	.	data	=	data	
def	__str__	(	self	)	:	
return	"str"	%	(	self	.	data	)	

class	MMode	(	MemObject	)	:	

def	__init__	(	self	,	name	,	pk	,	data	=	{	}	)	:	

MemObject	.	__init__	(	self	,	name	,	mclient	)	
self	.	_state	=	MMODE_STATE_ORI	
self	.	_pk	=	pk	
self	.	data	=	data	
self	.	_time	=	time	.	time	(	)	

def	update	(	self	,	key	,	values	)	:	
data	=	self	.	get_multi	(	[	"str"	,	"str"	]	)	
ntime	=	time	.	time	(	)	
data	[	"str"	]	.	update	(	{	key	:	values	}	)	
if	data	.	get	(	"str"	)	==	MMODE_STATE_NEW	:	
props	=	{	"str"	:	data	.	get	(	"str"	)	,	"str"	:	ntime	}	
else	:	
props	=	{	"str"	:	MMODE_STATE_UPDATE	,	"str"	:	data	.	get	(	"str"	)	,	"str"	:	ntime	}	
return	MemObject	.	update_multi	(	self	,	props	)	

def	update_multi	(	self	,	mapping	)	:	
ntime	=	time	.	time	(	)	
data	=	self	.	get_multi	(	[	"str"	,	"str"	]	)	
data	[	"str"	]	.	update	(	mapping	)	
if	data	.	get	(	"str"	)	==	MMODE_STATE_NEW	:	
props	=	{	"str"	:	data	.	get	(	"str"	)	,	"str"	:	ntime	}	
else	:	
props	=	{	"str"	:	MMODE_STATE_UPDATE	,	"str"	:	data	.	get	(	"str"	)	,	"str"	:	ntime	}	
return	MemObject	.	update_multi	(	self	,	props	)	

def	get	(	self	,	key	)	:	
ntime	=	time	.	time	(	)	
MemObject	.	update	(	self	,	"str"	,	ntime	)	
return	MemObject	.	get	(	self	,	key	)	

def	get_multi	(	self	,	keys	)	:	
ntime	=	time	.	time	(	)	
MemObject	.	update	(	self	,	"str"	,	ntime	)	
return	MemObject	.	get_multi	(	self	,	keys	)	

def	delete	(	self	)	:	

return	MemObject	.	update	(	self	,	"str"	,	MMODE_STATE_DEL	)	

def	mdelete	(	self	)	:	

self	.	syncDB	(	)	
MemObject	.	mdelete	(	self	)	

def	IsEffective	(	self	)	:	

if	self	.	get	(	"str"	)	==	MMODE_STATE_DEL	:	
return	False	
return	True	

def	syncDB	(	self	)	:	

state	=	self	.	get	(	"str"	)	
tablename	=	self	.	_name	.	split	(	"str"	)	[	0	]	
if	state	==	MMODE_STATE_ORI	:	
return	
elif	state	==	MMODE_STATE_NEW	:	
props	=	self	.	get	(	"str"	)	
pk	=	self	.	get	(	"str"	)	
result	=	util	.	InsertIntoDB	(	tablename	,	props	)	
elif	state	==	MMODE_STATE_UPDATE	:	
props	=	self	.	get	(	"str"	)	
pk	=	self	.	get	(	"str"	)	
prere	=	{	pk	:	props	.	get	(	pk	)	}	
util	.	UpdateWithDict	(	tablename	,	props	,	prere	)	
result	=	True	
else	:	
pk	=	self	.	get	(	"str"	)	
props	=	self	.	get	(	"str"	)	
prere	=	{	pk	:	props	.	get	(	pk	)	}	
result	=	util	.	DeleteFromDB	(	tablename	,	prere	)	
if	result	:	
MemObject	.	update	(	self	,	"str"	,	MMODE_STATE_ORI	)	

def	checkSync	(	self	,	timeout	=	TIMEOUT	)	:	

ntime	=	time	.	time	(	)	
objtime	=	MemObject	.	get	(	self	,	"str"	)	
if	ntime	-	objtime	>	=	timeout	and	timeout	:	
self	.	mdelete	(	)	
else	:	
self	.	syncDB	(	)	


class	MFKMode	(	MemObject	)	:	

def	__init__	(	self	,	name	,	pklist	=	[	]	)	:	
MemObject	.	__init__	(	self	,	name	,	mclient	)	
self	.	pklist	=	pklist	

class	MAdmin	(	MemObject	)	:	


def	__init__	(	self	,	name	,	pk	,	timeout	=	TIMEOUT	,	*	*	kw	)	:	
MemObject	.	__init__	(	self	,	name	,	mclient	)	
self	.	_pk	=	pk	
self	.	_fk	=	kw	.	get	(	"str"	,	"str"	)	
self	.	_incrkey	=	kw	.	get	(	"str"	,	"str"	)	
self	.	_incrvalue	=	kw	.	get	(	"str"	,	0	)	
self	.	_timeout	=	timeout	

def	insert	(	self	)	:	

if	self	.	_incrkey	and	not	self	.	get	(	"str"	)	:	
self	.	_incrvalue	=	util	.	GetTableIncrValue	(	self	.	_name	)	
MemObject	.	insert	(	self	)	

def	load	(	self	)	:	

mmname	=	self	.	_name	
recordlist	=	util	.	ReadDataFromDB	(	mmname	)	
for	record	in	recordlist	:	
pk	=	record	[	self	.	_pk	]	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	record	)	
mm	.	insert	(	)	

@property	
def	madmininfo	(	self	)	:	

keys	=	self	.	__dict__	.	keys	(	)	
info	=	self	.	get_multi	(	keys	)	
return	info	

def	getAllPkByFk	(	self	,	fk	)	:	

name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
pklist	=	fkmm	.	get	(	"str"	)	
if	pklist	is	not	None	:	
return	pklist	
props	=	{	self	.	_fk	:	fk	}	
dbkeylist	=	util	.	getAllPkByFkInDB	(	self	.	_name	,	self	.	_pk	,	props	)	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	,	pklist	=	dbkeylist	)	
fkmm	.	insert	(	)	
return	dbkeylist	

def	getObj	(	self	,	pk	)	:	

mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	)	
if	not	mm	.	IsEffective	(	)	:	
return	None	
if	mm	.	get	(	"str"	)	:	
return	mm	
props	=	{	self	.	_pk	:	pk	}	
record	=	util	.	GetOneRecordInfo	(	self	.	_name	,	props	)	
if	not	record	:	
return	None	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	record	)	
mm	.	insert	(	)	
return	mm	

def	getObjData	(	self	,	pk	)	:	

mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	)	
if	not	mm	.	IsEffective	(	)	:	
return	None	
data	=	mm	.	get	(	"str"	)	
if	mm	.	get	(	"str"	)	:	
return	data	
props	=	{	self	.	_pk	:	pk	}	
record	=	util	.	GetOneRecordInfo	(	self	.	_name	,	props	)	
if	not	record	:	
return	None	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	record	)	
mm	.	insert	(	)	
return	record	


def	getObjList	(	self	,	pklist	)	:	

_pklist	=	[	]	
objlist	=	[	]	
for	pk	in	pklist	:	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	)	
if	not	mm	.	IsEffective	(	)	:	
continue	
if	mm	.	get	(	"str"	)	:	
objlist	.	append	(	mm	)	
else	:	
_pklist	.	append	(	pk	)	
if	_pklist	:	
recordlist	=	util	.	GetRecordList	(	self	.	_name	,	self	.	_pk	,	_pklist	)	
for	record	in	recordlist	:	
pk	=	record	[	self	.	_pk	]	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	record	)	
mm	.	insert	(	)	
objlist	.	append	(	mm	)	
return	objlist	

def	deleteMode	(	self	,	pk	)	:	

mm	=	self	.	getObj	(	pk	)	
if	mm	:	
if	self	.	_fk	:	
data	=	mm	.	get	(	"str"	)	
if	data	:	
fk	=	data	.	get	(	self	.	_fk	,	0	)	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
pklist	=	fkmm	.	get	(	"str"	)	
if	pklist	and	pk	in	pklist	:	
pklist	.	remove	(	pk	)	
fkmm	.	update	(	"str"	,	pklist	)	
mm	.	delete	(	)	
return	True	

def	checkAll	(	self	)	:	

key	=	"str"	%	(	mclient	.	_hostname	,	self	.	_name	)	
_pklist	=	util	.	getallkeys	(	key	,	mclient	.	connection	)	
for	pk	in	_pklist	:	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	)	
if	not	mm	.	IsEffective	(	)	:	
mm	.	mdelete	(	)	
continue	
if	not	mm	.	get	(	"str"	)	:	
continue	
mm	.	checkSync	(	timeout	=	self	.	_timeout	)	
self	.	deleteAllFk	(	)	

def	deleteAllFk	(	self	)	:	

key	=	"str"	%	(	mclient	.	_hostname	,	self	.	_name	)	
_fklist	=	util	.	getallkeys	(	key	,	mclient	.	connection	)	
for	fk	in	_fklist	:	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
fkmm	.	mdelete	(	)	

def	new	(	self	,	data	)	:	

incrkey	=	self	.	_incrkey	
if	incrkey	:	
incrvalue	=	self	.	incr	(	"str"	,	1	)	
data	[	incrkey	]	=	incrvalue	-	1	
pk	=	data	.	get	(	self	.	_pk	)	
if	pk	is	None	:	
raise	PKValueError	(	data	)	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	data	)	
setattr	(	mm	,	incrkey	,	pk	)	
else	:	
pk	=	data	.	get	(	self	.	_pk	)	
mm	=	MMode	(	self	.	_name	+	"str"	%	pk	,	self	.	_pk	,	data	=	data	)	
if	self	.	_fk	:	
fk	=	data	.	get	(	self	.	_fk	,	0	)	
name	=	"str"	%	(	self	.	_name	,	fk	)	
fkmm	=	MFKMode	(	name	)	
pklist	=	fkmm	.	get	(	"str"	)	
if	pklist	is	None	:	
pklist	=	self	.	getAllPkByFk	(	fk	)	
pklist	.	append	(	pk	)	
fkmm	.	update	(	"str"	,	pklist	)	
setattr	(	mm	,	"str"	,	MMODE_STATE_NEW	)	
mm	.	insert	(	)	
return	mm	

	