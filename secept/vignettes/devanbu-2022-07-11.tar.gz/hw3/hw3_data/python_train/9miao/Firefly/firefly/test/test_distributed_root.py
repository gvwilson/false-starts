

from	firefly	.	utils	import	services	
from	firefly	.	distributed	.	root	import	PBRoot	,	BilateralFactory	
from	twisted	.	internet	import	reactor	
from	twisted	.	python	import	log	
import	sys	
reactor	=	reactor	
log	.	startLogging	(	sys	.	stdout	)	

root	=	PBRoot	(	)	
ser	=	services	.	Service	(	"str"	)	
root	.	addServiceChannel	(	ser	)	


def	serviceHandle	(	target	)	:	

ser	.	mapTarget	(	target	)	

@serviceHandle	
def	printData1	(	data	,	data1	)	:	
print	data	,	data1	
print	"str"	

return	data	

@serviceHandle	
def	printData2	(	data	,	data1	)	:	
print	data	,	data1	
print	"str"	

return	data	

if	__name__	==	"str"	:	
reactor	.	listenTCP	(	1000	,	BilateralFactory	(	root	)	)	
reactor	.	callLater	(	5	,	root	.	callChildByName	,	"str"	,	"str"	,	"str"	)	
reactor	.	run	(	)	
	