

import	subprocess	,	json	,	sys	
from	twisted	.	internet	import	reactor	
from	firefly	.	utils	import	services	
from	firefly	.	distributed	.	root	import	PBRoot	,	BilateralFactory	
from	firefly	.	server	.	globalobject	import	GlobalObject	
from	twisted	.	web	import	vhost	
from	firefly	.	web	.	delayrequest	import	DelaySite	
from	twisted	.	python	import	log	
from	firefly	.	server	.	logobj	import	loogoo	

reactor	=	reactor	

MULTI_SERVER_MODE	=	1	
SINGLE_SERVER_MODE	=	2	
MASTER_SERVER_MODE	=	3	



class	Master	:	


def	__init__	(	self	)	:	

self	.	configpath	=	None	
self	.	mainpath	=	None	
self	.	root	=	None	
self	.	webroot	=	None	

def	config	(	self	,	configpath	,	mainpath	)	:	

self	.	configpath	=	configpath	
self	.	mainpath	=	mainpath	

def	masterapp	(	self	)	:	

config	=	json	.	load	(	open	(	self	.	configpath	,	"str"	)	)	
GlobalObject	(	)	.	json_config	=	config	
mastercnf	=	config	.	get	(	"str"	)	
rootport	=	mastercnf	.	get	(	"str"	)	
webport	=	mastercnf	.	get	(	"str"	)	
masterlog	=	mastercnf	.	get	(	"str"	)	
self	.	root	=	PBRoot	(	)	
rootservice	=	services	.	Service	(	"str"	)	
self	.	root	.	addServiceChannel	(	rootservice	)	
self	.	webroot	=	vhost	.	NameVirtualHost	(	)	
self	.	webroot	.	addHost	(	"str"	,	"str"	)	
GlobalObject	(	)	.	root	=	self	.	root	
GlobalObject	(	)	.	webroot	=	self	.	webroot	
if	masterlog	:	
log	.	addObserver	(	loogoo	(	masterlog	)	)	
log	.	startLogging	(	sys	.	stdout	)	
import	webapp	
import	rootapp	
reactor	.	listenTCP	(	webport	,	DelaySite	(	self	.	webroot	)	)	
reactor	.	listenTCP	(	rootport	,	BilateralFactory	(	self	.	root	)	)	

def	start	(	self	)	:	

sys_args	=	sys	.	argv	
if	len	(	sys_args	)	>	2	and	sys_args	[	1	]	==	"str"	:	
server_name	=	sys_args	[	2	]	
if	server_name	==	"str"	:	
mode	=	MASTER_SERVER_MODE	
else	:	
mode	=	SINGLE_SERVER_MODE	
else	:	
mode	=	MULTI_SERVER_MODE	
server_name	=	"str"	

if	mode	==	MULTI_SERVER_MODE	:	
self	.	masterapp	(	)	
config	=	json	.	load	(	open	(	self	.	configpath	,	"str"	)	)	
sersconf	=	config	.	get	(	"str"	)	
for	sername	in	sersconf	.	keys	(	)	:	
cmds	=	"str"	%	(	self	.	mainpath	,	sername	,	self	.	configpath	)	
subprocess	.	Popen	(	cmds	,	shell	=	True	)	
reactor	.	run	(	)	
elif	mode	==	SINGLE_SERVER_MODE	:	
config	=	json	.	load	(	open	(	self	.	configpath	,	"str"	)	)	
sername	=	server_name	
cmds	=	"str"	%	(	self	.	mainpath	,	sername	,	self	.	configpath	)	
subprocess	.	Popen	(	cmds	,	shell	=	True	)	
else	:	
self	.	masterapp	(	)	
reactor	.	run	(	)	


	