


class	MemObject	:	


def	__init__	(	self	,	name	,	mc	)	:	

self	.	_client	=	mc	
self	.	_name	=	name	
self	.	_lock	=	0	

def	produceKey	(	self	,	keyname	)	:	

if	isinstance	(	keyname	,	basestring	)	:	
return	"str"	.	join	(	[	self	.	_name	,	"str"	,	keyname	]	)	
else	:	
raise	"str"	

def	locked	(	self	)	:	

key	=	self	.	produceKey	(	"str"	)	
return	self	.	_client	.	get	(	key	)	

def	lock	(	self	)	:	

key	=	self	.	produceKey	(	"str"	)	
self	.	_client	.	set	(	key	,	1	)	

def	release	(	self	)	:	

key	=	self	.	produceKey	(	"str"	)	
self	.	_client	.	set	(	key	,	0	)	

def	get	(	self	,	key	)	:	

key	=	self	.	produceKey	(	key	)	
return	self	.	_client	.	get	(	key	)	

def	get_multi	(	self	,	keys	)	:	

keynamelist	=	[	self	.	produceKey	(	keyname	)	for	keyname	in	keys	]	
olddict	=	self	.	_client	.	get_multi	(	keynamelist	)	
newdict	=	dict	(	zip	(	[	keyname	.	split	(	"str"	)	[	-	1	]	for	keyname	in	olddict	.	keys	(	)	]	,	
olddict	.	values	(	)	)	)	
return	newdict	

def	update	(	self	,	key	,	values	)	:	

if	self	.	locked	(	)	:	
return	False	
key	=	self	.	produceKey	(	key	)	
return	self	.	_client	.	set	(	key	,	values	)	

def	update_multi	(	self	,	mapping	)	:	

if	self	.	locked	(	)	:	
return	False	
newmapping	=	dict	(	zip	(	[	self	.	produceKey	(	keyname	)	for	keyname	in	mapping	.	keys	(	)	]	,	
mapping	.	values	(	)	)	)	
return	self	.	_client	.	set_multi	(	newmapping	)	

def	mdelete	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
del	nowdict	[	"str"	]	
keys	=	nowdict	.	keys	(	)	
keys	=	[	self	.	produceKey	(	key	)	for	key	in	keys	]	
self	.	_client	.	delete_multi	(	keys	)	

def	incr	(	self	,	key	,	delta	)	:	

key	=	self	.	produceKey	(	key	)	
return	self	.	_client	.	incr	(	key	,	delta	)	

def	insert	(	self	)	:	

nowdict	=	dict	(	self	.	__dict__	)	
del	nowdict	[	"str"	]	
newmapping	=	dict	(	zip	(	[	self	.	produceKey	(	keyname	)	for	keyname	in	nowdict	.	keys	(	)	]	,	
nowdict	.	values	(	)	)	)	
self	.	_client	.	set_multi	(	newmapping	)	




	