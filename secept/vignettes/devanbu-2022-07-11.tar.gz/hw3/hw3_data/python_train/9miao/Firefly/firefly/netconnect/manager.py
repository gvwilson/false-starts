


from	twisted	.	python	import	log	
from	connection	import	Connection	

class	ConnectionManager	:	


def	__init__	(	self	)	:	

self	.	_connections	=	{	}	

def	getNowConnCnt	(	self	)	:	

return	len	(	self	.	_connections	.	items	(	)	)	

def	addConnection	(	self	,	conn	)	:	

_conn	=	Connection	(	conn	)	
if	self	.	_connections	.	has_key	(	_conn	.	id	)	:	
raise	Exception	(	"str"	)	
self	.	_connections	[	_conn	.	id	]	=	_conn	

def	dropConnectionByID	(	self	,	connID	)	:	

try	:	
del	self	.	_connections	[	connID	]	
except	Exception	as	e	:	
log	.	msg	(	str	(	e	)	)	

def	getConnectionByID	(	self	,	connID	)	:	

return	self	.	_connections	.	get	(	connID	,	None	)	

def	loseConnection	(	self	,	connID	)	:	

conn	=	self	.	getConnectionByID	(	connID	)	
if	conn	:	
conn	.	loseConnection	(	)	

def	pushObject	(	self	,	topicID	,	msg	,	sendList	)	:	

for	target	in	sendList	:	
try	:	
conn	=	self	.	getConnectionByID	(	target	)	
if	conn	:	
conn	.	safeToWriteData	(	topicID	,	msg	)	
except	Exception	,	e	:	
log	.	err	(	str	(	e	)	)	
	