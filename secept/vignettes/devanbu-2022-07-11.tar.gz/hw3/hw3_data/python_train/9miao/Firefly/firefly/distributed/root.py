

from	twisted	.	python	import	log	
from	twisted	.	spread	import	pb	
from	manager	import	ChildsManager	
from	child	import	Child	

class	BilateralBroker	(	pb	.	Broker	)	:	

def	connectionLost	(	self	,	reason	)	:	
clientID	=	self	.	transport	.	sessionno	
log	.	msg	(	"str"	%	clientID	)	
self	.	factory	.	root	.	dropChildSessionId	(	clientID	)	
pb	.	Broker	.	connectionLost	(	self	,	reason	)	



class	BilateralFactory	(	pb	.	PBServerFactory	)	:	

protocol	=	BilateralBroker	



class	PBRoot	(	pb	.	Root	)	:	


def	__init__	(	self	,	dnsmanager	=	ChildsManager	(	)	)	:	

self	.	service	=	None	
self	.	childsmanager	=	dnsmanager	

def	addServiceChannel	(	self	,	service	)	:	

self	.	service	=	service	

def	remote_takeProxy	(	self	,	name	,	transport	)	:	

log	.	msg	(	"str"	%	name	)	
child	=	Child	(	name	,	name	)	
self	.	childsmanager	.	addChild	(	child	)	
child	.	setTransport	(	transport	)	
self	.	doChildConnect	(	name	,	transport	)	

def	doChildConnect	(	self	,	name	,	transport	)	:	

pass	

def	remote_callTarget	(	self	,	command	,	*	args	,	*	*	kw	)	:	

data	=	self	.	service	.	callTarget	(	command	,	*	args	,	*	*	kw	)	
return	data	

def	dropChild	(	self	,	*	args	,	*	*	kw	)	:	

self	.	childsmanager	.	dropChild	(	*	args	,	*	*	kw	)	

def	dropChildByID	(	self	,	childId	)	:	

self	.	doChildLostConnect	(	childId	)	
self	.	childsmanager	.	dropChildByID	(	childId	)	

def	dropChildSessionId	(	self	,	session_id	)	:	

child	=	self	.	childsmanager	.	getChildBYSessionId	(	session_id	)	
if	not	child	:	
return	
child_id	=	child	.	_id	
self	.	doChildLostConnect	(	child_id	)	
self	.	childsmanager	.	dropChildByID	(	child_id	)	

def	doChildLostConnect	(	self	,	childId	)	:	

pass	

def	callChild	(	self	,	key	,	*	args	,	*	*	kw	)	:	

return	self	.	childsmanager	.	callChild	(	key	,	*	args	,	*	*	kw	)	

def	callChildByName	(	self	,	childname	,	*	args	,	*	*	kw	)	:	

return	self	.	childsmanager	.	callChildByName	(	childname	,	*	args	,	*	*	kw	)	

	