

from	twisted	.	python	import	log	

from	zope	.	interface	import	Interface	
from	zope	.	interface	import	implements	

class	_ChildsManager	(	Interface	)	:	


def	__init__	(	self	)	:	


def	getChildById	(	self	,	childId	)	:	


def	getChildByName	(	self	,	childname	)	:	


def	addChild	(	self	,	child	)	:	


def	dropChild	(	self	,	*	arg	,	*	*	kw	)	:	


def	callChild	(	self	,	*	args	,	*	*	kw	)	:	


def	callChildByName	(	self	,	*	args	,	*	*	kw	)	:	


def	dropChildByID	(	self	,	childId	)	:	


def	dropChildSessionId	(	self	,	session_id	)	:	


class	ChildsManager	(	object	)	:	


implements	(	_ChildsManager	)	

def	__init__	(	self	)	:	

self	.	_childs	=	{	}	

def	getChildById	(	self	,	childId	)	:	

return	self	.	_childs	.	get	(	childId	)	

def	getChildByName	(	self	,	childname	)	:	

for	key	,	child	in	self	.	_childs	.	items	(	)	:	
if	child	.	getName	(	)	==	childname	:	
return	self	.	_childs	[	key	]	
return	None	

def	addChild	(	self	,	child	)	:	

key	=	child	.	_id	
if	self	.	_childs	.	has_key	(	key	)	:	
raise	"str"	%	key	
self	.	_childs	[	key	]	=	child	

def	dropChild	(	self	,	child	)	:	

key	=	child	.	_id	
try	:	
del	self	.	_childs	[	key	]	
except	Exception	,	e	:	
log	.	msg	(	str	(	e	)	)	

def	dropChildByID	(	self	,	childId	)	:	

try	:	
del	self	.	_childs	[	childId	]	
except	Exception	,	e	:	
log	.	msg	(	str	(	e	)	)	

def	callChild	(	self	,	childId	,	*	args	,	*	*	kw	)	:	

child	=	self	.	_childs	.	get	(	childId	,	None	)	
if	not	child	:	
log	.	err	(	"str"	%	childId	)	
return	
return	child	.	callbackChild	(	*	args	,	*	*	kw	)	

def	callChildByName	(	self	,	childname	,	*	args	,	*	*	kw	)	:	

child	=	self	.	getChildByName	(	childname	)	
if	not	child	:	
log	.	err	(	"str"	%	childname	)	
return	
return	child	.	callbackChild	(	*	args	,	*	*	kw	)	

def	getChildBYSessionId	(	self	,	session_id	)	:	

for	child	in	self	.	_childs	.	values	(	)	:	
if	child	.	_transport	.	broker	.	transport	.	sessionno	==	session_id	:	
return	child	
return	None	


	