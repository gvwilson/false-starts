

from	twisted	.	web	.	server	import	Request	,	Site	
from	twisted	.	internet	import	defer	
from	twisted	.	web	import	http	,	html	
from	twisted	.	python	import	log	,	reflect	
from	twisted	.	web	import	resource	
from	twisted	.	web	.	error	import	UnsupportedMethod	
from	twisted	.	web	.	microdom	import	escape	

import	string	,	types	

NOT_DONE_YET	=	1	


date_time_string	=	http	.	datetimeToString	
string_date_time	=	http	.	stringToDatetime	


supportedMethods	=	(	"str"	,	"str"	,	"str"	)	


class	DelayRequest	(	Request	)	:	

def	__init__	(	self	,	*	args	,	*	*	kw	)	:	
Request	.	__init__	(	self	,	*	args	,	*	*	kw	)	

def	render	(	self	,	resrc	)	:	

try	:	
body	=	resrc	.	render	(	self	)	
except	UnsupportedMethod	,	e	:	
allowedMethods	=	e	.	allowedMethods	
if	(	self	.	method	==	"str"	)	and	(	"str"	in	allowedMethods	)	:	




log	.	msg	(	"str"	%	
(	resrc	,	)	)	
self	.	method	=	"str"	
self	.	_inFakeHead	=	True	
body	=	resrc	.	render	(	self	)	

if	body	is	NOT_DONE_YET	:	
log	.	msg	(	"str"	
"str"	%	resrc	)	

else	:	
self	.	setHeader	(	"str"	,	str	(	len	(	body	)	)	)	

self	.	_inFakeHead	=	False	
self	.	method	=	"str"	
self	.	write	(	"str"	)	
self	.	finish	(	)	
return	

if	self	.	method	in	(	supportedMethods	)	:	


self	.	setHeader	(	"str"	,	"str"	.	join	(	allowedMethods	)	)	
s	=	(	"str"	

%	{	
"str"	:	escape	(	self	.	uri	)	,	
"str"	:	self	.	method	,	
"str"	:	(	(	len	(	allowedMethods	)	>	1	)	and	"str"	)	or	"str"	,	
"str"	:	string	.	join	(	allowedMethods	,	"str"	)	
}	)	
epage	=	resource	.	ErrorPage	(	http	.	NOT_ALLOWED	,	
"str"	,	s	)	
body	=	epage	.	render	(	self	)	
else	:	
epage	=	resource	.	ErrorPage	(	
http	.	NOT_IMPLEMENTED	,	"str"	,	
"str"	%	
(	escape	(	self	.	method	)	,	)	)	
body	=	epage	.	render	(	self	)	


if	body	==	NOT_DONE_YET	:	
return	
if	not	isinstance	(	body	,	defer	.	Deferred	)	and	type	(	body	)	is	not	types	.	StringType	:	
body	=	resource	.	ErrorPage	(	
http	.	INTERNAL_SERVER_ERROR	,	
"str"	,	
"str"	+	html	.	PRE	(	reflect	.	safe_repr	(	self	)	)	+	"str"	+	
"str"	+	html	.	PRE	(	reflect	.	safe_repr	(	resrc	)	)	+	"str"	+	
"str"	+	html	.	PRE	(	reflect	.	safe_repr	(	body	)	)	)	.	render	(	self	)	

if	self	.	method	==	"str"	:	
if	len	(	body	)	>	0	:	

log	.	msg	(	"str"	
"str"	
"str"	
%	(	self	,	resrc	)	)	
self	.	setHeader	(	"str"	,	str	(	len	(	body	)	)	)	
self	.	write	(	"str"	)	
self	.	finish	(	)	
else	:	
if	isinstance	(	body	,	defer	.	Deferred	)	:	
body	.	addCallback	(	self	.	_deferwrite	)	
else	:	
self	.	setHeader	(	"str"	,	str	(	len	(	body	)	)	)	
self	.	write	(	body	)	
self	.	finish	(	)	

def	_deferwrite	(	self	,	body	)	:	

self	.	setHeader	(	"str"	,	str	(	len	(	body	)	)	)	
self	.	write	(	body	)	
self	.	finish	(	)	


class	DelaySite	(	Site	)	:	

def	__init__	(	self	,	resource	,	logPath	=	None	,	timeout	=	60	*	60	*	12	)	:	
Site	.	__init__	(	self	,	resource	,	logPath	=	logPath	,	timeout	=	timeout	)	
self	.	requestFactory	=	DelayRequest	



	