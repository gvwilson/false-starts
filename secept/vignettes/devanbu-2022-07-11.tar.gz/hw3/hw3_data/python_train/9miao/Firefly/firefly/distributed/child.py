

class	Child	(	object	)	:	


def	__init__	(	self	,	cid	,	name	)	:	

self	.	_id	=	cid	
self	.	_name	=	name	
self	.	_transport	=	None	

def	getName	(	self	)	:	

return	self	.	_name	

def	setTransport	(	self	,	transport	)	:	

self	.	_transport	=	transport	

def	callbackChild	(	self	,	*	args	,	*	*	kw	)	:	

recvdata	=	self	.	_transport	.	callRemote	(	"str"	,	*	args	,	*	*	kw	)	
return	recvdata	





	