

from	server	.	globalobject	import	GlobalObject	

def	netserviceHandle	(	target	)	:	

GlobalObject	(	)	.	netfactory	.	service	.	mapTarget	(	target	)	

@netserviceHandle	
def	echo_111	(	_conn	,	data	)	:	
return	data	
	