

from	firefly	import	management	
import	sys	

if	__name__	==	"str"	:	
args	=	sys	.	argv	
management	.	execute_commands	(	*	args	)	
	