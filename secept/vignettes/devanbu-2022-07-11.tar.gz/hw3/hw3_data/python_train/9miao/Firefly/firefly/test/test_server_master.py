

import	os	
if	os	.	name	!=	"str"	:	
from	twisted	.	internet	import	epollreactor	
epollreactor	.	install	(	)	

def	println	(	a	)	:	
print	a	

if	__name__	==	"str"	:	
from	firefly	.	master	.	master	import	Master	
master	=	Master	(	)	
master	.	config	(	"str"	,	"str"	)	
master	.	start	(	)	


	