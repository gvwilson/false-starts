

from	firefly	.	dbentrust	.	dbpool	import	dbpool	
from	firefly	.	dbentrust	.	madminanager	import	MAdminManager	
from	firefly	.	dbentrust	import	mmode	
from	firefly	.	dbentrust	.	memclient	import	mclient	
import	time	


if	__name__	==	"str"	:	









hostname	=	"str"	
username	=	"str"	
password	=	"str"	
dbname	=	"str"	
charset	=	"str"	
tablename	=	"str"	
aa	=	{	"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	3306	,	
"str"	:	"str"	}	
dbpool	.	initPool	(	*	*	aa	)	
mclient	.	connect	(	[	"str"	]	,	"str"	)	

mmanager	=	MAdminManager	(	)	
m1	=	mmode	.	MAdmin	(	"str"	,	"str"	,	incrkey	=	"str"	)	
m1	.	insert	(	)	
print	m1	.	get	(	"str"	)	
m2	=	mmode	.	MAdmin	(	"str"	,	"str"	,	incrkey	=	"str"	)	
print	m2	.	get	(	"str"	)	
	