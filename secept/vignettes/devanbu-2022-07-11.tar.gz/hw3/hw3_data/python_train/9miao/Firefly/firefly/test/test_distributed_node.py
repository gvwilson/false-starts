

from	firefly	.	utils	import	services	
from	firefly	.	distributed	.	node	import	RemoteObject	
from	twisted	.	internet	import	reactor	
from	twisted	.	python	import	util	,	log	
import	sys	

log	.	startLogging	(	sys	.	stdout	)	

reactor	=	reactor	

addr	=	(	"str"	,	1000	)	
remote	=	RemoteObject	(	"str"	)	

service	=	services	.	Service	(	"str"	,	services	.	Service	.	SINGLE_STYLE	)	
remote	.	addServiceChannel	(	service	)	


def	serviceHandle	(	target	)	:	

service	.	mapTarget	(	target	)	

@serviceHandle	
def	printOK	(	data	)	:	
print	data	
print	"str"	
return	"str"	

def	apptest	(	commandID	,	*	args	,	*	*	kw	)	:	
d	=	remote	.	callRemote	(	commandID	,	*	args	,	*	*	kw	)	
d	.	addCallback	(	lambda	a	:	util	.	println	(	a	)	)	
return	d	

def	startClient	(	)	:	
reactor	.	callLater	(	1	,	apptest	,	"str"	,	"str"	,	"str"	)	
remote	.	connect	(	addr	)	
reactor	.	run	(	)	

if	__name__	==	"str"	:	
startClient	(	)	
	