

from	gfirefly	.	utils	import	services	
from	gfirefly	.	distributed	.	node	import	RemoteObject	
from	gtwisted	.	core	import	reactor	
from	gtwisted	.	utils	import	log	
import	sys	

log	.	startLogging	(	sys	.	stdout	)	

reactor	=	reactor	

addr	=	(	"str"	,	9090	)	
remote	=	RemoteObject	(	"str"	)	

service	=	services	.	CommandService	(	"str"	)	
remote	.	addServiceChannel	(	service	)	


def	serviceHandle	(	target	)	:	

service	.	mapTarget	(	target	)	

@serviceHandle	
def	printOK_1	(	data	)	:	
print	data	
print	"str"	
return	"str"	

def	apptest	(	commandID	,	*	args	,	*	*	kw	)	:	
d	=	remote	.	callRemote	(	commandID	,	*	args	,	*	*	kw	)	
print	"str"	,	d	
return	d	

def	startClient	(	)	:	
reactor	.	callLater	(	3	,	apptest	,	"str"	,	"str"	,	"str"	)	
remote	.	connect	(	addr	)	
reactor	.	run	(	)	

if	__name__	==	"str"	:	
startClient	(	)	
	