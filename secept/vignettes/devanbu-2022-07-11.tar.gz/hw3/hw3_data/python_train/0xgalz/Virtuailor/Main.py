from	__future__	import	print_function	
import	idc	
import	idautils	
import	idaapi	

idaapi	.	require	(	"str"	)	
idaapi	.	require	(	"str"	)	
idaapi	.	require	(	"str"	)	

from	vtableAddress	import	REGISTERS	

def	get_all_functions	(	)	:	
for	func	in	idautils	.	Functions	(	)	:	
print	(	hex	(	func	)	,	idc	.	GetFunctionName	(	func	)	)	


def	get_xref_code_to_func	(	func_addr	)	:	
a	=	idautils	.	XrefsTo	(	func_addr	,	1	)	
addr	=	{	}	
for	xref	in	a	:	
frm	=	xref	.	frm	
start	=	idc	.	GetFunctionAttr	(	frm	,	idc	.	FUNCATTR_START	)	
func_name	=	idc	.	GetFunctionName	(	start	)	
addr	[	func_name	]	=	[	xref	.	iscode	,	start	]	
return	addr	


def	add_bp_to_virtual_calls	(	cur_addr	,	end	)	:	
while	cur_addr	<	end	:	
if	cur_addr	==	idc	.	BADADDR	:	
break	
elif	idc	.	GetMnem	(	cur_addr	)	==	"str"	or	idc	.	GetMnem	(	cur_addr	)	==	"str"	:	
if	True	in	[	idc	.	GetOpnd	(	cur_addr	,	0	)	.	find	(	reg	)	!=	-	1	for	reg	in	REGISTERS	]	:	
cond	,	bp_address	=	vtableAddress	.	write_vtable2file	(	cur_addr	)	
if	cond	!=	"str"	:	
bp_vtable	=	AddBP	.	add	(	bp_address	,	cond	)	
cur_addr	=	idc	.	NextHead	(	cur_addr	)	


def	set_values	(	start	,	end	)	:	
start	=	start	
end	=	end	
return	start	,	end	


if	__name__	==	"str"	:	
start_addr_range	=	idc	.	MinEA	(	)	
end_addr_range	=	idc	.	MaxEA	(	)	
oldTo	=	idaapi	.	set_script_timeout	(	0	)	

gui	=	GUI	.	VirtuailorBasicGUI	(	set_values	,	{	"str"	:	hex	(	start_addr_range	)	[	2	:	-	1	]	,	"str"	:	hex	(	end_addr_range	)	[	2	:	-	1	]	}	)	
gui	.	exec_	(	)	
if	gui	.	start_line	.	text	!=	"str"	:	
print	(	"str"	)	
add_bp_to_virtual_calls	(	int	(	gui	.	start_line	.	text	(	)	,	16	)	,	int	(	gui	.	stop_line	.	text	(	)	,	16	)	)	
print	(	"str"	)	
	