







def	get_fixed_name_for_object	(	address	,	prefix	=	"str"	)	:	

v_func_name	=	GetFunctionName	(	int	(	address	)	)	
calc_func_name	=	int	(	address	)	-	SegStart	(	int	(	address	)	)	
if	v_func_name	[	:	4	]	==	"str"	:	
v_func_name	=	prefix	+	str	(	calc_func_name	)	
elif	v_func_name	==	"str"	:	
v_func_name	=	prefix	+	str	(	calc_func_name	)	
return	v_func_name	

def	get_vtable_and_vfunc_addr	(	is_brac	,	register_vtable	,	offset	)	:	

if	is_brac	==	-	1	:	
p_vtable_addr	=	idc	.	GetRegValue	(	register_vtable	)	
pv_func_addr	=	p_vtable_addr	+	offset	
v_func_addr	=	idc	.	read_dbg_qword	(	pv_func_addr	)	
return	p_vtable_addr	,	v_func_addr	
else	:	
p_vtable_addr	=	idc	.	read_dbg_qword	(	idc	.	GetRegValue	(	register_vtable	)	)	
pv_func_addr	=	p_vtable_addr	+	offset	
v_func_addr	=	idc	.	read_dbg_qword	(	pv_func_addr	)	
return	p_vtable_addr	,	v_func_addr	

def	add_comment_to_struct_members	(	struct_id	,	vtable_func_offset	,	start_address	)	:	

cur_cmt	=	idc	.	GetMemberComment	(	struct_id	,	vtable_func_offset	,	1	)	
new_cmt	=	"str"	
if	cur_cmt	:	
if	cur_cmt	[	:	23	]	!=	"str"	:	
new_cmt	=	cur_cmt	
else	:	
new_cmt	=	cur_cmt	+	"str"	+	start_address	
else	:	
new_cmt	=	"str"	+	start_address	
succ1	=	idc	.	SetMemberComment	(	struct_id	,	vtable_func_offset	,	new_cmt	,	1	)	
return	succ1	

def	add_all_functions_to_struct	(	start_address	,	struct_id	,	p_vtable_addr	,	offset	)	:	
vtable_func_offset	=	0	
vtable_func_value	=	idc	.	read_dbg_qword	(	p_vtable_addr	)	

while	vtable_func_value	!=	0	:	
v_func_name	=	GetFunctionName	(	vtable_func_value	)	
if	v_func_name	==	"str"	:	
vtable_func_value	=	idc	.	read_dbg_qword	(	vtable_func_value	)	
v_func_name	=	GetFunctionName	(	vtable_func_value	)	
if	v_func_name	==	"str"	:	
print	"str"	,	hex	(	start_address	)	

v_func_name	=	get_fixed_name_for_object	(	int	(	vtable_func_value	)	,	"str"	)	
idaapi	.	set_name	(	vtable_func_value	,	v_func_name	,	idaapi	.	SN_FORCE	)	

succ	=	idc	.	add_struc_member	(	struct_id	,	v_func_name	,	vtable_func_offset	,	FF_QWRD	,	-	1	,	8	)	
if	offset	==	vtable_func_offset	:	
add_comment_to_struct_members	(	struct_id	,	vtable_func_offset	,	start_address	)	
vtable_func_offset	+	=	8	
vtable_func_value	=	idc	.	read_dbg_qword	(	p_vtable_addr	+	vtable_func_offset	)	


def	create_vtable_struct	(	start_address	,	vtable_name	,	p_vtable_addr	,	offset	)	:	
struct_name	=	vtable_name	+	"str"	
struct_id	=	add_struc	(	-	1	,	struct_name	,	0	)	
if	struct_id	!=	idc	.	BADADDR	:	
add_all_functions_to_struct	(	start_address	,	struct_id	,	p_vtable_addr	,	offset	)	
idc	.	OpStroff	(	idautils	.	DecodeInstruction	(	int	(	idc	.	GetRegValue	(	"str"	)	)	)	,	1	,	struct_id	)	
else	:	
struct_id	=	idc	.	GetStrucIdByName	(	struct_name	)	

if	struct_id	!=	idc	.	BADADDR	:	
idc	.	OpStroff	(	idautils	.	DecodeInstruction	(	int	(	idc	.	GetRegValue	(	"str"	)	)	)	,	1	,	struct_id	)	
else	:	
print	"str"	+	struct_name	

def	do_logic	(	virtual_call_addr	,	register_vtable	,	offset	)	:	

is_brac_assign	=	idc	.	GetOpnd	(	int	(	idc	.	GetRegValue	(	"str"	)	)	,	1	)	.	find	(	"str"	)	


call_addr	=	int	(	virtual_call_addr	)	+	idc	.	SegStart	(	int	(	idc	.	GetRegValue	(	"str"	)	)	)	
is_brac_call	=	idc	.	GetOpnd	(	call_addr	,	0	)	.	find	(	"str"	)	
is_brac	=	-	1	
if	is_brac_assign	!=	-	1	and	is_brac_call	!=	-	1	:	
is_brac	=	0	

p_vtable_addr	,	v_func_addr	=	get_vtable_and_vfunc_addr	(	is_brac	,	register_vtable	,	offset	)	

v_func_name	=	get_fixed_name_for_object	(	v_func_addr	,	"str"	)	
idaapi	.	set_name	(	v_func_addr	,	v_func_name	,	idaapi	.	SN_FORCE	)	

vtable_name	=	get_fixed_name_for_object	(	p_vtable_addr	,	"str"	)	
idaapi	.	set_name	(	p_vtable_addr	,	vtable_name	,	idaapi	.	SN_FORCE	)	

idc	.	add_cref	(	int	(	idc	.	GetRegValue	(	"str"	)	)	,	v_func_addr	,	idc	.	XREF_USER	)	

create_vtable_struct	(	int	(	virtual_call_addr	)	,	vtable_name	,	p_vtable_addr	,	offset	)	

virtual_call_addr	=	str	(	<<	<	start_addr	>>	>	)	

register_vtable	=	"str"	
offset	=	<<	<	offset	>>	>	
if	offset	==	"str"	:	
opnd2	=	idc	.	GetOpnd	(	virtual_call_addr	,	1	)	
reg_offset	=	0	
place	=	opnd2	.	find	(	"str"	)	
if	place	!=	-	1	:	
sep	=	opnd2	.	find	(	"str"	)	
if	sep	!=	-	1	:	
reg_offset	=	idc	.	GetRegValue	(	opnd2	[	place	+	1	:	sep	]	)	
register	=	opnd2	[	opnd2	.	find	(	"str"	)	+	1	:	place	]	
if	reg_offset	:	
offset	=	opnd2	[	sep	+	1	:	opnd2	.	find	(	"str"	)	]	
if	offset	.	find	(	"str"	)	!=	-	1	:	
int_offset	=	int	(	offset	[	:	offset	.	find	(	"str"	)	]	,	16	)	
else	:	
int_offset	=	int	(	offset	)	
offset	=	int_offset	*	reg_offset	

else	:	
offset	=	opnd2	[	place	+	1	:	opnd2	.	find	(	"str"	)	]	
try	:	
do_logic	(	virtual_call_addr	,	register_vtable	,	offset	)	
except	:	
print	"str"	,	hex	(	idc	.	GetRegValue	(	"str"	)	)	


	