from	__future__	import	print_function	
import	idc	
import	idautils	
import	ida_frame	
import	ida_struct	
import	idaapi	
import	sys	,	os	

idaapi	.	require	(	"str"	)	

REGISTERS	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	


def	get_processor_architecture	(	)	:	
arch	=	"str"	
info	=	idaapi	.	get_inf_structure	(	)	
if	info	.	procName	==	"str"	:	
arch	=	"str"	
if	info	.	is_64bit	(	)	:	
return	arch	,	True	
elif	info	.	is_32bit	(	)	:	
return	arch	,	False	
else	:	
return	"str"	,	False	


def	get_local_var_value_64	(	loc_var_name	)	:	
frame	=	ida_frame	.	get_frame	(	idc	.	here	(	)	)	
loc_var	=	ida_struct	.	get_member_by_name	(	frame	,	loc_var_name	)	
loc_var_start	=	loc_var	.	soff	
loc_var_ea	=	loc_var_start	+	idc	.	GetRegValue	(	"str"	)	
loc_var_value	=	idc	.	read_dbg_qword	(	loc_var_ea	)	
return	loc_var_value	


def	get_arch_dct	(	)	:	
arch	,	is_64	=	get_processor_architecture	(	)	
if	arch	!=	"str"	or	(	arch	==	"str"	and	not	is_64	)	:	
dct_arch	=	{	}	
if	arch	==	"str"	:	
dct_arch	[	"str"	]	=	"str"	
dct_arch	[	"str"	]	=	"str"	
dct_arch	[	"str"	]	=	2	
if	arch	==	"str"	:	
dct_arch	[	"str"	]	=	"str"	
dct_arch	[	"str"	]	=	"str"	
dct_arch	[	"str"	]	=	1	
return	dct_arch	
else	:	
print	(	"str"	)	
return	-	1	


def	get_con2_var_or_num	(	i_cnt	,	cur_addr	)	:	

start_addr	=	idc	.	GetFunctionAttr	(	cur_addr	,	idc	.	FUNCATTR_START	)	
virt_call_addr	=	cur_addr	
cur_addr	=	idc	.	PrevHead	(	cur_addr	)	
dct_arch	=	get_arch_dct	(	)	
if	dct_arch	==	-	1	:	
return	"str"	,	"str"	,	cur_addr	

while	cur_addr	>	=	start_addr	:	
if	idc	.	GetMnem	(	cur_addr	)	[	:	3	]	==	dct_arch	[	"str"	]	and	idc	.	GetOpnd	(	cur_addr	,	0	)	==	i_cnt	:	
opnd2	=	idc	.	GetOpnd	(	cur_addr	,	1	)	
place	=	opnd2	.	find	(	dct_arch	[	"str"	]	)	
if	place	!=	-	1	:	
register	=	opnd2	[	opnd2	.	find	(	"str"	)	+	1	:	place	]	
if	opnd2	.	find	(	"str"	)	==	-	1	:	
offset	=	opnd2	[	place	+	dct_arch	[	"str"	]	:	opnd2	.	find	(	"str"	)	]	
else	:	
offset	=	"str"	
return	register	,	offset	,	cur_addr	
else	:	
offset	=	"str"	
if	opnd2	.	find	(	"str"	)	!=	-	1	:	
register	=	opnd2	[	opnd2	.	find	(	"str"	)	+	1	:	opnd2	.	find	(	"str"	)	]	
else	:	
register	=	opnd2	
return	register	,	offset	,	cur_addr	
elif	idc	.	GetMnem	(	cur_addr	)	[	:	4	]	==	"str"	:	
intr_func_name	=	idc	.	GetOpnd	(	cur_addr	,	0	)	

if	"str"	not	in	intr_func_name	:	
if	"str"	not	in	intr_func_name	:	

print	(	"str"	
"str"	%	(	virt_call_addr	,	intr_func_name	)	)	
cur_addr	=	start_addr	
cur_addr	=	idc	.	PrevHead	(	cur_addr	)	
return	"str"	,	"str"	,	cur_addr	

return	"str"	,	0	,	cur_addr	


def	get_bp_condition	(	start_addr	,	register_vtable	,	offset	)	:	
arch	,	is_64	=	get_processor_architecture	(	)	
file_name	=	"str"	
if	arch	==	"str"	:	
if	is_64	:	
file_name	=	"str"	
else	:	
file_name	=	"str"	
condition_file	=	os	.	path	.	join	(	os	.	path	.	dirname	(	os	.	path	.	abspath	(	sys	.	argv	[	0	]	)	)	,	file_name	)	
if	arch	!=	"str"	or	(	arch	==	"str"	and	not	is_64	)	:	
with	open	(	condition_file	,	"str"	)	as	f1	:	
bp_cond_text	=	f1	.	read	(	)	
bp_cond_text	=	bp_cond_text	.	replace	(	"str"	,	str	(	start_addr	)	)	
bp_cond_text	=	bp_cond_text	.	replace	(	"str"	,	register_vtable	)	
bp_cond_text	=	bp_cond_text	.	replace	(	"str"	,	offset	)	
return	bp_cond_text	
return	"str"	


def	write_vtable2file	(	start_addr	)	:	

raw_opnd	=	idc	.	GetOpnd	(	start_addr	,	0	)	
if	raw_opnd	in	REGISTERS	:	
reg	=	raw_opnd	
else	:	
for	reg	in	REGISTERS	:	
if	raw_opnd	.	find	(	reg	)	!=	-	1	:	
break	
opnd	=	get_con2_var_or_num	(	reg	,	start_addr	)	

reg_vtable	=	opnd	[	0	]	
offset	=	opnd	[	1	]	
bp_address	=	opnd	[	2	]	
set_bp	=	True	
cond	=	"str"	

try	:	


arch_dct	=	get_arch_dct	(	)	
plus_indx	=	raw_opnd	.	find	(	arch_dct	[	"str"	]	)	
if	plus_indx	!=	-	1	:	
call_offset	=	raw_opnd	[	plus_indx	+	1	:	raw_opnd	.	find	(	"str"	)	]	

if	call_offset	.	find	(	"str"	)	!=	-	1	:	
call_offset	=	int	(	call_offset	[	:	call_offset	.	find	(	"str"	)	]	,	16	)	
if	offset	.	find	(	"str"	)	!=	-	1	:	
offset	=	str	(	int	(	offset	[	:	offset	.	find	(	"str"	)	]	,	16	)	)	
elif	offset	.	find	(	"str"	)	!=	-	1	:	
offset	=	str	(	int	(	offset	[	offset	.	find	(	"str"	)	+	2	:	]	,	16	)	)	
except	ValueError	:	

set_bp	=	False	
finally	:	
if	set_bp	:	

if	reg_vtable	in	REGISTERS	:	
cond	=	get_bp_condition	(	start_addr	,	reg_vtable	,	offset	)	
return	cond	,	bp_address	
	