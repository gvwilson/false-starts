

import	os	
import	djcelery	


BASE_DIR	=	os	.	path	.	dirname	(	os	.	path	.	dirname	(	os	.	path	.	abspath	(	__file__	)	)	)	






SECRET_KEY	=	"str"	


DEBUG	=	True	

ALLOWED_HOSTS	=	[	]	




INSTALLED_APPS	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	

MIDDLEWARE_CLASSES	=	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	

ROOT_URLCONF	=	"str"	

TEMPLATES	=	[	
{	
"str"	:	"str"	,	
"str"	:	[	os	.	path	.	join	(	BASE_DIR	,	"str"	)	]	,	
"str"	:	True	,	
"str"	:	{	
"str"	:	[	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
]	,	
}	,	
}	,	
]	

WSGI_APPLICATION	=	"str"	






DATABASES	=	{	
"str"	:	{	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
"str"	:	"str"	,	
}	
}	





AUTH_PASSWORD_VALIDATORS	=	[	
{	
"str"	:	"str"	,	
}	,	
{	
"str"	:	"str"	,	
}	,	
{	
"str"	:	"str"	,	
}	,	
{	
"str"	:	"str"	,	
}	,	
]	





LANGUAGE_CODE	=	"str"	
TIME_ZONE	=	"str"	
USE_I18N	=	True	
USE_L10N	=	True	
USE_TZ	=	False	





STATIC_URL	=	"str"	

STATIC_ROOT	=	os	.	path	.	join	(	BASE_DIR	,	"str"	)	
STATICFILES_DIRS	=	[	os	.	path	.	join	(	BASE_DIR	,	"str"	)	,	BASE_DIR	]	



djcelery	.	setup_loader	(	)	
BROKER_URL	=	"str"	
CELERYBEAT_SCHEDULER	=	"str"	



CORS_ORIGIN_ALLOW_ALL	=	True	



REST_FRAMEWORK	=	{	
"str"	:	(	
"str"	,	
)	,	
"str"	:	(	
"str"	,	
)	,	
"str"	:	"str"	,	
"str"	:	10	,	

}	



EMAIL_BACKEND	=	"str"	
EMAIL_USE_TLS	=	False	
EMAIL_HOST	=	"str"	
EMAIL_PORT	=	25	
EMAIL_HOST_USER	=	"str"	
EMAIL_HOST_PASSWORD	=	"str"	
DEFAULT_FROM_EMAIL	=	"str"	
	