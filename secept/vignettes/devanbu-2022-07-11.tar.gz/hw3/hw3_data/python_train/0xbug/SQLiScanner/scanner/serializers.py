
from	rest_framework	import	serializers	
from	scanner	.	models	import	SqliScanTask	
from	scanner	.	tasks	import	SqlScanTask	


class	SqliScanTaskSerializer	(	serializers	.	HyperlinkedModelSerializer	)	:	
class	Meta	:	
model	=	SqliScanTask	
fields	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
)	

def	create	(	self	,	validated_data	)	:	

sqli	=	SqliScanTask	.	objects	.	create	(	*	*	validated_data	)	
s	=	SqlScanTask	(	sqli	)	
s	.	run	.	delay	(	s	)	
return	sqli	
	