
from	scanner	.	serializers	import	SqliScanTaskSerializer	
from	scanner	.	models	import	SqliScanTask	
from	rest_framework	import	viewsets	,	filters	
from	rest_framework	.	authentication	import	SessionAuthentication	,	BasicAuthentication	
from	django	.	shortcuts	import	render_to_response	
from	django	.	http	import	HttpResponse	
from	django	.	contrib	.	auth	.	decorators	import	login_required	
from	django	.	utils	.	decorators	import	method_decorator	
from	django	.	views	.	decorators	.	csrf	import	csrf_exempt	
from	scanner	.	tasks	import	SqlScanTask	
import	redis	
import	os	
import	json	
import	re	

class	CsrfExemptSessionAuthentication	(	SessionAuthentication	)	:	
def	enforce_csrf	(	self	,	request	)	:	
return	

@method_decorator	(	login_required	,	name	=	"str"	)	
class	SqliScanTaskViewSet	(	viewsets	.	ModelViewSet	)	:	

queryset	=	SqliScanTask	.	objects	.	all	(	)	
serializer_class	=	SqliScanTaskSerializer	
authentication_classes	=	(	CsrfExemptSessionAuthentication	,	BasicAuthentication	)	
filter_backends	=	(	filters	.	DjangoFilterBackend	,	)	
filter_fields	=	(	"str"	,	"str"	)	


@login_required	
@csrf_exempt	
def	addtaskbyhar	(	request	)	:	
if	request	.	method	==	"str"	and	str	(	request	.	FILES	[	"str"	]	)	.	split	(	"str"	)	[	-	1	]	==	"str"	:	
handle_uploaded_file	(	request	.	FILES	[	"str"	]	,	str	(	request	.	FILES	[	"str"	]	)	)	
return	HttpResponse	(	"str"	)	

return	HttpResponse	(	"str"	)	


def	handle_uploaded_file	(	file	,	filename	)	:	
if	not	os	.	path	.	exists	(	"str"	)	:	
os	.	mkdir	(	"str"	)	
with	open	(	"str"	+	filename	,	"str"	)	as	destination	:	
for	chunk	in	file	.	chunks	(	)	:	
destination	.	write	(	chunk	)	
parse_uploaded_file	(	filename	)	


def	parse_uploaded_file	(	filename	)	:	

with	open	(	"str"	+	filename	,	"str"	)	as	harf	:	
scan_url	=	[	]	
scan_url_path	=	[	]	
entries	=	json	.	loads	(	harf	.	read	(	)	)	[	"str"	]	[	"str"	]	
for	entrie	in	entries	:	
status_code	=	entrie	[	"str"	]	[	"str"	]	
scan_options	=	{	}	
scan_options	[	"str"	]	=	1	
scan_options	[	"str"	]	=	entrie	[	"str"	]	[	"str"	]	
scan_options	[	"str"	]	=	entrie	[	"str"	]	[	"str"	]	
target	=	scan_options	[	"str"	]	.	split	(	"str"	)	
target_path	=	"str"	.	join	(	target	[	3	:	]	)	
try	:	
target_path	=	target_path	.	split	(	"str"	)	[	0	]	
except	:	
pass	
if	status_code	!=	404	and	scan_options	[	"str"	]	in	[	"str"	,	"str"	]	and	entrie	[	"str"	]	[	
"str"	]	not	in	scan_url	and	target_path	not	in	scan_url_path	:	
if	"str"	in	scan_options	[	"str"	]	:	
scan_options	[	"str"	]	=	True	
if	entrie	[	"str"	]	[	"str"	]	:	
scan_options	[	"str"	]	=	"str"	.	join	(	
"str"	.	format	(	i	[	"str"	]	,	i	[	"str"	]	)	for	i	in	entrie	[	"str"	]	[	"str"	]	)	
if	entrie	[	"str"	]	[	"str"	]	:	
scan_options	[	"str"	]	=	"str"	.	join	(	
"str"	.	format	(	i	[	"str"	]	,	i	[	"str"	]	)	for	i	in	entrie	[	"str"	]	[	"str"	]	)	
for	i	in	entrie	[	"str"	]	[	"str"	]	:	
if	i	[	"str"	]	==	"str"	:	
scan_options	[	"str"	]	=	i	[	"str"	]	
if	scan_options	[	"str"	]	==	"str"	:	
scan_options	=	handle_get_request_entrie	(	entrie	,	scan_options	)	
else	:	
scan_options	=	handle_post_request_entrie	(	entrie	,	scan_options	)	
try	:	
sqli	=	SqliScanTask	.	objects	.	create	(	target_url	=	scan_options	[	"str"	]	,	scan_options	=	scan_options	)	
s	=	SqlScanTask	(	sqli	)	
s	.	run	.	delay	(	s	)	
scan_url	.	append	(	entrie	[	"str"	]	[	"str"	]	)	
scan_url_path	.	append	(	scan_url_path	)	
except	:	
pass	


def	handle_get_request_entrie	(	entrie	,	scan_options	)	:	
if	not	entrie	[	"str"	]	[	"str"	]	:	
nodes	=	scan_options	[	"str"	]	.	split	(	"str"	)	
for	node	in	nodes	:	
if	"str"	not	in	node	and	re	.	findall	(	"str"	,	node	)	:	
scan_options	[	"str"	]	=	scan_options	[	"str"	]	.	replace	(	node	,	node	+	"str"	)	
elif	"str"	in	node	and	re	.	findall	(	"str"	,	node	)	:	
scan_options	[	"str"	]	=	scan_options	[	"str"	]	.	replace	(	node	,	node	.	replace	(	"str"	,	"str"	)	)	
else	:	
pass	
return	scan_options	


def	handle_post_request_entrie	(	entrie	,	scan_options	)	:	
try	:	
scan_options	[	"str"	]	=	"str"	.	join	(	
"str"	.	format	(	i	[	"str"	]	,	i	[	"str"	]	)	for	i	in	entrie	[	"str"	]	[	"str"	]	[	"str"	]	)	
except	:	
pass	
return	scan_options	


@login_required	
@csrf_exempt	
def	taskstat	(	request	)	:	
stat_db	=	redis	.	Redis	(	host	=	"str"	,	port	=	6379	,	db	=	0	)	
if	not	stat_db	.	exists	(	"str"	)	:	
hosts	=	[	]	
for	target	in	SqliScanTask	.	objects	.	all	(	)	:	
s	=	{	"str"	:	target	.	target_host	,	"str"	:	len	(	SqliScanTask	.	objects	.	filter	(	target_host	=	target	.	target_host	)	)	}	
if	s	not	in	hosts	:	
hosts	.	append	(	s	)	
else	:	
pass	
stat_db	.	set	(	"str"	,	json	.	dumps	(	hosts	)	,	ex	=	500	)	
else	:	
pass	
data	=	stat_db	.	get	(	"str"	)	
return	HttpResponse	(	data	)	


def	index	(	request	)	:	
return	render_to_response	(	"str"	)	
	