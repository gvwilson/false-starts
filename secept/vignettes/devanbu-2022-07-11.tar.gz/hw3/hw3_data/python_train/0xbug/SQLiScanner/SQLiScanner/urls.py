
from	django	.	conf	.	urls	import	url	,	include	
from	django	.	contrib	import	admin	
from	django	.	conf	import	settings	
from	django	.	conf	.	urls	.	static	import	static	
from	rest_framework	import	routers	
from	scanner	.	views	import	*	

apirouter	=	routers	.	DefaultRouter	(	"str"	)	
apirouter	.	register	(	"str"	,	SqliScanTaskViewSet	)	

urlpatterns	=	[	
url	(	"str"	,	include	(	apirouter	.	urls	)	)	,	
url	(	"str"	,	include	(	"str"	,	namespace	=	"str"	)	)	,	
url	(	"str"	,	admin	.	site	.	urls	)	,	
url	(	"str"	,	index	)	,	
url	(	"str"	,	taskstat	)	,	
url	(	"str"	,	addtaskbyhar	)	,	
]	+	static	(	settings	.	STATIC_URL	,	document_root	=	settings	.	STATIC_ROOT	)	
	