
from	django	.	core	.	mail	import	send_mail	
from	celery	import	task	,	platforms	
import	json	
from	requests	import	*	
import	logging	

platforms	.	C_FORCE_ROOT	=	True	


class	SqlScanTask	(	object	)	:	
def	__init__	(	self	,	sqli_obj	)	:	
self	.	api_url	=	"str"	
self	.	mail_from	=	"str"	
self	.	mail_to	=	[	"str"	]	
self	.	sqli_obj	=	sqli_obj	
self	.	scan_options	=	self	.	sqli_obj	.	scan_options	
self	.	target_detail	(	)	
self	.	sqli_obj	.	target_method	=	self	.	sqli_obj	.	scan_options	[	"str"	]	
self	.	sqli_obj	.	target_url	=	self	.	sqli_obj	.	scan_options	[	"str"	]	
self	.	target_url	=	json	.	dumps	(	{	"str"	:	self	.	sqli_obj	.	scan_options	[	"str"	]	}	)	
self	.	headers	=	{	"str"	:	"str"	}	
self	.	sqli_obj	.	save	(	)	

@task	(	)	
def	start	(	self	)	:	
self	.	task_id	=	json	.	loads	(	get	(	"str"	.	format	(	self	.	api_url	)	)	.	text	)	[	"str"	]	
self	.	sqli_obj	.	task_id	=	self	.	task_id	
logging	.	info	(	json	.	dumps	(	self	.	scan_options	)	)	
res	=	json	.	loads	(	post	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	,	data	=	json	.	dumps	(	self	.	scan_options	)	,	
headers	=	self	.	headers	)	.	text	)	
if	res	[	"str"	]	:	
post	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	,	data	=	self	.	target_url	,	
headers	=	self	.	headers	)	
self	.	update	.	apply_async	(	(	self	,	)	,	countdown	=	10	)	
else	:	
self	.	delete	.	delay	(	self	)	

@task	(	)	
def	delete	(	self	)	:	
get	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	)	
self	.	sqli_obj	.	delete	(	)	

@task	(	)	
def	update	(	self	)	:	
self	.	sqli_obj	.	scan_status	=	json	.	loads	(	get	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	)	.	text	)	[	
"str"	]	
try	:	
self	.	sqli_obj	.	scan_log	=	json	.	loads	(	get	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	)	.	text	)	[	"str"	]	[	
-	1	]	
self	.	sqli_obj	.	scan_data	=	json	.	loads	(	get	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	)	.	text	)	[	"str"	]	
except	:	
pass	
if	self	.	sqli_obj	.	scan_status	!=	"str"	:	
self	.	update	.	apply_async	(	(	self	,	)	,	countdown	=	60	)	
else	:	
get	(	"str"	.	format	(	self	.	api_url	,	self	.	task_id	)	)	
self	.	sqli_obj	.	vulnerable	=	bool	(	self	.	sqli_obj	.	scan_data	)	
if	self	.	sqli_obj	.	vulnerable	:	
send_mail	(	"str"	,	
"str"	.	format	(	self	.	sqli_obj	.	target_url	,	
self	.	sqli_obj	.	scan_data	[	0	]	[	"str"	]	[	0	]	[	"str"	]	)	,	
self	.	mail_from	,	
self	.	mail_to	,	fail_silently	=	False	)	
self	.	sqli_obj	.	save	(	)	

@task	(	)	
def	balance	(	self	)	:	

self	.	tasks_num	=	json	.	loads	(	get	(	"str"	.	format	(	self	.	api_url	)	)	.	text	)	[	"str"	]	
self	.	start	.	delay	(	self	)	

def	target_detail	(	self	)	:	
target	=	self	.	scan_options	[	"str"	]	.	split	(	"str"	)	
self	.	sqli_obj	.	target_host	=	target	[	2	]	
self	.	sqli_obj	.	target_path	=	"str"	.	join	(	target	[	3	:	]	)	
try	:	
self	.	sqli_obj	.	target_param	=	self	.	sqli_obj	.	target_path	.	split	(	"str"	)	[	1	]	
self	.	sqli_obj	.	target_path	=	self	.	sqli_obj	.	target_path	.	split	(	"str"	)	[	0	]	
except	:	
self	.	sqli_obj	.	target_param	=	"str"	

@task	(	)	
def	run	(	self	,	)	:	
self	.	balance	.	delay	(	self	)	
	