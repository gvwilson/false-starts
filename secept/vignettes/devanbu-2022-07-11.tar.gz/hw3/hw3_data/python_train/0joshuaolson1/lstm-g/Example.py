import	LSTM_g	


specString	=	"str"	
for	memoryBlock	in	range	(	8	)	:	
specString	+	=	"str"	+	str	(	memoryBlock	)	+	"str"	
for	memoryBlock	in	range	(	8	)	:	
specString	+	=	"str"	+	str	(	memoryBlock	)	+	"str"	+	str	(	memoryBlock	)	+	"str"	
specString	+	=	"str"	
net	=	LSTM_g	.	LSTM_g	(	specString	)	
print	net	.	toString	(	True	)	
	