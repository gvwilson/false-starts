import	LSTM_g	,	random	
specString	=	"str"	
for	memoryBlock	in	range	(	4	)	:	
specString	+	=	"str"	+	str	(	memoryBlock	)	+	"str"	
for	memoryBlock	in	range	(	4	)	:	
specString	+	=	"str"	+	str	(	memoryBlock	)	+	"str"	+	str	(	memoryBlock	)	+	"str"	
specString	+	=	"str"	
net	=	LSTM_g	.	LSTM_g	(	specString	)	
numErrors	=	0	
for	trial	in	range	(	15000	)	:	
inputs	=	[	random	.	randint	(	0	,	1	)	,	random	.	randint	(	0	,	1	)	,	1	]	
targets	=	[	inputs	[	0	]	^	inputs	[	1	]	]	
outputs	=	net	.	step	(	inputs	,	True	)	
if	targets	[	0	]	!=	round	(	outputs	[	0	]	)	:	
numErrors	+	=	1	
net	.	learn	(	targets	,	.	1	)	
if	trial	>	0	and	trial	%	100	==	0	:	
print	float	(	numErrors	)	/	trial	



	