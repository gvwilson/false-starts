

import	math	,	random	,	os	
class	LSTM_g	:	




def	actFunc	(	self	,	s	,	derivative	,	bias	=	0	)	:	
value	=	1	/	(	1	+	math	.	exp	(	-	s	-	bias	)	)	
if	derivative	:	
value	*	=	1	-	value	
return	value	


def	gain	(	self	,	j	,	i	)	:	


if	(	j	,	i	)	in	self	.	gater	:	
return	self	.	activation	[	self	.	gater	[	j	,	i	]	]	

if	(	j	,	i	)	in	self	.	weight	:	
return	1	
return	0	


def	theTerm	(	self	,	j	,	k	)	:	
term	=	0	
if	(	k	,	k	)	in	self	.	gater	and	j	==	self	.	gater	[	k	,	k	]	:	
term	=	self	.	oldState	[	k	]	



for	l	,	a	in	self	.	gater	:	
if	l	==	k	and	a	!=	k	and	j	==	self	.	gater	[	k	,	a	]	:	
term	+	=	self	.	weight	[	k	,	a	]	*	self	.	oldActivation	[	k	,	a	]	
return	term	


def	clear	(	self	)	:	
for	j	,	i	in	self	.	weight	:	


if	j	!=	i	:	
self	.	state	[	j	]	=	self	.	activation	[	j	]	=	self	.	trace	[	j	,	i	]	=	0	


for	k	,	a	in	self	.	gater	:	
if	j	<	k	and	j	==	self	.	gater	[	k	,	a	]	:	
self	.	extendedTrace	[	j	,	i	,	k	]	=	0	


def	build	(	self	,	specData	)	:	


self	.	state	,	self	.	activation	,	self	.	weight	,	self	.	gater	=	{	}	,	{	}	,	{	}	,	{	}	
self	.	trace	,	self	.	extendedTrace	=	{	}	,	{	}	


self	.	numInputs	,	self	.	numOutputs	=	int	(	specData	[	0	]	[	0	]	)	,	int	(	specData	[	0	]	[	1	]	)	



newNetwork	=	True	


for	args	in	specData	[	1	:	]	:	


if	len	(	args	)	<	3	:	
newNetwork	=	False	
self	.	state	[	int	(	args	[	0	]	)	]	=	float	(	args	[	1	]	)	
self	.	activation	[	int	(	args	[	0	]	)	]	=	self	.	actFunc	(	self	.	state	[	int	(	args	[	0	]	)	]	,	False	)	


if	newNetwork	:	
self	.	weight	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	]	=	float	(	args	[	2	]	)	


if	args	[	3	]	!=	"str"	:	
self	.	gater	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	]	=	int	(	args	[	3	]	)	

elif	len	(	args	)	>	3	:	
self	.	extendedTrace	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	,	int	(	args	[	2	]	)	]	=	float	(	args	[	3	]	)	
elif	len	(	args	)	>	2	:	
self	.	trace	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	]	=	float	(	args	[	2	]	)	


if	newNetwork	:	
self	.	clear	(	)	


self	.	numUnits	=	max	(	self	.	state	)	+	1	


def	toLowLevel	(	self	,	specData	)	:	



def	addConnection	(	j	,	i	,	g	=	-	1	)	:	
specData	.	append	(	[	str	(	j	)	,	str	(	i	)	,	repr	(	random	.	uniform	(	-	.	1	,	.	1	)	)	,	str	(	g	)	]	)	


def	unitsInBlock	(	blockNum	)	:	
for	firstBlockInLayer	,	layerSize	in	layerData	:	


if	0	<	=	blockNum	-	firstBlockInLayer	<	layerSize	:	


offset	=	numInputs	+	3	*	firstBlockInLayer	+	blockNum	



return	range	(	offset	,	offset	+	4	*	layerSize	,	layerSize	)	
return	range	(	numInputs	+	4	*	blockNum	,	numInputs	+	4	*	blockNum	+	4	)	


numInputs	,	numOutputs	=	int	(	specData	[	0	]	[	0	]	)	,	int	(	specData	[	0	]	[	1	]	)	
inputToOutput	,	biasOutput	=	specData	[	0	]	[	2	]	,	int	(	specData	[	0	]	[	3	]	)	



lastInput	=	numInputs	-	biasOutput	



blockData	,	connections	,	layerData	=	[	]	,	[	]	,	[	]	
for	args	in	specData	[	1	:	]	:	
if	len	(	args	)	>	3	:	
blockData	.	append	(	[	int	(	args	[	0	]	)	,	args	[	1	]	,	args	[	2	]	,	args	[	3	]	]	)	


if	args	[	3	]	==	"str"	:	
lastInput	=	numInputs	-	1	

elif	len	(	args	)	>	2	:	
connections	.	append	(	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	,	int	(	args	[	2	]	)	]	)	
else	:	
layerData	.	append	(	[	int	(	args	[	0	]	)	,	int	(	args	[	1	]	)	]	)	


numUnits	=	numInputs	+	4	*	max	(	blockData	)	[	0	]	+	4	+	numOutputs	



specData	[	:	]	=	[	specData	[	0	]	[	:	2	]	]	


for	outputUnit	in	range	(	numUnits	-	numOutputs	,	numUnits	)	:	


if	inputToOutput	==	"str"	:	


for	inputUnit	in	range	(	lastInput	)	:	

addConnection	(	outputUnit	,	inputUnit	)	


if	biasOutput	>	0	:	
addConnection	(	outputUnit	,	lastInput	)	


for	memoryBlock	,	receiveInput	,	sendToOutput	,	biased	in	blockData	:	
inputGate	,	forgetGate	,	memoryCell	,	outputGate	=	unitsInBlock	(	memoryBlock	)	


if	receiveInput	==	"str"	:	
for	inputUnit	in	range	(	lastInput	)	:	
for	unit	in	[	inputGate	,	forgetGate	,	outputGate	]	:	
addConnection	(	unit	,	inputUnit	)	
addConnection	(	memoryCell	,	inputUnit	,	inputGate	)	


if	sendToOutput	==	"str"	:	
for	outputUnit	in	range	(	numUnits	-	numOutputs	,	numUnits	)	:	
addConnection	(	outputUnit	,	memoryCell	,	outputGate	)	


if	biased	==	"str"	:	
for	unit	in	unitsInBlock	(	memoryBlock	)	:	
addConnection	(	unit	,	lastInput	)	


specData	.	append	(	[	str	(	memoryCell	)	,	str	(	memoryCell	)	,	"str"	,	str	(	forgetGate	)	]	)	


for	toBlock	,	fromBlock	,	connectionType	in	connections	:	
toIGate	,	toFGate	,	toMCell	,	toOGate	=	unitsInBlock	(	toBlock	)	
fromIGate	,	fromFGate	,	fromMCell	,	fromOGate	=	unitsInBlock	(	fromBlock	)	


for	toUnit	in	[	toIGate	,	toFGate	,	toOGate	]	:	


if	connectionType	<	1	:	
fromOGate	=	-	1	
addConnection	(	toUnit	,	fromMCell	,	fromOGate	)	


if	connectionType	>	1	:	
addConnection	(	toMCell	,	fromMCell	,	toIGate	)	


def	__init__	(	self	,	specString	)	:	
specData	=	[	]	


for	line	in	specString	.	splitlines	(	)	:	
if	line	.	strip	(	)	!=	"str"	:	


specData	.	append	(	[	arg	.	strip	(	)	for	arg	in	line	.	split	(	"str"	)	]	)	


if	len	(	specData	[	0	]	)	>	2	:	
self	.	toLowLevel	(	specData	)	
self	.	build	(	specData	)	




def	toString	(	self	,	newNetwork	,	newline	=	os	.	linesep	)	:	
specString	=	str	(	self	.	numInputs	)	+	"str"	+	str	(	self	.	numOutputs	)	


for	(	j	,	i	)	,	w	in	sorted	(	self	.	weight	.	items	(	)	)	:	

specString	+	=	newline	+	str	(	j	)	+	"str"	+	str	(	i	)	+	"str"	+	repr	(	w	)	+	"str"	


if	(	j	,	i	)	in	self	.	gater	:	
specString	=	specString	[	:	-	2	]	+	str	(	self	.	gater	[	j	,	i	]	)	

if	not	newNetwork	:	
for	j	,	s	in	sorted	(	self	.	state	.	items	(	)	)	:	
specString	+	=	newline	+	str	(	j	)	+	"str"	+	repr	(	s	)	
for	(	j	,	i	)	,	t	in	sorted	(	self	.	trace	.	items	(	)	)	:	
specString	+	=	newline	+	str	(	j	)	+	"str"	+	str	(	i	)	+	"str"	+	repr	(	t	)	
for	(	j	,	i	,	k	)	,	e	in	sorted	(	self	.	extendedTrace	.	items	(	)	)	:	
specString	+	=	newline	+	str	(	j	)	+	"str"	+	str	(	i	)	+	"str"	+	str	(	k	)	+	"str"	+	repr	(	e	)	
return	specString	





def	step	(	self	,	inputs	,	clearValues	)	:	
if	clearValues	:	
self	.	clear	(	)	


for	j	in	range	(	self	.	numInputs	)	:	
self	.	activation	[	j	]	=	inputs	[	j	]	


self	.	oldState	,	self	.	oldActivation	,	self	.	oldGain	=	self	.	state	.	copy	(	)	,	{	}	,	{	}	


for	j	in	sorted	(	self	.	state	)	:	


self	.	oldGain	[	j	]	=	self	.	gain	(	j	,	j	)	

for	l	,	i	in	self	.	trace	:	
if	l	==	j	:	
self	.	oldGain	[	j	,	i	]	=	self	.	gain	(	j	,	i	)	


self	.	oldActivation	[	j	,	i	]	=	self	.	activation	[	i	]	


self	.	state	[	j	]	*	=	self	.	gain	(	j	,	j	)	


bias	=	0	


for	l	,	i	in	self	.	trace	:	
if	l	==	j	:	


if	(	j	,	j	)	in	self	.	weight	and	i	<	self	.	numInputs	and	(	j	,	i	)	not	in	self	.	gater	:	
bias	=	self	.	trace	[	j	,	i	]	=	self	.	activation	[	i	]	


else	:	
self	.	state	[	j	]	+	=	self	.	gain	(	j	,	i	)	*	self	.	weight	[	j	,	i	]	*	self	.	activation	[	i	]	


self	.	trace	[	j	,	i	]	*	=	self	.	oldGain	[	j	]	
self	.	trace	[	j	,	i	]	+	=	self	.	oldGain	[	j	,	i	]	*	self	.	oldActivation	[	j	,	i	]	


self	.	activation	[	j	]	=	self	.	actFunc	(	self	.	state	[	j	]	,	False	,	bias	)	


for	j	,	i	,	k	in	self	.	extendedTrace	:	
terms	=	self	.	actFunc	(	self	.	oldState	[	j	]	,	True	)	*	self	.	trace	[	j	,	i	]	*	self	.	theTerm	(	j	,	k	)	
self	.	extendedTrace	[	j	,	i	,	k	]	=	self	.	oldGain	[	k	]	*	self	.	extendedTrace	[	j	,	i	,	k	]	+	terms	


return	[	self	.	activation	[	j	]	for	j	in	range	(	self	.	numUnits	-	self	.	numOutputs	,	self	.	numUnits	)	]	


def	getError	(	self	,	targets	)	:	
error	=	0	
for	j	in	range	(	self	.	numUnits	-	self	.	numOutputs	,	self	.	numUnits	)	:	
t	,	y	=	targets	[	j	+	self	.	numOutputs	-	self	.	numUnits	]	,	self	.	activation	[	j	]	


error	+	=	t	*	math	.	log	(	y	,	2	)	+	(	1	-	t	)	*	math	.	log	(	1	-	y	,	2	)	

return	error	


def	learn	(	self	,	targets	,	learningRate	=	.	1	)	:	


errorProj	,	errorResp	=	{	}	,	{	}	


for	j	in	range	(	self	.	numUnits	-	self	.	numOutputs	,	self	.	numUnits	)	:	
errorResp	[	j	]	=	targets	[	j	+	self	.	numOutputs	-	self	.	numUnits	]	-	self	.	activation	[	j	]	


for	j	in	reversed	(	range	(	self	.	numInputs	,	self	.	numUnits	-	self	.	numOutputs	)	)	:	



errorProj	[	j	]	=	errorResp	[	j	]	=	0	


for	k	,	l	in	self	.	trace	:	
if	l	==	j	and	j	<	k	:	
errorProj	[	j	]	+	=	errorResp	[	k	]	*	self	.	oldGain	[	k	,	j	]	*	self	.	weight	[	k	,	j	]	

errorProj	[	j	]	*	=	self	.	actFunc	(	self	.	oldState	[	j	]	,	True	)	


lastK	=	0	
for	k	,	a	in	sorted	(	self	.	gater	)	:	
if	lastK	<	k	and	j	<	k	and	j	==	self	.	gater	[	k	,	a	]	:	
lastK	=	k	
errorResp	[	j	]	+	=	errorResp	[	k	]	*	self	.	theTerm	(	j	,	k	)	


errorResp	[	j	]	=	errorProj	[	j	]	+	self	.	actFunc	(	self	.	oldState	[	j	]	,	True	)	*	errorResp	[	j	]	


for	j	,	i	in	self	.	trace	:	


if	j	<	self	.	numUnits	-	self	.	numOutputs	:	


self	.	weight	[	j	,	i	]	+	=	learningRate	*	errorProj	[	j	]	*	self	.	trace	[	j	,	i	]	


for	(	l	,	m	,	k	)	,	e	in	self	.	extendedTrace	.	items	(	)	:	
if	l	==	j	and	m	==	i	:	
self	.	weight	[	j	,	i	]	+	=	learningRate	*	errorResp	[	k	]	*	e	


else	:	
self	.	weight	[	j	,	i	]	+	=	learningRate	*	errorResp	[	j	]	*	self	.	trace	[	j	,	i	]	
	