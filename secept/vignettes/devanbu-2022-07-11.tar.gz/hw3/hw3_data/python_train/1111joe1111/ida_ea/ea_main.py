from	ea_cmd	import	ea_cmd	
from	ea_emu_client	import	ea_emulate	
from	ea_heap	import	ea_heap	
from	ea_skin	import	apply_skin	,	ea_reskin	
from	ea_trace	import	ea_trace	
from	ea_utils	import	QtWidgets	,	config	
from	ea_view	import	ea_view	

if	config	[	"str"	]	:	
apply_skin	(	init	=	True	)	


menu_bar	=	next	(	i	for	i	in	QtWidgets	.	qApp	.	allWidgets	(	)	if	isinstance	(	i	,	QtWidgets	.	QMenuBar	)	)	
menu	=	menu_bar	.	addMenu	(	"str"	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_view	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_heap	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_emulate	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_trace	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_cmd	)	
menu	.	addAction	(	"str"	)	.	triggered	.	connect	(	ea_reskin	)	
	