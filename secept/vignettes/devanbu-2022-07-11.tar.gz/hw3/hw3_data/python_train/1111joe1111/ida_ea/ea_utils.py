from	idaapi	import	*	
from	idautils	import	*	
from	idc	import	*	
from	api_funcs	import	get_rg	
from	ea_UI	import	QtCore	,	QtWidgets	,	Warning_UI	
from	json	import	dump	,	load	
from	os	import	remove	
from	os	.	path	import	isfile	
from	string	import	printable	


def	read	(	file	,	mode	=	"str"	)	:	
with	open	(	file	,	mode	)	as	f	:	
return	f	.	read	(	)	


def	write	(	string	,	file	,	type	=	"str"	)	:	
with	open	(	file	,	type	)	as	f	:	
f	.	write	(	string	)	


def	cPrint	(	color	,	msg	)	:	
return	(	"str"	%	(	color	)	)	+	msg	+	"str"	


def	parse_mem	(	mem	)	:	
return	(	"str"	+	root_dir	+	"str"	)	.	join	(	mem	)	


def	get_bits	(	)	:	

global	file_name	
global	_32_bit	

new_name	=	get_root_filename	(	)	

if	new_name	!=	file_name	:	
file_name	=	new_name	


if	get_inf_structure	(	)	.	is_32bit	(	)	and	get_inf_structure	(	)	.	is_64bit	(	)	:	
_32_bit	=	(	next	(	(	False	for	i	in	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
if	get_rg	(	i	)	!=	0xffffffffffffffff	)	,	True	)	and	
next	(	(	False	for	i	in	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
if	get_rg	(	i	)	>	0xffffffff	)	,	True	)	)	
else	:	
_32_bit	=	get_inf_structure	(	)	.	is_32bit	(	)	

return	_32_bit	


def	get_mem_recursive	(	mem	,	matches	,	prev_mem	=	False	,	get_perm	=	True	,	int_size	=	4	)	:	

global	iterations	

mem_str	=	hex	(	mem	)	[	2	:	]	.	strip	(	"str"	)	.	zfill	(	int_size	*	2	)	

if	get_perm	:	
try	:	
perm	=	bin	(	GetSegmentAttr	(	mem	,	SEGATTR_PERM	)	)	[	2	:	]	.	zfill	(	3	)	
if	"str"	in	perm	:	
perm	=	"str"	+	"str"	.	join	(	sym	if	int	(	v	)	else	"str"	for	v	,	sym	in	zip	(	perm	,	(	"str"	,	"str"	,	"str"	)	)	)	+	"str"	
else	:	
perm	=	"str"	
except	:	
perm	=	"str"	
else	:	
perm	=	"str"	

offset	=	None	

if	codeSegment	and	codeStart	<	mem	<	codeEnd	:	
offset	=	GetFuncOffset	(	mem	)	
if	offset	:	
text	=	cPrint	(	"str"	,	"str"	+	mem_str	)	+	cPrint	(	"str"	,	"str"	+	offset	+	"str"	)	
code	=	True	

if	not	offset	:	
if	perm	or	not	get_perm	:	
text	=	cPrint	(	"str"	,	"str"	+	mem_str	)	
elif	next	(	(	False	for	i	in	mem_str	if	i	!=	"str"	)	,	True	)	:	
text	=	cPrint	(	"str"	,	"str"	+	mem_str	)	
else	:	
text	=	"str"	+	mem_str	

if	next	(	(	False	for	i	in	reversed	(	mem_str	.	decode	(	"str"	)	)	if	i	not	in	printable	)	,	True	)	and	prev_mem	:	
r_mem	=	dbg_read_memory	(	prev_mem	,	50	)	
if	r_mem	:	
text	+	=	"str"	+	cPrint	(	"str"	,	"str"	+	r_mem	.	split	(	"str"	)	[	0	]	.	replace	(	"str"	,	"str"	)	+	"str"	)	+	"str"	

code	=	False	

matches	.	append	(	text	)	

if	not	code	and	iterations	<	max_iterations	:	
iterations	+	=	1	
next_mem	=	dbg_read_memory	(	mem	,	int_size	)	

if	next_mem	:	
get_mem_recursive	(	int	(	"str"	.	join	(	reversed	(	next_mem	)	)	.	encode	(	"str"	)	,	16	)	,	matches	,	mem	,	int_size	=	int_size	)	

iterations	=	0	


def	ea_warning	(	text	,	buttons	=	(	(	"str"	,	None	,	True	)	,	)	,	checkboxes	=	[	]	,	title	=	"str"	)	:	

global	warning	
global	form	

warning	=	QtWidgets	.	QFrame	(	)	
form	=	Warning_UI	(	)	
form	.	setupUi	(	warning	)	
form	.	label	.	setText	(	text	)	

for	button	,	handler	,	close_on_click	in	buttons	:	
setattr	(	form	,	button	,	QtWidgets	.	QPushButton	(	warning	)	)	
getattr	(	form	,	button	)	.	clicked	.	connect	(	handler	if	handler	else	warning	.	close	)	
getattr	(	form	,	button	)	.	setText	(	QtWidgets	.	QApplication	.	translate	(	"str"	,	button	,	None	)	)	

if	close_on_click	:	
getattr	(	form	,	button	)	.	clicked	.	connect	(	warning	.	close	)	

form	.	horizontalLayout	.	addWidget	(	getattr	(	form	,	button	)	)	

for	checkbox	,	handler	,	checked	in	checkboxes	:	
setattr	(	form	,	checkbox	,	QtWidgets	.	QCheckBox	(	warning	)	)	
getattr	(	form	,	checkbox	)	.	stateChanged	.	connect	(	handler	)	
getattr	(	form	,	checkbox	)	.	setText	(	QtWidgets	.	QApplication	.	translate	(	"str"	,	checkbox	,	None	)	)	
getattr	(	form	,	checkbox	)	.	setChecked	(	checked	)	
form	.	horizontalLayout_2	.	addWidget	(	getattr	(	form	,	checkbox	)	)	

warning	.	setWindowFlags	(	warning	.	windowFlags	(	)	|	QtCore	.	Qt	.	WindowStaysOnTopHint	)	
warning	.	setWindowTitle	(	QtWidgets	.	QApplication	.	translate	(	"str"	,	title	,	None	)	)	
warning	.	show	(	)	


def	set_style	(	)	:	

global	style	

s	=	QtCore	.	QSettings	(	)	
s	.	beginGroup	(	"str"	)	
s	.	beginGroup	(	"str"	)	
font_name	=	s	.	value	(	"str"	)	

style	[	0	]	=	str	(	
(	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	
"str"	%	(	
(	config	[	"str"	]	[	0	]	if	config	[	"str"	]	else	config	[	"str"	]	[	9	]	)	,	
"str"	,	
config	[	"str"	]	[	11	]	,	
config	[	"str"	]	[	10	]	,	
config	[	"str"	]	[	12	]	,	
config	[	"str"	]	[	13	]	)	
)	
)	


def	save_config	(	)	:	

with	open	(	root_dir	+	"str"	,	"str"	)	as	w	:	
dump	(	config	,	w	)	


def	load_config	(	)	:	

global	config	

init_config	=	{	
"str"	:	[	0	,	0	,	0	,	0	]	,	
"str"	:	"str"	,	
"str"	:	25	,	
"str"	:	True	,	
"str"	:	True	,	
"str"	:	True	,	
"str"	:	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
"str"	:	[	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	,	
[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	]	
}	

if	not	isfile	(	root_dir	+	"str"	)	:	
config	=	init_config	

else	:	
try	:	
with	open	(	root_dir	+	"str"	,	"str"	)	as	f	:	
config	=	load	(	f	)	
except	:	
print	"str"	
remove	(	root_dir	+	"str"	)	
load_config	(	)	
return	

for	i	,	v	in	init_config	.	items	(	)	:	
if	i	not	in	config	:	
config	[	i	]	=	v	

if	len	(	config	[	"str"	]	)	==	9	:	

new_settings	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	
config	[	"str"	]	+	=	new_settings	
for	i	in	config	[	"str"	]	:	
i	+	=	new_settings	


if	len	(	config	[	"str"	]	)	!=	14	:	
config	[	"str"	]	=	init_config	[	"str"	]	
print	"str"	

for	i	in	config	[	"str"	]	[	:	]	:	
if	len	(	i	)	!=	15	:	
config	[	"str"	]	.	remove	(	i	)	
print	"str"	%	i	[	0	]	

skin_names	=	[	a	[	0	]	for	a	in	init_config	[	"str"	]	]	
if	i	[	0	]	in	skin_names	:	
config	[	"str"	]	.	append	(	init_config	[	"str"	]	[	skin_names	.	index	(	i	[	0	]	)	]	)	
print	"str"	%	i	[	0	]	

for	k	in	init_config	:	
if	type	(	config	[	k	]	)	!=	type	(	init_config	[	k	]	)	:	
config	[	k	]	=	init_config	[	k	]	
print	"str"	%	k	

save_config	(	)	



def	a_sync	(	func	,	ThreadClass	=	QtCore	.	QThread	)	:	





thread_idx	=	next	(	(	i	for	i	,	v	in	enumerate	(	threads	)	if	not	v	.	isRunning	(	)	)	,	False	)	
thread	=	ThreadClass	(	)	

if	thread_idx	is	not	False	:	
threads	[	thread_idx	]	=	thread	
else	:	
threads	.	append	(	thread	)	

thread	.	run	=	func	
thread	.	start	(	)	


max_iterations	=	10	
iterations	=	0	

codeSegment	=	get_segm_by_name	(	"str"	)	

if	codeSegment	:	
codeStart	=	codeSegment	.	startEA	
codeEnd	=	codeSegment	.	endEA	

file_name	=	None	
_32_bit	=	None	
root_dir	=	__file__	[	:	max	(	__file__	.	rfind	(	"str"	)	,	__file__	.	rfind	(	"str"	)	,	0	)	]	+	"str"	
warning	=	None	
config	=	None	
threads	=	[	]	
style	=	[	"str"	]	

load_config	(	)	
set_style	(	)	
	