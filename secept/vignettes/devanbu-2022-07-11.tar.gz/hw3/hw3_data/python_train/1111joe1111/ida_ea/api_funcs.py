from	idaapi	import	*	
from	idautils	import	*	
from	idc	import	*	


def	add_bp	(	addr	,	flags	=	9	,	type	=	4	,	size	=	0	)	:	
add_bpt	(	addr	,	size	,	type	)	
bp	=	bpt_t	(	)	
get_bpt	(	addr	,	bp	)	
bp	.	flags	=	flags	
bp	.	type	=	type	
bp	.	size	=	size	
update_bpt	(	bp	)	
return	bp	


def	get_bp	(	addr	,	ret_flags	=	True	)	:	
bp	=	bpt_t	(	)	
get_bpt	(	addr	,	bp	)	
return	bp	.	flags	if	ret_flags	else	bp	


def	set_trace	(	start	,	end	)	:	
add_bp	(	start	,	104	)	
add_bp	(	end	,	72	)	


def	runDebugger	(	file	,	args	=	None	)	:	
if	not	args	:	
StartDebugger	(	file	,	file	,	file	[	:	max	(	file	.	rfind	(	"str"	)	,	file	.	rfind	(	"str"	)	)	]	)	
else	:	
StartDebugger	(	file	,	"str"	.	join	(	[	file	]	+	args	)	,	file	[	:	max	(	file	.	rfind	(	"str"	)	,	file	.	rfind	(	"str"	)	)	]	)	


def	get_rg	(	reg	)	:	
get_reg_val	(	reg	,	reg_mem	)	
return	reg_mem	.	ival	


def	set_rg	(	reg	,	val	)	:	
reg_mem	.	ival	=	val	
set_reg_val	(	reg	,	reg_mem	)	


def	set_grp_flags	(	name	,	flag	,	type	=	4	,	size	=	0	)	:	
a	=	bpt_vec_t	(	)	
get_grp_bpts	(	a	,	name	)	

for	bp	in	a	:	
add_bp	(	bp	.	ea	,	flag	,	type	,	size	)	


def	add_grp	(	name	,	l	,	flags	=	9	,	type	=	4	,	size	=	0	)	:	
for	i	in	l	:	
set_bpt_group	(	add_bp	(	i	,	flags	,	type	,	size	)	,	name	)	


def	disas	(	start	,	end	)	:	

result	=	[	]	
i	=	start	
while	i	<	end	:	
result	.	append	(	(	i	,	GetDisasm	(	i	)	)	)	
i	+	=	ItemSize	(	i	)	

return	result	


def	find_ins	(	ins	,	addr	,	limit	=	1000	)	:	

for	x	in	range	(	limit	)	:	
addr	+	=	ItemSize	(	addr	)	
if	ins	in	GetDisasm	(	addr	)	:	
break	
else	:	
addr	=	0	

return	addr	


def	brk_write	(	start	,	end	,	name	=	"str"	)	:	

for	addr	,	i	in	disas	(	start	,	end	)	:	
target	=	i	.	split	(	"str"	)	[	0	]	

if	"str"	in	target	:	
set_bpt_group	(	add_bp	(	addr	)	,	name	)	


def	brk_read	(	start	,	end	,	name	=	"str"	)	:	

for	addr	,	i	in	disas	(	start	,	end	)	:	
target	=	i	.	split	(	"str"	)	

if	len	(	target	)	>	1	:	
if	"str"	in	target	[	1	]	:	
set_bpt_group	(	add_bp	(	addr	)	,	name	)	


def	traceFunc	(	filter	=	"str"	,	type	=	10	)	:	

for	func	in	Functions	(	0	,	0xffffffff	)	:	
name	=	GetFunctionName	(	func	)	

if	filter	in	name	.	lower	(	)	:	
print	name	
add_bp	(	func	,	type	)	


def	traceSeg	(	filter	=	"str"	)	:	

global	hooked	

if	not	hooked	:	
p_hooks	.	hook	(	)	

for	addr	in	Segments	(	)	:	
name	=	SegName	(	addr	)	
end	=	SegEnd	(	addr	)	

if	filter	in	name	.	lower	(	)	:	
print	name	
add_bp	(	addr	,	10	,	end	-	addr	)	


def	rd_int	(	addr	=	None	,	reg	=	None	,	size	=	4	)	:	
addr	=	get_rg	(	reg	)	if	reg	else	addr	
a	=	dbg_read_memory	(	addr	,	size	)	
return	int	(	"str"	.	join	(	reversed	(	list	(	a	)	)	)	.	encode	(	"str"	)	,	16	)	if	a	else	0	


def	nop	(	ea	)	:	
for	x	in	range	(	ItemSize	(	ea	)	)	:	
patch_byte	(	ea	+	x	,	0x90	)	


regs	=	[	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	]	

reg_mem	=	regval_t	(	)	
	