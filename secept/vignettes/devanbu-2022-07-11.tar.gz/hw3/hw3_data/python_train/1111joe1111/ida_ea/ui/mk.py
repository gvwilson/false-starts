from	pysideuic	import	compileUi	


with	open	(	"str"	,	"str"	)	as	r	:	
with	open	(	"str"	,	"str"	)	as	w	:	
compileUi	(	r	,	w	)	

quit	(	)	
	