from	re	import	search	
from	subprocess	import	PIPE	,	Popen	,	call	,	check_output	
from	sys	import	maxsize	
from	time	import	sleep	


with	open	(	"str"	,	"str"	)	as	w	:	
w	.	write	(	"str"	)	

if	not	maxsize	>	2	*	*	32	:	
print	"str"	


def	get_offsets	(	bits	)	:	

try	:	
call	(	"str"	%	bits	,	shell	=	True	,	stderr	=	PIPE	)	

except	:	
if	bits	==	32	:	
print	(	"str"	
"str"	
"str"	
"str"	)	
else	:	
print	(	"str"	
"str"	)	
return	


p	=	Popen	(	"str"	,	shell	=	True	,	stdin	=	PIPE	,	stdout	=	PIPE	)	

sleep	(	0.5	)	
p	.	stdin	.	write	(	"str"	)	
sleep	(	0.5	)	

p	.	stdin	.	write	(	
"str"	
"str"	
"str"	
)	

main_arena	,	malloc	=	[	int	(	i	,	16	)	for	i	in	check_output	(	"str"	+	"str"	+	search	(	"str"	,	p	.	stdout	.	read	(	)	)	.	group	(	1	)	+	
"str"	,	shell	=	True	)	.	split	(	"str"	)	if	i	]	

print	"str"	%	bits	
print	"str"	+	hex	(	main_arena	)	
print	"str"	+	hex	(	malloc	)	
print	


print	"str"	
get_offsets	(	32	)	
get_offsets	(	64	)	
	