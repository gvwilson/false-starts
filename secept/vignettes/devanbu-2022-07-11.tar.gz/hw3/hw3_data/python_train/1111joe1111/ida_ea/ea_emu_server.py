

import	socket	
import	sys	

from	cPickle	import	dumps	,	loads	
from	collections	import	OrderedDict	
from	copy	import	copy	
from	time	import	sleep	
from	traceback	import	format_tb	

try	:	
from	unicorn	import	*	
from	unicorn	.	x86_const	import	*	
found_unicorn	=	True	
except	:	
found_unicorn	=	False	

try	:	
from	capstone	import	*	
found_capstone	=	True	
except	:	
found_capstone	=	False	


def	debug	(	type	,	value	,	traceback	)	:	
print	"str"	.	join	(	format_tb	(	traceback	,	None	)	)	
print	type	
print	value	
raw_input	(	)	


def	get	(	func	,	args	)	:	
conn	.	send	(	dumps	(	(	func	,	args	)	)	)	
data	=	loads	(	conn	.	recv	(	BUFFER_SIZE	)	)	
return	data	


def	mem_to_int	(	val	)	:	
return	int	(	"str"	.	join	(	list	(	reversed	(	val	)	)	)	.	encode	(	"str"	)	,	16	)	


def	lookup_reg	(	target	,	uc	)	:	
return	uc	.	reg_read	(	reg_total	[	target	]	)	if	target	in	reg_total	else	eval	(	target	)	


def	dbg_read_memory	(	mem	,	size	)	:	
return	get	(	"str"	,	(	mem	,	size	)	)	


def	get_rg	(	rg	)	:	
return	get	(	"str"	,	(	rg	,	)	)	


def	get_mem	(	addr	,	uc	)	:	

size	=	0x1000	
rounded	=	addr	&	0xfffffffffffff000	
uc	.	mem_map	(	rounded	,	size	)	

while	True	:	
mem	=	dbg_read_memory	(	rounded	,	size	)	
size	-	=	0x10	
if	mem	:	
break	
if	not	size	:	
return	0	

mapped_mem	[	rounded	]	=	size	
uc	.	mem_write	(	rounded	,	mem	)	

return	1	


def	hook_code	(	uc	,	address	,	size	,	user_data	)	:	

global	last	
global	reg_state	

new_reg_state	=	get_state	(	uc	)	

reg_changes	=	[	(	i	,	new_reg_state	[	i	]	)	for	i	in	new_reg_state	if	new_reg_state	[	i	]	!=	reg_state	[	i	]	]	

if	last	not	in	annotations	:	
annotations	[	last	]	=	reg_changes	

reg_state	=	new_reg_state	

if	server_print	:	
if	address	in	instructions	:	
print	(	hex	(	address	)	+	"str"	+	"str"	.	join	(	instructions	[	address	]	)	)	.	ljust	(	50	)	+	"str"	.	join	(	"str"	%	(	a	,	hex	(	b	)	)	for	a	,	b	in	reg_changes	)	
elif	dbg	:	
print	"str"	%	address	

if	address	==	0	:	
uc	.	emu_stop	(	)	

last	=	address	


def	hook_err	(	uc	,	access	,	address	,	size	,	value	,	user_data	,	real	=	False	)	:	

rounded	=	address	&	0xfffffffffffff000	
size	=	0x1000	

if	access	==	UC_MEM_WRITE_UNMAPPED	:	
uc	.	mem_map	(	rounded	,	size	)	
return	True	

elif	access	==	UC_MEM_READ_UNMAPPED	:	
if	get_mem	(	address	,	uc	)	:	
return	True	

return	False	


def	get_state	(	uc	)	:	
return	{	name	:	uc	.	reg_read	(	reg	)	for	name	,	reg	in	x86_regs	.	items	(	)	if	name	!=	"str"	}	


def	emulate	(	address	=	False	,	code	=	False	,	_32_bits	=	True	)	:	

if	found_capstone	and	found_unicorn	:	

global	instructions	
global	reg_state	
global	last	
global	annotations	

annotations	=	{	}	
reg_dict	=	x86_regs	if	_32_bits	else	x64_regs	
reg_vals	=	{	r	:	get_rg	(	r	.	upper	(	)	)	for	r	in	reg_dict	}	

if	not	address	:	
address	=	reg_vals	[	"str"	if	_32_bits	else	"str"	]	
if	not	code	:	
code	=	dbg_read_memory	(	address	,	200	)	

address	=	int	(	address	)	
rounded	=	address	&	0xfffffffffffff000	
last	=	address	
md	=	Cs	(	CS_ARCH_X86	,	CS_MODE_32	if	_32_bits	else	CS_MODE_64	)	
instructions	=	OrderedDict	(	(	i	.	address	,	(	i	.	mnemonic	,	i	.	op_str	)	)	for	i	in	md	.	disasm	(	code	[	address	-	rounded	:	]	,	address	)	)	

if	dbg	:	
print	reg_vals	
print	instructions	

uc	=	Uc	(	UC_ARCH_X86	,	UC_MODE_32	if	_32_bits	else	UC_MODE_64	)	
uc	.	mem_map	(	rounded	,	0x1000	)	
uc	.	mem_write	(	rounded	,	code	)	

for	name	,	reg	in	reg_dict	.	items	(	)	:	
if	name	in	reg_vals	:	
uc	.	reg_write	(	reg	,	reg_vals	[	name	]	)	

uc	.	reg_write	(	reg_dict	[	"str"	if	_32_bits	else	"str"	]	,	address	)	
uc	.	hook_add	(	UC_HOOK_CODE	,	hook_code	)	
uc	.	hook_add	(	UC_HOOK_MEM_READ_UNMAPPED	|	UC_HOOK_MEM_WRITE_UNMAPPED	|	UC_HOOK_MEM_FETCH_UNMAPPED	,	hook_err	)	

reg_state	=	get_state	(	uc	)	

try	:	
print	"str"	
uc	.	emu_start	(	address	,	address	+	200	,	timeout	=	1000000	)	
except	UcError	as	e	:	
if	dbg	:	
print	e	

print	"str"	

return	"str"	,	annotations	

else	:	
found_neither	=	True	if	not	found_unicorn	and	not	found_capstone	else	False	
error	=	(	"str"	+	
(	"str"	if	found_neither	else	"str"	if	not	found_capstone	else	"str"	)	+	
"str"	+	(	"str"	if	found_neither	else	"str"	)	+	
"str"	)	

return	"str"	,	error	


def	server	(	)	:	

global	conn	
global	server_print	
s	=	socket	.	socket	(	socket	.	AF_INET	,	socket	.	SOCK_STREAM	)	

error	=	False	

try	:	
s	.	bind	(	(	TCP_IP	,	TCP_PORT	)	)	
except	socket	.	error	as	e	:	
error	=	True	
if	e	.	args	[	0	]	==	10048	:	


s	=	socket	.	socket	(	socket	.	AF_INET	,	socket	.	SOCK_STREAM	)	
s	.	connect	(	(	TCP_IP	,	TCP_PORT	)	)	
s	.	send	(	dumps	(	(	"str"	,	(	0	,	0	,	0	,	0	)	)	)	)	
if	s	.	recv	(	0x10	)	==	"str"	:	
print	"str"	
sleep	(	2	)	
else	:	
print	"str"	%	TCP_PORT	
raw_input	(	)	
else	:	
raise	

if	not	error	:	

s	.	listen	(	1	)	

while	True	:	
conn	,	addr	=	s	.	accept	(	)	
res	=	conn	.	recv	(	0x5000	)	
cmd	,	(	addr	,	code	,	bits	,	server_print	)	=	loads	(	res	)	

if	cmd	==	"str"	:	
conn	.	send	(	"str"	)	
conn	.	close	(	)	
elif	cmd	==	"str"	:	
conn	.	close	(	)	
break	
elif	cmd	==	"str"	:	
conn	.	send	(	dumps	(	emulate	(	addr	,	code	,	bits	)	)	)	
conn	.	close	(	)	
else	:	
print	"str"	+	cmd	
conn	.	close	(	)	

sys	.	excepthook	=	debug	
TCP_IP	=	"str"	
TCP_PORT	=	28745	
BUFFER_SIZE	=	0x5000	

annotations	=	{	}	
mapped_mem	=	{	}	
reg_state	=	None	
instructions	=	False	
conn	=	None	
registers	=	None	

x86_regs	=	dict	(	[	(	"str"	,	UC_X86_REG_EAX	)	,	(	"str"	,	UC_X86_REG_EBX	)	,	
(	"str"	,	UC_X86_REG_ECX	)	,	(	"str"	,	UC_X86_REG_EDX	)	,	
(	"str"	,	UC_X86_REG_ESI	)	,	(	"str"	,	UC_X86_REG_EDI	)	,	
(	"str"	,	UC_X86_REG_ESP	)	,	(	"str"	,	UC_X86_REG_EBP	)	,	
(	"str"	,	UC_X86_REG_EIP	)	]	)	

x64_regs	=	dict	(	[	(	"str"	,	UC_X86_REG_RAX	)	,	(	"str"	,	UC_X86_REG_RBX	)	,	
(	"str"	,	UC_X86_REG_RCX	)	,	(	"str"	,	UC_X86_REG_RDX	)	,	
(	"str"	,	UC_X86_REG_RSI	)	,	(	"str"	,	UC_X86_REG_RDI	)	,	
(	"str"	,	UC_X86_REG_RSP	)	,	(	"str"	,	UC_X86_REG_RBP	)	,	
(	"str"	,	UC_X86_REG_R8	)	,	(	"str"	,	UC_X86_REG_R9	)	,	
(	"str"	,	UC_X86_REG_R10	)	,	(	"str"	,	UC_X86_REG_R11	)	,	
(	"str"	,	UC_X86_REG_R12	)	,	(	"str"	,	UC_X86_REG_R13	)	,	
(	"str"	,	UC_X86_REG_R14	)	,	(	"str"	,	UC_X86_REG_R15	)	,	
(	"str"	,	UC_X86_REG_RIP	)	
]	)	

reg_total	=	copy	(	x64_regs	)	
reg_total	.	update	(	x86_regs	)	

dbg	=	False	
server_print	=	True	

print	"str"	

server	(	)	
	