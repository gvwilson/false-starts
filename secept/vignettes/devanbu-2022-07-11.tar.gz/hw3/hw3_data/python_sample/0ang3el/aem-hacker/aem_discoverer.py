import	itertools	
import	concurrent	.	futures	
import	sys	
import	json	
import	datetime	
import	traceback	
import	argparse	
from	threading	import	Lock	,	Semaphore	

import	requests	

requests	.	packages	.	urllib3	.	disable_warnings	(	)	

registered	=	[	]	
lock	=	Lock	(	)	
semaphore	=	None	


def	error	(	message	,	*	*	kwargs	)	:	
print	(	"str"	.	format	(	datetime	.	datetime	.	now	(	)	.	time	(	)	,	message	)	,	sys	.	stderr	)	
for	n	,	a	in	kwargs	.	items	(	)	:	
print	(	"str"	.	format	(	n	,	a	)	,	sys	.	stderr	)	

exc_type	,	exc_value	,	exc_traceback	=	sys	.	exc_info	(	)	
print	(	"str"	+	str	(	exc_type	)	,	sys	.	stderr	)	
print	(	"str"	+	str	(	exc_value	)	,	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	
traceback	.	print_tb	(	exc_traceback	,	file	=	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	


def	register	(	f	)	:	
registered	.	append	(	f	)	

return	f	


def	normalize_url	(	base_url	,	path	)	:	
if	base_url	[	-	1	]	==	"str"	and	(	path	[	0	]	==	"str"	or	path	[	0	]	==	"str"	)	:	
url	=	base_url	[	:	-	1	]	+	path	
else	:	
url	=	base_url	+	path	

return	url	


def	http_request	(	url	,	method	=	"str"	,	data	=	None	,	additional_headers	=	None	,	proxy	=	None	)	:	
headers	=	{	"str"	:	"str"	}	
if	additional_headers	:	
headers	.	update	(	additional_headers	)	

if	not	proxy	:	
proxy	=	{	}	

resp	=	requests	.	request	(	method	,	url	,	data	=	data	,	headers	=	headers	,	proxies	=	proxy	,	verify	=	False	,	timeout	=	15	,	allow_redirects	=	False	)	

return	resp	


def	preflight	(	url	,	proxy	=	None	)	:	
try	:	
http_request	(	url	,	proxy	=	proxy	)	
except	:	
return	False	
else	:	
return	True	


def	content_type	(	ct	)	:	
return	ct	.	split	(	"str"	)	[	0	]	.	lower	(	)	.	strip	(	)	


@register	
def	by_login_page	(	base_url	,	debug	,	proxy	=	None	)	:	
LOGIN_PAGE	=	"str"	
url	=	normalize_url	(	base_url	,	LOGIN_PAGE	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	and	"str"	in	resp	.	content	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	


@register	
def	by_geometrixx_page	(	base_url	,	debug	,	proxy	=	None	)	:	
GEOMETRIXX	=	"str"	
url	=	normalize_url	(	base_url	,	GEOMETRIXX	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	and	"str"	in	resp	.	content	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	


@register	
def	by_get_servlet	(	base_url	,	debug	,	proxy	=	None	)	:	
GETSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	)	
GETSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	GETSERVLET	)	

for	path	in	GETSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
return	True	

try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	[	"str"	]	
except	:	
pass	
else	:	
return	True	

try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	0	]	[	"str"	]	
except	:	
pass	
else	:	
return	True	

except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_bin_receive	(	base_url	,	debug	,	proxy	=	None	)	:	
BINRECEIVE	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
BINRECEIVE	=	list	(	p1	.	format	(	p2	)	for	p1	,	p2	in	BINRECEIVE	)	

for	path	in	BINRECEIVE	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

header	=	resp	.	headers	.	get	(	"str"	,	"str"	)	.	lower	(	)	
if	resp	.	status_code	==	401	and	(	"str"	in	header	or	"str"	in	header	or	"str"	in	header	or	"str"	in	header	or	"str"	in	header	)	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_loginstatus_servlet	(	base_url	,	debug	,	proxy	=	None	)	:	
LOGINSTATUS	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	)	
LOGINSTATUS	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	LOGINSTATUS	)	

for	path	in	LOGINSTATUS	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	and	"str"	in	resp	.	content	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_bgtest_servlet	(	base_url	,	debug	,	proxy	=	None	)	:	
TESTSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	)	
TESTSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	TESTSERVLET	)	

for	path	in	TESTSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	and	"str"	in	resp	.	content	and	"str"	in	resp	.	content	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_crx	(	base_url	,	debug	,	proxy	=	None	)	:	
CRX	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
CRX	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CRX	)	

for	path	in	CRX	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	and	(	"str"	in	resp	.	content	or	"str"	in	resp	.	content	or	
"str"	in	resp	.	content	)	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_gql_servlet	(	base_url	,	debug	,	proxy	=	None	)	:	
GQLSERVLET	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

for	path	in	GQLSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


@register	
def	by_swf	(	base_url	,	debug	,	proxy	=	None	)	:	
SWFS	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

for	path	in	SWFS	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

ct	=	content_type	(	resp	.	headers	.	get	(	"str"	,	"str"	)	)	
if	resp	.	status_code	==	200	and	ct	==	"str"	:	
return	True	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	,	url	=	url	)	

return	False	


def	check_url	(	base_url	,	debug	,	proxy	=	None	)	:	
if	not	preflight	(	base_url	,	proxy	)	:	
return	

if	any	(	method	(	base_url	,	debug	,	proxy	)	for	method	in	registered	)	:	
return	base_url	


def	handle_finding	(	future	)	:	
global	semaphore	,	lock	

semaphore	.	release	(	)	

if	future	.	done	(	)	:	
if	not	future	.	exception	(	)	:	
result	=	future	.	result	(	)	

with	lock	:	
if	result	:	
print	(	result	)	


def	parse_args	(	)	:	
parser	=	argparse	.	ArgumentParser	(	description	=	"str"	)	

parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	action	=	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	50	,	help	=	"str"	)	

return	parser	.	parse_args	(	sys	.	argv	[	1	:	]	)	


def	main	(	)	:	
global	semaphore	

args	=	parse_args	(	)	

if	args	.	proxy	:	
p	=	args	.	proxy	
proxy	=	{	"str"	:	p	,	"str"	:	p	}	
else	:	
proxy	=	{	}	

if	not	args	.	file	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

semaphore	=	Semaphore	(	args	.	workers	)	

with	concurrent	.	futures	.	ThreadPoolExecutor	(	args	.	workers	)	as	tpe	,	open	(	args	.	file	,	"str"	)	as	input	:	
while	True	:	
line	=	input	.	readline	(	)	
if	not	line	:	
break	

url	=	line	.	strip	(	)	

semaphore	.	acquire	(	)	
try	:	
future	=	tpe	.	submit	(	check_url	,	url	,	args	.	debug	,	proxy	)	
future	.	add_done_callback	(	handle_finding	)	
except	:	
semaphore	.	release	(	)	

tpe	.	shutdown	(	wait	=	True	)	


if	__name__	==	"str"	:	
main	(	)	
	