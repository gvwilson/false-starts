from	http	.	server	import	BaseHTTPRequestHandler	,	HTTPServer	

class	testHTTPServer_RequestHandler	(	BaseHTTPRequestHandler	)	:	

def	do_print	(	self	,	method	)	:	
print	(	"str"	.	format	(	method	,	self	.	path	)	)	

print	(	"str"	)	
for	name	,	value	in	sorted	(	self	.	headers	.	items	(	)	)	:	
print	(	"str"	.	format	(	name	,	value	)	)	

try	:	
print	(	"str"	+	self	.	rfile	.	read	(	int	(	self	.	headers	.	get	(	"str"	)	)	)	.	decode	(	"str"	)	)	
except	:	
pass	

def	do_POST	(	self	)	:	
self	.	do_print	(	"str"	)	

self	.	send_response	(	200	)	
self	.	end_headers	(	)	
return	

def	do_GET	(	self	)	:	
self	.	do_print	(	"str"	)	

self	.	send_response	(	200	)	

data	=	open	(	"str"	,	"str"	)	.	read	(	)	

self	.	send_header	(	"str"	,	"str"	)	
self	.	send_header	(	"str"	,	len	(	data	)	)	
self	.	end_headers	(	)	

self	.	wfile	.	write	(	data	)	
return	


def	run	(	)	:	
print	(	"str"	)	

server_address	=	(	"str"	,	80	)	
httpd	=	HTTPServer	(	server_address	,	testHTTPServer_RequestHandler	)	
print	(	"str"	)	
httpd	.	serve_forever	(	)	


if	__name__	==	"str"	:	
run	(	)	
	